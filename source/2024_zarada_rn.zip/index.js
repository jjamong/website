/**
 * @format
 */

import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';
import messaging from '@react-native-firebase/messaging';

// 앱이 백그라운드에 있을때 알림이 온 경우 처리
// aos만 동작함
messaging().setBackgroundMessageHandler(async remoteMessage => {
    if (remoteMessage) {
        const remoteMessageJSON = JSON.parse(JSON.stringify(remoteMessage));

        // 알림 내용
        const notification = remoteMessageJSON.notification || {};
        const title = notification.title || 'No title';
        const body = notification.body || 'No body';

        // 데이터
        const data = remoteMessageJSON.data || {};
        const moveUrl = data.moveUrl;

        console.log('>>>>>>>>>>>>>>>>> setBackgroundMessageHandler() : 앱이 백그라운드 상태에서 알림이 옴');
        console.log("title : " + title);
        console.log("body : " + body);
        console.log("moveUrl : " + moveUrl);
    }
});

AppRegistry.registerComponent(appName, () => App);
