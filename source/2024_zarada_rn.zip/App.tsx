import WebView from 'react-native-webview';
import Modal from 'react-native-modal';
import React, {useRef, useState, useEffect} from 'react';
import {Platform, SafeAreaView, StyleSheet, View, Text, Alert, BackHandler} from 'react-native';
import {PermissionsAndroid} from 'react-native';
import messaging from '@react-native-firebase/messaging';
import SplashScreen from 'react-native-splash-screen';
import CookieManager from "@react-native-cookies/cookies";
import AsyncStorage from '@react-native-async-storage/async-storage';

function formatDate(date: Date): string {
    const year: number = date.getFullYear();
    const month: string = String(date.getMonth() + 1).padStart(2, '0'); // 월을 2자리로 맞추기 위해 padStart 사용
    const day: string = String(date.getDate()).padStart(2, '0'); // 일을 2자리로 맞추기 위해 padStart 사용
    const hours: string = String(date.getHours()).padStart(2, '0'); // 시간을 2자리로 맞추기 위해 padStart 사용
    const minutes: string = String(date.getMinutes()).padStart(2, '0'); // 분을 2자리로 맞추기 위해 padStart 사용
    const seconds: string = String(date.getSeconds()).padStart(2, '0'); // 초를 2자리로 맞추기 위해 padStart 사용

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

export default function App() {
    const webviewRef = useRef<WebView | null>(null);
    const [canGoBack, setCanGoBack] = useState(false);
    const [platform, setPlatform] = useState('');
    const [isNiceModalVisible, setIsNiceModalVisible] = useState(false);
    const [niceUri, setNiceUri] = useState('');
    const [niceEncData, setNiceEncData] = useState('');

    async function requestAndroidPermissions() {
        if (Platform.OS === 'android' && Platform.Version >= 33) {
            const result = await PermissionsAndroid.request(
                PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
                {
                    title: '자라다',
                    message: '원할한 자라다 앱 사용을 위해 알림을 허용 해주세요.',
                    buttonPositive: 'OK',
                },
            );
        }
    }

    async function requestUserPermission() {
        await messaging().requestPermission();
        getFCMToken().then();
    }

    async function getFCMToken() {
        try {
            const msgType = "GET_FCM_TOKEN";

            await messaging().getToken().then((fcmToken) => {
                // console.log(">>>>> fcmToken : " + fcmToken);
                webviewRef.current?.postMessage(JSON.stringify({msgType, fcmToken}));
            });
        } catch (e) {
            console.log(">>>>> getFCMToken() Error : " + e);
        }
    }

    const fNice = (data: any) => {
        setNiceUri(data.formAction);
        setNiceEncData(data.encData);
        setIsNiceModalVisible(true);
    };

    const fNiceSuccess = (data: any) => {
        const msgType = "NICE_SUCCESS";
        const encodeData = data.encData;

        setIsNiceModalVisible(false);

        webviewRef.current?.postMessage(JSON.stringify({msgType, encodeData}));
    };

    const fSetAndroidCookie = () => {
        if (platform === 'android')
            CookieManager.flush();
    };

    const fMoveUrl = async () => {
        const moveUrl = await AsyncStorage.getItem('moveUrl');
        if (moveUrl !== null) {
            const msgType = "MOVE_URL";
            webviewRef.current?.postMessage(JSON.stringify({msgType, moveUrl}));
            AsyncStorage.removeItem('moveUrl');
        }
    }

    const fOnMessage = ({nativeEvent}: any) => {
        const data = JSON.parse(nativeEvent.data);
        switch (data.msgType) {
            case 'NICE':
                fNice(data);
                break;
            case 'GET_FCM_TOKEN':
                getFCMToken().then();
                break;
            case 'SET_ANDROID_COOKIE':
                fSetAndroidCookie();
                break;
            case 'WEBVIEW_ONLOAD':
                fMoveUrl();
                break;
        }
    };

    const fModalOnMessage = ({nativeEvent}: any) => {
        const data = JSON.parse(nativeEvent.data);
        switch (data.msgType) {
            case 'NICE_SUCCESS':
                fNiceSuccess(data);
                break;
        }
    };

    // useEffect - 기본
    useEffect(() => {
        setTimeout(() => {
            SplashScreen.hide();
        }, 1500);

        setPlatform(Platform.OS);
    }, []);

    // useEffect - 알림 권한 요청, FCM Token
    useEffect(() => {
        requestAndroidPermissions().then();
        requestUserPermission().then();

        const unsubscribe = messaging().onTokenRefresh(token => {
            getFCMToken().then();
        });

        return unsubscribe;
    }, []);

    // useEffect - 포그라운드 상태일때 알림 처리
    useEffect(() => {
        const unsubscribe = messaging().onMessage(async remoteMessage => {
            if (remoteMessage) {
                const remoteMessageJSON = JSON.parse(JSON.stringify(remoteMessage));

                // 알림 내용
                const notification = remoteMessageJSON.notification || {};
                const title = notification.title || 'No title';
                const body = notification.body || 'No body';

                // 데이터
                const data = remoteMessageJSON.data || {};
                const moveUrl = data.moveUrl;

                const now: Date = new Date();
                console.log('>>>>>>>>>>>>>>>>> [' + formatDate(now) + '] onMessage() : 앱이 포그라운드에 있음');
                console.log("title : " + title);
                console.log("body : " + body);
                console.log("moveUrl : " + moveUrl);

                Alert.alert(title, body);
            }
        });

        return unsubscribe;
    }, []);

    // useEffect - 백그라운드에서 알림으로 앱이 실행된 경우 처리
    // ios는 종료 상태에서 실행된 경우에도 해당 이벤트가 동작함
    useEffect(() => {
        const unsubscribe = messaging().onNotificationOpenedApp(remoteMessage => {
            if (remoteMessage) {
                const remoteMessageJSON = JSON.parse(JSON.stringify(remoteMessage));

                // 알림 내용
                const notification = remoteMessageJSON.notification || {};
                const title = notification.title || 'No title';
                const body = notification.body || 'No body';

                // 데이터
                const data = remoteMessageJSON.data || {};
                const moveUrl = data.moveUrl;

                // moveUrl이 있는 경우 웹뷰로 postMessage도 쏘고 AsyncStorage에 저장도 함
                if (moveUrl !== null) {
                    const msgType = "MOVE_URL";
                    webviewRef.current?.postMessage(JSON.stringify({msgType, moveUrl}));
                    AsyncStorage.setItem('moveUrl', moveUrl);
                }

                const now: Date = new Date();
                console.log('>>>>>>>>>>>>>>>>> [' + formatDate(now) + '] onNotificationOpenedApp() : 앱이 백그라운드 상태에서 알림을 눌러 실행됨');
                console.log('title : ' + title);
                console.log('body : ' + body);
                console.log("moveUrl : " + moveUrl);
            }
        });

        return unsubscribe;
    }, []);

    // useEffect - 종료 상태에서 알림으로 앱이 실행된 경우 처리
    // aos만 동작함
    useEffect(() => {
        messaging().getInitialNotification().then(remoteMessage => {
            if (remoteMessage) {
                const remoteMessageJSON = JSON.parse(JSON.stringify(remoteMessage));

                // 알림 내용
                const notification = remoteMessageJSON.notification || {};
                const title = notification.title || 'No title';
                const body = notification.body || 'No body';

                // 데이터
                const data = remoteMessageJSON.data || {};
                const moveUrl = data.moveUrl;

                // AsyncStorage에 이동할 URL 저장
                AsyncStorage.setItem('moveUrl', moveUrl);

                const now: Date = new Date();
                console.log('>>>>>>>>>>>>>>>>> [' + formatDate(now) + '] getInitialNotification() : 앱이 종료 상태에서 알림을 눌러 실행됨');
                console.log("title : " + title);
                console.log("body : " + body);
                console.log("moveUrl : " + moveUrl);
            }
        });
    }, []);

    // useEffect - 기기 뒤로가기 버튼 제어
    useEffect(() => {
        const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
            if (canGoBack) {
                webviewRef.current?.goBack();
            } else {
                Alert.alert("자라다", "앱을 종료하시겠습니까?", [
                    {
                        text: "취소",
                        onPress: () => null,
                        style: "cancel"
                    },
                    {text: "확인", onPress: () => BackHandler.exitApp()}
                ]);
            }
            return true;
        });

        return () => backHandler.remove();
    }, [canGoBack]);

    return (
        <SafeAreaView style={styles.container}>
            {/* Main */}
            <WebView
                ref={webviewRef}
                originWhitelist={['*']}
                source={{uri: 'http://172.16.4.132:8080'}}
                onMessage={fOnMessage}
                onNavigationStateChange={navState => setCanGoBack(navState.canGoBack)}
            />
            {/* 나이스 인증 Modal */}
            <Modal style={styles.modal} isVisible={isNiceModalVisible}>
                <View style={styles.modalHeader}>
                    <Text style={styles.modalHeaderText}>휴대폰 인증</Text>
                    <Text
                        style={styles.modalCloseText}
                        onPress={() => {
                            setIsNiceModalVisible(false);
                        }}>
                        닫기
                    </Text>
                </View>
                <WebView
                    originWhitelist={['*']}
                    source={{
                        uri: niceUri,
                        method: 'POST',
                        body: `m=checkplusService&EncodeData=${niceEncData}&recvMethodType=get`,
                        headers:
                            platform === 'ios'
                                ? {'Content-Type': 'application/x-www-form-urlencoded'}
                                : undefined,
                    }}
                    onMessage={fModalOnMessage}
                />
            </Modal>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    modal: {
        padding: 0,
        margin: 0,
    },
    modalHeader: {
        height: 50,
        backgroundColor: '#7C53DD',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalHeaderText: {
        color: '#fff',
        fontSize: 18,
    },
    modalCloseText: {
        color: '#fff',
        position: 'absolute',
        right: 30,
    },
});
