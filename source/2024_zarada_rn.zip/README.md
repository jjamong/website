# 개요

동아ST ZARADA 앱 고도화 프로젝트 Mobile (React Native)

### 세트 프로젝트

- zarada_back
- zarada_front
- zarada_rn

# 실행 - Android

1. install

    ```bash
    npm install
    ```

2. 프로젝트내 android 폴더를 Android Studio로 Open

3. Gradle Sync

    - Android Studio - `Sync Project with Gradle Files` 실행

4. start

    ```bash
    npm start
    ```

### 추가 세팅

JavaScript Alert Title이 도메인으로 표시되는 내용 수정

1. `node_modules/react-native-webview/android/src/main/java/com/reactnativecommunity/webview/RNCWebChromeClient.java` File Open

    - Android Studio로 열어서 import까지 한번에 하는것을 권장

2. 코드 추가

    ```java
    /**
     * 직접 추가 부분
     * <p>
     * .setPositiveButton() : 확인
     * .setNegativeButton() : 취소
     * .setOnCancelListener() : alert이 취소될때
     */
    @Override
    public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
       Context context = view.getContext();
       String customTitle = "자라다";
    
       new AlertDialog.Builder(context)
    		   .setTitle(customTitle)
    		   .setMessage(message)
    		   .setPositiveButton("확인", new AlertDialog.OnClickListener() {
    			   public void onClick(DialogInterface dialog, int which) {
    				   result.confirm();
    			   }
    		   })
    		   .setOnCancelListener(new DialogInterface.OnCancelListener() {
    			   public void onCancel(DialogInterface dialog) {
    				   result.cancel();
    			   }
    		   })
    		   .setCancelable(false)
    		   .create()
    		   .show();
    
       return true;
    }
    
    @Override
    public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
       Context context = view.getContext();
       String customTitle = "자라다";
    
       new AlertDialog.Builder(context)
    		   .setTitle(customTitle)
    		   .setMessage(message)
    		   .setPositiveButton("확인", new DialogInterface.OnClickListener() {
    			   public void onClick(DialogInterface dialog, int which) {
    				   result.confirm();
    			   }
    		   })
    		   .setNegativeButton("취소", new DialogInterface.OnClickListener() {
    			   public void onClick(DialogInterface dialog, int which) {
    				   result.cancel();
    			   }
    		   })
    		   .setOnCancelListener(new DialogInterface.OnCancelListener() {
    			   public void onCancel(DialogInterface dialog) {
    				   result.cancel();
    			   }
    		   })
    		   .setCancelable(false)
    		   .create()
    		   .show();
    
       return true;
    }
    
    @Override
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
       Context context = view.getContext();
       String customTitle = "자라다";
    
       final EditText input = new EditText(context);
       input.setText(defaultValue);
    
       new AlertDialog.Builder(context)
    		   .setTitle(customTitle)
    		   .setMessage(message)
    		   .setView(input)
    		   .setPositiveButton("확인", new DialogInterface.OnClickListener() {
    			   public void onClick(DialogInterface dialog, int which) {
    				   result.confirm();
    			   }
    		   })
    		   .setNegativeButton("취소", new DialogInterface.OnClickListener() {
    			   public void onClick(DialogInterface dialog, int which) {
    				   result.cancel();
    			   }
    		   })
    		   .setOnCancelListener(new DialogInterface.OnCancelListener() {
    			   public void onCancel(DialogInterface dialog) {
    				   result.cancel();
    			   }
    		   })
    		   .setCancelable(false)
    		   .create()
    		   .show();
    
       return true;
    }
    ```

# 실행 - IOS

1. 폴더 권한 수정

    1. 소스 폴더 우클릭 > 정보 가져오기 > 우측 하단의 자물쇠 클릭 > 비밀번호 입력 후 하단의 공유 및 사용 권한: 읽기 및 쓰기로 모두 변경

    2. 좌측 하단의 ... 버튼 클릭 > 하위 항목에 적용 > 자물쇠 클릭

2. install

    - ios/Podfile 의 config = use_native_modules! 아래에 코드 추가

        ```bash
        pod 'Firebase', :modular_headers => true
        pod 'FirebaseCoreInternal', :modular_headers => true
        pod 'FirebaseCore', :modular_headers => true
        pod 'FirebaseMessaging', :modular_headers => true
        pod 'GoogleUtilities', :modular_headers => true
        ```

    - 모듈 설치(yarn, pod가 맥북에 설치되어 있어야 함)

        ```bash
        npm install
        yarn install
        cd ios
        pod install
        cd ../
        ```

    - xcode 세팅(a~e의 과정은 세팅 되어 있으므로, f 과정만 필수로 진행)

        1. ios 폴더의 [프로젝트명].xcworkspace 파일 xcode로 오픈

        2. [프로젝트명]/[프로젝트명]/info 설정 추가

            + App Transport Security Settings 에 아래 항목 추가

            + Allow Arbitrary Loads - YES

            + Allow Arbitrary Loads in Web Content - YES

            + Allows Arbitrary Loads for Media - YES

        3. TARGET setting

            + 최상위 [프로젝트명] -> TARGETS 아래의 [프로젝트명] 선택 후 Signing & Capabilities 탭의 팀 DA Information. Co. Ltd 선택

            + 상단 서브 탭 All 좌측의 + Capability 클릭 후 Background Modes, Push Notifications 더블클릭으로 추가

            + Background Modes의 Background fetch, Remote notifications 체크

        4. GoogleService-Info.plist 파일 추가

            + Firebase Console에서 파일 다운로드

            + 하위[프로젝트명] 폴더 선택 후 xcode > File > Add Files to [프로젝트명] 으로 파일 추가

        5. AppDelegate.m 파일 didFinishLaunchingWithOptions 내부에 코드 추가(import는 최상단)

            ```bash
            #import <Firebase.h>
            
            [FIRApp configure];
            ```

        6. alert, confirm, prompt 한글로 변경

            + RNCWebViewImpl.m 내부의

                runJavaScriptAlertPanelWithMessage

                runJavaScriptConfirmPanelWithMessage

                runJavaScriptTextInputPanelWithPrompt

                각각의 actionWithTitle를 한글로 수정
3. start

    ```bash
    npm start
    i
    ```

    npm start로 RN 실행 이후에는 xcode의 빌드로도 실행 가능
