const fs = require("fs");

function mergeJsonFiles(src, files) {
  const originalJson = JSON.parse(fs.readFileSync(src, "utf-8"));

  if (Object.keys(originalJson.data).length == 0) originalJson.data = []; // data:{} 일 경우
  if (typeof originalJson.data == "undefined") originalJson.data = [];
  //const mergedData = [...originalJson.data];

  let mergedData = [...originalJson.data];

  const lastSeqMap = {};
  let maxChunkSeq = 0;
  for (const item of mergedData) {
    const page = item.page;
    const seq = item.chunk_seq;

    if (maxChunkSeq < seq) {
      maxChunkSeq = seq;
    }

    if (!lastSeqMap[page] || seq > lastSeqMap[page]) {
      lastSeqMap[page] = seq;
    }
  }

  const dpItems = [];
  for (const file of files) {
    const dpJson = JSON.parse(fs.readFileSync(file, "utf-8"));
    
    // 20250725 cbkim 추론결과 빈 데이터가 {} 형태로 넘어옴. {}는 패스하고 [] length > 0 인 경우만 처리되도록
    if (Array.isArray(dpJson.data)) {
      dpItems.push(...(dpJson.data || []));
    } 
  }

  dpItems.sort((a, b) => (a.page || 0) - (b.page || 0));

  for (const item of dpItems) {
    const page = item.page;
    if (!(page in lastSeqMap)) {
      lastSeqMap[page] = 0;
    }

    lastSeqMap[page] += 1;

    mergedData.push({
      ...item,
      //chunk_seq: lastSeqMap[page],
      chunk_seq: ++maxChunkSeq,
    });
  }

  // 20250722 cbkim, 원본+DP 섞여있는부분 json sorting
  mergedData = mergedData.sort((a, b) => {
    if (a.page === b.page) {
      return a.chunk_seq - b.chunk_seq;
    }
    return a.page - b.page;
  });

  // 20250722 cbkim, chunk_seq 순번대로 다시 채번
  mergedData.forEach((item, index) => {
    item.chunk_seq = index + 1;
  });

  fs.writeFileSync(src, JSON.stringify({ data: mergedData }, null, 2), "utf-8");
}

//실행예1시 mergeJsonFiles('jeff.json', ['dp_jeff.json', 'dp_jeff.json', 'dp_jeff.json']);
//mergeJsonFiles("/data/asset/iem/ieb/20250505/json/1150729101330262925.json", [  "/data/asset/iem/ieb/20250505/json/1150729101330262925_DP_1_1.json"]
module.exports = {
  mergeJsonFiles,
};
