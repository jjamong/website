const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

const LOG_ROOT = "/log/uda/asset/htmltojson";
fs.mkdirSync(LOG_ROOT, { recursive: true });

const now = new Date();
const logFileName = `htmltojson_${now
  .toISOString()
  .slice(0, 10)
  .replace(/-/g, "")}.log`;
const logFilePath = path.join(LOG_ROOT, logFileName);
fs.mkdirSync(LOG_ROOT, { recursive: true });

function logResult(inputPath, outputPath, result, errorMsg = "") {
  const timestamp = new Date().toISOString().replace("T", " ").split(".")[0];

  const inputAbs = path.resolve(inputPath);
  const inputDir = path.dirname(inputAbs);
  const inputFile = path.basename(inputAbs);

  const outputAbs = path.resolve(outputPath);
  const outputFolder = path.dirname(outputAbs);
  const outputFile = path.basename(outputAbs);

  const line = `[${timestamp}][htmltojson][${inputDir}][${inputFile}][${outputFolder}][${outputFile}][${result}]`;
  console.log(line);
  fs.appendFileSync(logFilePath, line + "\n");
  if (result === "Fail" && errorMsg) {
    fs.appendFileSync(logFilePath, `Exception: ${errorMsg}\n`);
  }
}

function extractTestToJson(inputPath, outputPath) {
  if (!fs.existsSync(inputPath)) {
    return;
  }

  const html = fs.readFileSync(inputPath, "utf-8");
  const $ = cheerio.load(html);
  $('[style*="display:none"]').remove();
  $('[style*="DISPLAY:none"]').remove();
  $('[style*="DISPLAY: none"]').remove();
  $("script, style, noscript").remove();

  let textContent = "\\r\\n";
  const seen = new Set();

  $("body").each((_, el) => {
    const text = $(el).text();
    if (text && !seen.has(text)) {
      seen.add(text);
      textContent += text.replaceAll("\n", " ") + "\\r\\n";
    }
  });

  const result = {
    data: [
      {
        page: 1,
        chunk_seq: 1,
        chunk: textContent,
      },
    ],
  };

  const outputDir = path.dirname(outputPath);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  fs.writeFileSync(outputPath, JSON.stringify(result, null, 2), "utf-8");
  const inputFile = path.resolve(inputPath);
  const outputFile = path.resolve(outputPath);
  logResult(inputFile, outputFile, "Success");
}

if (require.main === module) {
  const [, , inputPath, outputPath] = process.argv;

  const inputFile = path.resolve(inputPath);
  const outputFile = path.resolve(outputPath);

  try {
    extractTestToJson(inputPath, outputPath);
  } catch (err) {
    logResult(inputFile, null, "Fail", err.stack || err.message);
  }
}
