import time
import requests 
import os
import sys
from logger_setup import LoggerSetup

logger = LoggerSetup()

BASE_URL = 'http://172.18.120.150:10009'
INPUT_FILE = sys.argv[1]
OUTPUT_DIR = sys.argv[2]


os.makedirs(OUTPUT_DIR, exist_ok= True)
#os.makedirs('./logs', exist_ok= True)

def detect_file_type(file_path):
  with open(file_path,'rb') as f:
    header =f.read(8)

    if header.startswith(b'%PDF'):
      return 'PDF'
    elif header.startswith(b'\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1'):
      return 'HWP (OLE)'
    elif header.startswith(b'PK'):
      return 'HWPX (ZIP based)'
    else:
      return 'Unknown'

def convert_hwp_to_pdf(file_path):
  with open(file_path,'rb')as f:
    files = {'file':f}
    data = {'convertType': 'PDF'}
    response = requests.post(f'{BASE_URL}/file/upload', files=files, data=data)

    if response.status_code != 200:
      raise Exception('Upload failed:', response.text)

    file_id = response.json().get('id')
    stamp = response.json().get('stamp')

    output_filename = None

    while True:
      poll_resp = requests.get(f'{BASE_URL}/file/convert/{file_id}')
      if poll_resp is None:
        logger.log(file_path, None,"Fail", "File download failed.")
        return
       
      poll_json = poll_resp.json()

      status = poll_json.get('status')
      #print(f'Checking status: {status}')

      if status == 'S':
        break
      elif status == 'F':
        if 'PDF' == detect_file_type(file_path):
          print(f'{file_path} 확장자다름')
          break
        else:
          logger.log(file_path, None,"Fail", f"File conversion failed")
          return
      time.sleep(0.5)
    
    output_filename = os.path.splitext(os.path.basename(file_path))[0] + '.pdf'
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    download_resp = requests.get(f'{BASE_URL}/file/download/{file_id}.pdf?stamp={stamp}')
    if download_resp.status_code == 200:
      with open(output_path, 'wb') as out_file:
          out_file.write(download_resp.content)
          logger.log(file_path, output_path,"Success")
      #print(f'PDF 저장 완료: {output_path}')
    else:  
      logger.log(file_path, None,"Fail", "File download failed.")
      return

convert_hwp_to_pdf(INPUT_FILE)
