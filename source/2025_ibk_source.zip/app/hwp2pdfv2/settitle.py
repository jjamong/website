from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import io
import os
import sys
import argparse

def add_title_to_pdf(input_pdf, output_dir, content_name):
    # 출력 디렉토리가 없으면 생성
    os.makedirs(output_dir, exist_ok=True)
    
    # 출력 파일 경로 생성
    output_pdf = os.path.join(output_dir, os.path.basename(input_pdf))
    
    # 한글 폰트 등록
    font_path = "/app/hwpmergev2/NotoSansKR-Regular.ttf"
    pdfmetrics.registerFont(TTFont('NotoSansKR', font_path))

    # 기존 PDF 읽기
    reader = PdfReader(input_pdf, strict=False)
    writer = PdfWriter()

    print(len(reader.pages))


    # 첫 페이지 가져오기
    page = reader.pages[0]
    
    # 페이지 크기 확인
    page_width = float(page.mediabox.width)
    page_height = float(page.mediabox.height)

    # 텍스트를 그릴 임시 PDF 생성
    packet = io.BytesIO()
    c = canvas.Canvas(packet, pagesize=(page_width, page_height))
    c.setFont('NotoSansKR', 12)
    # 페이지 상단에서 약간 아래로 (y 좌표를 페이지 높이에서 약간 뺌)
    c.drawString(50, page_height - 20, f"**{content_name}**")
    c.save()

    # 임시 PDF를 읽어서 기존 페이지에 병합
    packet.seek(0)
    overlay = PdfReader(packet)
    page.merge_page(overlay.pages[0])
    
    # 수정된 페이지 추가
    try:
        writer.add_page(page)
    except Exception as e:
        print("수정된 페이지 추가시 실패:::::")

    # 나머지 페이지들도 추가
    for page in reader.pages[1:]:
        if page is not None:
            writer.add_page(page)

    # 결과 저장
    with open(output_pdf, "wb") as output_file:
        writer.write(output_file)
    
    #print(f"PDF가 성공적으로 생성되었습니다: {output_pdf}")

# def main():
#     parser = argparse.ArgumentParser(description='PDF 파일에 컨텐츠명을 추가합니다.')
#     parser.add_argument('input_pdf', help='입력 PDF 파일 경로')
#     parser.add_argument('output_dir', help='출력 디렉토리 경로')
#     parser.add_argument('content_name', help='추가할 컨텐츠명')
    
#     args = parser.parse_args()
    
#     add_title_to_pdf(args.input_pdf, args.output_dir, args.content_name)

# if __name__ == "__main__":
#     main()