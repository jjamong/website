import time
import requests 
import os
import sys
from logger_setup import LoggerSetup
from settitle import add_title_to_pdf
from contextlib import ExitStack

logger = LoggerSetup()

BASE_URL = 'http://172.18.120.150:10009'
INPUT_FILE = sys.argv[1]
OUTPUT_DIR = sys.argv[2]
TITLE = sys.argv[3]


os.makedirs(OUTPUT_DIR, exist_ok= True)
#os.makedirs('./logs', exist_ok= True)

def convert_hwp_to_pdf(file_path):
  with open(file_path,'rb')as f:
    files = {'file':f}
    data = {'convertType': 'PDF'}
    response = requests.post(f'{BASE_URL}/file/upload', files=files, data=data)

    if response.status_code != 200:
      raise Exception('Upload failed:', response.text)

    file_id = response.json().get('id')
    stamp = response.json().get('stamp')

    while True:
      poll_resp = requests.get(f'{BASE_URL}/file/convert/{file_id}')
      if poll_resp is None:
        logger.log(file_path, None,"Fail", "File download failed.")
        return

      poll_json = poll_resp.json()


      status = poll_json.get('status')
      #print(f'Checking status: {status}')

      if status == 'S':
        break
      elif status == 'F':
        logger.log(file_path, None,"Fail", "File conversion failed")
        return
      time.sleep(0.5)
    
    output_filename = os.path.splitext(os.path.basename(file_path))[0] + '.pdf'
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    download_resp = requests.get(f'{BASE_URL}/file/download/{file_id}.pdf?stamp={stamp}')
    if download_resp.status_code == 200:
      with open(output_path, 'wb') as out_file:
          out_file.write(download_resp.content)
          logger.log(file_path, output_path,"Success")
      
      add_title_to_pdf(output_path,OUTPUT_DIR,TITLE)
      #print(f'PDF 저장 완료: {output_path}')
    else:  
      logger.log(file_path, None,"Fail", "File download failed.")
      return

convert_hwp_to_pdf(INPUT_FILE)
