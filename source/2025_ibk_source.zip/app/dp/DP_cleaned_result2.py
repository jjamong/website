import sys
import os
import re
import json
from collections import defaultdict
from html_with_markdown import *

if len(sys.argv) !=2:
    #print("사용법: python3 DP_cleaned_result2.py [입력파일"]
    sys.exit(1)

input_file = sys.argv[1]
output_file = input_file # 덮어쓰기

def tag_filter(match):
    tag = match.group(0)
    if re.match(r"<td\b[^>]*>", tag, flags=re.IGNORECASE):
        return "<td>"
    elif re.match(r"</td\s*>", tag, flags=re.IGNORECASE):
        return "</td>"
    else:
        return ""

def extract_img_alt(text):
    match  = re.search(r'alt=\\"([^\\"]*)\\"', text, re.DOTALL)
    return match.group(1) if match else None

def replace_img_with_alt(match):
    alt_text = match.group(1)
    return '\n'.join(['', alt_text, ''])

def replace_img_tags_with_alt(text):
    pattern = r'<img[^>]*alt=\"([^"]+)\"[^>]*>'
    replace_text = re.sub(pattern, replace_img_with_alt, text)
    return replace_text

def find_html_tag_text(text):
    #regex=r"</?[a-zA-Z][a-zA-Z0-9]*[^>]*>"
    #regex=r"</?[a-zA-Z][a-zA-Z0-9]*[^>]*"
    regex=r"</?[a-zA-Z][a-zA-Z0-9]*(\s[^<>]*?)?>"
    
    matched_text = dict()
    inform_dict = dict()
    regex_comp = re.compile(regex)
    re_iter = regex_comp.finditer(text)
    for re_result in re_iter:
        print(re_result)
        inform = re_result.group()
        start = re_result.start()
        end = re_result.end()
        if inform not in inform_dict:
            inform_dict[inform] = [start, end, regex]
    
        if 1 < len(inform.split(' ')):
            key = inform.split(' ')[0]
        else:
            key = inform.rstrip('>')
    
        if '/' in key:
            flag = 'E'
            key = key.replace('/','')
        else:
            flag = 'S'
    
        if key not in matched_text:
            matched_text[key] = {'S':1, 'E':0, 'text':[inform]}
        else:
            if flag == 'S':
                matched_text[key][flag] += 1
                matched_text[key]['text'].append(inform)
            else:
                matched_text[key][flag] += 1
                matched_text[key]['text'].append(inform)
    
    tag_text_list = list()
    check_list = list()
    print(matched_text)
    for key in matched_text:
        if key not in ['<td','<br']: # ['<td','<tr','<br']
            if 'cgv' in key:
                print('#'*70)

            if 0 < matched_text[key]['S'] and matched_text[key]['S'] == matched_text[key]['E']:
                tag_text_list.extend(matched_text[key]['text'])
            
            elif key[:4] == '<img' or key[:8] == '<figure':
                for text in matched_text[key]['text']:
                    alt_text = extract_img_alt(text)
                   
                    if alt_text:
                        tag_text_list.append(alt_text)
                    if '<img alt=""' == text[:11]:
                        tag_text_list.append(text)
                    elif '<img style='== text[:11]:
                        tag_text_list.append(text)
                    elif '<img data-coord=' == text[:16]:
                        tag_text_list.append(text)
                 
            
            elif key == '<thead':
                tag_text_list.extend(matched_text[key]['text'])
            elif key == '<footer':
                tag_text_list.extend(matched_text[key]['text'])
            elif key == '<tbody':
                tag_text_list.extend(matched_text[key]['text'])
            elif key == '<table id':
                tag_text_list.extend(matched_text[key]['text'])  
            else:
                print('check_key :', key, '   | vlaue :', matched_text[key])
                print('*'*50)
                check_list.append(matched_text[key])
                
    tag_text_list = list(set(tag_text_list))
    # tag_text_list = [line for line in tag_text_list if line.strip() != '>']
    return tag_text_list

def extract_clean_html(raw_text):
    try:
        data = json.loads(raw_text)
        html = data.get("content", {}).get("html", "")
    except Exception:
        html_match = re.search(r'"html"\s*:\s*"(.+?)"', raw_text, re.DOTALL)
        html = html_match.group(1) if html_match else ""

        if not html:
            return ""

    #markdown 이후 제거
    if len(re.split(r"\",\"markdown", html)) < 2:
        html = re.split(r"\"markdown", html)[0]
    else:
        html = re.split(r"\",\"markdown", html)[0]

    html = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)

    html = html_with_markdown_tables(html)
    
    #html = re.split(r"---|markdown", html)[0]
    # html = re.split(r"\"markdown", html)[0]

    html = re.sub(r"<td\b[^>]*>", "<td>", html)

    html = re.sub(r"</td\s*>", "</td>", html)

    html = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)

    #특수문자 정리
    html = html.replace("&nbsp;", " ")
    html = re.sub(r"\\u[0-9a-fA-F]{4}", "",  html)
    #html = re.sub(r"\s{2,}", " ", html)

    html = re.sub(r"[ \t]{2,}", "", html)

    html = re.sub(r"(</table>)\n(?=<p\b[^>]*>)", r"\1\r\n", html, flags=re.IGNORECASE)

    html = replace_img_tags_with_alt(html)

    tag_text_list = find_html_tag_text(html)
    # print(tag_text_list)
    for tag_text in tag_text_list:
        # print(tag_text)
        html = html.replace(tag_text, '\n')# re.sub(tag_text, '\n', html, flags=re.IGNORECASE)
    html = html.replace("\\n", "\n")
    html = html.replace("\n", "\r\n")

    filtering_html = list()
    for h_line in html.split('\r\n'):
        if '</td>' in h_line.strip():
            if h_line.strip()[-5] != '</td>':
                above_line = '</td>'.join(h_line.split('</td>')[:-1]+[''])
                below_line = h_line.split('</td>')[-1]
                filtering_html.extend([above_line, below_line])
            else:
                filtering_html.append(h_line)
        else:
            filtering_html.append(h_line)

    # html = re.sub(r"</?tr\s*>", "\n", html, flags=re.IGNORECASE)
    html = '\r\n'.join(filtering_html)
    html = re.sub(r"</?tr\s*>", "\r\n", html, flags=re.IGNORECASE)
    ## html = [line for line in tag_text_list if '>' in line.strip()]
    html = "\n".join(line.lstrip('>') if line.strip().startswith('>') else line
                     for line in html.splitlines())
    return html.strip()


try:
    parts = os.path.basename(input_file).split('_')
    print(f"################### {len(parts)}")

    page_num = "1"    

    if len(parts) != 2:
        page_idx = parts.index("DP")
        page_num = parts[page_idx + 1]

    #파일처리
    with open(input_file,  "r", encoding="utf-8") as f:
        raw_text = f.read()
        
    cleaned_text = f"<page num='{page_num}'>\n\n{extract_clean_html(raw_text)}\n\n</page>\n\n"

    with open(output_file, "w", encoding="utf-8", newline='') as f:
        f.write(cleaned_text)
    print(f"[Success]: {input_file} DP TXT CLEAN")
except Exception:
    print(f"[Fail]: {input_file} DP TXT CLEAN")
