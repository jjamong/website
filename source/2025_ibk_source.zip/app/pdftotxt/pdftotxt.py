import os
import sys
import fitz  # PyMuPDF
from shapely.geometry import Polygon, box
import unicodedata
from collections import defaultdict
import pymupdf4llm
import traceback
# import win32com.client as win32
import psutil
from logger_setup import LoggerSetup
import re
import pypdfium2 as pdfium
from collections import Counter
import PyPDF2
import pdfplumber
import shutil
import Qnut
from personal_masking import masking_personal_text


class PDFProcessor:
    def __init__(self, input_file, output_file,masking):
        self.input_file = input_file
        self.output_file = output_file
        self.lotated_files = {}  # PDF 파일의 회전 상태를 저장하는 딕셔너리
        self.splited_files = {}  # PDF 파일의 분할할 상태를 저장하는 딕셔너리
        self.page_texts = {}  # 각 페이지별 텍스트를 저장할 딕셔너리
        self.footnote_count = defaultdict(int)  # 각주 카운트
        self.footnote_path = defaultdict(None)     # 각주 좌표
        self.masking = False

        # Logger 설정 (LoggerSetup 사용)
        self.logger = LoggerSetup()

    def process_file(self):
        filename = os.path.basename(self.input_file)
        try:
            if not os.path.exists(self.input_file) or os.path.getsize(self.input_file) == 0:
                raise ValueError("Input file does not exist or is empty.")
            
            if self.input_file.lower().endswith('.pdf'):
                #self._process_pdf(self.input_file)
                text = self.extract_text_from_pdf(self.input_file)

                if text.startswith("Error"):
                    self.logger.log(self.input_file, None, "Fail", text)
                    return

                if masking == True:
                    text, masking_count_dict = masking_personal_text(text)

                output_dir = os.path.dirname(self.output_file)
                os.makedirs(output_dir, exist_ok=True)

                # 결과를 저장
                with open(self.output_file,'w') as f: 
                    f.write(text)

                self.logger.log(self.input_file, self.output_file, "Success")
            else:
                raise ValueError("Unsupported file format.")
        except ValueError as e:
            self.logger.log(self.input_file, None, "Fail", type(e).__name__)
        except Exception as e:
            self.logger.log(self.input_file, None, "Fail", type(e).__name__)
        
    def _process_pdf(self, pdf_file):
        """ PDF 파일을 처리하는 함수 """
        # self.process_logger.info(f'Processing {pdf_file} (Thread ID: {os.getpid()})')
        
        try:
            # 파일이 비어있는지 확인
            if os.path.getsize(pdf_file) == 0:
                raise ValueError(f"File is empty: {pdf_file}")
            
            # 1. PDF 읽기
            doc = fitz.open(pdf_file)

            # 2. Rotate 체크 및 회전 처리
            rotated_file = self._check_and_rotate(doc, pdf_file)
            
            # 3. 멀티 컬럼 체크 및 분할
            if self.get_rotation_status(self._get_original_filename(rotated_file)):
                split_file = self._split_if_needed(doc, rotated_file)
            else:
                split_file = pdf_file

            # 4. 각주 체크 및 저장
            self._process_footnotes(split_file if self.get_split_status(pdf_file) else pdf_file)

            # 5. 중복 텍스트 체크
            processed_text = self._check_duplicates_and_extract_text(split_file if self.get_split_status(pdf_file) else pdf_file)

            # 6. 텍스트 저장
            self._save_text(processed_text, split_file)

        except fitz.EmptyFileError:
            # 파일이 비어있을 경우
            self.error_logger.error(f"Cannot open empty file: {pdf_file}")
        except fitz.FileDataError:
            # 파일을 열지 못하는 경우우
            self.error_logger.error(f"Failed to open file: {pdf_file}")
        except ValueError as e:
            # 빈 파일 처리
            self.error_logger.error(e)
        finally:
            doc.close()

    def is_pdf_image_based(self, doc):  
        # doc = fitz.open(pdf_file)  
        for page in doc:  
            if page.get_images():  # 이미지 객체가 있는지 확인
                return True  
        return False  

    def _get_original_filename(self, pdf_file):
        """ 회전된 파일, 분할된 파일, 회전 후 분할된 파일의 경우 원본 파일명을 추출 """
        """ _rotated와 _split을 빈값으로 바꿔서 원본 파일명을 추출 """
        # '_rotated'와 '_split'을 빈 문자열로 교체
        # cleaned_filename = pdf_file.replace('_hwp', '').replace('_rotated', '').replace('_split', '')
        cleaned_filename = pdf_file.replace('_rotated', '').replace('_split', '')
        
        return cleaned_filename

    def _check_and_rotate(self, doc, pdf_file):
        """ 회전된 PDF 확인 및 회전 처리 """
        # 회전 여부 확인 후 처리
        rotated_file = pdf_file
        rotated = self._check_and_remove_rotation(doc)  # 회전 여부 확인 및 제거

        # 회전된 상태 저장
        self.lotated_files[pdf_file] = rotated  # 회전 여부 저장

        if rotated:
            rotated_file = pdf_file.replace('.pdf', '_rotated.pdf')
            doc.save(rotated_file)  # 회전 제거 후 새로운 파일로 저장
            # self.process_logger.info(f'{pdf_file} was rotated and saved as {rotated_file}')
        return rotated_file

    def _check_and_remove_rotation(self, doc):
        """ PDF의 회전 여부를 확인하고, 회전된 경우 제거 """
        rotated = False
        for page in doc:
            if page.rotation != 0:
                page.remove_rotation()  # 회전 제거
                rotated = True
        return rotated

    def _split_if_needed(self, doc, pdf_file):
        """ 페이지 나누기 (멀티컬럼 체크) """
        # 회전된 경우 분할하고, 새로운 파일로 저장
        if self.get_rotation_status(self._get_original_filename(pdf_file)) or self.has_page_wider_than_a4(doc):  # 회전된 상태 확인
            return self._split_rotated_pdf(doc, pdf_file)
        else:
            return self._split_if_multicolumn(doc, pdf_file)

    def has_page_wider_than_a4(self, doc):
        """ PDF 내에서 A4 크기보다 큰 페이지가 있는지 절대값으로 확인 """
        # A4 사이즈 너비
        width, _ = fitz.paper_size("a4")

        # 각 페이지의 너비를 절대값으로 확인
        for spage in doc:
            if int(spage.rect.width) != int(width):  # A4 너비와 차이가 있으면  # A4 너비와 차이가 있으면
                return True  # A4 크기보다 큰 페이지가 있으면 True 반환

        return False  # A4 크기보다 큰 페이지가 없으면 False 반환
    
    def _split_rotated_pdf(self, doc, pdf_file):
        # print(pdf_file)
        """ 회전된 PDF 분할 """
        output_doc = fitz.open()  # 빈 출력 PDF 파일 생성

        split_file = pdf_file

        # A4 사이즈로 출력 페이지 설정 (세로형)
        width, height = fitz.paper_size("a4")
        r = fitz.Rect(0, 0, width, height)

        # 페이지를 순차적으로 분할
        for spage in doc:
            # spage.rect.width와 A4의 width를 절대값으로 비교
            if abs(spage.rect.width - width) > 20:  # A4 width와 차이가 있으면 분할
                paths = spage.get_drawings()  # 경로 정보 추출

                # 가장 큰 Y값을 가진 경로 찾기
                max_y_path = self._find_max_y_path(paths)      

                # 페이지 내 이미지 정보 가져오기
                images = spage.get_images(full=True)
                image_area = 0

                for img in images:
                    x0, y0, x1, y1 = img[0:4]  # 이미지 좌표 정보 추출 (left, top, right, bottom)
                    image_width = x1 - x0
                    image_height = y1 - y0
                    image_area += image_width * image_height

                page_area = spage.rect.width * spage.rect.height

                if image_area / page_area >= 0.8:  # 이미지가 페이지 면적의 80% 이상 차지하면
                    num_pages = 1  # 1페이지 그대로 유지
                elif max_y_path:
                    path_width = max_y_path['rect'][2] - max_y_path['rect'][0]  # 경로의 가로 길이 계산
                    if path_width >= spage.rect.width * 0.8:  # 페이지 width의 80% 이상인지 확인
                        num_pages = 1  # 1페이지 그대로 유지
                    else:
                        num_pages = 2  # 2페이지로 나누기
                else:
                    num_pages = 2  # 2페이지로 나누기
            else:
                num_pages = 1  # 그렇지 않으면 1페이지 그대로

            for i in range(num_pages):
                # 새 페이지 추가 (A4 사이즈로)
                page = output_doc.new_page(-1, width=width, height=height)
                    
                # 각 페이지를 두 부분으로 나누기
                if num_pages == 2:
                    x0 = i * spage.rect.width / 2  # 좌측 또는 우측
                    x1 = x0 + spage.rect.width / 2
                    src_rect_part = fitz.Rect(x0, 0, x1, spage.rect.height)
                else:
                    # 분할하지 않고 전체 영역을 그대로 복사
                    src_rect_part = fitz.Rect(0, 0, spage.rect.width, spage.rect.height)

                # 나눠진 부분을 출력 페이지에 복사
                page.show_pdf_page(
                    r,  # 출력 사각형 영역
                    doc,  # 입력 PDF
                    spage.number,  # 입력 페이지 번호
                    clip=src_rect_part,  # 자른 영역
                )

                # 텍스트가 없다면 페이지 삭제
                text = page.get_text("text")
                if not text.strip() and num_pages == 2 :  # 빈 텍스트가 있으면
                    output_doc.delete_page(page.number)

        if output_doc.page_count > 0:
            if doc.page_count < output_doc.page_count:
                # 분할 상태 저장
                self.splited_files[self._get_original_filename(pdf_file)] = True  # 분할 여부 저장

                # 분할된 파일 저장
                split_file = pdf_file.replace('.pdf', '_split.pdf')
                output_doc.save(split_file)
                # self.process_logger.info(f'Split file saved as {split_file}')

        # output_doc을 닫기
        output_doc.close()

        # 기존 _rotated.pdf 삭제
        if os.path.exists(pdf_file) and "_rotated.pdf" in os.path.basename(pdf_file):
            os.remove(pdf_file)
            # self.process_logger.info(f'Removed original rotated file: {pdf_file}')

        # doc은 사용 후 닫지 않음
        return split_file

    def _split_if_multicolumn(self, doc, pdf_file):
        """ 멀티 컬럼 페이지 분할 """
        output_doc = fitz.open()  # 빈 출력 PDF 파일 생성

        is_split_pdf = False

        for page_num in range(len(doc)):
            page = doc.load_page(page_num)

            # 페이지의 크기
            page_width = page.rect.width
            page_height = page.rect.height
            
            # 왼쪽 및 오른쪽 영역 정의
            left_box = box(0, 0, page_width / 2, page_height)
            right_box = box(page_width / 2, 0, page_width, page_height)
            
            # 사각형 좌표를 저장할 리스트
            rectangles = []

            # 페이지에서 경로 가져오기
            drawings = page.get_drawings()  # 모든 경로를 가져옴

            # 모든 경로를 순회하며 사각형 좌표만 모은다
            for path in drawings:
                for item in path['items']:
                    if item[0] == 're':  # 사각형인 경우
                        x0, y0, x1, y1 = item[1]

                        # 사각형의 꼭짓점 좌표
                        coords = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
                        
                        # Polygon 객체로 변환
                        rect_polygon = Polygon(coords)
                        rectangles.append(rect_polygon)
                        
                        # 사각형을 파란색으로 채우기
                        # page.draw_rect(item[1], color=(0, 0, 1), fill=(0, 0, 1))
                        # print(f"Rectangle coordinates: {coords}")

            # 왼쪽 영역의 총 면적과 채워진 면적 계산
            left_area = left_box.area
            left_combined_area = self._get_intersecting_area(rectangles, left_box)
            left_fill_ratio = (left_combined_area / left_area) * 100
            is_left_over_50 = left_fill_ratio > 50
            
            # 오른쪽 영역의 총 면적과 채워진 면적 계산
            right_area = right_box.area
            right_combined_area = self._get_intersecting_area(rectangles, right_box)
            right_fill_ratio = (right_combined_area / right_area) * 100
            is_right_over_50 = right_fill_ratio > 50

            # 페이지 면적 대비 경로 면적 비율이 50% 이상인 경우 페이지를 2개로 나눔
            if ((is_left_over_50 or is_right_over_50) and (is_left_over_50 != is_right_over_50)) or is_split_pdf :
                src_left_rect = fitz.Rect(0, 0, page_width / 2, page_height)
                src_right_rect = fitz.Rect(page_width / 2, 0, page_width, page_height)

                # 왼쪽 페이지
                left_page = output_doc.new_page(-1, width=page_width, height=page_height)
                left_page.show_pdf_page(page.rect, doc, page.number, clip=src_left_rect)

                # 오른쪽 페이지
                right_page = output_doc.new_page(-1, width=page_width, height=page_height)
                right_page.show_pdf_page(page.rect, doc, page.number, clip=src_right_rect)

                is_split_pdf = True
            # else:
            #     # 경로 면적이 적으면 하나의 페이지로 처리
            #     full_page = output_doc.new_page(-1, width=page_width, height=page_height)
            #     full_page.show_pdf_page(page.rect, doc, page.number)

        if is_split_pdf and output_doc.page_count > 0:
            # 분할 상태 저장
            self.splited_files[pdf_file] = is_split_pdf  # 분할 여부 저장
            # 분할된 파일 저장
            pdf_file = pdf_file.replace('.pdf', '_split.pdf')
            output_doc.save(pdf_file)
            # self.process_logger.info(f'Split file saved as {pdf_file}')

        # output_doc을 닫기
        output_doc.close()

        return pdf_file

    def _get_combined_area(self, rectangles):
        """ 중복 면적을 제거하며 총 사각형 면적을 계산하는 함수 """
        if not rectangles:
            return 0
        union_polygon = rectangles[0]
        for rect in rectangles[1:]:
            union_polygon = union_polygon.union(rect)
        return union_polygon.area

    def _get_intersecting_area(self, rectangles, area_box):
        """ 특정 영역과 겹치는 부분만 잘라내어 면적을 계산하는 함수 """
        intersecting_rectangles = []
        for rect in rectangles:
            intersection = rect.intersection(area_box)
            if not intersection.is_empty:
                intersecting_rectangles.append(intersection)
        return self._get_combined_area(intersecting_rectangles)

    def _process_footnotes(self, pdf_file):
        """ 각주 추출 및 저장 """
        # print(f"!!!!!!!!!!! {pdf_file}")
        fn_doc = fitz.open(pdf_file)
        
        # 각 페이지를 순회하면서 경로와 텍스트 처리
        for page_index in range(len(fn_doc)):
            if pdf_file not in self.footnote_path:
                self.footnote_path[self._get_original_filename(pdf_file)] = []

            page = fn_doc[page_index]  # 페이지 가져오기
            paths = page.get_drawings()  # 경로 정보 추출
            text_dict = page.get_text("dict")   # 페이지에서 텍스트 정보 추출

            cur_page_width = page.rect.width
            # 가장 큰 Y값을 가진 경로 찾기
            max_y_path = self._find_max_y_path(paths)           
            # 경로에 가장 큰 Y값을 가진 사각형 그리기 (하늘색)
            if max_y_path:
                max_y_path_width = max_y_path['rect'][2] - max_y_path['rect'][0]
                if (round(self._get_min_x(text_dict), 0) - round(max_y_path['rect'][0], 0) >= 0) and (cur_page_width / 2) > max_y_path_width:
                    if not self._is_table(paths, max_y_path) and not self._is_underline_text(max_y_path, text_dict):
                        self.footnote_path[self._get_original_filename(pdf_file)].append((page_index, max_y_path))
                        # page.draw_rect(max_y_rect, color=self.red, width=1.0)
                    else:
                        self.footnote_path[self._get_original_filename(pdf_file)].append((page_index, None))

            # 각주 텍스트 영역 찾기
            highlighted_text = self._highlight_footnotes(text_dict, pdf_file, page_index)
            
            # 페이지별 텍스트를 딕셔너리에 저장
            self.page_texts[f"{self._get_original_filename(pdf_file)}_{(page_index + 1)}"] = highlighted_text
            if self._match_first_text(text_dict, page_index, pdf_file, cur_page_width) == 0 : # 첫 번째 텍스트 매칭 확인
                continue

        fn_doc.close()

    def _find_max_y_path(self, paths):
        # 가장 큰 Y값을 가진 경로를 찾기
        max_y_value = -float('inf')
        max_y_path = None
        for path in paths:
            rect = path['rect']
            if rect[1] == rect[3]:
                max_y = max(rect[1], rect[3])  # Y값이 더 큰 값 사용

                if max_y > max_y_value:
                    max_y_value = max_y
                    max_y_path = path
        
        return max_y_path

    def _highlight_footnotes(self, text_dict, pdf_file, page_index):
        # 각주 텍스트 영역을 연두색으로 하이라이트
        highlighted_text = []
        text_blocks = text_dict['blocks']
        footnote_path = self._get_footnote_path(self._get_original_filename(pdf_file), page_index)
        
        for block in text_blocks:
            block_rect = block['bbox']  # 텍스트 좌표 (x0, y0, x1, y1)
            block_x0, block_y0, block_x1, block_y1 = block_rect

            # 각주 경로 아래에 위치한 텍스트에 연두색 사각형 그리기
            if footnote_path and block_y0 > footnote_path['rect'][1] and block_y1 > footnote_path['rect'][1]:
                if abs(round(block_x0, 1) - round(footnote_path['rect'][0], 1)) <= 20:
                    # page.draw_rect(block_rect, color=self.light_green, width=1.0)

                    # 텍스트 내용 출력
                    for line in block.get('lines', []):
                        for span in line['spans']:
                            text = span['text']
                            text_bbox = span['bbox']
                            highlighted_text.append((text, text_bbox))

        return highlighted_text

    def _match_first_text(self, text_dict, page_num, pdf_file, cur_page_width):
        footnote_path = self._get_footnote_path(self._get_original_filename(pdf_file), page_num)
        page_texts = self._get_page_texts(f"{self._get_original_filename(pdf_file)}_{(page_num + 1)}")
        text_blocks = text_dict['blocks']

        if len(page_texts) > 0:
            first_text, first_bbox = page_texts[0]

            first_word = first_text.split(" ")[0]
            if not first_word.strip():  # 빈 텍스트 건너뛰기
                return 0

            if first_word.isdigit():
                self.page_texts[f"{self._get_original_filename(pdf_file)}_{(page_num + 1)}"] = []  # 텍스트 삭제
                return 0

            # 첫 번째 글자가 한글인 경우
            # 첫 번째 단어에서 첫 번째 또는 두 번째 글자 체크
            chk_idx = 1 if len(first_word) > 1 and first_word[1].strip() else 0
            if first_word[chk_idx].strip() and (unicodedata.category(first_word[chk_idx]) in ['Lo', 'Lm'] or first_word[chk_idx].isalpha()):
                return 0

            found_match = False
            for block in text_blocks:
                for line in block.get('lines', []):
                    for span in line['spans']:
                        text = span['text']
                        text_bbox = span['bbox']

                        min_x_rounded = round(((first_bbox[2] - first_bbox[0]) / 2) + first_bbox[0], 1)

                        # 기준선을 페이지 가로의 절반으로 설정
                        half_page_width = cur_page_width / 2  # 페이지의 절반

                        if min_x_rounded == half_page_width:
                            continue
                        
                        if footnote_path:
                            footnote_rect = footnote_path['rect']
                            if text_bbox[1] > footnote_rect[1] and text_bbox[3] > footnote_rect[3]:
                                continue

                        if text_bbox[1] != first_bbox[1] and first_word in text:
                            found_match = True
                            # self.footnote_count += 1  # 각주 카운트 증가
                            if self._get_footnote_count(self._get_original_filename(pdf_file)) >= 0:
                                self.footnote_count[self._get_original_filename(pdf_file)] += 1
                            else:
                                self.footnote_count[self._get_original_filename(pdf_file)] = 0
                            # page.draw_rect(text_bbox, color=self.blue, width=1.0)
                            break
                    if found_match:
                        break
                if found_match:
                    break
        return 1

    def _get_footnote_count(self, pdf_file):        
        # 각주 카운트를 반환
        return self.footnote_count[pdf_file]
    
    def _get_footnote_path(self, pdf_file, page_index):
        # pdf_file에 해당하는 데이터가 없으면 빈 리스트 반환
        if pdf_file not in self.footnote_path:
            return []
        
        # pdf_file에 해당하는 각주 데이터 가져오기
        file_data = self.footnote_path[pdf_file]

        # 각 항목에서 page_index가 일치하는지 확인
        for data in file_data:
            # data[0]이 페이지 번호로 보이며, 해당 페이지 번호와 page_index를 비교
            page_number = data[0]
            if page_number == page_index:
                return data[1]  # 해당 페이지의 각주 데이터를 반환
        
        # 해당 page_index에 해당하는 각주 데이터가 없으면 빈 리스트 반환
        return []
    
    def _get_page_texts(self, pdf_file):
        # return self.page_texts[pdf_file]
        return self.page_texts.get(pdf_file, [])
    
    def _get_min_x(self, text_dict):

        # 가장 작은 x0 좌표 초기화 (큰 값으로 설정)
        min_x0 = float('inf')

        # 각 블록을 순회하면서 가장 작은 x0 찾기
        for block in text_dict['blocks']:
            for line in block.get('lines', []):
                for span in line['spans']:
                    x0 = span['bbox'][0]  # 각 텍스트의 x0 값
                    if x0 < min_x0:
                        min_x0 = x0

        return min_x0
    
    def _is_table(self, paths, max_y_path):
        x0 = max_y_path['rect'][0]
        x1 = max_y_path['rect'][2]
        y0 = max_y_path['rect'][1]
        i = 0
        for path in paths:
            rect = path['rect']
            x0_path = rect[0]  # 경로의 x1 값
            y1_path = rect[3]  # 경로의 y1 값
            if max_y_path['rect'] != rect:
                if ((round(x0_path, 0) - round(x0, 0) >= 0) and (round(x0_path, 0) - round(x1, 0) <= 0) and (round(y1_path, 0) - round(y0, 0) >= 0)):
                    return True
            i += 1
        return False
    
    def _is_underline_text(self, max_y_path, text_dict):
        underline_y = max_y_path['rect'][1]
        for block in text_dict['blocks']:
            block_rect = block['bbox']
            block_x0, block_y0, block_x1, block_y1 = block_rect
            if abs(underline_y - block_y1) < 1:
                return True
        return False
    
    def get_rotation_status(self, pdf_file):
        """ 저장된 회전 상태 확인 """
        return self.lotated_files.get(pdf_file, False)  # 회전된 상태 반환
    
    def get_split_status(self, pdf_file):
        """ 저장된 분할 상태 확인 """
        return self.splited_files.get(pdf_file, False)  # 분할된 상태 반환

    def _check_duplicates_and_extract_text(self, pdf_file):
        """ 중복 텍스트 체크 후 텍스트 추출 """
        processed_text = ""
        all_text = ""
        # if self.get_rotation_status(self._get_original_filename(pdf_file)):
        #     # processed_text = self._get_rotated_pdf_text(pdf_file)
        #     processed_text = self._get_pdf_to_text(pdf_file)
        #     # print(processed_text)
        #     all_text = self._combine_texts_by_page(self._get_original_filename(pdf_file), processed_text, 1)
        # else :
        threshold = 5  # 텍스트 결합 기준 간격
        processed_text1_positions = self._combine_texts_by_y0(self._extract_and_return_processed_text_positions(pdf_file), threshold)
        processed_text = self._process_and_return_pdf_text(pdf_file, processed_text1_positions)
        all_text = self._combine_texts_by_page(self._get_original_filename(pdf_file), processed_text, 2)
            # print(all_text)

        # doc = fitz.open(pdf_file)
        # processed_text = ""
        
        # for page_num in range(len(doc)):
        #     page = doc.load_page(page_num)
        #     text = page.get_text("text")
        #     # 중복 텍스트 처리 로직 추가
        #     processed_text += text + "\r\n"

        return all_text

    def _combine_texts_by_page(self, pdf_file, texts, type):
        all_texts = []
        temp_page = []
        combined_page_num = 1  # 묶은 페이지 번호

        if type == 1:
            for page_data in texts:
                page_text = page_data.get('text', '')
                page_text = page_text.replace('\n\n', '').replace('\n', '\\r\\n')
                temp_page.append(page_text)

                # 두 개의 페이지를 묶음
                if len(temp_page) == 2:
                    combined_text = f"<page num='{combined_page_num}'>\r\n\\r\\n"
                    combined_text += temp_page[0] + "\\r\\n" + temp_page[1]
                    combined_text += "\\r\\n\r\n</page>\r\n"

                    all_texts.append(combined_text)
                    temp_page = []
                    combined_page_num += 1

            # 홀수 페이지가 남는 경우 마지막 페이지 처리
            if temp_page:
                combined_text = f"<page num='{combined_page_num}'>\r\n\\r\\n"
                combined_text += temp_page[0]
                combined_text += "\\r\\n\r\n</page>\r\n"
                all_texts.append(combined_text)

            return "".join(all_texts)
        elif type == 2:
            is_split = self.get_split_status(pdf_file)

            for idx, page in enumerate(texts):
                texts = [text.replace('\n\n', '').replace('\n', '\\r\\n') for text in page['texts']]
                # texts = texts.replace('\n\n', '').replace('\n', '\\r\\n')
                # print(texts)
                temp_page.extend(texts)

                # Split된 경우: 2페이지씩 묶음, 그렇지 않은 경우: 1페이지씩 묶음
                if not is_split or (is_split and (idx + 1) % 2 == 0):
                    # combined_text = f"---------------- Page {combined_page_num} ----------------"
                    combined_text = f"<page num='{combined_page_num}'>\r\n\\r\\n"
                    combined_text += "\\r\\n".join(temp_page)
                    combined_text += "\\r\\n\r\n</page>\r\n"
                    
                    all_texts.append(combined_text)
                    temp_page = []  # 임시 리스트 초기화
                    combined_page_num += 1

            # 페이지 개수가 홀수일 때 마지막 페이지 처리
            if temp_page:
                combined_text = f"<page num='{combined_page_num}'>\r\n\\r\\n"
                combined_text += "\\r\\n".join(temp_page)
                combined_text += "\\r\\n\r\n</page>\r\n"
                all_texts.append(combined_text)

            return "".join(all_texts)
    
    def _get_rotated_pdf_text(self, pdf_file):
        return pymupdf4llm.to_markdown(pdf_file, margins=0, show_progress=False, page_chunks=True)
    
    def _get_pdf_to_text(self, doc_or_pdf_file):
        # 만약 doc_or_pdf_file이 문자열이면, 새로운 문서 인스턴스를 생성
        if isinstance(doc_or_pdf_file, str):
            doc_instance = fitz.open(doc_or_pdf_file)
        else:
            doc_instance = doc_or_pdf_file
        result = pymupdf4llm.to_markdown(doc_instance, margins=0, show_progress=False, page_chunks=True)
        # doc_instance.close()
        return result

    def _extract_and_return_processed_text_positions(self, pdf_file):
        doc = fitz.open(pdf_file)
        
        processed_text1_positions = {}  # 결과를 저장할 딕셔너리
        
        # 각 페이지에서 텍스트 블록 추출
        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)  # 페이지 로드
            text_instances = page.get_text("rawdict")["blocks"]  # 페이지에서 텍스트 블록 가져오기

            text_boxes = []
            for block in text_instances:
                if block['type'] == 0:  # 텍스트 블록만 처리
                    for line in block["lines"]:
                        for span in line["spans"]:
                            result = ""
                            prev_right = None
                            for char_info in span.get("chars", []):
                                char = char_info["c"]
                                x0 = char_info["bbox"][0]
                                x1 = char_info["bbox"][2]

                                if prev_right is not None:
                                    gap = x0 - prev_right
                                    if gap > 1.5:
                                        result += " "
                                result += char
                                prev_rigth = x1

                            rect = fitz.Rect(span['bbox'])  # 텍스트의 위치(bbox) 정보
                            text_boxes.append((result, rect))  # 텍스트와 위치 정보 저장
                            #text_boxes.append((span["text"], rect))  # 텍스트와 위치 정보 저장
                            #print(result)

            # 텍스트 상자 간의 겹침 여부 확인
            for i, (text1, box1) in enumerate(text_boxes):
                for j, (text2, box2) in enumerate(text_boxes):
                    if i < j and self._is_overlap(box1, box2):  # 겹치는 텍스트 상자 찾기
                        overlap_ratio = self._get_overlap_ratio(box1, box2)  # 겹침 비율 계산

                        if overlap_ratio >= 0.8:  # 겹침 비율이 80% 이상인 경우
                            # page.draw_rect(box1, color=(1, 0, 0), width=2)  # 겹치는 상자에 빨간색 사각형 그리기
                            # page.draw_rect(box2, color=(1, 0, 0), width=2)  # 겹치는 상자에 빨간색 사각형 그리기
                            
                            # print(f"Page {page_num + 1}:")
                            # print(f"  Text 1: '{text1.strip()}'")  # 첫 번째 텍스트 출력
                            # print(f"  Text 2: '{text2.strip()}'")  # 두 번째 텍스트 출력
                            # print(f"  Overlap Ratio: {overlap_ratio:.2f}")  # 겹침 비율 출력
                            # print("-" * 50)

                            # 처리된 텍스트를 저장
                            if page_num not in processed_text1_positions:
                                processed_text1_positions[page_num] = []
                            processed_text1_positions[page_num].append({'text': text1.strip().replace(" ", ""), 'y0': box1.y0})
        
        doc.close()
        # 결과 반환
        return processed_text1_positions

    def _extract_and_return_processed_text_positions2(self, pdf_file):
        doc = fitz.open(pdf_file)
        
        processed_text1_positions = {}  # 결과를 저장할 딕셔너리

        all_gaps = []
        
        # 각 페이지에서 텍스트 블록 추출
        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)  # 페이지 로드
            text_instances = page.get_text("rawdict")["blocks"]  # 페이지에서 텍스트 블록 가져오기

            text_boxes = []
            for block in text_instances:
                if block['type'] == 0:  # 텍스트 블록만 처리
                    for line in block["lines"]:
                        for span in line["spans"]:
                            result = ""
                            prev_right = None
                            for char_info in span.get("chars", []):
                                char = char_info["c"]
                                x0 = char_info["bbox"][0]
                                x1 = char_info["bbox"][2]

                                if prev_right is not None:
                                    gap = x0 - prev_right
                                    if gap > 1.5:
                                        result += " "
                                result += char
                                prev_rigth = x1

                            rect = fitz.Rect(span['bbox'])  # 텍스트의 위치(bbox) 정보
                            text_boxes.append((result, rect))  # 텍스트와 위치 정보 저장
                            #text_boxes.append((span["text"], rect))  # 텍스트와 위치 정보 저장
                            #print(result)

            # 텍스트 상자 간의 겹침 여부 확인
            for i, (text1, box1) in enumerate(text_boxes):
                for j, (text2, box2) in enumerate(text_boxes):
                    if i < j and self._is_overlap(box1, box2):  # 겹치는 텍스트 상자 찾기
                        overlap_ratio = self._get_overlap_ratio(box1, box2)  # 겹침 비율 계산

                        if overlap_ratio >= 0.8:  # 겹침 비율이 80% 이상인 경우
                            # page.draw_rect(box1, color=(1, 0, 0), width=2)  # 겹치는 상자에 빨간색 사각형 그리기
                            # page.draw_rect(box2, color=(1, 0, 0), width=2)  # 겹치는 상자에 빨간색 사각형 그리기
                            
                            # print(f"Page {page_num + 1}:")
                            # print(f"  Text 1: '{text1.strip()}'")  # 첫 번째 텍스트 출력
                            # print(f"  Text 2: '{text2.strip()}'")  # 두 번째 텍스트 출력
                            # print(f"  Overlap Ratio: {overlap_ratio:.2f}")  # 겹침 비율 출력
                            # print("-" * 50)

                            # 처리된 텍스트를 저장
                            if page_num not in processed_text1_positions:
                                processed_text1_positions[page_num] = []
                            processed_text1_positions[page_num].append({'text': text1.strip().replace(" ", ""), 'y0': box1.y0})
        
        doc.close()
        # 결과 반환
        return processed_text1_positions
    
    def _combine_texts_by_y0(self, processed_text1_positions, threshold):
        for page_num, positions in processed_text1_positions.items():
            positions.sort(key=lambda x: x['y0'])  # y0 값 기준으로 정렬

            combined_texts = []
            current_text = positions[0]['text']  # 첫 번째 텍스트
            current_y0 = positions[0]['y0']  # 첫 번째 y0 값

            # 텍스트 결합
            for i in range(1, len(positions)):
                text = positions[i]['text']
                y0 = positions[i]['y0']
                if abs(y0 - current_y0) <= threshold:  # y0 값 차이가 기준 이하일 때 결합
                    current_text += text
                else:
                    combined_texts.append({'text': current_text, 'y0': current_y0})  # 결합된 텍스트 저장
                    current_text = text  # 새로운 텍스트로 변경
                current_y0 = y0

            # 마지막 텍스트 추가
            combined_texts.append({'text': current_text, 'y0': current_y0})
            
            # 결합된 텍스트 업데이트
            processed_text1_positions[page_num] = processed_text1_positions.get(page_num, []) + combined_texts

        return processed_text1_positions
    
    def _process_and_return_pdf_text(self, pdf_file, processed_text1_positions):
        # PDF 페이지별로 텍스트를 수집하여 반환 (각주 텍스트는 <footnotes></footnotes> 태그로 감싸기)
        all_texts = []
        doc = fitz.open(pdf_file)
        
        pdf_texts = self._get_pdf_to_text(doc)
        # pdf_texts = pymupdf4llm.to_markdown(doc, margins=0, show_progress=False, page_chunks=True)
        # pdf_texts = pymupdf4llm.to_markdown(fitz.open(pdf_file), margins=0, show_progress=False, page_chunks=True)
        # print(pdf_texts)

        for page_data in pdf_texts:            
            page_index = page_data["metadata"]["page"] - 1  # 0부터 시작하는 인덱스
            page = doc[page_index]
            
            # 1. 테이블 그룹화: 겹치는 테이블들을 그룹으로 묶음
            table_groups = []
            for table in page_data.get("tables", []):
                bbox = table["bbox"]
                added_to_group = False
                for group in table_groups:
                    if self._is_contained(group[0]["bbox"], bbox):
                        group.append(table)
                        added_to_group = True
                        break
                if not added_to_group:
                    table_groups.append([table])

            # 2. 각 그룹에서 가장 큰 테이블 선택 및 빨간 네모 표시, table_text 추출
            table_regions = {}  # 페이지별로 테이블 정보를 저장할 딕셔너리
            
            # group은 해당 페이지의 테이블 그룹 리스트라고 가정합니다.
            largest_marked = False
            # print(table_groups)
            for group in table_groups:
                # 그룹 내에서 면적이 가장 큰 테이블과 그 면적 계산
                all_tables = [table for group in table_groups for table in group]
                largest_table = max(all_tables, key=lambda t: (t["bbox"][2] - t["bbox"][0]) * (t["bbox"][3] - t["bbox"][1]))
                # print(f"$$$$$$$$$$$ {page_index+1} {largest_table}")
                largest_area = (largest_table["bbox"][2] - largest_table["bbox"][0]) * (largest_table["bbox"][3] - largest_table["bbox"][1])
                
                # 그룹 내 테이블들을 순회하며, 최초로 면적이 largest_area인 항목만 is_largest=True로 지정
                for table in group:
                    bbox = table["bbox"]
                    rect = fitz.Rect(bbox)
                    table_text = page.get_text("text", clip=rect)
                    area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
                    if area == largest_area and not largest_marked:
                        is_largest = True
                        largest_marked = True
                    else:
                        is_largest = False
                    
                    table_info = {
                        "bbox": bbox,
                        "table_text": table_text,
                        "replaced": False,
                        "is_largest": is_largest
                    }
                    if page_index+1 not in table_regions:
                        table_regions[page_index+1] = []
                    table_regions[page_index+1].append(table_info)
            
            # 3. 페이지 전체 텍스트 재구성: 블록 정렬을 통해 컬럼 분리 및 순서 조정
            page_dict = page.get_text("dict")
            blocks = page_dict["blocks"]
            # print(blocks)
            # 컬럼 분리를 위해 각 블록의 좌측 x좌표 모으기
            if blocks:
                # (1) x좌표 중복 제거 후 정렬
                for block in blocks:
                    block_rect = fitz.Rect(block["bbox"])
                    page.draw_rect(block_rect, color=(0, 1, 1), width=2)
                x_positions = [block["bbox"][0] for block in blocks]
                unique_x = sorted(set(x_positions))

                # (2) 가장 큰 간격(largest gap) 찾기
                #     gap이 최대인 인접 값 pair에서 '오른쪽 값'을 분리 기준으로 사용
                largest_gap = 0
                boundary_x = None
                for i in range(len(unique_x) - 1):
                    gap = unique_x[i+1] - unique_x[i]
                    if gap > largest_gap:
                        largest_gap = gap
                        boundary_x = unique_x[i+1]

                # 혹시 모든 gap이 0이거나, 블록이 1개뿐이면 기본값
                if boundary_x is None:
                    boundary_x = unique_x[len(unique_x)//2]

                # (3) boundary_x가 페이지 중앙보다 왼쪽이면, while 루프를 통해 계속 갱신 (타이틀 구분)
                page_width = page.rect.width
                idx = unique_x.index(boundary_x)
                while boundary_x < page_width / 2 and idx < len(unique_x) - 1:
                    idx += 1
                    boundary_x = unique_x[idx]

                if len(unique_x) == idx + 1:
                    boundary_x = None
                # print(unique_x)
                # print(f"[페이지 {page_index+1}] boundary_x (가장 큰 간격 기준): {boundary_x}")

                # (3) 왼쪽 컬럼 vs 오른쪽 컬럼 분리
                if boundary_x:
                    left_blocks = [b for b in blocks if b["bbox"][0] < boundary_x]
                    right_blocks = [b for b in blocks if b["bbox"][0] >= boundary_x]
                else :
                    left_blocks = blocks
                    right_blocks = []

                # (4) 컬럼 내부에서 y축 정렬 + 합치기
                left_sorted = sorted(left_blocks, key=lambda b: b["bbox"][1])
                # print(left_sorted)
                right_sorted = sorted(right_blocks, key=lambda b: b["bbox"][1])
                final_blocks = left_sorted + right_sorted
            else:
                final_blocks = []

            text_boxes = self._get_text_boxes(final_blocks)

            page_texts = self._get_pages_texts(pdf_file, text_boxes, page_index, processed_text1_positions)  # 페이지 별로 텍스트를 저장할 리스트

            # 현재 페이지에 해당하는 테이블 정보 리스트 불러오기 (없으면 빈 리스트)
            regions = table_regions.get(page_index+1, [])
            
            # 1. 페이지의 테이블 트리 구조 생성 및 조정
            table_tree = self._build_table_tree(regions)  # regions: 현재 페이지의 테이블 정보 리스트
            
            # 3. 최상위 부모 테이블 정보 가져오기 (adjusted_tree가 비어있지 않은 경우)
            if table_tree:
                top_parent_region = table_tree[0]["region"]
            else:
                top_parent_region = None

            # 4. 모든 부모의 자식 테이블 정보를 추출 (adjusted_tree가 여러 부모일 경우)
            child_regions = []
            for parent_node in table_tree:
                if parent_node.get("children"):
                    for child_node in parent_node["children"]:
                        child_regions.append(child_node["region"])

            # 7. 최종 출력 텍스트 생성 (top_parent_region이 None이면 final_blocks의 텍스트만 출력)
            final_output = []

            if top_parent_region is None:
                for text, bbox in page_texts:
                    # final_output += text.strip() + "\n"
                    final_output.append(text.strip())  # 일반 텍스트는 그대로 추가
            else:
                if len(table_tree) == 1:
                    final_output = self._generate_final_text_single_parent(top_parent_region, child_regions, page_texts)
                else:
                    # 여러 부모 테이블이 존재하는 경우:
                    # 각 부모 테이블 영역에 대해, 겹치는 블록은 부모 테이블 텍스트로 대체하되,
                    # 각 부모 테이블의 텍스트는 한 번만 출력되도록 처리
                    for text, bbox in page_texts:
                        # block_bbox = block["bbox"]
                        is_table_block = False
                        for parent_node in table_tree:
                            region = parent_node["region"]
                            if self._is_contained(bbox, region["bbox"]):
                                if not region.get("replaced", False):
                                    # final_output += region["table_text"] + "\n"
                                    final_output.append(region["table_text"])
                                    region["replaced"] = True
                                is_table_block = True
                                break
                        if not is_table_block:
                            # final_output += text.strip() + "\n"
                            final_output.append(text.strip())

            # print(f"📄 [페이지 {page_index + 1}] 최종 텍스트:")
            # print(final_output)
            # print("=" * 50)
            all_texts.append({"page_num": page_index + 1, "texts": final_output})  # 페이지 번호와 텍스트 리스트 추가

        doc.close()
        return all_texts
    
    def _build_table_tree(self, regions):
        """
        regions: 한 페이지의 모든 테이블 정보를 담은 리스트
        각 항목은 {'bbox': (x0, y0, x1, y1), 'table_text': str, 'replaced': bool, 'is_largest': bool} 형태입니다.
        
        반환: 트리 구조 (리스트 형태)로, 각 노드는 다음과 같이 구성됩니다.
        { 'region': region, 'area': area, 'children': [ ... ] }
        
        부모-자식 관계는, 한 테이블의 bbox가 다른 테이블의 bbox에 완전히 포함되는 경우로 정의합니다.
        만약 여러 부모 후보가 있다면, 면적이 가장 작은 부모(즉, 가장 가까운 상위 테이블)를 선택합니다.
        """
        # 먼저 각 region에 대해 면적을 계산하고, 노드로 변환합니다.
        nodes = []
        for region in regions:
            # region['bbox']는 (x0, y0, x1, y1) 형태
            area = (region['bbox'][2] - region['bbox'][0]) * (region['bbox'][3] - region['bbox'][1])
            node = {'region': region, 'area': area, 'children': []}
            nodes.append(node)
        
        # 트리 구조를 구성합니다.
        tree = []
        for node in nodes:
            # 후보 부모: 자기 자신을 제외하고, 면적이 더 크며, node의 bbox가 부모의 bbox에 완전히 포함되는 경우
            candidate_parents = []
            for other in nodes:
                if other is node:
                    continue
                # other의 bbox가 node보다 커야 하고, node가 완전히 포함되어야 함.
                if other['area'] > node['area'] and self._is_fully_contained(node['region']['bbox'], other['region']['bbox']):
                    candidate_parents.append(other)
            if candidate_parents:
                # 가장 작은 면적의 부모를 선택합니다.
                parent = min(candidate_parents, key=lambda n: n['area'])
                parent['children'].append(node)
            else:
                tree.append(node)
        return tree

    def _is_fully_contained(self, inner_bbox, outer_bbox):
        """
        inner_bbox, outer_bbox: (x0, y0, x1, y1) 튜플 또는 fitz.Rect 객체.
        inner_bbox가 outer_bbox에 완전히 포함되면 True, 그렇지 않으면 False를 반환합니다.
        """
        if not isinstance(inner_bbox, fitz.Rect):
            inner_bbox = fitz.Rect(inner_bbox)
        if not isinstance(outer_bbox, fitz.Rect):
            outer_bbox = fitz.Rect(outer_bbox)
        return (inner_bbox.x0 >= outer_bbox.x0 and
                inner_bbox.y0 >= outer_bbox.y0 and
                inner_bbox.x1 <= outer_bbox.x1 and
                inner_bbox.y1 <= outer_bbox.y1)

    def _check_text_outside_top_parent(self, top_parent_region, text_boxes):
        """
        최상위 부모 테이블 영역(top_parent_region['bbox'])과 겹치지 않는 텍스트 블록이 있는지 확인합니다.
        
        :param top_parent_region: 최상위 부모 테이블 정보 딕셔너리
            예: {"bbox": (x0, y0, x1, y1), "table_text": "...", ...}
        :param text_boxes: 페이지 내 텍스트 블록 리스트. 각 요소는 (text, bbox) 튜플 (bbox는 (x0, y0, x1, y1) 또는 fitz.Rect)
        :return: 부모 테이블 영역과 전혀 겹치지 않는 텍스트 블록이 있다면 True, 모두 겹치면 False
        """
        parent_bbox = top_parent_region["bbox"]
        if not isinstance(parent_bbox, fitz.Rect):
            parent_rect = fitz.Rect(parent_bbox)
        else:
            parent_rect = parent_bbox

        for text, bbox in text_boxes:
            # block_bbox = block["bbox"]
            if not isinstance(bbox, fitz.Rect):
                tbbox = fitz.Rect(bbox)
            # 만약 텍스트 블록이 부모 영역과 전혀 겹치지 않는다면
            if not self._is_tbl_overlap(tbbox, parent_rect):
                return True
        return False

    def _generate_final_text_single_parent(self, top_parent_region, child_regions, text_boxes):
        """
        단일 부모 테이블의 경우, 부모 영역 및 자식 테이블 영역 외의 텍스트 존재 여부에 따라 최종 텍스트를 생성합니다.
        
        :param top_parent_region: 최상위 부모 테이블 정보 딕셔너리 
            예: {"bbox": (x0, y0, x1, y1), "table_text": "...", ...}
        :param child_regions: 부모 테이블의 자식 테이블 영역 리스트 (각 항목은 {"bbox": ..., "table_text": ..., ...})
        :param text_boxes: 페이지 내의 전체 텍스트 박스 리스트, 각 요소는 (text, bbox) 튜플.
        :return: 최종 출력 텍스트 문자열
        """
        final_output = []
        
        # 1. 부모 영역 처리
        if self._check_text_outside_top_parent(top_parent_region, text_boxes):
            # 부모 영역 외에 추가 텍스트가 있음 → 각 블록을 검사: 블록이 부모 영역과 겹치면 부모 테이블의 텍스트 사용 (한 번만 출력)
            parent_printed = False
            for text, bbox in text_boxes:
                # block_bbox = block["bbox"]
                if self._is_tbl_overlap(bbox, top_parent_region["bbox"]):
                    if not parent_printed:
                        # final_output += top_parent_region["table_text"] + "\n"
                        final_output.append(top_parent_region["table_text"])
                        parent_printed = True
                else:
                    # final_output += text + "\n"
                    final_output.append(text.strip())
        else:
            # 부모 영역 외 텍스트가 없으면 → 단순히 부모 테이블의 텍스트만 출력
            # final_output += top_parent_region["table_text"] + "\n"
            final_output.append(top_parent_region["table_text"])
        
        # 2. 자식 테이블 처리 (자식이 존재하는 경우)
        if child_regions:
            final_output = []
            for child in child_regions:
                # 자식 영역 외에 추가 텍스트가 있는지 체크
                if self._check_text_outside_top_parent(child, text_boxes):
                    # 자식 영역 외에 추가 텍스트가 있음 → 각 블록 검사: 블록이 자식 영역과 겹치면 자식 테이블의 텍스트 사용(한 번만)
                    child_printed = False
                    for text, bbox in text_boxes:
                        # block_bbox = block["bbox"]
                        if self._is_tbl_overlap(bbox, child["bbox"]):
                            if not child_printed:
                                # final_output += child["table_text"] + "\n"
                                final_output.append(child["table_text"])
                                child_printed = True
                        else:
                            # final_output += text.strip() + "\n"
                            final_output.append(text.strip())
                else:
                    # 자식 영역 외에 추가 텍스트가 없으면 → 단순히 자식 테이블의 텍스트만 출력
                    # final_output += child["table_text"] + "\n"
                    final_output.append(child["table_text"])
        
        return final_output

    def _get_pages_texts(self, pdf_file, text_boxes, page_num, processed_text1_positions):
        page_texts = []  # 페이지 별로 텍스트를 저장할 리스트

        # 페이지별 각주 텍스트 리스트 불러오기
        # highlighted_text = self.page_texts.get(f"{pdf_file}_{page_num + 1}", [])
        highlighted_text = self._get_page_texts(f"{self._get_original_filename(pdf_file)}_{(page_num + 1)}")
        # print(f"=================================")
        # print(f"{pdf_file}")
        # print(f"{self._get_original_filename(pdf_file)} / {(page_num + 1)}")
        # print(highlighted_text)
        # print(f"=================================")
        for text, rect in text_boxes:
            is_duplicate = False
            for existing_text in processed_text1_positions.get(page_num, []):
                if text.strip().replace(" ", "") == existing_text['text'] and rect[1] == existing_text['y0']:
                    is_duplicate = True  # 중복 텍스트 확인
                    break

            if is_duplicate:
                continue  # 중복 텍스트는 건너뜀

            # 중복되는 각주 텍스트를 <footnotes></footnotes>로 감싸기
            is_footnote = False
            for footnote_text, footnote_rect in highlighted_text:
                # if "테스트 각주" in text:
                # print(f"width : {page.rect.width} / height : {page.rect.height}")
                # print(f"***** rect : {rect}")
                # print(f"***** footnote_rect : {footnote_rect}")
                if abs(rect[1] - footnote_rect[1]) <= 10 and abs(rect[0] - footnote_rect[0]) <= 20:
                    # 위치가 비슷한 각주 텍스트를 찾은 경우
                    # if "테스트 각주" in text:
                    #     print(f"<footnotes>{text.strip()}</footnotes>")
                    page_texts.append((f"<footnotes>{text.strip()}</footnotes>", rect))
                    is_footnote = True
                    break

            if not is_footnote:
                page_texts.append((text.strip(), rect))  # 일반 텍스트는 그대로 추가

        return page_texts

    # 블록에서 텍스트를 추출하는 함수 (lines와 spans 활용)
    def get_block_text_sorted_by_y(self, block):
        """
        주어진 block 내 각 line의 spans를 span["bbox"][1] (y좌표)를 기준으로 정렬하여 텍스트를 생성합니다.
        
        :param block: PDF 텍스트 블록 (예: {'lines': [...], 'bbox': (...) ...})
        :return: 각 line의 정렬된 span 텍스트들을 결합한 문자열.
        """
        text = ""

        # 각 block의 모든 span을 수집합니다.
        spans = [span for line in block.get("lines", []) for span in line.get("spans", [])]

        # 각 span의 bbox가 없는 경우 기본값 (0,0,0,0) 사용
        sorted_spans = sorted(
            spans,
            key=lambda s: (
                int(s.get("bbox", (0, 0, 0, 0))[1]),
                int(s.get("bbox", (0, 0, 0, 0))[0])
            )
        )

        # 정렬된 순서대로 (텍스트, bbox) 튜플을 생성합니다.
        block_text = [(span.get("text", ""), span.get("bbox", ())) for span in sorted_spans]
        
        # 정렬된 각 line의 텍스트들을 한 줄로 이어붙입니다.
        for span in sorted_spans:
            text += span.get("text", "")
        text += "\n"
        return text
    
    def _get_text_boxes(self, blocks):
        """
        블록 리스트에서 텍스트 박스(텍스트가 있는 영역)만 추출하는 함수.
        각 텍스트 박스는 (text, bbox) 튜플로 반환됩니다.
        """
        text_boxes = []
        for block in blocks:
            text = self.get_block_text_sorted_by_y(block)
            bbox = block["bbox"]
            text_boxes.append((text, bbox))
        return text_boxes

    def _is_contained(self, inner, outer):
        """
        두 사각형(inner, outer) 중 inner가 outer에 완전히 포함되는지 확인합니다.
        inner와 outer는 fitz.Rect 객체 또는 (x0, y0, x1, y1) 튜플 형태로 제공된다고 가정합니다.
        inner가 outer에 완전히 포함되면 True, 그렇지 않으면 False를 반환합니다.
        """
        if not isinstance(inner, fitz.Rect):
            inner = fitz.Rect(inner)
        if not isinstance(outer, fitz.Rect):
            outer = fitz.Rect(outer)
        return inner.x0 >= outer.x0 and inner.y0 >= outer.y0 and inner.x1 <= outer.x1 and inner.y1 <= outer.y1

    def _is_tbl_overlap(self, rect1, rect2):
        """
        두 개의 사각형(rect1, rect2)이 겹치는지 확인하는 함수.
        rect1과 rect2는 fitz.Rect 객체 또는 (x0, y0, x1, y1) 튜플 형태로 제공된다고 가정합니다.
        두 사각형이 조금이라도 겹치면 True를, 그렇지 않으면 False를 반환합니다.
        """
        # rect1, rect2가 튜플인 경우 fitz.Rect 객체로 변환
        if not isinstance(rect1, fitz.Rect):
            rect1 = fitz.Rect(rect1)
        if not isinstance(rect2, fitz.Rect):
            rect2 = fitz.Rect(rect2)
        
        # 두 사각형이 겹치지 않는 조건:
        # rect1이 rect2의 왼쪽에 있거나, rect1이 rect2의 오른쪽에 있거나,
        # rect1이 rect2의 위쪽에 있거나, rect1이 rect2의 아래쪽에 있는 경우.
        if rect1.x1 <= rect2.x0 or rect1.x0 >= rect2.x1 or rect1.y1 <= rect2.y0 or rect1.y0 >= rect2.y1:
            return False
        return True

    # 두 개의 bounding box (bbox1, bbox2)가 겹치는지 확인하는 함수
    def _is_overlap(self, bbox1, bbox2):
        return not (bbox1.x1 < bbox2.x0 or
                    bbox1.x0 > bbox2.x1 or
                    bbox1.y1 < bbox2.y0 or
                    bbox1.y0 > bbox2.y1)

    # 두 개의 bounding box가 겹치는 영역의 면적을 계산하는 함수
    def _get_intersection_area(self, bbox1, bbox2):
        # 겹치는 영역의 좌표를 찾기
        x0 = max(bbox1.x0, bbox2.x0)
        y0 = max(bbox1.y0, bbox2.y0)
        x1 = min(bbox1.x1, bbox2.x1)
        y1 = min(bbox1.y1, bbox2.y1)

        # 겹치는 부분이 있으면 면적 계산, 없으면 0 반환
        if x0 < x1 and y0 < y1:
            return (x1 - x0) * (y1 - y0)
        else:
            return 0

    # 두 bounding box의 겹치는 비율을 계산하는 함수
    def _get_overlap_ratio(self, bbox1, bbox2):
        intersection_area = self._get_intersection_area(bbox1, bbox2)  # 겹치는 면적
        area1 = (bbox1.x1 - bbox1.x0) * (bbox1.y1 - bbox1.y0)  # bbox1의 면적
        area2 = (bbox2.x1 - bbox2.x0) * (bbox2.y1 - bbox2.y0)  # bbox2의 면적
        
        min_area = min(area1, area2)  # 두 면적 중 작은 면적
        if min_area == 0:  # 면적이 0이면 겹침 비율이 0
            return 0
        return intersection_area / min_area  # 겹침 비율 계산

    def _save_text(self, text, pdf_file):
        """ Save extracted text to the specified output file """

        # Convert to pypdfium2 text if space ratio is low
        #print(self._get_space_ratio(text))
        #print(text)
        # if self._get_space_ratio(text) < 5:
        #     text = self._extract_text_from_pypdfium2(self._get_original_filename(pdf_file))

        # Ensure parent directory exists
        output_dir = os.path.dirname(self.output_file)
        os.makedirs(output_dir, exist_ok=True)

        # Save directly to self.output_file
        with open(self.output_file, 'w', encoding='utf-8') as f:
            f.write(text)

        # Optionally remove split file if needed
        if os.path.exists(pdf_file) and self.get_split_status(self._get_original_filename(pdf_file)):
            os.remove(pdf_file)

    def _get_space_ratio(self, text):
        # 페이지별 추출 (정규표현식: <page num='번호'> ... </page>)
        pages = re.findall(r"<page num='(\d+)'>\s*(.*?)\s*</page>", text, re.DOTALL)
        
        summary_dict = {}       # 페이지별 스페이스 총합 (delete_flag가 'N'인 라인만)
        summary_nonspace = {}   # 페이지별 스페이스 제외 글자 총합 (delete_flag가 'N'인 라인만)
        
        # 각 페이지 처리
        for page_num, page_content in pages:
            page = int(page_num)
            # 문자열 그대로 "\r\n" 기준 분리 (문자열 자체의 "\r\n")
            lines = page_content.split("\\r\\n")
            
            page_space_total = 0       # 해당 페이지의 스페이스 총합
            page_non_space_total = 0   # 해당 페이지의 스페이스 제외 문자 총합
            for i, line in enumerate(lines, start=1):
                if len(line) < 10:
                    delete_flag = "Y"
                else:
                    delete_flag = "N"
                    space_count = line.count(" ")
                    non_space_char_count = len(line.replace(" ", ""))
                
                if delete_flag == "N":
                    page_space_total += space_count
                    page_non_space_total += non_space_char_count

            summary_dict[page] = page_space_total
            summary_nonspace[page] = page_non_space_total
        
        overall_spaces = 0
        overall_non_space = 0
        for page in sorted(summary_dict.keys()):
            spaces = summary_dict[page]
            non_space = summary_nonspace[page]

            overall_spaces += spaces
            overall_non_space += non_space

        # 전체 합계 행 추가
        total_all = overall_spaces + overall_non_space
        if total_all > 0:
            overall_ratio = overall_spaces / total_all
        else:
            overall_ratio = 0
        
        space_ratio = overall_ratio*100

        return space_ratio
    
    def _extract_text_from_pypdfium2(self, pdf_path):
        """
        PDF 파일에서 페이지별 텍스트를 추출하여 XML 태그 형식 문자열로 반환합니다.
        각 페이지의 텍스트 내 개행 문자는 리터럴 문자열 "\r\n"로 변경됩니다.
        """
        if sys.platform.startswith("linux"):
            import locale
            locale.setlocale(locale.LC_ALL, 'ko_KR.UTF-8')

        output_lines = []
        pdf = pdfium.PdfDocument(pdf_path)
        try:
            for page_num, page in enumerate(pdf, start=1):
                text_page = page.get_textpage()
                text = text_page.get_text_range()
                print(text)
                # 실제 개행 문자를 리터럴 "\r\n" 문자열로 변경
                replaced_text = text.replace("\r\n", "\\r\\n")
                
                # XML 태그 형식으로 감싸기
                output_lines.append(f"<page num='{page_num}'>")
                output_lines.append("\\r\\n" + replaced_text + "\\r\\n")
                output_lines.append("</page>")
                # output_lines.append("")  # 페이지 간 빈 줄 추가
                
                text_page.close()
        finally:
            pdf.close()

        return "\n".join(output_lines)

    def open_pdf_with_fallback(self,input_path):
        try:
            pdf = pdfplumber.open(input_path)
            return pdf
        except Exception as e:
            print(f"PDF파일열기시 오류발생")
        
        try:
            base, ext = os.path.splitext(input_path)
            backup_file = F"{base}.bak{ext}"
            shutil.move(input_path, backup_file)


            doc = fitz.open(backup_file)
            doc.save(input_path)

            os.remove(backup_file)

            print(f"{input_path} PDF복구")

            pdf = pdfplumber.open(input_path)
            return pdf
        except Exception as e2:
            print(f"{input_path} 복구실패")
            shutil.move(backup_file,input_path)
            if os.path.exists(backup_file):
                os.remove(backup_file)
            
            return f"Error: {str(e2)}"

    def extract_text_from_pdf(self, pdf_path):
        text = ""
        i = 1
        pdf = self.open_pdf_with_fallback(pdf_path)
        if isinstance(pdf, pdfplumber.pdf.PDF):
            for page in pdf.pages:
                text += f"<page num='{i}'>\n\n"
                # text += "\\r\\n" + page.extract_text(x_tolerance=1).replace("\n","\\r\\n") + "\\r\\n"
                text += "\\r\\n" + Qnut.Qnut(page).replace("\n","\\r\\n") + "\\r\\n"
                text = re.sub(r'\(cid:\d+\)','',text)
                text += "\n\n</page>\n\n"
                i = i + 1
        else:
            text = pdf
        
#        with open(pdf_path, "rb") as f:
#            reader = PyPDF2.PdfReader(f)
#            i = 1
#            for page in reader.pages:
#                #text += page.extract_text()
#                text += f"<page num='{i}'>\n\n"
#                text += "\\r\\n" + page.extract_text().replace("\n","\\r\\n") + "\\r\\n"
#                text += "\n\n</page>\n\n"
#                i = i + 1
        #matches = re.findall(r'/((?:\(cid:\d+\)){5})',text)

        #if matches:
        #    text = None

        return text

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python pdftotxt.py <input_file> <output_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    masking = False

    if(len(sys.argv) == 4):
        masking_yn = sys.argv[3]
    
        if masking_yn in ['y', 'yes']:
            masking = True

    processor = PDFProcessor(input_file, output_file, masking)
    processor.process_file()
 
