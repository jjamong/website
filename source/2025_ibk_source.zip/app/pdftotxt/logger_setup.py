import os
from datetime import datetime

class LoggerSetup:
    def __init__(self):
        log_path = "/log/uda/asset/pdftotxt"
        os.makedirs(log_path, exist_ok=True)
        date_str = datetime.today().strftime('%Y%m%d')
        self.log_file = os.path.join(log_path, f"pdftotxt_{date_str}.log")

    def log(self, input_path, output_path, result, exception_msg=None):
        now = datetime.now().strftime("%Y-%m-%d][%H:%M:%S")

        # 절대경로로 변환
        abs_input = os.path.abspath(input_path)
        input_dir = os.path.dirname(abs_input)
        input_file = os.path.basename(abs_input)

        if output_path:
            abs_output = os.path.abspath(output_path)
            output_dir = os.path.dirname(abs_output)
            output_file = os.path.basename(abs_output)
        else:
            output_dir = ""
            output_file = ""

        line = f"[{now}][pdftotxt][{input_dir}][{input_file}][{output_dir}][{output_file}][{result}]"
        if result == "Fail" and exception_msg:
            line += f"[{exception_msg}]"

        print(line)
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(line + "\n")
            if result == "Fail" and exception_msg:
                f.write(f"Exception: {exception_msg}\n")
