import pdfplumber
import re
import difflib
import os

from collections import defaultdict
from collections import Counter


# 테이블 세팅
ts = {
    "vertical_strategy": "lines",
    "horizontal_strategy": "lines",
    "snap_x_tolerance": 1,      # 수직선 스냅 허용 오차 (가장 중요)
    "snap_y_tolerance": 3,      # 수평선 스냅 허용 오차
    "join_x_tolerance": 1,      # 수직선 연결 허용 오차
    "join_y_tolerance": 3,      # 수평선 연결 허용 오차
    "intersection_x_tolerance": 1, # 교차점 x 허용 오차
    "intersection_y_tolerance": 3, # 교차점 y 허용 오차
}


###################################
# 함수
###################################
def convert_to_markdown_table(table_data):
    """
    pdfplumber의 table.extract() 결과를 마크다운 테이블 형식으로 변환합니다.
    (예: [['a', 'b'], ['c', 'd']])
    """
    # 테이블 데이터가 없거나 비어있으면 빈 문자열 반환
    if not table_data:
        return ""

    # 테이블 내 None 값이나 개행문자를 처리하여 데이터를 정리
    cleaned_data = []
    for row in table_data:
        if row: # 행이 비어있지 않은 경우에만 처리
            cleaned_row = []
            for cell in row:
                # cell이 None이면 빈 문자열로, 아니면 문자열로 변환
                # cell 내용에 포함된 개행문자는 공백으로 치환하여 테이블 깨짐 방지
                cell_text = str(cell) if cell is not None else ""
                cleaned_row.append(cell_text.replace('\n', ' ').strip())
            cleaned_data.append(cleaned_row)

    if not cleaned_data:
        return ""

    # 헤더 행 생성
    header = cleaned_data[0]
    header_line = "| " + " | ".join(header) + " |"

    # 구분선 행 생성 (헤더의 열 개수에 맞춤)
    separator_line = "| " + " | ".join(["---"] * len(header)) + " |"

    # 본문 행 생성

    body_lines = []
    for row in cleaned_data[1:]:
        # 데이터 행의 열 개수가 헤더와 다를 경우, 빈 문자열로 채워줌
        while len(row) < len(header):
            row.append("")
        body_lines.append("| " + " | ".join(row) + " |")

    # 모든 부분을 합쳐서 최종 마크다운 테이블 문자열 생성
    result = "\n".join([header_line, separator_line] + body_lines)
    if not [char for char in result.replace('|','').replace('-','') if char.strip()]:
        result = ''
    else:
        result = result
    return result
    
# def extract_with_markdown_tables(pdf_path):
#     with pdfplumber.open(pdf_path) as pdf:
#         output = []

#         for page in pdf.pages:
#             tables = page.find_tables(table_settings = ts)
#             table_bboxes = [table.bbox for table in tables]

#             text_lines = page.extract_text_lines(x_tolerance=1)
#             filtered_lines = [
#                 line for line in text_lines
#                 if not any(
#                     table_bbox[1] <= line['top'] <= table_bbox[3] and \
#                     table_bbox[0] <= (line['x0'] + line['x1']) / 2 <= table_bbox[2]
#                     for table_bbox in table_bboxes
#                 )
#             ]

#             elements = []
#             elements.extend([('text', line['text'], line['top']) for line in filtered_lines])

#             # --- 여기부터 수정된 부분 ---

#             # table.extract() 결과를 바로 마크다운으로 변환하여 추가
#             for table in tables:
#                 markdown_table = convert_to_markdown_table(table.extract(x_tolerance=1,table_settings = ts))
#                 elements.append(('table', markdown_table, table.bbox[1]))

#             # --------------------------

#             elements.sort(key=lambda x: x[2])

#             page_output = [f"<table>\n{elem[1]}\n</table>" if elem[0] == 'table' else elem[1]
#             for elem in elements]

#             # 최종 결과 리스트 생성
#             output.append('\n'.join(page_output))

#     return ','.join(output)



# 셀 좌표랑 텍스트 매핑하기 위해서 셀 좌표 정렬 맞추는 함수
def group_cells_by_row(cells, tolerance=2.0):

    rows = defaultdict(list)
    for bbox in cells:
        # bbox 기준 y중심값
        y_center = (bbox[1] + bbox[3]) / 2
        matched = False
        for key in rows:
            if abs(key - y_center) <= tolerance:
                rows[key].append(bbox)
                matched = True
                break
        if not matched:
            rows[y_center].append(bbox)

    # 행을 위에서 아래로 정렬한 후 각 행 안의 셀을 좌→우로 정렬
    sorted_rows = sorted(rows.items(), key=lambda kv: kv[0])
    grouped = []
    for _, row in sorted_rows:
        row_sorted = sorted(row, key=lambda b: b[0])  # x0 기준 좌→우
        grouped.append(row_sorted)
    return grouped




# 셀 bbox와 텍스트 매핑되어 있는 걸로 마크다운 만들어야 할때 사용하는 함수
def extract_markdown_table_from_cells(cells, n_cols, tolerance=2.0):
    # 1. 셀 정리
    cleaned_cells = []
    for cell in cells:
        text = (cell.get("text") or "").strip().replace("\n", " ")
        if text:
            x0, top, x1, bottom = cell["bbox"]
            x_center = (x0 + x1) / 2
            y_center = (top + bottom) / 2
            cleaned_cells.append({
                "text": text,
                "x": x_center,
                "y": y_center,
                "bbox": cell["bbox"]
            })

    # 2. y값 기준으로 행 그룹핑 (위에서 아래로 정렬)
    cleaned_cells.sort(key=lambda c: c["y"])
    rows = []
    current_row = []
    current_y = None

    for cell in cleaned_cells:
        if current_y is None or abs(cell["y"] - current_y) <= tolerance:
            current_row.append(cell)
            current_y = cell["y"]
        else:
            # 정렬된 행 하나 완성
            rows.append(current_row)
            current_row = [cell]
            current_y = cell["y"]
    if current_row:
        rows.append(current_row)

    # 3. 각 행의 셀들을 x 기준 정렬해서 n_cols 맞추기
    table_data = []
    for row in rows:
        row.sort(key=lambda c: c["x"])
        texts = [c["text"] for c in row]
        while len(texts) < n_cols:
            texts.append("")
        table_data.append(texts[:n_cols])

    # 4. 마크다운 테이블 변환
    return convert_to_markdown_table(table_data)





# 테이블 안에 테이블이 있는 지 확인하는 함수
def is_bbox_inside(inner_bbox, outer_bbox):

    inner_x0, inner_top, inner_x1, inner_bottom = inner_bbox
    outer_x0, outer_top, outer_x1, outer_bottom = outer_bbox

    return (
        inner_x0 >= outer_x0 and
        inner_x1 <= outer_x1 and
        inner_top >= outer_top and
        inner_bottom <= outer_bottom
    )



def get_inserted_text(a: str, b: str):
    # a: 짧은 쪽, b: 긴 쪽 (b에 삽입된 텍스트를 찾음)
    diff = difflib.ndiff(a, b)
    inserted = ''.join(c[2:] for c in diff if c.startswith('+ '))

    return inserted



def compare_texts(page, table_settings):
    table_flag = False
    table_flag_list = []
    tables = page.find_tables(table_settings = table_settings)

    text_chars = page.chars

    tables_bbox = []
    tables_text = []

    area_text_chars = []

    for table in tables:
        bbox = table.bbox
        tables_bbox.append(bbox)
        tables_text.append(table.extract(x_tolerance=1,table_settings = table_settings))

    for table_bbox in tables_bbox:
        txt_sum_list = []
        for txt in text_chars :
            # 테이블 박스에 포함된 chars
            if (txt['top'] >= table_bbox[1]) & (txt['bottom'] <= table_bbox[3]) & (txt['x0'] >= (table_bbox[0] - 1)) & (txt['x1'] <= (table_bbox[2] + 1.5)):
                txt_sum_list.append(txt['text'])
            else:
                pass

        area_text_chars.append(txt_sum_list)
    if tables:
        c = 1
        for table_text_list, area_text_list in zip(tables_text,area_text_chars):

            table_text = ''.join(str(item) for sublist in table_text_list for item in sublist if item is not None)
            area_text= ''.join(area_text_list)

            cleanded_table_text = re.sub(r'\s', '', table_text)
            cleanded_area_text = re.sub(r'\s', '', area_text)

            table_len = len(cleanded_table_text)
            area_len =  len(cleanded_area_text)

            if table_len == area_len :
                table_flag = True
                table_flag_list.append(table_flag)
            else :
                table_flag = False
                table_flag_list.append(table_flag)

                # if table_len < area_len :
                #     extra = get_inserted_text(cleanded_table_text, cleanded_area_text)
                # else :
                #     extra = get_inserted_text(cleanded_area_text, cleanded_table_text)
            c += 1
    return table_flag_list



def page_verification(table, text):
    clean_table = table.replace('<table>', '').replace('</table>', '').replace('<sub_table>', '').replace('</sub_table>', '').replace("---", '').replace("|", '')
    clean_table = re.sub(r'\s', '', clean_table)
    clean_text = re.sub(r'\s', '', text)

    # 길이가 다르면 무조건 False
    if len(clean_table) != len(clean_text):
        # if clean_table < clean_text:
        #     extra = get_inserted_text(clean_table, clean_text)
        # else:
        #     extra = get_inserted_text(clean_text, clean_table)

        return False

    # 길이 같을때
    else:
        table_dict = Counter(sorted(clean_table))
        text_dict = Counter(sorted(clean_text))

        result = []
        # 음절 개수 비교
        for key in text_dict.keys():
            if text_dict[key] != table_dict[key]:
                result.append((key, text_dict[key], table_dict[key]))

        return not result



# 서브테이블 안에 서브테이블이 있을 수 있으므로 재배열 하는 함수
def group_nested_subtables(sub_tables_in_cell):

    grouped_sub_tables = {}

    for cell_bbox, tables in sub_tables_in_cell.items():
        n = len(tables)
        visited = [False] * n
        grouped = []

        for i in range(n):
            if visited[i]:
                continue
            current_group = [tables[i]]
            visited[i] = True
            outer_bbox = tables[i][1]  # 이게 bbox

            for j in range(n):
                if i == j or visited[j]:
                    continue
                inner_bbox = tables[j][1]
                if is_bbox_inside(inner_bbox, outer_bbox):
                    current_group.append(tables[j])
                    visited[j] = True

            grouped.append(current_group)

        grouped_sub_tables[cell_bbox] = grouped

    return grouped_sub_tables




###################################################################################

def convert_to_markdown_table_test(table_data):
    """
    pdfplumber의 table.extract() 결과를 마크다운 테이블 형식으로 변환합니다.
    (예: [['a', 'b'], ['c', 'd']])
    """
    # 테이블 데이터가 없거나 비어있으면 빈 문자열 반환
    if not table_data:
        return ""

    # 테이블 내 None 값이나 개행문자를 처리하여 데이터를 정리
    cleaned_data = []
    for row in table_data:
        if row: # 행이 비어있지 않은 경우에만 처리
            cleaned_row = []
            for cell in row:
                # cell이 None이면 빈 문자열로, 아니면 문자열로 변환
                # cell 내용에 포함된 개행문자는 공백으로 치환하여 테이블 깨짐 방지
                cell_text = str(cell) if cell is not None else ""
                cleaned_row.append(cell_text.replace('\n', ' ').strip())
            cleaned_data.append(cleaned_row)

    if not cleaned_data:
        return ""

    result_data = []
    for row in cleaned_data:
        join_row = '\n'.join(row)
        result_data.append(join_row)

    return '\n'.join(result_data)





def extract_markdown_table_from_cells_test(cells, n_cols, tolerance=2.0):
    # 1. 셀 정리
    cleaned_cells = []
    for cell in cells:
        text = (cell.get("text") or "").strip().replace("\n", " ")
        if text:
            x0, top, x1, bottom = cell["bbox"]
            x_center = (x0 + x1) / 2
            y_center = (top + bottom) / 2
            cleaned_cells.append({
                "text": text,
                "x": x_center,
                "y": y_center,
                "bbox": cell["bbox"]
            })

    # 2. y값 기준으로 행 그룹핑 (위에서 아래로 정렬)
    cleaned_cells.sort(key=lambda c: c["y"])
    rows = []
    current_row = []
    current_y = None

    for cell in cleaned_cells:
        if current_y is None or abs(cell["y"] - current_y) <= tolerance:
            current_row.append(cell)
            current_y = cell["y"]
        else:
            # 정렬된 행 하나 완성
            rows.append(current_row)
            current_row = [cell]
            current_y = cell["y"]
    if current_row:
        rows.append(current_row)

    # 3. 각 행의 셀들을 x 기준 정렬해서 n_cols 맞추기
    table_data = []
    for row in rows:
        row.sort(key=lambda c: c["x"])
        texts = [c["text"] for c in row]
        while len(texts) < n_cols:
            texts.append("")
        table_data.append(texts[:n_cols])

    # 4. 마크다운 테이블 변환
    return convert_to_markdown_table_test(table_data)

###################################
# 표 추출
###################################
def Qnut(page):
    try:
        clist = compare_texts(page, ts)
        # print("clist:", clist)
    
        tables = page.find_tables(table_settings=ts)
        table_bboxes = [table.bbox for table in tables]
    
        text_lines = page.extract_text_lines(x_tolerance=1)
        filtered_lines = [
            line for line in text_lines
            if not any(
                table_bbox[1] <= line['top'] <= table_bbox[3] and
                table_bbox[0] <= line['x0']<= table_bbox[2]
                for table_bbox in table_bboxes
            )
        ]
    
        elements = []
        elements.extend([('text', line['text'], line['top']) for line in filtered_lines])
    
        table_bbox = []
        table_cell = []
        table_extract = []
        if tables != []:
            for table in tables:
                table_bbox.append(table.bbox)
                table_cell.append(table.cells)
                table_extract.append(table.extract(x_tolerance=1, table_settings=ts))
                # print(table.extract(x_tolerance=1))
    
            cell_map_result = []
            for i in range(len(table_bbox)):
                cell_bboxes = table_cell[i]
                table_text = table_extract[i]
                
                
                flattened_texts = []
                # assert len(flattened_bboxes) == len(flattened_texts), "bbox 수와 텍스트 수가 다릅니다!"
                
                for row in table_text:
                    for cell in row:
                        if cell is None:
                            continue
                        else:
                            flattened_texts.append(cell)


                sorted_bboxes = sorted(cell_bboxes, key=lambda c: (round(c[1], 2), round(c[0], 2)))

                cell_map = []
                for bbox, text in zip(sorted_bboxes, flattened_texts):
                    box_tuple = (bbox[0], bbox[1], bbox[2], bbox[3])
                    cell_map.append({
                        "bbox": bbox,
                        "text": text
                    })
                cell_map_result.append(cell_map)
    
            if len(table_bbox) < 2:
                # print("서브 테이블이 없습니다")
                # print(f"table_bbox : {table_bbox}")
                for t in range(len(tables)):
                    table = tables[t]
                    if clist[t]:
                        markdown_table = convert_to_markdown_table(table.extract(x_tolerance=1, table_settings=ts)) # 혹시 줄바꿈 해야 하면 이 함수 _test 붙이기
                        elements.append(('table', markdown_table, table.bbox[1]))
                    else:
                        false_table_text = page.crop(table_bbox[t]).extract_text(x_tolerance=1)
                        elements.append(('text', false_table_text, table.bbox[1]))
            else:
                # print(f"table_bbox : {table_bbox}")
                grouped_bbox = [[table_bbox[0]]]
                grouped_tables = [[cell_map_result[0]]]
                grouped_extract = [[table_extract[0]]]
                grouped_clist = [[clist[0]]]
                for i in range(1, len(table_bbox)):
                    if len(grouped_bbox) < 2:
                        if is_bbox_inside(table_bbox[i], grouped_bbox[0][0]):
                            grouped_bbox[0].append(table_bbox[i])
                            grouped_tables[0].append(cell_map_result[i])
                            grouped_extract[0].append(table_extract[i])
                            grouped_clist[0].append(clist[i])
                        else:
                            grouped_bbox.append([table_bbox[i]])
                            grouped_tables.append([cell_map_result[i]])
                            grouped_extract.append([table_extract[i]])
                            grouped_clist.append([clist[i]])
                    else:
                        for j in range(len(grouped_bbox)):
                            if is_bbox_inside(table_bbox[i], grouped_bbox[j][0]):
                                grouped_bbox[j].append(table_bbox[i])
                                grouped_tables[j].append(cell_map_result[i])
                                grouped_extract[j].append(table_extract[i])
                                grouped_clist[j].append(clist[i])
                                # break
                            else:
                                if j == len(grouped_bbox) - 1:
                                    grouped_bbox.append([table_bbox[i]])
                                    grouped_tables.append([cell_map_result[i]])
                                    grouped_extract.append([table_extract[i]])
                                    grouped_clist.append([clist[i]])
    
                for idx in range(len(grouped_tables)):
                    group_table = grouped_tables[idx]
                    if len(group_table) == 1: # 그룹의 길이가 1이라는 것은 서브테이블이 없는 테이블 == 메인테이블
                        True
                    else: # 서브테이블이 속해져 있는 경우

                        outer_box = group_table[0] # 첫번째 테이블이 가장 큰 테이블
                        sub_tables_in_cell = {}
    
                        for cell_idx in range(len(outer_box)): # 가장 큰 박스의 셀 돌기
                            top_cell = outer_box[cell_idx]
                            top_bbox = top_cell["bbox"]
                            top_text = top_cell["text"]
    
    
                            for table_num in range(1, len(group_table)): # 이후 테이블 돌기
                                # 필요한 정보 저장
                                inner_box = group_table[table_num]
                                inner_bbox = grouped_bbox[idx][table_num]
                                inner_extract = grouped_extract[idx][table_num]
    
    
                                if is_bbox_inside(inner_bbox, top_bbox): # 미니테이블이 속해져 있는 메인 테이블 셀 찾기
    
                                    if top_bbox in sub_tables_in_cell:
                                        sub_tables_in_cell[top_bbox].append([inner_box, inner_bbox, inner_extract, grouped_clist[idx][table_num], idx, cell_idx])
                                    else:
                                        sub_tables_in_cell[top_bbox] = [[inner_box, inner_bbox, inner_extract, grouped_clist[idx][table_num], idx, cell_idx]]
    
                        new_sub_tables_in_cell = group_nested_subtables(sub_tables_in_cell)
    
                        for key in new_sub_tables_in_cell.keys():
                            value = new_sub_tables_in_cell[key]
    
                            for v_idx in range(len(value)):
                                # 서브테이블 안에 서브테이블이 있는 경우
                                if len(value[v_idx]) > 1:
                                    outer_mini_table_info = value[v_idx][0] # 가장 큰 서브테이블 지정
                                    outer_mini_cell_bbox_list = [item['bbox'] for item in outer_mini_table_info[0]] # 가장 큰 서브테이블의 셀 영역 저장
    
                                    for outer_mini_cell_bbox in outer_mini_cell_bbox_list:
                                        mini_table_inserted = set()
                                        mini_str = ''
                                        crop_mini_table = page.crop(bbox=outer_mini_cell_bbox)
                                        mini_cell_text_list = []
    
                                        for crop_cell_info in crop_mini_table.extract_text_lines(x_tolerance=1):
                                            
                                            x0 = crop_cell_info['x0']
                                            x1 = crop_cell_info['x1']
                                            top = crop_cell_info['top']
                                            bottom = crop_cell_info['bottom']
    
                                            text_info = (x0, top, x1, bottom)
    
                                            is_inside_any_subtable = False
    
                                            for num in range(1, len(value[v_idx])):
                                                inner_mini_table_info = value[v_idx][num]
                                                inner_mini_table_bbox = inner_mini_table_info[1]
    
                                                if inner_mini_table_info[3] and is_bbox_inside(text_info, inner_mini_table_bbox,):
                                                    is_inside_any_subtable = True
                                                    inner_mini_table = convert_to_markdown_table(inner_mini_table_info[2])
                                                    # inner_mini_table = f"\n<sub_table>\n{inner_mini_table}\n</sub_table>"
    
                                                    if str(inner_mini_table_bbox) not in mini_table_inserted:
                                                        # mini_str += inner_mini_table
                                                        mini_cell_text_list.append(inner_mini_table)
                                                        mini_table_inserted.add(str(inner_mini_table_bbox))
    
                                            if not is_inside_any_subtable:
                                                mini_cell_text_list.append(crop_cell_info['text'])
    
                                                # mini_str += crop_cell_info['text']
                                        mini_str = "\n".join(mini_cell_text_list)       
                                        new_sub_tables_in_cell[key][v_idx][0][0][outer_mini_cell_bbox_list.index(outer_mini_cell_bbox)]['text'] = mini_str
                                        c = 0
                                        for i in range(len(new_sub_tables_in_cell[key][v_idx][0][2])):
                                            t = new_sub_tables_in_cell[key][v_idx][0][2][i]
                                            for r in range(len(t)):
                                                if t[r] is not None:
                                                    c += 1
                                                    if c == outer_mini_cell_bbox_list.index(outer_mini_cell_bbox) + 1:
                                                        new_sub_tables_in_cell[key][v_idx][0][2][i][r] = mini_str
                                        # new_sub_tables_in_cell[key][v_idx][0][2][outer_mini_cell_bbox_list.index(outer_mini_cell_bbox)][0] = mini_str
    
                                    new_sub_tables_in_cell[key][v_idx] = [new_sub_tables_in_cell[key][v_idx][0]]
    
    
    
                        for key in new_sub_tables_in_cell.keys():
                            new_str = ''
                            inserted_tables = set()
    
                            crop_cell = page.crop(bbox=key)
                            idx = new_sub_tables_in_cell[key][0][0][4]
                            cell_idx = new_sub_tables_in_cell[key][0][0][5]
                            cell_text_list = []
                            for crop_cell_info in crop_cell.extract_text_lines(x_tolerance=1):
                                x0 = crop_cell_info['x0']
                                x1 = crop_cell_info['x1']
                                top = crop_cell_info['top']
                                bottom = crop_cell_info['bottom']
                                text_info = (x0, top, x1, bottom)
    
                                is_inside_any_subtable = False
    
                                for sub_table_info in new_sub_tables_in_cell[key]:
                                    sub_table_bbox = sub_table_info[0][1]
                                    sub_table_id = str(sub_table_bbox)
    
                                    if sub_table_info[0][3] and is_bbox_inside(text_info, sub_table_bbox):
                                        is_inside_any_subtable = True
    
                                        if sub_table_id not in inserted_tables:
                                            sub_table = convert_to_markdown_table(sub_table_info[0][2])
                                            # sub_table = extract_markdown_table_from_cells(sub_table_info[0][0], len(sub_table_info[0][2][0]))
                                            # sub_table = f"\n<sub_table>\n{sub_table}\n</sub_table>"
                                            # new_str += sub_table
                                            cell_text_list.append(sub_table)
                                            inserted_tables.add(sub_table_id)
    
                                # 만약 이 줄이 어떤 서브테이블 안에도 안 들어가면 원래 텍스트 추가하기
                                if not is_inside_any_subtable:
                                    cell_text_list.append(crop_cell_info['text'])
                                    # new_str += crop_cell_info['text']
    
                            # grouped_tables[idx][0][cell_idx]['text'] = new_str
                            new_str = "\n".join(cell_text_list)
                            c = 0
                            for i in range(len(grouped_extract[idx][0])):
                                g = grouped_extract[idx][0][i]
                                for t in range(len(g)):
                                    tt = g[t]
                                    if tt is not None:
                                        c += 1
                                        if c == cell_idx + 1:
                                            nnnn = [i , t]
                                            break
                            grouped_extract[idx][0][nnnn[0]][nnnn[1]] =  new_str
    
                for g in range(len(grouped_tables)):
                    if len(grouped_tables[g]) == 1:
                        if grouped_clist[g][0]:
                            markdown_table = convert_to_markdown_table(grouped_extract[g][0]) # 혹시 줄바꿈 해야 하면 이 함수 _test 붙이기
                            elements.append(('table', markdown_table, grouped_bbox[g][0][1]))
                        else:
                            false_table_text = page.crop(grouped_bbox[g][0]).extract_text(x_tolerance=1)
                            elements.append(('text', false_table_text, grouped_bbox[g][0][1]))
                    else:
                        if grouped_clist[g][0]:
                            g_table_info = grouped_tables[g][0]
                            markdown_table = convert_to_markdown_table(grouped_extract[g][0]) # 혹시 줄바꿈 해야 하면 이 함수 _test 붙이기
                            elements.append(('table', markdown_table, grouped_bbox[g][0][1]))
                        else:
                            false_table_text = page.crop(grouped_bbox[g][0]).extract_text(x_tolerance=1)
                            elements.append(('text', false_table_text, grouped_bbox[g][0][1]))
    
        elements.sort(key=lambda x: x[2])
    
        # page_output = [f"<table>\n{elem[1]}\n</table>" if elem[0] == 'table' else elem[1] for elem in elements]
        page_output = [elem[1] if elem[0] == 'table' else elem[1] for elem in elements]
        page_result = '\n'.join(page_output)
    
        # 검증 출력
        # print('최종 검증:', page_verification(page_result, page.extract_text(x_tolerance=1)))
    
        if not page_verification(page_result, page.extract_text(x_tolerance=1)):
            page_result = page.extract_text(x_tolerance=1)
    except : 
        page_result = page.extract_text(x_tolerance=1)
        
    return page_result
