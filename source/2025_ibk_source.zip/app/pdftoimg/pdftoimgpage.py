import sys
import os
import fitz
from PIL import Image
from logger_setup import LoggerSetup
logger = LoggerSetup()

def pdf_to_image_based_pdf(pdf_path, output_folder):
    try:
        print("!!!!")
        doc = fitz.open(pdf_path)
        print("#####")
        print(doc)
        new_pdf = fitz.open()

        for page_number in range(len(doc)):
            page = doc.load_page(page_number)
            pix = page.get_pixmap(dpi=200)
            img_rect = fitz.Rect(0,0,pix.width, pix.height)
            new_page = new_pdf.new_page(width=pix.width,height=pix.height)
            img_pdf_bytes = pix.tobytes("png")
            img_xref = new_page.insert_image(img_rect, stream=img_pdf_bytes)

        os.makedirs(output_folder,exist_ok=True)

        input_filename = os.path.splitext(os.path.basename(pdf_path))[0]
        output_path = os.path.join(output_folder,f"{input_filename}.pdf")
        new_pdf.save(output_path)
        new_pdf.close()
        
        logger.log(pdf_path, output_path, "Success")
    except fitz.EmptyFileError:
        logger.log(pdf_path, None, "Fail", f"Cannot open empty file: {pdf_path}")
        #error_logger.error(f"Cannot open empty file: {pdf_path}")
    except fitz.FileDataError:
        logger.log(pdf_path, None, "Fail", f"Failed to open file: {pdf_path}")
        #error_logger.error(f"Failed to open file: {pdf_path}")
    except Exception as e:
        print("runtimeerror")
        #print(e)
        logger.log(pdf_path, None, "Fail", f"file exists: {pdf_path}")
    except ValueError as e:
        logger.log(pdf_path, None, "Fail", f"Value Error: {pdf_path}")
        #error_logger.error(e)
    #finally:
     #   doc.close() 
 
def main():
    if len(sys.argv) != 3:
        print("사용법: python3 pdfimageperpage.py <pdf_파일_풀경로> <저장_폴더_풀경로>")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    output_folder = sys.argv[2]

    if not os.path.exists(pdf_path):
        logger.log(pdf_path, None, "Fail", f"PDF 파일이 존재하지 않습니다. {pdf_path}")
        sys.exit(1)
    
    pdf_to_image_based_pdf(pdf_path,output_folder)

if __name__ == "__main__":
    main()
