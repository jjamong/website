import fitz  # PyMuPDF
import os
import sys
from datetime import datetime
import subprocess
from datetime import datetime
from PIL import Image
Image.MAX_IMAGE_PIXELS = None
import io
from pdftoimgpage import pdf_to_image_based_pdf

# ----------------- 파라미터 처리 -----------------
if len(sys.argv) != 6:
    print("Usage: python pdftoimg.py <input_file.pdf> <output_root_folder> <assz_btch_acmp_id> <assz_unfc_id> <hdlr_id>")
    sys.exit(1)

input_file = os.path.abspath(sys.argv[1])
output_root = os.path.abspath(sys.argv[2])
assz_btch_acmp_id = sys.argv[3]
assz_unfc_id = sys.argv[4]
hdlr_id = sys.argv[5]
pdf_name_without_ext = os.path.splitext(os.path.basename(input_file))[0]
#output_dir = os.path.join(output_root, pdf_name_without_ext)

# ----------------- 로그 설정 -----------------
LOG_ROOT = os.path.join(os.getcwd(), "logs")
os.makedirs(LOG_ROOT, exist_ok=True)

now_str = datetime.now().strftime("%Y%m%d")
log_path = os.path.join(LOG_ROOT, f"pdftoimg_{now_str}.log")

def log_result(input_path, output_path, result, image_count=0, msg=None):
    now = datetime.now().strftime("%Y-%m-%d][%H:%M:%S")

    input_abs = os.path.abspath(input_path)
    input_dir = os.path.dirname(input_abs)
    input_file = os.path.basename(input_abs)

    if output_path:
        output_abs = os.path.abspath(output_path)
        output_dir = os.path.dirname(output_abs)
    else:
        output_dir = ""
    
    count_str = str(image_count) if result == "Success" else ""

    line = f"[{now}][pdftoimg][{input_dir}][{input_file}][{output_dir}][{count_str}][{result}]"

    print(line)
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(line + "\n")
        if result == "Fail" and msg:
            f.write(f"Fail Message: {msg}\n")
            print(msg)


def getTotalImageCount(input_file):
    doc = fitz.open(input_file)
    total = 0
    for page_idx in range(len(doc)):
        page = doc[page_idx]
        images = page.get_images(full=True)
        blocks = page.get_text("dict")["blocks"]
        for _, img in enumerate(images):            
            xref = img[0]
            base_image = doc.extract_image(xref)            
            image_bytes = base_image["image"]
            #print(image_bytes)
            #ext = base_image["ext"]
            ext = "jpg"
            for block in blocks:
                if block["type"] == 1:
                    bimage_bytes = block["image"]
                    if image_bytes == bimage_bytes:
                        bbox = block["bbox"]
                        total += 1
    return total


# ----------------- 이미지 추출 -----------------
try:
    '''
    20250814 
    PDF 내 이미지 개수가 1000개 이상이면 불필요한 이미지가 포함된 것으로 판단
    페이지별 통 이미지로 변환하여 처리
    '''
    if 1000 < getTotalImageCount(input_file):
        pdf_to_image_based_pdf(input_file, os.path.dirname(input_file))

    doc = fitz.open(input_file)

    output_pdf = fitz.open()
    page_images = []

    for page_idx in range(len(doc)):
        page = doc[page_idx]
        # 텍스트가 하나도 없을경우 전체를 이미지로
        text = page.get_text().strip()

        if not text:
            zoom = 150 / 72
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)
            img_pdf = fitz.open()
            rect = fitz.Rect(0,0,pix.width, pix.height)
            img_page = img_pdf.new_page(width=rect.width, height=rect.height)
            img_page.insert_image(rect,pixmap=pix)
            output_pdf.insert_pdf(img_pdf)
            #print("No text, image saved.")
        else:
            output_pdf.insert_pdf(doc,from_page=page_idx, to_page=page_idx)
            #print(f"Text exists, skipped. ")
    
    #output_pdf.save(f"{input_file}_tmp.pdf")

    doc = output_pdf

    for page_idx in range(len(doc)):
        page = doc[page_idx]

        

        images = page.get_images(full=True)
        blocks = page.get_text("dict")["blocks"]

        img_idx = 1
        for _, img in enumerate(images):            
            xref = img[0]
            base_image = doc.extract_image(xref)            
            image_bytes = base_image["image"]
            #print(image_bytes)
            #ext = base_image["ext"]
            ext = "jpg"
            for block in blocks:
                if block["type"] == 1:
                    bimage_bytes = block["image"]
                    if image_bytes == bimage_bytes:
                        bbox = block["bbox"]
                        page_images.append((page_idx + 1, img_idx, image_bytes, ext, bbox))
                        img_idx += 1
        
    if page_images:
        #os.makedirs(output_dir, exist_ok=True)
        base_file_name = os.path.basename(input_file)
        last_output_file = ""
        for page_no, img_no, data, ext, bbox in page_images:
            file_name = base_file_name.replace(".pdf", f"_DP_{page_no}_{img_no}.{ext}").replace(".PDF", f"_DP_{page_no}_{img_no}.{ext}")
            out_path = os.path.join(output_root, file_name)

            image = Image.open(io.BytesIO(data))

            if image.width > 2000:
                ratio = 2000 / float(image.width)
                new_height = int(image.height * ratio)
                image = image.resize((2000,new_height),Image.LANCZOS)

            image.convert("RGB").save(out_path,format="JPEG",quality=60)

            #with open(out_path, "wb") as f:
            #    f.write(data)

            last_output_file = out_path

            x0, y0, x1, y1 = bbox
            assz_page_no = page_no
            assz_img_no = img_no
            assz_img_tppo_xcr_vl = x0
            assz_img_tppo_ycr_vl = y0
            assz_img_lwen_xcr_vl = x1
            assz_img_lwen_ycr_vl = y1
            assz_img_pcsn_acmp_rslt_dcd = "01"
            eror_vl = "0000"
            assz_eror_con = ""
            acmp_sttg_ts = "" #시작시간
            acmp_fnsh_ts = "" #
            assz_img_file_path_nm = last_output_file

            datas = [assz_btch_acmp_id, assz_unfc_id, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, assz_img_pcsn_acmp_rslt_dcd, eror_vl, assz_eror_con, acmp_sttg_ts, acmp_fnsh_ts, assz_img_file_path_nm, hdlr_id]
            arg_data = "^|".join(map(str, datas))
            args = ["node", "/app/batch/node-batch/sql/pythonCallSql.js", "01", arg_data]
            subprocess.run(args)

        log_result(input_file, last_output_file, "Success", image_count=len(page_images))
    else:
        args = ["node", "/app/batch/node-batch/sql/pythonCallSql.js", "99", "No images found in the PDF."]
        subprocess.run(args)
        log_result(input_file, None, "Success", 0, "No images found in the PDF.")

    doc.close()
except ValueError as e:
    log_result(input_file, None, "Fail",0 , "ValueError")
except Exception as e:
    assz_page_no = ""
    assz_img_no = ""
    assz_img_tppo_xcr_vl = ""
    assz_img_tppo_ycr_vl = ""
    assz_img_lwen_xcr_vl = ""
    assz_img_lwen_ycr_vl = ""
    assz_img_pcsn_acmp_rslt_dcd = "01"
    eror_vl = "0301" # 에러코드 0301
    assz_eror_con = ""
    acmp_sttg_ts = "" #시작시간
    acmp_fnsh_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S") #종료시간
    assz_img_file_path_nm = ""

    datas = [assz_btch_acmp_id, assz_unfc_id, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, assz_img_pcsn_acmp_rslt_dcd, eror_vl, assz_eror_con, acmp_sttg_ts, acmp_fnsh_ts, assz_img_file_path_nm, hdlr_id]
    arg_data = "^|".join(datas)
    args = ["node", "/app/batch/node-batch/sql/pythonCallSql.js", "01", arg_data]
    subprocess.run(args)
    
    log_result(input_file, None, "Fail", 0, "pdf to img failed")
