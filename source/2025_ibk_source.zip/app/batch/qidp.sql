

CREATE SCHEMA qidp AUTHORIZATION qidp;


CREATE SEQUENCE qidp.tb_api_api_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_api_api_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_api_api_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_chunk_update_request_update_request_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_chunk_update_request_update_request_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_chunk_update_request_update_request_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_deidentification_data_deid_data_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_deidentification_data_deid_data_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_deidentification_data_deid_data_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_deidentification_regex_regex_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_deidentification_regex_regex_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_deidentification_regex_regex_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_document_chunk_chunk_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_document_chunk_chunk_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_document_chunk_chunk_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_employee_access_log_log_seq_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_employee_access_log_log_seq_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_employee_access_log_log_seq_seq TO qidp;


CREATE SEQUENCE qidp.tb_file_group_file_group_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_file_group_file_group_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_file_group_file_group_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_file_info_file_group_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_file_info_file_group_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_file_info_file_group_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_file_info_file_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_file_info_file_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_file_info_file_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_login_history_history_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_login_history_history_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_login_history_history_id_seq TO qidp;


CREATE SEQUENCE qidp.tb_model_model_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE qidp.tb_model_model_id_seq OWNER TO qidp;
GRANT ALL ON SEQUENCE qidp.tb_model_model_id_seq TO qidp;
-- qidp.tb_anonymized_data definition



CREATE TABLE qidp.tb_anonymized_data (
	anonymized_data_id varchar(50) NOT NULL, -- 비식별화데이터ID(PK)
	document_id varchar(50) NOT NULL, -- 문서ID(FK)
	approval_no varchar(50) NULL, -- 결재ID(FK)
	executed_at timestamp NULL, -- 비식별화실행일시
	target bpchar(1) DEFAULT 'N'::bpchar NULL, -- 비식별화처리대상
	file_path varchar(500) NULL, -- 비식별화문서경로
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 변경자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부(soft delete)
	CONSTRAINT pk_anonymized_data PRIMARY KEY (anonymized_data_id)
);
COMMENT ON TABLE qidp.tb_anonymized_data IS '비식별화데이터 마스터 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_anonymized_data.anonymized_data_id IS '비식별화데이터ID(PK)';
COMMENT ON COLUMN qidp.tb_anonymized_data.document_id IS '문서ID(FK)';
COMMENT ON COLUMN qidp.tb_anonymized_data.approval_no IS '결재ID(FK)';
COMMENT ON COLUMN qidp.tb_anonymized_data.executed_at IS '비식별화실행일시';
COMMENT ON COLUMN qidp.tb_anonymized_data.target IS '비식별화처리대상';
COMMENT ON COLUMN qidp.tb_anonymized_data.file_path IS '비식별화문서경로';
COMMENT ON COLUMN qidp.tb_anonymized_data.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_anonymized_data.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_anonymized_data.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_anonymized_data.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_anonymized_data.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_anonymized_data.del_yn IS '삭제여부(soft delete)';

-- Permissions

ALTER TABLE qidp.tb_anonymized_data OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_anonymized_data TO qidp;


-- qidp.tb_api definition



CREATE TABLE qidp.tb_api (
	api_id serial4 NOT NULL, -- API 고유 ID
	api_name varchar(255) NOT NULL, -- API명
	"method" varchar(6) NOT NULL, -- 요청 방식
	url varchar(255) NOT NULL, -- URL 주소
	request_data text NULL, -- 요청데이터
	response_data text NOT NULL, -- 응답데이터
	description text NULL, -- 설명
	request_example text NULL, -- 요청전문 예시
	status int4 NOT NULL, -- 결과코드
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일자
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일자
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT tb_api_pkey PRIMARY KEY (api_id)
);

-- Column comments

COMMENT ON COLUMN qidp.tb_api.api_id IS 'API 고유 ID';
COMMENT ON COLUMN qidp.tb_api.api_name IS 'API명';
COMMENT ON COLUMN qidp.tb_api."method" IS '요청 방식';
COMMENT ON COLUMN qidp.tb_api.url IS 'URL 주소';
COMMENT ON COLUMN qidp.tb_api.request_data IS '요청데이터';
COMMENT ON COLUMN qidp.tb_api.response_data IS '응답데이터';
COMMENT ON COLUMN qidp.tb_api.description IS '설명';
COMMENT ON COLUMN qidp.tb_api.request_example IS '요청전문 예시';
COMMENT ON COLUMN qidp.tb_api.status IS '결과코드';
COMMENT ON COLUMN qidp.tb_api.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_api.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_api.registered_at IS '등록일자';
COMMENT ON COLUMN qidp.tb_api.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_api.updated_at IS '수정일자';
COMMENT ON COLUMN qidp.tb_api.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_api OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_api TO qidp;


-- qidp.tb_batch definition



CREATE TABLE qidp.tb_batch (
	batch_id varchar(100) NOT NULL, -- 배치 ID
	batch_name varchar(255) NOT NULL, -- 배치명
	int_system_id varchar(50) NOT NULL, -- 배치가 속한 연계 시스템 ID
	batch_cycle varchar(20) NULL, -- 배치 주기
	description text NULL, -- 배치 상세 설명
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부 (Y/N)
	deleted_at timestamp NULL, -- 삭제일시
	CONSTRAINT tb_batch_pkey PRIMARY KEY (batch_id)
);
COMMENT ON TABLE qidp.tb_batch IS '배치 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_batch.batch_id IS '배치 ID';
COMMENT ON COLUMN qidp.tb_batch.batch_name IS '배치명';
COMMENT ON COLUMN qidp.tb_batch.int_system_id IS '배치가 속한 연계 시스템 ID';
COMMENT ON COLUMN qidp.tb_batch.batch_cycle IS '배치 주기';
COMMENT ON COLUMN qidp.tb_batch.description IS '배치 상세 설명';
COMMENT ON COLUMN qidp.tb_batch.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_batch.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_batch.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_batch.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_batch.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_batch.del_yn IS '삭제여부 (Y/N)';
COMMENT ON COLUMN qidp.tb_batch.deleted_at IS '삭제일시';

-- Permissions

ALTER TABLE qidp.tb_batch OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_batch TO qidp;


-- qidp.tb_chunk_update_request definition



CREATE TABLE qidp.tb_chunk_update_request (
	update_request_id serial4 NOT NULL, -- 수정 요청 ID
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행 ID
	document_id varchar(20) NOT NULL, -- 문서 ID (자산화통합 ID)
	chunk_id int4 NOT NULL, -- 수정 대상 청크 ID
	original_content text NULL, -- 원본 청크 내용
	updated_content text NOT NULL, -- 수정된 청크 내용
	registered_by varchar(50) NULL, -- 등록자 (수정요청자)
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시 (수정요청일시)
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부 (Y/N)
	CONSTRAINT tb_chunk_update_request_pkey PRIMARY KEY (update_request_id)
);
COMMENT ON TABLE qidp.tb_chunk_update_request IS '청크 수정 요청 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_chunk_update_request.update_request_id IS '수정 요청 ID';
COMMENT ON COLUMN qidp.tb_chunk_update_request.assz_btch_acmp_id IS '자산화배치수행 ID';
COMMENT ON COLUMN qidp.tb_chunk_update_request.document_id IS '문서 ID (자산화통합 ID)';
COMMENT ON COLUMN qidp.tb_chunk_update_request.chunk_id IS '수정 대상 청크 ID';
COMMENT ON COLUMN qidp.tb_chunk_update_request.original_content IS '원본 청크 내용';
COMMENT ON COLUMN qidp.tb_chunk_update_request.updated_content IS '수정된 청크 내용';
COMMENT ON COLUMN qidp.tb_chunk_update_request.registered_by IS '등록자 (수정요청자)';
COMMENT ON COLUMN qidp.tb_chunk_update_request.registered_at IS '등록일시 (수정요청일시)';
COMMENT ON COLUMN qidp.tb_chunk_update_request.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_chunk_update_request.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_chunk_update_request.del_yn IS '삭제여부 (Y/N)';

-- Permissions

ALTER TABLE qidp.tb_chunk_update_request OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_chunk_update_request TO qidp;


-- qidp.tb_code_group definition



CREATE TABLE qidp.tb_code_group (
	group_code varchar(50) NOT NULL, -- 대분류 코드
	group_name varchar(255) NOT NULL, -- 대분류 코드명
	description text NULL, -- 설명
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_code_group_pkey PRIMARY KEY (group_code)
);
COMMENT ON TABLE qidp.tb_code_group IS '대분류코드 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_code_group.group_code IS '대분류 코드';
COMMENT ON COLUMN qidp.tb_code_group.group_name IS '대분류 코드명';
COMMENT ON COLUMN qidp.tb_code_group.description IS '설명';
COMMENT ON COLUMN qidp.tb_code_group.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_code_group.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_code_group.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_code_group.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_code_group.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_code_group.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_code_group OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_code_group TO qidp;


-- qidp.tb_deidentification_data definition



CREATE TABLE qidp.tb_deidentification_data (
	deid_data_id int4 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1 NO CYCLE) NOT NULL, -- 비식별 항목 ID
	item_name varchar(100) NOT NULL, -- 항목 이름
	registered_branch varchar(50) NULL, -- 등록 부서
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록 일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정 일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제 여부 (Y/N)
	CONSTRAINT tb_deidentification_data_del_yn_check CHECK ((del_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT tb_deidentification_data_pkey PRIMARY KEY (deid_data_id)
);
COMMENT ON TABLE qidp.tb_deidentification_data IS '자산화 비식별화데이터 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_deidentification_data.deid_data_id IS '비식별 항목 ID';
COMMENT ON COLUMN qidp.tb_deidentification_data.item_name IS '항목 이름';
COMMENT ON COLUMN qidp.tb_deidentification_data.registered_branch IS '등록 부서';
COMMENT ON COLUMN qidp.tb_deidentification_data.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_deidentification_data.registered_at IS '등록 일시';
COMMENT ON COLUMN qidp.tb_deidentification_data.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_deidentification_data.updated_at IS '수정 일시';
COMMENT ON COLUMN qidp.tb_deidentification_data.del_yn IS '삭제 여부 (Y/N)';

-- Permissions

ALTER TABLE qidp.tb_deidentification_data OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_deidentification_data TO qidp;


-- qidp.tb_document definition



CREATE TABLE qidp.tb_document (
	document_id varchar(20) NOT NULL, -- 문서 ID
	approval_no varchar(50) NULL, -- 결재 번호
	document_name varchar(255) NULL, -- 문서명
	source_system varchar(100) NOT NULL, -- 원천시스템
	classification varchar(255) NULL, -- 분류체계
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	registration_type varchar(50) NULL, -- 등록유형
	assetized_at timestamp NULL, -- 자산화일시
	status_changed_at timestamp NULL, -- 상태변경일시
	assetization_status varchar(50) NULL, -- 자산화상태
	approval_status varchar(50) NULL, -- 결재상태
	original_doc_type varchar(20) NULL, -- 원본문서유형(HWP/PDF_TXT/PDF_IMG/DOC/HTML/ETC)
	approval_task_type varchar(50) NULL, -- 결재업무유형
	original_doc_path varchar(500) NULL, -- 원본문서 파일 경로
	chunked_file_path varchar(500) NULL, -- 청킹 파일 경로
	failure_log text NULL, -- 실패 로그 (팝업 조회용)
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NULL, -- 등록자
	registered_at timestamp DEFAULT now() NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 변경자
	updated_at timestamp NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부 (Y/N)
	assz_pcsn_tcd bpchar(1) NULL, -- 자산화처리유형코드
	CONSTRAINT document_del_yn_check CHECK ((del_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT document_pk PRIMARY KEY (document_id, source_system)
);
CREATE INDEX tb_document_approval_no_idx ON qidp.tb_document USING btree (approval_no);
CREATE INDEX tb_document_assz_cfbo_idnt_id_idx ON qidp.tb_document USING btree (assz_cfbo_idnt_id);
CREATE INDEX tb_document_registered_branch_idx ON qidp.tb_document USING btree (registered_branch);
CREATE INDEX tb_document_registered_by_idx ON qidp.tb_document USING btree (registered_by);
COMMENT ON TABLE qidp.tb_document IS '문서 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_document.document_id IS '문서 ID';
COMMENT ON COLUMN qidp.tb_document.approval_no IS '결재 번호';
COMMENT ON COLUMN qidp.tb_document.document_name IS '문서명';
COMMENT ON COLUMN qidp.tb_document.source_system IS '원천시스템';
COMMENT ON COLUMN qidp.tb_document.classification IS '분류체계';
COMMENT ON COLUMN qidp.tb_document.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_document.registration_type IS '등록유형';
COMMENT ON COLUMN qidp.tb_document.assetized_at IS '자산화일시';
COMMENT ON COLUMN qidp.tb_document.status_changed_at IS '상태변경일시';
COMMENT ON COLUMN qidp.tb_document.assetization_status IS '자산화상태';
COMMENT ON COLUMN qidp.tb_document.approval_status IS '결재상태';
COMMENT ON COLUMN qidp.tb_document.original_doc_type IS '원본문서유형(HWP/PDF_TXT/PDF_IMG/DOC/HTML/ETC)';
COMMENT ON COLUMN qidp.tb_document.approval_task_type IS '결재업무유형';
COMMENT ON COLUMN qidp.tb_document.original_doc_path IS '원본문서 파일 경로';
COMMENT ON COLUMN qidp.tb_document.chunked_file_path IS '청킹 파일 경로';
COMMENT ON COLUMN qidp.tb_document.failure_log IS '실패 로그 (팝업 조회용)';
COMMENT ON COLUMN qidp.tb_document.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_document.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_document.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_document.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_document.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_document.del_yn IS '삭제여부 (Y/N)';
COMMENT ON COLUMN qidp.tb_document.assz_pcsn_tcd IS '자산화처리유형코드';

-- Permissions

ALTER TABLE qidp.tb_document OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_document TO qidp;


-- qidp.tb_document_chunk definition



CREATE TABLE qidp.tb_document_chunk (
	chunk_id serial4 NOT NULL, -- 청크 ID
	document_id varchar(20) NOT NULL, -- 문서 ID
	page_no int4 NOT NULL, -- 페이지 번호
	chunk_seq int4 NOT NULL, -- 청크 번호
	chunk_content text NOT NULL, -- 청크 내용
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 변경자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부 (Y/N)
	CONSTRAINT tb_document_chunk_pkey PRIMARY KEY (chunk_id)
);
COMMENT ON TABLE qidp.tb_document_chunk IS '문서 청킹 결과 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_document_chunk.chunk_id IS '청크 ID';
COMMENT ON COLUMN qidp.tb_document_chunk.document_id IS '문서 ID';
COMMENT ON COLUMN qidp.tb_document_chunk.page_no IS '페이지 번호';
COMMENT ON COLUMN qidp.tb_document_chunk.chunk_seq IS '청크 번호';
COMMENT ON COLUMN qidp.tb_document_chunk.chunk_content IS '청크 내용';
COMMENT ON COLUMN qidp.tb_document_chunk.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_document_chunk.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_document_chunk.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_document_chunk.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_document_chunk.del_yn IS '삭제여부 (Y/N)';

-- Permissions

ALTER TABLE qidp.tb_document_chunk OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_document_chunk TO qidp;


-- qidp.tb_document_testset definition



CREATE TABLE qidp.tb_document_testset (
	testset_id varchar(20) NOT NULL, -- 테스트셋 ID
	document_id varchar(20) NOT NULL, -- 테스트 대상 문서 ID(FK)
	test_chunk_file_path varchar(500) NULL, -- 테스트 수행된 청킹 파일 경로
	test_status varchar(50) NULL, -- 테스트 상태 (미수행/진행중/완료)
	test_executed_at timestamp NULL, -- 최종 테스트 수행일시
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부 (Y/N)
	CONSTRAINT tb_document_testset_pkey PRIMARY KEY (testset_id)
);
COMMENT ON TABLE qidp.tb_document_testset IS '테스트셋 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_document_testset.testset_id IS '테스트셋 ID';
COMMENT ON COLUMN qidp.tb_document_testset.document_id IS '테스트 대상 문서 ID(FK)';
COMMENT ON COLUMN qidp.tb_document_testset.test_chunk_file_path IS '테스트 수행된 청킹 파일 경로';
COMMENT ON COLUMN qidp.tb_document_testset.test_status IS '테스트 상태 (미수행/진행중/완료)';
COMMENT ON COLUMN qidp.tb_document_testset.test_executed_at IS '최종 테스트 수행일시';
COMMENT ON COLUMN qidp.tb_document_testset.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_document_testset.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_document_testset.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_document_testset.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_document_testset.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_document_testset.del_yn IS '삭제여부 (Y/N)';

-- Permissions

ALTER TABLE qidp.tb_document_testset OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_document_testset TO qidp;


-- qidp.tb_employee_access_log definition



CREATE TABLE qidp.tb_employee_access_log (
	emp_no varchar(20) NOT NULL, -- 사번
	log_seq bigserial NOT NULL, -- 로그순번
	log_type_code varchar(50) NOT NULL, -- 로그구분코드(퀀텀에서는 API별로 구분코드를 쓴다고 함)
	access_uri varchar(255) NOT NULL, -- API URI
	summary varchar(255) NULL, -- API 요약정보
	description varchar(255) NULL, -- API 상세정보
	access_date timestamp NOT NULL, -- API 요청일자
	"method" varchar(6) NOT NULL, -- HTTP Request method
	success_yn varchar(1) NOT NULL, -- 성공여부
	request_body text NULL, -- Request Body(추가 처리 필요한지 문의 필요)
	response_json text NULL, -- Response 정보
	ip varchar(96) NOT NULL, -- IP정보 AES128이라면 varchar(96)으로 세팅 아니라면 협의 필요
	device text NULL, -- 접속 디바이스 정보
	os varchar(50) NULL, -- 접속 OS정보
	cpu varchar(20) NULL, -- 접속 CPU정보
	status int4 NULL, -- HTTP 상태 코드
	CONSTRAINT "PK_TB_EMPLOYEE_ACCESS_LOG" PRIMARY KEY (emp_no, log_seq)
);
COMMENT ON TABLE qidp.tb_employee_access_log IS '사용자 접근이력 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_employee_access_log.emp_no IS '사번';
COMMENT ON COLUMN qidp.tb_employee_access_log.log_seq IS '로그순번';
COMMENT ON COLUMN qidp.tb_employee_access_log.log_type_code IS '로그구분코드(퀀텀에서는 API별로 구분코드를 쓴다고 함)';
COMMENT ON COLUMN qidp.tb_employee_access_log.access_uri IS 'API URI';
COMMENT ON COLUMN qidp.tb_employee_access_log.summary IS 'API 요약정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.description IS 'API 상세정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.access_date IS 'API 요청일자';
COMMENT ON COLUMN qidp.tb_employee_access_log."method" IS 'HTTP Request method';
COMMENT ON COLUMN qidp.tb_employee_access_log.success_yn IS '성공여부';
COMMENT ON COLUMN qidp.tb_employee_access_log.request_body IS 'Request Body(추가 처리 필요한지 문의 필요)';
COMMENT ON COLUMN qidp.tb_employee_access_log.response_json IS 'Response 정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.ip IS 'IP정보 AES128이라면 varchar(96)으로 세팅 아니라면 협의 필요';
COMMENT ON COLUMN qidp.tb_employee_access_log.device IS '접속 디바이스 정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.os IS '접속 OS정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.cpu IS '접속 CPU정보';
COMMENT ON COLUMN qidp.tb_employee_access_log.status IS 'HTTP 상태 코드';

-- Permissions

ALTER TABLE qidp.tb_employee_access_log OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_employee_access_log TO qidp;


-- qidp.tb_file_group definition



CREATE TABLE qidp.tb_file_group (
	file_group_id bigserial NOT NULL, -- 파일그룹 아이디
	file_count int4 NOT NULL, -- 파일 갯수
	registered_branch varchar(50) NOT NULL, -- 등록부점
	registered_by varchar(50) NOT NULL, -- 등록자
	registered_at timestamp NOT NULL, -- 등록일시
	updated_by varchar(50) NOT NULL, -- 수정자
	updated_at timestamp NOT NULL, -- 수정일시
	del_yn varchar(1) DEFAULT 'N'::character varying NOT NULL, -- 삭제여부
	CONSTRAINT "PK_TB_FILE_GROUP" PRIMARY KEY (file_group_id)
);

-- Column comments

COMMENT ON COLUMN qidp.tb_file_group.file_group_id IS '파일그룹 아이디';
COMMENT ON COLUMN qidp.tb_file_group.file_count IS '파일 갯수';
COMMENT ON COLUMN qidp.tb_file_group.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_file_group.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_file_group.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_file_group.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_file_group.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_file_group.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_file_group OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_file_group TO qidp;


-- qidp.tb_interface_system definition



CREATE TABLE qidp.tb_interface_system (
	interface_id varchar(20) NOT NULL, -- 연계 시스템 ID(20자 문자열)
	interface_type varchar(50) NULL, -- 연계유형
	interface_system_name varchar(255) NULL, -- 연계시스템명
	source_system varchar(100) NOT NULL, -- 출발지 원천시스템
	source_is_batch bool DEFAULT false NOT NULL, -- 출발지 배치 등록 유형
	source_is_manual bool DEFAULT false NOT NULL, -- 출발지 수기 등록 유형
	source_send_targets _text DEFAULT '{}'::text[] NOT NULL, -- 출발지 전송대상(원본문서, 표준문서, 청킹파일, 첨부파일, 메타파일)
	source_ip varchar(50) NULL, -- 출발지 IP 주소
	source_port int4 NULL, -- 출발지 포트
	source_base_path varchar(255) NULL, -- 출발지 기본 연계경로
	source_sub_paths _text DEFAULT '{}'::text[] NULL, -- 출발지 추가 연계경로
	target_system varchar(100) NULL, -- 도착지 원천시스템
	target_ip varchar(50) NULL, -- 도착지 IP 주소
	target_port int4 NULL, -- 도착지 포트
	target_base_path varchar(255) NULL, -- 도착지 기본 연계경로
	target_sub_paths _text DEFAULT '{}'::text[] NULL, -- 도착지 추가 연계경로
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 변경자
	updated_at timestamp NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부 (Y/N)
	deleted_at timestamp NULL, -- 삭제일시
	CONSTRAINT tb_interface_system_del_yn_check CHECK ((del_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT tb_interface_system_pkey PRIMARY KEY (interface_id)
);
COMMENT ON TABLE qidp.tb_interface_system IS '연계시스템 정보 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_interface_system.interface_id IS '연계 시스템 ID(20자 문자열)';
COMMENT ON COLUMN qidp.tb_interface_system.interface_type IS '연계유형';
COMMENT ON COLUMN qidp.tb_interface_system.interface_system_name IS '연계시스템명';
COMMENT ON COLUMN qidp.tb_interface_system.source_system IS '출발지 원천시스템';
COMMENT ON COLUMN qidp.tb_interface_system.source_is_batch IS '출발지 배치 등록 유형';
COMMENT ON COLUMN qidp.tb_interface_system.source_is_manual IS '출발지 수기 등록 유형';
COMMENT ON COLUMN qidp.tb_interface_system.source_send_targets IS '출발지 전송대상(원본문서, 표준문서, 청킹파일, 첨부파일, 메타파일)';
COMMENT ON COLUMN qidp.tb_interface_system.source_ip IS '출발지 IP 주소';
COMMENT ON COLUMN qidp.tb_interface_system.source_port IS '출발지 포트';
COMMENT ON COLUMN qidp.tb_interface_system.source_base_path IS '출발지 기본 연계경로';
COMMENT ON COLUMN qidp.tb_interface_system.source_sub_paths IS '출발지 추가 연계경로';
COMMENT ON COLUMN qidp.tb_interface_system.target_system IS '도착지 원천시스템';
COMMENT ON COLUMN qidp.tb_interface_system.target_ip IS '도착지 IP 주소';
COMMENT ON COLUMN qidp.tb_interface_system.target_port IS '도착지 포트';
COMMENT ON COLUMN qidp.tb_interface_system.target_base_path IS '도착지 기본 연계경로';
COMMENT ON COLUMN qidp.tb_interface_system.target_sub_paths IS '도착지 추가 연계경로';
COMMENT ON COLUMN qidp.tb_interface_system.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_interface_system.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_interface_system.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_interface_system.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_interface_system.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_interface_system.del_yn IS '삭제여부 (Y/N)';
COMMENT ON COLUMN qidp.tb_interface_system.deleted_at IS '삭제일시';

-- Permissions

ALTER TABLE qidp.tb_interface_system OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_interface_system TO qidp;


-- qidp.tb_lifecycle_target definition



CREATE TABLE qidp.tb_lifecycle_target (
	lifecycle_id varchar(20) NOT NULL, -- 수명주기 대상 ID
	document_id varchar(20) NOT NULL, -- 문서 ID
	approval_no varchar(50) NULL, -- 결재 ID
	lifecycle_target_yn varchar(1) DEFAULT 'N'::character varying NULL, -- 수명주기 관리 대상 여부 (대상(Y)/비대상(N))
	renewal_cycle_code varchar(20) NULL, -- 갱신 주기 (코드값: 당월, 분기, 반기, 연, 1년, 3년, 5년, 7년)
	expiration_at timestamp DEFAULT '2999-12-31 23:59:59'::timestamp without time zone NULL, -- 유효 종료 일시 (기본값: 2999-12-31 23:59:59)
	registered_branch varchar(50) NULL, -- 등록 부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록 일시
	updated_by varchar(100) NULL, -- 변경자
	updated_at timestamp NULL, -- 변경 일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제 여부
	CONSTRAINT tb_lifecycle_target_del_yn_check CHECK ((del_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT tb_lifecycle_target_pkey PRIMARY KEY (lifecycle_id)
);
COMMENT ON TABLE qidp.tb_lifecycle_target IS '자산화 수명주기관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_lifecycle_target.lifecycle_id IS '수명주기 대상 ID';
COMMENT ON COLUMN qidp.tb_lifecycle_target.document_id IS '문서 ID';
COMMENT ON COLUMN qidp.tb_lifecycle_target.approval_no IS '결재 ID';
COMMENT ON COLUMN qidp.tb_lifecycle_target.lifecycle_target_yn IS '수명주기 관리 대상 여부 (대상(Y)/비대상(N))';
COMMENT ON COLUMN qidp.tb_lifecycle_target.renewal_cycle_code IS '갱신 주기 (코드값: 당월, 분기, 반기, 연, 1년, 3년, 5년, 7년)';
COMMENT ON COLUMN qidp.tb_lifecycle_target.expiration_at IS '유효 종료 일시 (기본값: 2999-12-31 23:59:59)';
COMMENT ON COLUMN qidp.tb_lifecycle_target.registered_branch IS '등록 부점';
COMMENT ON COLUMN qidp.tb_lifecycle_target.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_lifecycle_target.registered_at IS '등록 일시';
COMMENT ON COLUMN qidp.tb_lifecycle_target.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_lifecycle_target.updated_at IS '변경 일시';
COMMENT ON COLUMN qidp.tb_lifecycle_target.del_yn IS '삭제 여부';

-- Permissions

ALTER TABLE qidp.tb_lifecycle_target OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_lifecycle_target TO qidp;


-- qidp.tb_login_history definition



CREATE TABLE qidp.tb_login_history (
	history_id bigserial NOT NULL, -- 이력 고유ID
	emp_no varchar(20) NOT NULL, -- 사원번호
	login_at timestamp DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Seoul'::text) NULL, -- 로그인 일시
	logout_at timestamp NULL, -- 로그아웃 일시
	ip_address varchar(45) NULL, -- IP주소
	user_agent text NULL, -- 접속환경
	login_status varchar(10) NOT NULL, -- 로그인 상태
	failure_reason text NULL, -- 실패 사유
	created_at timestamp DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Seoul'::text) NULL, -- 생성일시
	created_by varchar(50) NULL, -- 생성자
	updated_at timestamp NULL, -- 수성일시
	updated_by varchar(50) NULL, -- 수정사
	delete_yn varchar(1) DEFAULT 'N'::character varying NOT NULL, -- 삭제여부
	CONSTRAINT tb_login_history_pkey PRIMARY KEY (history_id)
);
COMMENT ON TABLE qidp.tb_login_history IS '로그인이력 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_login_history.history_id IS '이력 고유ID';
COMMENT ON COLUMN qidp.tb_login_history.emp_no IS '사원번호';
COMMENT ON COLUMN qidp.tb_login_history.login_at IS '로그인 일시';
COMMENT ON COLUMN qidp.tb_login_history.logout_at IS '로그아웃 일시';
COMMENT ON COLUMN qidp.tb_login_history.ip_address IS 'IP주소';
COMMENT ON COLUMN qidp.tb_login_history.user_agent IS '접속환경';
COMMENT ON COLUMN qidp.tb_login_history.login_status IS '로그인 상태';
COMMENT ON COLUMN qidp.tb_login_history.failure_reason IS '실패 사유';
COMMENT ON COLUMN qidp.tb_login_history.created_at IS '생성일시';
COMMENT ON COLUMN qidp.tb_login_history.created_by IS '생성자';
COMMENT ON COLUMN qidp.tb_login_history.updated_at IS '수성일시';
COMMENT ON COLUMN qidp.tb_login_history.updated_by IS '수정사';
COMMENT ON COLUMN qidp.tb_login_history.delete_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_login_history OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_login_history TO qidp;


-- qidp.tb_manual_registration definition



CREATE TABLE qidp.tb_manual_registration (
	manual_reg_id varchar(20) NOT NULL, -- 수기등록 ID(20자 문자열)
	approval_no varchar(50) NULL, -- 결재 번호(FK)
	source_system varchar(100) NULL, -- 원천시스템
	classification varchar(255) NULL, -- 원천시스템 업무구분(분류체계)
	file_group_id int8 NOT NULL, -- 파일그룹 ID
	registration_reason text NULL, -- 수기등록 사유
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 변경자
	updated_at timestamp NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부 (Y/N)
	CONSTRAINT tb_manual_registration_pkey PRIMARY KEY (manual_reg_id)
);
COMMENT ON TABLE qidp.tb_manual_registration IS '수기등록문서 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_manual_registration.manual_reg_id IS '수기등록 ID(20자 문자열)';
COMMENT ON COLUMN qidp.tb_manual_registration.approval_no IS '결재 번호(FK)';
COMMENT ON COLUMN qidp.tb_manual_registration.source_system IS '원천시스템';
COMMENT ON COLUMN qidp.tb_manual_registration.classification IS '원천시스템 업무구분(분류체계)';
COMMENT ON COLUMN qidp.tb_manual_registration.file_group_id IS '파일그룹 ID';
COMMENT ON COLUMN qidp.tb_manual_registration.registration_reason IS '수기등록 사유';
COMMENT ON COLUMN qidp.tb_manual_registration.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_manual_registration.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_manual_registration.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_manual_registration.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_manual_registration.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_manual_registration.del_yn IS '삭제여부 (Y/N)';

-- Permissions

ALTER TABLE qidp.tb_manual_registration OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_manual_registration TO qidp;


-- qidp.tb_menu definition



CREATE TABLE qidp.tb_menu (
	menu_id varchar(20) NOT NULL, -- 메뉴 ID
	parent_menu_id varchar(20) NULL, -- 부모 메뉴 ID
	screen_id varchar(20) NULL, -- 화면 ID
	menu_name varchar(100) NOT NULL, -- 메뉴명
	display_order int4 NULL, -- 화면 출력 순서
	is_popup bool DEFAULT false NOT NULL, -- 팝업 여부
	is_screen bool DEFAULT false NOT NULL, -- 화면 여부
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT pk_tb_menu PRIMARY KEY (menu_id)
);
COMMENT ON TABLE qidp.tb_menu IS '메뉴 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_menu.menu_id IS '메뉴 ID';
COMMENT ON COLUMN qidp.tb_menu.parent_menu_id IS '부모 메뉴 ID';
COMMENT ON COLUMN qidp.tb_menu.screen_id IS '화면 ID';
COMMENT ON COLUMN qidp.tb_menu.menu_name IS '메뉴명';
COMMENT ON COLUMN qidp.tb_menu.display_order IS '화면 출력 순서';
COMMENT ON COLUMN qidp.tb_menu.is_popup IS '팝업 여부';
COMMENT ON COLUMN qidp.tb_menu.is_screen IS '화면 여부';
COMMENT ON COLUMN qidp.tb_menu.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_menu.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_menu.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_menu.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_menu.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_menu.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_menu OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_menu TO qidp;


-- qidp.tb_model definition



CREATE TABLE qidp.tb_model (
	model_id serial4 NOT NULL, -- 모델 ID
	source_system varchar(100) NULL, -- 원천시스템
	classification varchar(255) NULL, -- 원천시스템 분류체계 ID
	model_name varchar(255) NOT NULL, -- 모델명
	model_type varchar(50) NOT NULL, -- 모델유형
	model_description text NULL, -- 모델내용
	registered_branch varchar(50) NULL,
	registered_by varchar(50) NULL, -- 생성자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 생성일시
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	updated_by varchar(50) NULL, -- 수정자
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_model_pkey PRIMARY KEY (model_id)
);
COMMENT ON TABLE qidp.tb_model IS '모델 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_model.model_id IS '모델 ID';
COMMENT ON COLUMN qidp.tb_model.source_system IS '원천시스템';
COMMENT ON COLUMN qidp.tb_model.classification IS '원천시스템 분류체계 ID';
COMMENT ON COLUMN qidp.tb_model.model_name IS '모델명';
COMMENT ON COLUMN qidp.tb_model.model_type IS '모델유형';
COMMENT ON COLUMN qidp.tb_model.model_description IS '모델내용';
COMMENT ON COLUMN qidp.tb_model.registered_by IS '생성자';
COMMENT ON COLUMN qidp.tb_model.registered_at IS '생성일시';
COMMENT ON COLUMN qidp.tb_model.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_model.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_model.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_model OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_model TO qidp;


-- qidp.tb_notification definition



CREATE TABLE qidp.tb_notification (
	notification_id varchar(20) NOT NULL, -- 알림 ID
	emp_no varchar(50) NOT NULL, -- 직원번호
	approval_no varchar(20) NOT NULL, -- 결재 ID (결재번호)
	"type" varchar(30) NOT NULL, -- 알림 유형
	message text NOT NULL, -- 알림 메시지
	target_path varchar(200) NULL, -- 화면 경로
	is_read bool DEFAULT false NOT NULL, -- 조회 여부
	registered_branch varchar(20) NOT NULL, -- 등록부점
	registered_by varchar(20) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(20) NULL, -- 변경자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 변경일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_notification_pkey PRIMARY KEY (notification_id)
);
COMMENT ON TABLE qidp.tb_notification IS '알림 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_notification.notification_id IS '알림 ID';
COMMENT ON COLUMN qidp.tb_notification.emp_no IS '직원번호';
COMMENT ON COLUMN qidp.tb_notification.approval_no IS '결재 ID (결재번호)';
COMMENT ON COLUMN qidp.tb_notification."type" IS '알림 유형';
COMMENT ON COLUMN qidp.tb_notification.message IS '알림 메시지';
COMMENT ON COLUMN qidp.tb_notification.target_path IS '화면 경로';
COMMENT ON COLUMN qidp.tb_notification.is_read IS '조회 여부';
COMMENT ON COLUMN qidp.tb_notification.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_notification.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_notification.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_notification.updated_by IS '변경자';
COMMENT ON COLUMN qidp.tb_notification.updated_at IS '변경일시';
COMMENT ON COLUMN qidp.tb_notification.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_notification OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_notification TO qidp;


-- qidp.tb_role_menu definition



CREATE TABLE qidp.tb_role_menu (
	"role" varchar(20) NOT NULL, -- 사용자 권한
	menu_id varchar(50) NOT NULL, -- 메뉴 ID
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT pk_tb_role_menu PRIMARY KEY (role, menu_id)
);
COMMENT ON TABLE qidp.tb_role_menu IS '사용자 권한 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_role_menu."role" IS '사용자 권한';
COMMENT ON COLUMN qidp.tb_role_menu.menu_id IS '메뉴 ID';
COMMENT ON COLUMN qidp.tb_role_menu.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_role_menu.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_role_menu.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_role_menu.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_role_menu.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_role_menu.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_role_menu OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_role_menu TO qidp;


-- qidp.tb_sequence_mng definition



CREATE TABLE qidp.tb_sequence_mng (
	seq_name varchar(50) NOT NULL, -- 시퀀스명 (컬럼명)
	yyyymmdd varchar(8) NOT NULL, -- 기준일자
	current_value int4 NOT NULL, -- 현재 값(시퀀스)
	step int4 DEFAULT 1 NOT NULL, -- 시퀀스 증가 간격
	update_time timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL, -- 수정일시
	CONSTRAINT tb_sequence_mng_pkey PRIMARY KEY (seq_name, yyyymmdd)
);
COMMENT ON TABLE qidp.tb_sequence_mng IS '채번 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_sequence_mng.seq_name IS '시퀀스명 (컬럼명)';
COMMENT ON COLUMN qidp.tb_sequence_mng.yyyymmdd IS '기준일자';
COMMENT ON COLUMN qidp.tb_sequence_mng.current_value IS '현재 값(시퀀스)';
COMMENT ON COLUMN qidp.tb_sequence_mng.step IS '시퀀스 증가 간격';
COMMENT ON COLUMN qidp.tb_sequence_mng.update_time IS '수정일시';

-- Permissions

ALTER TABLE qidp.tb_sequence_mng OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_sequence_mng TO qidp;


-- qidp.tb_special_symbol definition



CREATE TABLE qidp.tb_special_symbol (
	special_symbol_id varchar(50) NOT NULL, -- 특수문자ID
	special_symbol varchar(10) NOT NULL, -- 특수문자
	registered_branch varchar(20) NULL, -- 등록부점
	registered_by varchar(20) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(20) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_special_character_pkey PRIMARY KEY (special_symbol_id)
);
COMMENT ON TABLE qidp.tb_special_symbol IS '특수문자 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_special_symbol.special_symbol_id IS '특수문자ID';
COMMENT ON COLUMN qidp.tb_special_symbol.special_symbol IS '특수문자';
COMMENT ON COLUMN qidp.tb_special_symbol.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_special_symbol.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_special_symbol.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_special_symbol.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_special_symbol.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_special_symbol.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_special_symbol OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_special_symbol TO qidp;


-- qidp.tb_training_model definition



CREATE TABLE qidp.tb_training_model (
	training_model_id varchar(20) NOT NULL, -- 학습모델 ID
	training_model_name varchar(255) NOT NULL, -- 학습모델명
	source_system varchar(100) NULL, -- 원천시스템
	classification varchar(255) NULL, -- 분류체계
	document_count int4 DEFAULT 0 NULL, -- 문서 수
	token_count int4 DEFAULT 0 NULL, -- 토큰 수
	trained_by varchar(50) NULL, -- 학습자
	training_started_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 학습 시작일시
	training_completed_at timestamp NULL, -- 학습 완료일시
	deployed_at timestamp NULL, -- 배포일시
	status varchar(20) DEFAULT 'TRAINING'::character varying NULL, -- 상태 (TRAINING/SUCCESS/FAIL)
	log_file_path varchar(500) NULL, -- 로그파일 경로
	registered_by varchar(50) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT tb_training_model_pkey PRIMARY KEY (training_model_id)
);
COMMENT ON TABLE qidp.tb_training_model IS '학습모델 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_training_model.training_model_id IS '학습모델 ID';
COMMENT ON COLUMN qidp.tb_training_model.training_model_name IS '학습모델명';
COMMENT ON COLUMN qidp.tb_training_model.source_system IS '원천시스템';
COMMENT ON COLUMN qidp.tb_training_model.classification IS '분류체계';
COMMENT ON COLUMN qidp.tb_training_model.document_count IS '문서 수';
COMMENT ON COLUMN qidp.tb_training_model.token_count IS '토큰 수';
COMMENT ON COLUMN qidp.tb_training_model.trained_by IS '학습자';
COMMENT ON COLUMN qidp.tb_training_model.training_started_at IS '학습 시작일시';
COMMENT ON COLUMN qidp.tb_training_model.training_completed_at IS '학습 완료일시';
COMMENT ON COLUMN qidp.tb_training_model.deployed_at IS '배포일시';
COMMENT ON COLUMN qidp.tb_training_model.status IS '상태 (TRAINING/SUCCESS/FAIL)';
COMMENT ON COLUMN qidp.tb_training_model.log_file_path IS '로그파일 경로';
COMMENT ON COLUMN qidp.tb_training_model.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_training_model.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_training_model.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_training_model.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_training_model.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_training_model OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_training_model TO qidp;


-- qidp.tb_uda_uai000d definition



CREATE TABLE qidp.tb_uda_uai000d (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_rslt_dtl_sqn numeric(5) NOT NULL, -- 자산화결과상세순번
	assz_pcsn_rslt_tcd bpchar(2) NOT NULL, -- 자산화처리결과유형코드
	assz_page_no numeric(5) NOT NULL, -- 자산화페이지번호
	assz_no numeric(5) NOT NULL, -- 자산화번호
	assz_pcsn_file_path_nm varchar(200) NOT NULL, -- 자산화처리파일경로명
	assz_con text NOT NULL, -- 자산화내용
	assz_img_tppo_xcr_vl numeric(11, 4) DEFAULT 0 NOT NULL, -- 자산화이미지상단X좌표값
	assz_img_tppo_ycr_vl numeric(11, 4) DEFAULT 0 NOT NULL, -- 자산화이미지상단Y좌표값
	assz_img_lwen_xcr_vl numeric(11, 4) DEFAULT 0 NOT NULL, -- 자산화이미지하단X좌표값
	assz_img_lwen_ycr_vl numeric(11, 4) DEFAULT 0 NOT NULL, -- 자산화이미지하단Y좌표값
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai000d_pk PRIMARY KEY (assz_unfc_id, assz_rslt_dtl_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai000d IS 'UDA자산화메타통합상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_rslt_dtl_sqn IS '자산화결과상세순번';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_pcsn_rslt_tcd IS '자산화처리결과유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_page_no IS '자산화페이지번호';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_no IS '자산화번호';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_con IS '자산화내용';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_img_tppo_xcr_vl IS '자산화이미지상단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_img_tppo_ycr_vl IS '자산화이미지상단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_img_lwen_xcr_vl IS '자산화이미지하단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai000d.assz_img_lwen_ycr_vl IS '자산화이미지하단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai000d.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai000d.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai000d OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai000d TO qidp;


-- qidp.tb_uda_uai000m definition



CREATE TABLE qidp.tb_uda_uai000m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_scd bpchar(2) NOT NULL, -- 자산화상태코드
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	rgsn_ymd varchar(8) NOT NULL, -- 등록년월일
	mdfc_ymd varchar(8) NOT NULL, -- 변경년월일
	assz_pcsn_tcd bpchar(1) NOT NULL, -- 자산화처리유형코드
	eror_vl varchar(50) NOT NULL, -- 오류값
	assz_eror_con text NOT NULL, -- 자산화오류내용
	assz_pcsn_file_path_nm varchar(200) NOT NULL, -- 자산화처리파일경로명
	flsz_vl numeric(20) NULL, -- 파일크기값
	assz_orgn_file_encp_rnnm_vl bpchar(32) NULL, -- 자산화원천파일암호화난수값
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai000m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai000m IS 'UDA자산화메타통합기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_scd IS '자산화상태코드';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai000m.rgsn_ymd IS '등록년월일';
COMMENT ON COLUMN qidp.tb_uda_uai000m.mdfc_ymd IS '변경년월일';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_pcsn_tcd IS '자산화처리유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai000m.eror_vl IS '오류값';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_eror_con IS '자산화오류내용';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai000m.flsz_vl IS '파일크기값';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_orgn_file_encp_rnnm_vl IS '자산화원천파일암호화난수값';
COMMENT ON COLUMN qidp.tb_uda_uai000m.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai000m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai000m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai000m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai000m TO qidp;


-- qidp.tb_uda_uai001m definition



CREATE TABLE qidp.tb_uda_uai001m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	assz_fmts_base_orgn_idnt_id varchar(50) NOT NULL, -- 자산화이전기준원천식별ID
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	rgsr_dept_id varchar(20) NOT NULL, -- 등록자부서ID
	inq_nbi numeric(15) NOT NULL, -- 조회건수
	vrsn_no numeric(6) NOT NULL, -- 버전번호
	suco_dcmn_shrn_yn bpchar(1) NOT NULL, -- 자회사문서공유여부
	suco_oppb_info_con varchar(100) NOT NULL, -- 자회사공개정보내용
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_nm varchar(300) NOT NULL, -- 첨부파일명
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai001m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai001m IS 'UDA시행문메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_fmts_base_orgn_idnt_id IS '자산화이전기준원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai001m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai001m.rgsr_dept_id IS '등록자부서ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.inq_nbi IS '조회건수';
COMMENT ON COLUMN qidp.tb_uda_uai001m.vrsn_no IS '버전번호';
COMMENT ON COLUMN qidp.tb_uda_uai001m.suco_dcmn_shrn_yn IS '자회사문서공유여부';
COMMENT ON COLUMN qidp.tb_uda_uai001m.suco_oppb_info_con IS '자회사공개정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai001m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai001m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai001m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai001m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai001m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai001m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai001m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai001m TO qidp;


-- qidp.tb_uda_uai003m definition



CREATE TABLE qidp.tb_uda_uai003m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	file_nm varchar(250) NOT NULL, -- 파일명
	file_sqn numeric(5) NOT NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	sub_ttl_nm varchar(200) NULL, -- 서브제목명
	url_adr varchar(200) NOT NULL, -- URL주소
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai003m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai003m IS 'UDA업무매뉴얼메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai003m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai003m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai003m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai003m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai003m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai003m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai003m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai003m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai003m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai003m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai003m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai003m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai003m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai003m.sub_ttl_nm IS '서브제목명';
COMMENT ON COLUMN qidp.tb_uda_uai003m.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai003m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai003m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai003m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai003m TO qidp;


-- qidp.tb_uda_uai004m definition



CREATE TABLE qidp.tb_uda_uai004m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	file_nm varchar(250) NOT NULL, -- 파일명
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai004m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai004m IS 'UDA내규메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai004m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai004m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai004m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai004m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai004m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai004m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai004m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai004m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai004m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai004m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai004m TO qidp;


-- qidp.tb_uda_uai005m definition



CREATE TABLE qidp.tb_uda_uai005m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천식별ID
	assz_cnfg_id varchar(20) NOT NULL, -- 자산화구성ID
	assz_sbtl_id varchar(20) NOT NULL, -- 자산화부제ID
	assz_sbtl_con text NOT NULL, -- 자산화부제내용
	url_adr varchar(200) NOT NULL, -- URL주소
	qstn_id varchar(20) NOT NULL, -- 질문ID
	assz_qstn_con text NOT NULL, -- 자산화질문내용
	rply_id varchar(20) NOT NULL, -- 답변ID
	assz_rply_con text NOT NULL, -- 자산화답변내용
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	tab_nm varchar(100) NOT NULL, -- 탭명
	sb_ttl_nm varchar(100) NOT NULL, -- 부제목명
	file_yn bpchar(1) NOT NULL, -- 파일여부
	file_nm varchar(250) NOT NULL, -- 파일명
	atch_key_vl varchar(50) NOT NULL, -- 첨부파일KEY값
	apnd_file_rgsn_ts timestamp NOT NULL, -- 첨부파일등록일시
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	atch_nm varchar(300) NOT NULL, -- 첨부파일명
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai005m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai005m IS 'UDA지식샘메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_cfbo_idnt_id IS '자산화원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_cnfg_id IS '자산화구성ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_sbtl_id IS '자산화부제ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_sbtl_con IS '자산화부제내용';
COMMENT ON COLUMN qidp.tb_uda_uai005m.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai005m.qstn_id IS '질문ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_qstn_con IS '자산화질문내용';
COMMENT ON COLUMN qidp.tb_uda_uai005m.rply_id IS '답변ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_rply_con IS '자산화답변내용';
COMMENT ON COLUMN qidp.tb_uda_uai005m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai005m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.tab_nm IS '탭명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.sb_ttl_nm IS '부제목명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.file_yn IS '파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai005m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.atch_key_vl IS '첨부파일KEY값';
COMMENT ON COLUMN qidp.tb_uda_uai005m.apnd_file_rgsn_ts IS '첨부파일등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai005m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai005m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai005m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai005m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai005m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai005m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai005m TO qidp;


-- qidp.tb_uda_uai007m definition



CREATE TABLE qidp.tb_uda_uai007m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	url_adr varchar(200) NOT NULL, -- URL주소
	assz_chb_frtm_conn_url_adr varchar(200) NOT NULL, -- 자산화챗봇첫번째콘텐츠URL주소
	assz_chb_sctm_conn_url_adr varchar(200) NOT NULL, -- 자산화챗봇두번째콘텐츠URL주소
	assz_chb_thtm_conn_url_adr varchar(200) NOT NULL, -- 자산화챗봇세번째콘텐츠URL주소
	assz_chb_fotm_conn_url_adr varchar(200) NOT NULL, -- 자산화챗봇네번째콘텐츠URL주소
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai007m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai007m IS 'UDA챗봇FAQ메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai007m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai007m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai007m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai007m.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_chb_frtm_conn_url_adr IS '자산화챗봇첫번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_chb_sctm_conn_url_adr IS '자산화챗봇두번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_chb_thtm_conn_url_adr IS '자산화챗봇세번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai007m.assz_chb_fotm_conn_url_adr IS '자산화챗봇네번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai007m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai007m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai007m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai007m TO qidp;


-- qidp.tb_uda_uai008m definition



CREATE TABLE qidp.tb_uda_uai008m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	rgsr_dept_id varchar(20) NOT NULL, -- 등록자부서ID
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai001m_pk_1 PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai008m IS 'UDA수기등록메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai008m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai008m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai008m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai008m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai008m.rgsr_dept_id IS '등록자부서ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai008m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai008m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai008m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai008m TO qidp;


-- qidp.tb_uda_uai071m definition



CREATE TABLE qidp.tb_uda_uai071m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	assz_fmts_base_orgn_idnt_id varchar(50) NOT NULL, -- 자산화이전기준원천식별ID
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	rgsr_dept_id varchar(20) NOT NULL, -- 등록자부서ID
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	atch_nm varchar(300) NOT NULL, -- 첨부파일명
	use_sttg_ymd varchar(8) NULL, -- 사용시작년월일
	use_fnsh_ymd varchar(8) NULL, -- 사용종료년월일
	sale_info_con varchar(100) NULL, -- 판매정보내용
	assz_dcmn_clsf_con varchar(50) NULL, -- 자산화문서분류내용
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai071m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai071m IS 'UDA업무포탈상품설명서메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_fmts_base_orgn_idnt_id IS '자산화이전기준원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai071m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai071m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai071m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai071m.rgsr_dept_id IS '등록자부서ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai071m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai071m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai071m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai071m.use_sttg_ymd IS '사용시작년월일';
COMMENT ON COLUMN qidp.tb_uda_uai071m.use_fnsh_ymd IS '사용종료년월일';
COMMENT ON COLUMN qidp.tb_uda_uai071m.sale_info_con IS '판매정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai071m.assz_dcmn_clsf_con IS '자산화문서분류내용';
COMMENT ON COLUMN qidp.tb_uda_uai071m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai071m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai071m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai071m TO qidp;


-- qidp.tb_uda_uai072m definition



CREATE TABLE qidp.tb_uda_uai072m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	file_nm varchar(250) NOT NULL, -- 파일명
	file_sqn numeric(5) NOT NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	isnc_tgt_con text NOT NULL, -- 발급대상내용
	card_kind_con text NOT NULL, -- 카드종류내용
	isnc_intt_con text NOT NULL, -- 발급기관내용
	fee_cndt_con text NOT NULL, -- 수수료조건내용
	cdis_info_con text NOT NULL, -- 카드발급정보내용
	card_ftpm_trfc_con text NOT NULL, -- 카드후불교통내용
	anf_con text NOT NULL, -- 연회비내용
	assz_card_alnc_cd_nm bpchar(6) NOT NULL, -- 카드제휴코드
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai072m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai072m IS 'UDA카드상품설명서메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai072m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai072m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai072m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai072m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai072m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai072m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai072m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai072m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai072m.isnc_tgt_con IS '발급대상내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.card_kind_con IS '카드종류내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.isnc_intt_con IS '발급기관내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.fee_cndt_con IS '수수료조건내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.cdis_info_con IS '카드발급정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.card_ftpm_trfc_con IS '카드후불교통내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.anf_con IS '연회비내용';
COMMENT ON COLUMN qidp.tb_uda_uai072m.assz_card_alnc_cd_nm IS '카드제휴코드';
COMMENT ON COLUMN qidp.tb_uda_uai072m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai072m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai072m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai072m TO qidp;


-- qidp.tb_uda_uai074m definition



CREATE TABLE qidp.tb_uda_uai074m (
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	file_nm varchar(250) NOT NULL, -- 파일명
	file_sqn numeric(5) NOT NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	cnvs_grp_cd bpchar(8) NOT NULL, -- 전환그룹코드
	assz_fund_dcmn_dcd bpchar(1) NOT NULL, -- 자산화펀드문서구분코드
	assz_fund_new_abl_yn bpchar(1) NOT NULL, -- 자산화펀드신규가능여부
	sale_fnsh_ymd varchar(8) NOT NULL, -- 판매종료년월일
	atch_nm varchar(300) NOT NULL, -- 첨부파일명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai074m_pk PRIMARY KEY (assz_unfc_id)
);
COMMENT ON TABLE qidp.tb_uda_uai074m IS 'UDA펀드투자설명서메타기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai074m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai074m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai074m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai074m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai074m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai074m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai074m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai074m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai074m.cnvs_grp_cd IS '전환그룹코드';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_fund_dcmn_dcd IS '자산화펀드문서구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai074m.assz_fund_new_abl_yn IS '자산화펀드신규가능여부';
COMMENT ON COLUMN qidp.tb_uda_uai074m.sale_fnsh_ymd IS '판매종료년월일';
COMMENT ON COLUMN qidp.tb_uda_uai074m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai074m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai074m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai074m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai074m TO qidp;


-- qidp.tb_uda_uai101m definition



CREATE TABLE qidp.tb_uda_uai101m (
	wpt_athr_grp_id varchar(27) NOT NULL, -- 업무포탈권한그룹ID
	wpt_athr_grp_nm varchar(200) NOT NULL, -- 업무포탈권한그룹명
	wpt_hgrn_athr_grp_id varchar(27) NOT NULL, -- 업무포탈상위권한그룹ID
	wpt_athr_grp_type_nm varchar(200) NULL, -- 업무포탈권한그룹타입명
	wpt_athr_grp_ensn_nm varchar(200) NOT NULL, -- 업무포탈권한그룹영문명
	wpt_lrrn_athr_nbi numeric(5) NOT NULL, -- 업무포탈하위권한건수
	wpt_lnp_sqc_vl varchar(27) NOT NULL, -- 업무포탈정렬순서값
	wpt_rgsr_id varchar(27) NOT NULL, -- 업무포탈등록자ID
	wpt_rgsr_nm varchar(200) NOT NULL, -- 업무포탈등록자명
	wpt_mdfr_id varchar(27) NOT NULL, -- 업무포탈변경자ID
	wpt_mdfr_nm varchar(200) NOT NULL, -- 업무포탈변경자명
	rgsn_ts timestamp NOT NULL, -- 등록일시
	mdfc_ts timestamp NOT NULL, -- 변경일시
	scre_otpt_opt_vl numeric(1) NOT NULL, -- 화면출력옵션값
	wpt_all_athr_grp_path_vl varchar(4000) NOT NULL, -- 업무포탈전체권한그룹경로값
	ogzn_attcd bpchar(4) NOT NULL, -- 조직속성코드
	team_kcd bpchar(2) NOT NULL, -- 팀종류코드
	brcd bpchar(4) NOT NULL, -- 부점코드
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai101m_pk PRIMARY KEY (wpt_athr_grp_id, wpt_athr_grp_nm)
);
COMMENT ON TABLE qidp.tb_uda_uai101m IS 'UDA업무포탈권한그룹기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_athr_grp_id IS '업무포탈권한그룹ID';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_athr_grp_nm IS '업무포탈권한그룹명';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_hgrn_athr_grp_id IS '업무포탈상위권한그룹ID';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_athr_grp_type_nm IS '업무포탈권한그룹타입명';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_athr_grp_ensn_nm IS '업무포탈권한그룹영문명';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_lrrn_athr_nbi IS '업무포탈하위권한건수';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_lnp_sqc_vl IS '업무포탈정렬순서값';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_rgsr_id IS '업무포탈등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_rgsr_nm IS '업무포탈등록자명';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_mdfr_id IS '업무포탈변경자ID';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_mdfr_nm IS '업무포탈변경자명';
COMMENT ON COLUMN qidp.tb_uda_uai101m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai101m.mdfc_ts IS '변경일시';
COMMENT ON COLUMN qidp.tb_uda_uai101m.scre_otpt_opt_vl IS '화면출력옵션값';
COMMENT ON COLUMN qidp.tb_uda_uai101m.wpt_all_athr_grp_path_vl IS '업무포탈전체권한그룹경로값';
COMMENT ON COLUMN qidp.tb_uda_uai101m.ogzn_attcd IS '조직속성코드';
COMMENT ON COLUMN qidp.tb_uda_uai101m.team_kcd IS '팀종류코드';
COMMENT ON COLUMN qidp.tb_uda_uai101m.brcd IS '부점코드';
COMMENT ON COLUMN qidp.tb_uda_uai101m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai101m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai101m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai101m TO qidp;


-- qidp.tb_uda_uai102m definition



CREATE TABLE qidp.tb_uda_uai102m (
	wpt_enfr_dcmn_id varchar(27) NOT NULL,
	wpt_rtpl_grp_id varchar(27) NOT NULL, -- 업무포탈수신처그룹ID
	wpt_rtpl_grp_nm varchar(200) NOT NULL, -- 업무포탈수신처그룹명
	wpt_rgsr_id varchar(27) NOT NULL, -- 업무포탈등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	wpt_rtpl_grp_dsnc_vl varchar(27) NOT NULL, -- 업무포탈수신처그룹구분값
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai102m_pk PRIMARY KEY (wpt_enfr_dcmn_id, wpt_rtpl_grp_id)
);
COMMENT ON TABLE qidp.tb_uda_uai102m IS 'UDA업무포탈문서수신처기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai102m.wpt_rtpl_grp_id IS '업무포탈수신처그룹ID';
COMMENT ON COLUMN qidp.tb_uda_uai102m.wpt_rtpl_grp_nm IS '업무포탈수신처그룹명';
COMMENT ON COLUMN qidp.tb_uda_uai102m.wpt_rgsr_id IS '업무포탈등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai102m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai102m.wpt_rtpl_grp_dsnc_vl IS '업무포탈수신처그룹구분값';
COMMENT ON COLUMN qidp.tb_uda_uai102m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai102m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai102m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai102m TO qidp;


-- qidp.tb_uda_uai801l definition



CREATE TABLE qidp.tb_uda_uai801l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	assz_fmts_base_orgn_idnt_id varchar(50) NULL, -- 자산화이전기준원천식별ID
	conn_ttl_nm varchar(200) NULL, -- 콘텐츠제목명
	rgsr_dept_id varchar(20) NULL, -- 등록자부서ID
	inq_nbi numeric(15) NULL, -- 조회건수
	vrsn_no numeric(6) NULL, -- 버전번호
	suco_dcmn_shrn_yn bpchar(1) NULL, -- 자회사문서공유여부
	suco_oppb_info_con varchar(100) NULL, -- 자회사공개정보내용
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai801l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai801l IS 'UDA시행문메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai801l.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_fmts_base_orgn_idnt_id IS '자산화이전기준원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai801l.rgsr_dept_id IS '등록자부서ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.inq_nbi IS '조회건수';
COMMENT ON COLUMN qidp.tb_uda_uai801l.vrsn_no IS '버전번호';
COMMENT ON COLUMN qidp.tb_uda_uai801l.suco_dcmn_shrn_yn IS '자회사문서공유여부';
COMMENT ON COLUMN qidp.tb_uda_uai801l.suco_oppb_info_con IS '자회사공개정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai801l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai801l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai801l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai801l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai801l TO qidp;


-- qidp.tb_uda_uai802l definition



CREATE TABLE qidp.tb_uda_uai802l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	rgsn_ts timestamp NULL, -- 등록일시
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	atch_sqn numeric(5) NULL, -- 첨부파일순번
	atch_nm varchar(300) NULL, -- 첨부파일명
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai802l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai802l IS 'UDA시행문첨부파일메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai802l.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai802l.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai802l.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai802l.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai802l.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai802l.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai802l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai802l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai802l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai802l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai802l TO qidp;


-- qidp.tb_uda_uai803l definition



CREATE TABLE qidp.tb_uda_uai803l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	assz_mnl_id varchar(20) NULL, -- 자산화매뉴얼ID
	assz_mnl_grp_id varchar(10) NULL, -- 자산화매뉴얼그룹ID
	assz_cmpe_id varchar(20) NULL, -- 자산화컴포넌트ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	atch_sqn numeric(5) NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NULL, -- 콘텐츠제목명
	sub_ttl_nm varchar(200) NULL, -- 서브제목명
	url_adr varchar(200) NULL, -- URL주소
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai803l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai803l IS 'UDA업무매뉴얼메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_mnl_id IS '자산화매뉴얼ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_mnl_grp_id IS '자산화매뉴얼그룹ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_cmpe_id IS '자산화컴포넌트ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai803l.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai803l.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai803l.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai803l.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai803l.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai803l.sub_ttl_nm IS '서브제목명';
COMMENT ON COLUMN qidp.tb_uda_uai803l.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai803l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai803l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai803l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai803l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai803l TO qidp;


-- qidp.tb_uda_uai804l definition



CREATE TABLE qidp.tb_uda_uai804l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	file_nm varchar(250) NOT NULL, -- 파일명
	assz_orcp_file_path_nm varchar(200) NOT NULL, -- 자산화원본파일경로명
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	assz_pcsn_file_path_nm varchar(200) NOT NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai804l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai804l IS 'UDA내규메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai804l.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai804l.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai804l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai804l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai804l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai804l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai804l TO qidp;


-- qidp.tb_uda_uai805l definition



CREATE TABLE qidp.tb_uda_uai805l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NOT NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_cnfg_id varchar(20) NOT NULL, -- 자산화구성ID
	assz_sbtl_id varchar(20) NOT NULL, -- 자산화부제ID
	assz_sbtl_con text NOT NULL, -- 자산화부제내용
	url_adr varchar(200) NOT NULL, -- URL주소
	qstn_id varchar(20) NOT NULL, -- 질문ID
	assz_qstn_con text NOT NULL, -- 자산화질문내용
	rply_id varchar(20) NOT NULL, -- 답변ID
	assz_rply_con text NOT NULL, -- 자산화답변내용
	orgn_data_rgsr_id varchar(50) NOT NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NOT NULL, -- 등록일시
	amnn_ts timestamp NOT NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NOT NULL, -- 자산화원천처리구분코드
	assz_dcmn_clsf_id varchar(50) NOT NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NOT NULL, -- 콘텐츠제목명
	tab_nm varchar(100) NOT NULL, -- 탭명
	sb_ttl_nm varchar(100) NOT NULL, -- 부제목명
	file_yn bpchar(1) NOT NULL, -- 파일여부
	file_nm varchar(250) NOT NULL, -- 파일명
	atch_key_vl varchar(50) NOT NULL, -- 첨부파일KEY값
	assz_pcsn_file_path_nm varchar(200) NOT NULL, -- 자산화처리파일경로명
	apnd_file_rgsn_ts timestamp NOT NULL, -- 첨부파일등록일시
	atch_yn bpchar(1) NOT NULL, -- 첨부파일여부
	atch_sqn numeric(5) NOT NULL, -- 첨부파일순번
	atch_nm varchar(300) NOT NULL, -- 첨부파일명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai805l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai805l IS 'UDA지식샘메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_cnfg_id IS '자산화구성ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_sbtl_id IS '자산화부제ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_sbtl_con IS '자산화부제내용';
COMMENT ON COLUMN qidp.tb_uda_uai805l.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai805l.qstn_id IS '질문ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_qstn_con IS '자산화질문내용';
COMMENT ON COLUMN qidp.tb_uda_uai805l.rply_id IS '답변ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_rply_con IS '자산화답변내용';
COMMENT ON COLUMN qidp.tb_uda_uai805l.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai805l.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.tab_nm IS '탭명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.sb_ttl_nm IS '부제목명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.file_yn IS '파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai805l.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.atch_key_vl IS '첨부파일KEY값';
COMMENT ON COLUMN qidp.tb_uda_uai805l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.apnd_file_rgsn_ts IS '첨부파일등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai805l.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai805l.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai805l.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai805l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai805l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai805l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai805l TO qidp;


-- qidp.tb_uda_uai807l definition



CREATE TABLE qidp.tb_uda_uai807l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	url_adr varchar(200) NULL, -- URL주소
	assz_chb_frtm_conn_url_adr varchar(200) NULL, -- 자산화챗봇첫번째콘텐츠URL주소
	assz_chb_sctm_conn_url_adr varchar(200) NULL, -- 자산화챗봇두번째콘텐츠URL주소
	assz_chb_thtm_conn_url_adr varchar(200) NULL, -- 자산화챗봇세번째콘텐츠URL주소
	assz_chb_fotm_conn_url_adr varchar(200) NULL, -- 자산화챗봇네번째콘텐츠URL주소
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai807l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai807l IS 'UDA챗봇FAQ메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai807l.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_chb_frtm_conn_url_adr IS '자산화챗봇첫번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_chb_sctm_conn_url_adr IS '자산화챗봇두번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_chb_thtm_conn_url_adr IS '자산화챗봇세번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_chb_fotm_conn_url_adr IS '자산화챗봇네번째콘텐츠URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai807l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai807l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai807l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai807l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai807l TO qidp;


-- qidp.tb_uda_uai871m definition



CREATE TABLE qidp.tb_uda_uai871m (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	atch_sqn numeric(5) NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	assz_fmts_base_orgn_idnt_id varchar(50) NULL, -- 자산화이전기준원천식별ID
	conn_ttl_nm varchar(200) NULL, -- 콘텐츠제목명
	rgsr_dept_id varchar(20) NULL, -- 등록자부서ID
	use_sttg_ymd varchar(8) NULL, -- 사용시작년월일
	use_fnsh_ymd varchar(8) NULL, -- 사용종료년월일
	sale_info_con varchar(100) NULL, -- 판매정보내용
	assz_dcmn_clsf_con varchar(50) NULL, -- 자산화문서분류내용
	atch_nm varchar(300) NULL, -- 첨부파일명
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai871m_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai871m IS 'UDA업무포탈상품설명서메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai871m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai871m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai871m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai871m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai871m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_fmts_base_orgn_idnt_id IS '자산화이전기준원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai871m.rgsr_dept_id IS '등록자부서ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.use_sttg_ymd IS '사용시작년월일';
COMMENT ON COLUMN qidp.tb_uda_uai871m.use_fnsh_ymd IS '사용종료년월일';
COMMENT ON COLUMN qidp.tb_uda_uai871m.sale_info_con IS '판매정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_dcmn_clsf_con IS '자산화문서분류내용';
COMMENT ON COLUMN qidp.tb_uda_uai871m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai871m.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai871m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai871m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai871m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai871m TO qidp;


-- qidp.tb_uda_uai872d definition



CREATE TABLE qidp.tb_uda_uai872d (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	file_sqn numeric(5) NOT NULL,
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	isnc_tgt_con text NULL, -- 발급대상내용
	card_kind_con text NULL, -- 카드종류내용
	isnc_intt_con text NULL, -- 발급기관내용
	fee_cndt_con text NULL, -- 수수료조건내용
	cdis_info_con text NULL, -- 카드발급정보내용
	card_ftpm_trfc_con text NULL, -- 카드후불교통내용
	anf_con text NULL, -- 연회비내용
	assz_card_alnc_cd_nm bpchar(6) NULL, -- 카드제휴코드
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai873m_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, file_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai872d IS 'UDA카드상품추가메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai872d.isnc_tgt_con IS '발급대상내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.card_kind_con IS '카드종류내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.isnc_intt_con IS '발급기관내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.fee_cndt_con IS '수수료조건내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.cdis_info_con IS '카드발급정보내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.card_ftpm_trfc_con IS '카드후불교통내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.anf_con IS '연회비내용';
COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_card_alnc_cd_nm IS '카드제휴코드';
COMMENT ON COLUMN qidp.tb_uda_uai872d.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai872d.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai872d.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai872d OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai872d TO qidp;


-- qidp.tb_uda_uai872m definition



CREATE TABLE qidp.tb_uda_uai872m (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	atch_sqn numeric(5) NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NULL, -- 콘텐츠제목명
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai872m_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai872m IS 'UDA카드상품설명서메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai872m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai872m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai872m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai872m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai872m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai872m.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai872m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai872m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai872m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai872m TO qidp;


-- qidp.tb_uda_uai874m definition



CREATE TABLE qidp.tb_uda_uai874m (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL, -- 자산화메타처리순번
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	file_nm varchar(250) NULL, -- 파일명
	file_sqn numeric(5) NULL, -- 파일순번
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	orgn_data_rgsr_id varchar(50) NULL, -- 원천데이터등록자ID
	rgsn_ts timestamp NULL, -- 등록일시
	amnn_ts timestamp NULL, -- 수정일시
	assz_orgn_pcsn_dcd bpchar(1) NULL, -- 자산화원천처리구분코드
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	atch_sqn numeric(5) NULL, -- 첨부파일순번
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	conn_ttl_nm varchar(200) NULL, -- 콘텐츠제목명
	cnvs_grp_cd bpchar(8) NULL, -- 전환그룹코드
	assz_fund_dcmn_dcd bpchar(1) NULL, -- 자산화펀드문서구분코드
	assz_fund_new_abl_yn bpchar(1) NULL, -- 자산화펀드신규가능여부
	sale_fnsh_ymd varchar(8) NULL, -- 판매종료년월일
	atch_nm varchar(300) NULL, -- 첨부파일명
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	uda_sys_lsmd_id varchar(50) NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai874m_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai874m IS 'UDA펀드투자설명서메타배치수행내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_meta_pcsn_sqn IS '자산화메타처리순번';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai874m.file_sqn IS '파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai874m.orgn_data_rgsr_id IS '원천데이터등록자ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uai874m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_orgn_pcsn_dcd IS '자산화원천처리구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai874m.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai874m.atch_sqn IS '첨부파일순번';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.conn_ttl_nm IS '콘텐츠제목명';
COMMENT ON COLUMN qidp.tb_uda_uai874m.cnvs_grp_cd IS '전환그룹코드';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_fund_dcmn_dcd IS '자산화펀드문서구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_fund_new_abl_yn IS '자산화펀드신규가능여부';
COMMENT ON COLUMN qidp.tb_uda_uai874m.sale_fnsh_ymd IS '판매종료년월일';
COMMENT ON COLUMN qidp.tb_uda_uai874m.atch_nm IS '첨부파일명';
COMMENT ON COLUMN qidp.tb_uda_uai874m.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai874m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai874m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai874m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai874m TO qidp;


-- qidp.tb_uda_uai900m definition



CREATE TABLE qidp.tb_uda_uai900m (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_btch_tcd bpchar(2) NOT NULL, -- 자산화배치유형코드
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL, -- 자산화전송대상시스템구분코드
	acmp_ymd varchar(8) NOT NULL, -- 수행년월일
	btch_id varchar(20) NOT NULL, -- 배치ID
	assz_orgn_sys_cd_con varchar(6) NOT NULL, -- 자산화원천시스템코드내용
	assz_btch_pcsn_stg_dcd bpchar(2) NOT NULL, -- 자산화배치처리단계구분코드
	assz_btch_pcsn_tcd bpchar(2) NOT NULL, -- 자산화배치처리유형코드(T1:메타+파일, T2:DB, T3:지식샘)
	eror_vl varchar(50) NULL, -- 오류값
	assz_eror_con text NULL, -- 자산화오류내용
	acmp_sttg_ts timestamp NOT NULL, -- 수행시작일시
	acmp_fnsh_ts timestamp NULL, -- 수행종료일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai900m_pk PRIMARY KEY (assz_btch_acmp_id, assz_btch_tcd, assz_trms_tgt_sys_dcd)
);
COMMENT ON TABLE qidp.tb_uda_uai900m IS 'UDA배치기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_btch_tcd IS '자산화배치유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_trms_tgt_sys_dcd IS '자산화전송대상시스템구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai900m.acmp_ymd IS '수행년월일';
COMMENT ON COLUMN qidp.tb_uda_uai900m.btch_id IS '배치ID';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_btch_pcsn_stg_dcd IS '자산화배치처리단계구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_btch_pcsn_tcd IS '자산화배치처리유형코드(T1:메타+파일, T2:DB, T3:지식샘)';
COMMENT ON COLUMN qidp.tb_uda_uai900m.eror_vl IS '오류값';
COMMENT ON COLUMN qidp.tb_uda_uai900m.assz_eror_con IS '자산화오류내용';
COMMENT ON COLUMN qidp.tb_uda_uai900m.acmp_sttg_ts IS '수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai900m.acmp_fnsh_ts IS '수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai900m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai900m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai900m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai900m TO qidp;


-- qidp.tb_uda_uai901l definition



CREATE TABLE qidp.tb_uda_uai901l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL,
	assz_unfc_id varchar(20) NULL, -- 자산화통합ID
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천식별ID
	atch_yn bpchar(1) NULL, -- 첨부파일여부
	assz_pcsn_tgt_tcd bpchar(2) NULL, -- 자산화처리대상유형코드
	assz_prec_pcsn_stg_dcd bpchar(2) NULL, -- 자산화선행처리단계구분코드
	assz_pcsn_tcd bpchar(1) NULL, -- 자산화처리유형코드
	assz_img_pcsn_yn bpchar(1) NULL, -- 자산화이미지처리여부
	assz_img_pcsn_acmp_sttg_ts timestamp NULL, -- 자산화이미지처리수행시작일시
	assz_img_pcsn_acmp_fnsh_ts timestamp NULL, -- 자산화이미지처리수행종료일시
	assz_img_pcsn_acmp_rslt_dcd bpchar(2) NULL, -- 자산화이미지처리수행결과구분코드
	assz_conv_pcsn_tcd bpchar(2) NULL, -- 자산화변환처리유형코드
	assz_conv_acmp_sttg_ts timestamp NULL, -- 자산화변환수행시작일시
	assz_conv_acmp_fnsh_ts timestamp NULL, -- 자산화변환수행종료일시
	assz_conv_file_path_nm varchar(200) NULL, -- 자산화변환파일경로명
	assz_file_unfc_yn bpchar(1) NULL, -- 자산화파일통합여부
	assz_orcp_file_strc_tcd bpchar(2) NULL, -- 자산화원본파일구조유형코드
	orcp_file_assz_job_sttg_ts timestamp NULL, -- 원본파일자산화작업시작일시
	orcp_file_assz_job_fnsh_ts timestamp NULL, -- 원본파일자산화작업종료일시
	assz_orcp_file_path_nm varchar(200) NULL, -- 자산화원본파일경로명
	eror_vl varchar(50) NULL, -- 오류값
	assz_eror_con text NULL, -- 자산화오류내용
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai901l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai901l IS 'UDA자산화처리배치내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_cfbo_idnt_id IS '자산화원천식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai901l.atch_yn IS '첨부파일여부';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_pcsn_tgt_tcd IS '자산화처리대상유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_prec_pcsn_stg_dcd IS '자산화선행처리단계구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_pcsn_tcd IS '자산화처리유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_img_pcsn_yn IS '자산화이미지처리여부';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_img_pcsn_acmp_sttg_ts IS '자산화이미지처리수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_img_pcsn_acmp_fnsh_ts IS '자산화이미지처리수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_img_pcsn_acmp_rslt_dcd IS '자산화이미지처리수행결과구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_conv_pcsn_tcd IS '자산화변환처리유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_conv_acmp_sttg_ts IS '자산화변환수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_conv_acmp_fnsh_ts IS '자산화변환수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_conv_file_path_nm IS '자산화변환파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_file_unfc_yn IS '자산화파일통합여부';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_orcp_file_strc_tcd IS '자산화원본파일구조유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai901l.orcp_file_assz_job_sttg_ts IS '원본파일자산화작업시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.orcp_file_assz_job_fnsh_ts IS '원본파일자산화작업종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_orcp_file_path_nm IS '자산화원본파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai901l.eror_vl IS '오류값';
COMMENT ON COLUMN qidp.tb_uda_uai901l.assz_eror_con IS '자산화오류내용';
COMMENT ON COLUMN qidp.tb_uda_uai901l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai901l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai901l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai901l TO qidp;


-- qidp.tb_uda_uai902l definition



CREATE TABLE qidp.tb_uda_uai902l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL,
	img_sqn numeric(5) NOT NULL, -- 이미지순번
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_page_no numeric(5) NULL, -- 자산화페이지번호
	assz_img_no numeric(5) NULL, -- 자산화이미지번호
	assz_img_tppo_xcr_vl numeric(11, 4) NULL, -- 자산화이미지상단X좌표값
	assz_img_tppo_ycr_vl numeric(11, 4) NULL, -- 자산화이미지상단Y좌표값
	assz_img_lwen_xcr_vl numeric(11, 4) NULL, -- 자산화이미지하단X좌표값
	assz_img_lwen_ycr_vl numeric(11, 4) NULL, -- 자산화이미지하단Y좌표값
	assz_img_pcsn_acmp_rslt_dcd bpchar(2) NULL, -- 자산화이미지처리수행결과구분코드
	eror_vl varchar(50) NULL, -- 오류값
	assz_eror_con text NULL, -- 자산화오류내용
	acmp_sttg_ts timestamp NULL, -- 수행시작일시
	acmp_fnsh_ts timestamp NULL, -- 수행종료일시
	assz_img_file_path_nm varchar(200) NULL, -- 자산화이미지파일경로명
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai902l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, img_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai902l IS 'UDA이미치처리배치내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai902l.img_sqn IS '이미지순번';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_page_no IS '자산화페이지번호';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_no IS '자산화이미지번호';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_tppo_xcr_vl IS '자산화이미지상단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_tppo_ycr_vl IS '자산화이미지상단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_lwen_xcr_vl IS '자산화이미지하단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_lwen_ycr_vl IS '자산화이미지하단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_pcsn_acmp_rslt_dcd IS '자산화이미지처리수행결과구분코드';
COMMENT ON COLUMN qidp.tb_uda_uai902l.eror_vl IS '오류값';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_eror_con IS '자산화오류내용';
COMMENT ON COLUMN qidp.tb_uda_uai902l.acmp_sttg_ts IS '수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai902l.acmp_fnsh_ts IS '수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai902l.assz_img_file_path_nm IS '자산화이미지파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai902l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai902l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai902l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai902l TO qidp;


-- qidp.tb_uda_uai910l definition



CREATE TABLE qidp.tb_uda_uai910l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL,
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_orgn_sys_cd_con varchar(6) NULL, -- 자산화원천시스템코드내용
	assz_cfbo_idnt_id varchar(50) NULL, -- 자산화원천별식별ID
	dcmn_nm varchar(100) NULL, -- 문서명
	file_nm varchar(250) NULL, -- 파일명
	assz_pcsn_tgt_tcd bpchar(2) NULL, -- 자산화처리대상유형코드
	assz_pcsn_tcd bpchar(1) NULL, -- 자산화처리유형코드
	flsz_vl numeric(20) NULL, -- 파일크기값
	assz_file_type_cd bpchar(2) NULL, -- 자산화파일타입코드
	assz_acs_athr_con text NULL, -- 자산화접근권한내용
	assz_src_id varchar(20) NULL, -- 자산화출처ID
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	url_adr varchar(200) NULL, -- URL주소
	cret_ts timestamp NULL, -- 생성일시
	amnn_ts timestamp NULL, -- 수정일시
	acmp_sttg_ts timestamp NULL, -- 수행시작일시
	acmp_fnsh_ts timestamp NULL, -- 수행종료일시
	del_yn bpchar(1) NULL, -- 삭제여부
	del_ymd varchar(8) NULL, -- 삭제년월일
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_910l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai910l IS 'UDA자산화결과내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_cfbo_idnt_id IS '자산화원천별식별ID';
COMMENT ON COLUMN qidp.tb_uda_uai910l.dcmn_nm IS '문서명';
COMMENT ON COLUMN qidp.tb_uda_uai910l.file_nm IS '파일명';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_pcsn_tgt_tcd IS '자산화처리대상유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_pcsn_tcd IS '자산화처리유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai910l.flsz_vl IS '파일크기값';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_file_type_cd IS '자산화파일타입코드';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_acs_athr_con IS '자산화접근권한내용';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_src_id IS '자산화출처ID';
COMMENT ON COLUMN qidp.tb_uda_uai910l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai910l.url_adr IS 'URL주소';
COMMENT ON COLUMN qidp.tb_uda_uai910l.cret_ts IS '생성일시';
COMMENT ON COLUMN qidp.tb_uda_uai910l.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uai910l.acmp_sttg_ts IS '수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai910l.acmp_fnsh_ts IS '수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai910l.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uai910l.del_ymd IS '삭제년월일';
COMMENT ON COLUMN qidp.tb_uda_uai910l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai910l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai910l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai910l TO qidp;


-- qidp.tb_uda_uai911l definition



CREATE TABLE qidp.tb_uda_uai911l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL,
	assz_rslt_dtl_sqn numeric(5) NOT NULL, -- 자산화결과상세순번
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_pcsn_rslt_tcd bpchar(2) NULL, -- 자산화처리결과유형코드
	assz_con text NULL, -- 자산화내용
	assz_page_no numeric(5) NULL, -- 자산화페이지번호
	assz_no numeric(5) NULL, -- 자산화번호
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	acmp_sttg_ts timestamp NULL, -- 수행시작일시
	acmp_fnsh_ts timestamp NULL, -- 수행종료일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai911l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, assz_rslt_dtl_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai911l IS 'UDA자산화결과상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_rslt_dtl_sqn IS '자산화결과상세순번';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_pcsn_rslt_tcd IS '자산화처리결과유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_con IS '자산화내용';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_page_no IS '자산화페이지번호';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_no IS '자산화번호';
COMMENT ON COLUMN qidp.tb_uda_uai911l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai911l.acmp_sttg_ts IS '수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai911l.acmp_fnsh_ts IS '수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai911l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai911l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai911l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai911l TO qidp;


-- qidp.tb_uda_uai912l definition



CREATE TABLE qidp.tb_uda_uai912l (
	assz_btch_acmp_id varchar(20) NOT NULL, -- 자산화배치수행ID
	assz_trms_tgt_sys_dcd bpchar(2) NOT NULL,
	assz_btch_tcd bpchar(2) NOT NULL,
	assz_meta_pcsn_sqn numeric(10) NOT NULL,
	img_sqn numeric(5) NOT NULL, -- 이미지순번
	assz_unfc_id varchar(20) NOT NULL, -- 자산화통합ID
	assz_page_no numeric(5) NULL, -- 자산화페이지번호
	assz_img_no numeric(5) NULL, -- 자산화이미지번호
	assz_img_tppo_xcr_vl numeric(11, 4) NULL, -- 자산화이미지상단X좌표값
	assz_img_tppo_ycr_vl numeric(11, 4) NULL, -- 자산화이미지상단Y좌표값
	assz_img_lwen_xcr_vl numeric(11, 4) NULL, -- 자산화이미지하단X좌표값
	assz_img_lwen_ycr_vl numeric(11, 4) NULL, -- 자산화이미지하단Y좌표값
	assz_img_file_nm varchar(250) NULL, -- 자산화이미지파일명
	assz_img_con text NULL, -- 자산화이미지내용
	assz_img_pcsn_tcd bpchar(2) NULL, -- 자산화이미지처리유형코드
	assz_pcsn_file_path_nm varchar(200) NULL, -- 자산화처리파일경로명
	acmp_sttg_ts timestamp NULL, -- 수행시작일시
	acmp_fnsh_ts timestamp NULL, -- 수행종료일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uai912l_pk PRIMARY KEY (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, img_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uai912l IS 'UDA이미지자산화결과상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_btch_acmp_id IS '자산화배치수행ID';
COMMENT ON COLUMN qidp.tb_uda_uai912l.img_sqn IS '이미지순번';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_unfc_id IS '자산화통합ID';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_page_no IS '자산화페이지번호';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_no IS '자산화이미지번호';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_tppo_xcr_vl IS '자산화이미지상단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_tppo_ycr_vl IS '자산화이미지상단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_lwen_xcr_vl IS '자산화이미지하단X좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_lwen_ycr_vl IS '자산화이미지하단Y좌표값';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_file_nm IS '자산화이미지파일명';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_con IS '자산화이미지내용';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_img_pcsn_tcd IS '자산화이미지처리유형코드';
COMMENT ON COLUMN qidp.tb_uda_uai912l.assz_pcsn_file_path_nm IS '자산화처리파일경로명';
COMMENT ON COLUMN qidp.tb_uda_uai912l.acmp_sttg_ts IS '수행시작일시';
COMMENT ON COLUMN qidp.tb_uda_uai912l.acmp_fnsh_ts IS '수행종료일시';
COMMENT ON COLUMN qidp.tb_uda_uai912l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uai912l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uai912l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uai912l TO qidp;


-- qidp.tb_uda_uaib01m definition



CREATE TABLE qidp.tb_uda_uaib01m (
	brcd bpchar(4) NOT NULL, -- 부점코드
	lsmd_ymd varchar(8) NULL, -- 최종변경년월일
	bzn bpchar(10) NOT NULL, -- 사업자등록번호
	krn_brm varchar(50) NOT NULL, -- 한글부점명
	brnc_fgr6_krn_nm bpchar(12) NOT NULL, -- 부점6자리한글명
	brnc_fgr4_krn_nm bpchar(8) NOT NULL, -- 부점4자리한글명
	ensn_brm varchar(50) NOT NULL, -- 영문부점명
	zpcd bpchar(6) NOT NULL, -- 우편번호
	brnc_gu_bsc_adr varchar(200) NOT NULL, -- 부점구기본주소
	brnc_gu_dtl_adr varchar(200) NOT NULL, -- 부점구상세주소
	brnc_tel_lln varchar(4) NOT NULL, -- 부점전화지역번호
	brnc_tpn_ton varchar(4) NOT NULL, -- 부점전화번호국번호
	brnc_tpn_srn varchar(4) NOT NULL, -- 부점전화번호일련번호
	rprs_fax_lln varchar(4) NOT NULL, -- 대표팩스지역번호
	rprs_fax_ton varchar(4) NULL, -- 대표팩스국번호
	rprs_fax_srn varchar(4) NOT NULL, -- 대표팩스일련번호
	fax_lln varchar(4) NOT NULL, -- 팩스지역번호
	fxn_ton varchar(4) NOT NULL, -- 팩스번호국번호
	fxn_srn varchar(4) NOT NULL, -- 팩스번호일련번호
	clcn_tel_lln varchar(4) NOT NULL, -- 콜센터전화지역번호
	clcn_tel_ton varchar(4) NOT NULL, -- 콜센터전화국번호
	clcn_tel_srn varchar(4) NOT NULL, -- 콜센터전화일련번호
	brnc_scd bpchar(1) NOT NULL, -- 부점상태코드
	old_gicd bpchar(6) NOT NULL, -- 구지로코드
	noec_cd bpchar(2) NOT NULL, -- 어음교환소코드
	brnc_dcd bpchar(1) NOT NULL, -- 부점구분코드
	brnc_lctn_cd bpchar(2) NOT NULL, -- 부점소재지코드
	cog_area_dcd bpchar(1) NOT NULL, -- 당좌개설보증금지역구분코드
	fxbr_dcd bpchar(1) NOT NULL, -- 외환점구분코드
	frex_brcd bpchar(4) NOT NULL, -- 외국환부점코드
	fex_onbr_ymd varchar(8) NULL, -- 외환개점년월일
	mnex_scbr_yn bpchar(1) NOT NULL, -- 환전특화부점여부
	mnex_scbr_rgsn_ymd varchar(8) NULL, -- 환전특화부점등록년월일
	fex_cntz_brcd bpchar(4) NOT NULL, -- 외환집중부점코드
	frfn_cnbr_dcd bpchar(1) NOT NULL, -- 외화자금집중부점구분코드
	bok_jrsd_uncn_brcd bpchar(6) NOT NULL, -- 한국은행관할통할부점코드
	pb_brnc_yn bpchar(1) NOT NULL, -- PB부점여부
	pb_brnc_dcd bpchar(1) NOT NULL, -- PB부점구분코드
	dream_enpr_yn bpchar(1) NOT NULL, -- 드림기업여부
	rm_brnc_yn bpchar(1) NOT NULL, -- RM부점여부
	indv_magr_cd bpchar(3) NOT NULL, -- 개인경영평가그룹코드
	enpr_mnap_grp_cd bpchar(3) NOT NULL, -- 기업경영평가그룹코드
	rm_mnap_grp_cd bpchar(3) NOT NULL, -- RM경영평가그룹코드
	coh_lmt_amt numeric(21, 3) NOT NULL, -- 시재한도금액
	inel_mtbr_yn bpchar(1) NOT NULL, -- 타행환모점여부
	exmbr_yn bpchar(1) NOT NULL, -- 교환모점여부
	exmbr_brcd bpchar(4) NOT NULL, -- 교환모점부점코드
	imde_rcde_brnc_yn bpchar(1) NOT NULL, -- 중요증서인수도부점여부
	own_dcd bpchar(1) NOT NULL, -- 소유구분코드
	onl_no varchar(6) NOT NULL, -- 온라인번호
	onbr_ymd varchar(8) NULL, -- 개점년월일
	clsr_pban_ymd varchar(8) NULL, -- 폐쇄공고년월일
	clos_ymd varchar(8) NULL, -- 마감년월일
	mbcd bpchar(4) NOT NULL, -- 모점코드
	unfc_brcd bpchar(10) NOT NULL, -- 통합부점코드
	rhdcd bpchar(4) NOT NULL, -- 지역본부코드
	jrsd_hqcd bpchar(4) NOT NULL, -- 관할본부코드
	bzsc_cd bpchar(4) NOT NULL, -- 사무지원센터코드
	trstl_mthr_brcd bpchar(4) NOT NULL, -- 국고결제모부점코드
	rvst_mtbr_brcd bpchar(4) NOT NULL, -- 수입인지모점부점코드
	bshd_cd bpchar(4) NOT NULL, -- 사업본부코드
	rdsc_mthr_brcd bpchar(4) NOT NULL, -- 재할모부점코드
	rnss_mthr_brcd bpchar(4) NOT NULL, -- 수입인지결제모부점코드
	acon_brcd bpchar(4) NOT NULL, -- 계리부점코드
	bobm_nm varchar(30) NULL, -- 영업점장명
	brmg_emn bpchar(6) NULL, -- 부점장직원번호
	edps_csn numeric(10) NOT NULL, -- 전산고객번호
	brnc_bsop_dcd bpchar(1) NOT NULL, -- 부점영업구분코드
	bkin_gicd bpchar(7) NOT NULL, -- 은행기관지로코드
	bncd bpchar(3) NOT NULL, -- 은행코드
	bok_jrsd_svbr_gicd bpchar(7) NOT NULL, -- 한국은행관할통할점지로코드
	nw_zpcd bpchar(6) NOT NULL, -- 신우편번호
	brnc_nw_bsc_adr varchar(200) NOT NULL, -- 부점신기본주소
	brnc_nw_dtl_adr varchar(200) NOT NULL, -- 부점신상세주소
	hub_eai_rflc_yn bpchar(1) NOT NULL, -- BIZHUBEAI반영여부
	pdf_eai_rflc_yn bpchar(1) NOT NULL, -- 상품EAI반영여부
	bpm_eai_rflc_yn bpchar(1) NOT NULL, -- BPMEAI반영여부
	ogzn_attcd bpchar(4) NOT NULL, -- 조직속성코드
	ogzn_kcd bpchar(2) NOT NULL, -- 조직종류코드
	bdp_etl_base_ymd varchar(8) NOT NULL, -- ETCL기준년월일
	bdp_etl_job_ts timestamp NOT NULL, -- ETCL작업일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT pk_uda_uaib01m PRIMARY KEY (brcd)
);
COMMENT ON TABLE qidp.tb_uda_uaib01m IS 'UDA부점기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uaib01m.brcd IS '부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.lsmd_ymd IS '최종변경년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bzn IS '사업자등록번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.krn_brm IS '한글부점명';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_fgr6_krn_nm IS '부점6자리한글명';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_fgr4_krn_nm IS '부점4자리한글명';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.ensn_brm IS '영문부점명';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.zpcd IS '우편번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_gu_bsc_adr IS '부점구기본주소';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_gu_dtl_adr IS '부점구상세주소';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_tel_lln IS '부점전화지역번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_tpn_ton IS '부점전화번호국번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_tpn_srn IS '부점전화번호일련번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rprs_fax_lln IS '대표팩스지역번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rprs_fax_ton IS '대표팩스국번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rprs_fax_srn IS '대표팩스일련번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fax_lln IS '팩스지역번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fxn_ton IS '팩스번호국번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fxn_srn IS '팩스번호일련번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.clcn_tel_lln IS '콜센터전화지역번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.clcn_tel_ton IS '콜센터전화국번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.clcn_tel_srn IS '콜센터전화일련번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_scd IS '부점상태코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.old_gicd IS '구지로코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.noec_cd IS '어음교환소코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_dcd IS '부점구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_lctn_cd IS '부점소재지코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.cog_area_dcd IS '당좌개설보증금지역구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fxbr_dcd IS '외환점구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.frex_brcd IS '외국환부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fex_onbr_ymd IS '외환개점년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.mnex_scbr_yn IS '환전특화부점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.mnex_scbr_rgsn_ymd IS '환전특화부점등록년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.fex_cntz_brcd IS '외환집중부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.frfn_cnbr_dcd IS '외화자금집중부점구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bok_jrsd_uncn_brcd IS '한국은행관할통할부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.pb_brnc_yn IS 'PB부점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.pb_brnc_dcd IS 'PB부점구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.dream_enpr_yn IS '드림기업여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rm_brnc_yn IS 'RM부점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.indv_magr_cd IS '개인경영평가그룹코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.enpr_mnap_grp_cd IS '기업경영평가그룹코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rm_mnap_grp_cd IS 'RM경영평가그룹코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.coh_lmt_amt IS '시재한도금액';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.inel_mtbr_yn IS '타행환모점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.exmbr_yn IS '교환모점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.exmbr_brcd IS '교환모점부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.imde_rcde_brnc_yn IS '중요증서인수도부점여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.own_dcd IS '소유구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.onl_no IS '온라인번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.onbr_ymd IS '개점년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.clsr_pban_ymd IS '폐쇄공고년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.clos_ymd IS '마감년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.mbcd IS '모점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.unfc_brcd IS '통합부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rhdcd IS '지역본부코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.jrsd_hqcd IS '관할본부코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bzsc_cd IS '사무지원센터코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.trstl_mthr_brcd IS '국고결제모부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rvst_mtbr_brcd IS '수입인지모점부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bshd_cd IS '사업본부코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rdsc_mthr_brcd IS '재할모부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.rnss_mthr_brcd IS '수입인지결제모부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.acon_brcd IS '계리부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bobm_nm IS '영업점장명';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brmg_emn IS '부점장직원번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.edps_csn IS '전산고객번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_bsop_dcd IS '부점영업구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bkin_gicd IS '은행기관지로코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bncd IS '은행코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bok_jrsd_svbr_gicd IS '한국은행관할통할점지로코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.nw_zpcd IS '신우편번호';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_nw_bsc_adr IS '부점신기본주소';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.brnc_nw_dtl_adr IS '부점신상세주소';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.hub_eai_rflc_yn IS 'BIZHUBEAI반영여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.pdf_eai_rflc_yn IS '상품EAI반영여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bpm_eai_rflc_yn IS 'BPMEAI반영여부';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.ogzn_attcd IS '조직속성코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.ogzn_kcd IS '조직종류코드';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bdp_etl_base_ymd IS 'ETCL기준년월일';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.bdp_etl_job_ts IS 'ETCL작업일시';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uaib01m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uaib01m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uaib01m TO qidp;


-- qidp.tb_uda_uaie01m definition



CREATE TABLE qidp.tb_uda_uaie01m (
	emn bpchar(6) NOT NULL, -- 직원번호
	emm varchar(50) NOT NULL, -- 직원명
	emp_ensn_nm varchar(50) NULL, -- 직원영문명
	gndr_dcd bpchar(1) NOT NULL, -- 성별구분코드
	hlof_yn bpchar(1) NOT NULL, -- 재직여부
	etbn_dcd bpchar(2) NOT NULL, -- 입행구분코드
	etbn_ymd varchar(8) NULL, -- 입행년월일
	blng_brcd bpchar(4) NOT NULL, -- 소속부점코드
	beteam_cd bpchar(4) NOT NULL, -- 소속팀코드
	exig_blng_ymd varchar(8) NULL, -- 현소속년월일
	trth_work_brcd bpchar(4) NOT NULL, -- 실제근무부점코드
	rswr_brcd bpchar(4) NOT NULL, -- 주재근무부점코드
	brmd_rsn_con varchar(50) NULL, -- 부점변경사유내용
	ducd bpchar(4) NOT NULL, -- 직책코드
	duty_cd bpchar(4) NOT NULL, -- 직무코드
	duty_ymd varchar(50) NULL, -- 직무년월일
	duty_grd varchar(5) NOT NULL, -- 직무등급
	mndt_cd bpchar(4) NOT NULL, -- 보임코드
	mndt_ymd varchar(8) NULL, -- 보임년월일
	jbtt_cd bpchar(4) NOT NULL, -- 직위코드
	jbtt_ymd varchar(8) NULL, -- 직위년월일
	prar_jbtt_no bpchar(4) NOT NULL, -- 인사직위번호
	prar_jtm varchar(50) NULL, -- 인사직위명
	name_nm varchar(30) NULL, -- 호칭명
	emp_ext_name_nm varchar(50) NULL, -- 직원대외호칭명
	jbcl_cd bpchar(1) NOT NULL, -- 직급코드
	trth_birt_ymd varchar(8) NULL, -- 실제생년월일
	slcn_uncg_birt_ymd varchar(8) NULL, -- 양력환산생년월일
	lnsl_dcd bpchar(1) NOT NULL, -- 음양구분코드
	emp_rost_sqc numeric(7) NOT NULL, -- 직원명부순서
	emat_rcde_dcd bpchar(1) NOT NULL, -- 직원권한인수도구분코드
	user_rgsn_brcd bpchar(4) NOT NULL, -- 사용자등록부점코드
	user_rgsn_ymd varchar(8) NULL, -- 사용자등록년월일
	edps_csn numeric(10) NOT NULL, -- 전산고객번호
	rtrm_ymd varchar(8) NULL, -- 퇴직년월일
	prfl_nm varchar(50) NULL, -- 프로파일명
	prar_onl_no varchar(50) NULL, -- 인사온라인번호
	emp_exti_no varchar(50) NULL, -- 직원내선번호
	ead varchar(50) NULL, -- 이메일주소
	lsmd_ymd varchar(8) NULL, -- 최종변경년월일
	athr_mngm_id bpchar(8) NULL, -- 권한관리ID
	wbcs_rlnm_altr_no varchar(16) NULL, -- 전행고객실명대체번호
	lgl_birt_ymd bpchar(8) NULL, -- 법적생년월일
	etc_bswr_con varchar(300) NULL, -- 기타업무내용
	rgsf_dcd bpchar(4) NOT NULL, -- 정원구분코드
	bdp_etl_base_ymd varchar(8) NOT NULL, -- ETCL기준년월일
	bdp_etl_job_ts timestamp NOT NULL, -- ETCL작업일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT pk_uda_uaie01m PRIMARY KEY (emn)
);
COMMENT ON TABLE qidp.tb_uda_uaie01m IS 'UDA직원기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uaie01m.emn IS '직원번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emm IS '직원명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emp_ensn_nm IS '직원영문명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.gndr_dcd IS '성별구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.hlof_yn IS '재직여부';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.etbn_dcd IS '입행구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.etbn_ymd IS '입행년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.blng_brcd IS '소속부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.beteam_cd IS '소속팀코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.exig_blng_ymd IS '현소속년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.trth_work_brcd IS '실제근무부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.rswr_brcd IS '주재근무부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.brmd_rsn_con IS '부점변경사유내용';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.ducd IS '직책코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.duty_cd IS '직무코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.duty_ymd IS '직무년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.duty_grd IS '직무등급';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.mndt_cd IS '보임코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.mndt_ymd IS '보임년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.jbtt_cd IS '직위코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.jbtt_ymd IS '직위년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.prar_jbtt_no IS '인사직위번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.prar_jtm IS '인사직위명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.name_nm IS '호칭명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emp_ext_name_nm IS '직원대외호칭명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.jbcl_cd IS '직급코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.trth_birt_ymd IS '실제생년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.slcn_uncg_birt_ymd IS '양력환산생년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.lnsl_dcd IS '음양구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emp_rost_sqc IS '직원명부순서';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emat_rcde_dcd IS '직원권한인수도구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.user_rgsn_brcd IS '사용자등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.user_rgsn_ymd IS '사용자등록년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.edps_csn IS '전산고객번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.rtrm_ymd IS '퇴직년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.prfl_nm IS '프로파일명';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.prar_onl_no IS '인사온라인번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.emp_exti_no IS '직원내선번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.ead IS '이메일주소';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.lsmd_ymd IS '최종변경년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.athr_mngm_id IS '권한관리ID';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.wbcs_rlnm_altr_no IS '전행고객실명대체번호';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.lgl_birt_ymd IS '법적생년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.etc_bswr_con IS '기타업무내용';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.rgsf_dcd IS '정원구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.bdp_etl_base_ymd IS 'ETCL기준년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.bdp_etl_job_ts IS 'ETCL작업일시';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uaie01m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uaie01m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uaie01m TO qidp;


-- qidp.tb_uda_uaie40m definition



CREATE TABLE qidp.tb_uda_uaie40m (
	becd bpchar(4) NOT NULL, -- 소속코드
	hgrn_becd bpchar(4) NOT NULL, -- 상위소속코드
	blng_nm varchar(50) NOT NULL, -- 소속명
	ofor_sqc varchar(10) NULL, -- 직제순서
	ogzn_attcd bpchar(4) NOT NULL, -- 조직속성코드
	jrsd_hqcd bpchar(4) NOT NULL, -- 관할본부코드
	jrsd_brcd bpchar(4) NOT NULL, -- 관할부점코드
	brrm_cd bpchar(4) NOT NULL, -- 부점RM코드
	brgr_ut_ogcd bpchar(4) NOT NULL, -- 부점장급단위조직코드
	acon_brcd bpchar(4) NOT NULL, -- 계리부점코드
	blng_opn_ymd varchar(8) NULL, -- 소속개설년월일
	blng_clsr_ymd varchar(8) NULL, -- 소속폐쇄년월일
	inrc_tpn varchar(20) NULL, -- 교환전화번호
	strh_tpn varchar(20) NULL, -- 직통전화번호
	inbk_tpn varchar(20) NULL, -- 행내전화번호
	fxn varchar(20) NULL, -- 팩스번호
	mnap_grp_id varchar(10) NOT NULL, -- 경영평가그룹ID
	magr_nm varchar(100) NULL, -- 경영평가그룹명
	lsmd_ymd varchar(8) NULL, -- 최종변경년월일
	bdp_etl_base_ymd varchar(8) NOT NULL, -- ETCL기준년월일
	bdp_etl_job_ts timestamp NOT NULL, -- ETCL작업일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT pk_uda_uaie40m PRIMARY KEY (becd)
);
COMMENT ON TABLE qidp.tb_uda_uaie40m IS 'UDA소속팀기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uaie40m.becd IS '소속코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.hgrn_becd IS '상위소속코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.blng_nm IS '소속명';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.ofor_sqc IS '직제순서';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.ogzn_attcd IS '조직속성코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.jrsd_hqcd IS '관할본부코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.jrsd_brcd IS '관할부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.brrm_cd IS '부점RM코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.brgr_ut_ogcd IS '부점장급단위조직코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.acon_brcd IS '계리부점코드';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.blng_opn_ymd IS '소속개설년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.blng_clsr_ymd IS '소속폐쇄년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.inrc_tpn IS '교환전화번호';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.strh_tpn IS '직통전화번호';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.inbk_tpn IS '행내전화번호';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.fxn IS '팩스번호';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.mnap_grp_id IS '경영평가그룹ID';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.magr_nm IS '경영평가그룹명';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.lsmd_ymd IS '최종변경년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.bdp_etl_base_ymd IS 'ETCL기준년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.bdp_etl_job_ts IS 'ETCL작업일시';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uaie40m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uaie40m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uaie40m TO qidp;


-- qidp.tb_uda_uaie54d definition



CREATE TABLE qidp.tb_uda_uaie54d (
	emn bpchar(6) NOT NULL, -- 직원번호
	dllz_cd_vl bpchar(7) NOT NULL, -- 근태코드값
	hltm_dcd bpchar(1) NOT NULL, -- 반차구분코드
	sttg_ymd varchar(8) NOT NULL, -- 시작년월일
	fnsh_ymd varchar(8) NOT NULL, -- 종료년월일
	sttg_hms bpchar(6) NOT NULL, -- 시작시각
	fnsh_hms bpchar(6) NOT NULL, -- 종료시각
	snct_id varchar(20) NOT NULL, -- 결재ID
	dllz_cd_nm varchar(50) NULL, -- 근태코드명
	vctn_ndd numeric(6) NOT NULL, -- 휴가일수
	wrpx_emn bpchar(6) NULL, -- 대직자직원번호
	spcm_adt_yn bpchar(1) NOT NULL, -- 특명감사여부
	bdp_etl_base_ymd varchar(8) NOT NULL, -- ETCL기준년월일
	bdp_etl_job_ts timestamp NOT NULL, -- ETCL작업일시
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT pk_uda_uaie54d PRIMARY KEY (emn, dllz_cd_vl, hltm_dcd, sttg_ymd, fnsh_ymd, sttg_hms, fnsh_hms, snct_id)
);
COMMENT ON TABLE qidp.tb_uda_uaie54d IS 'UDA직원근태상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uaie54d.emn IS '직원번호';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.dllz_cd_vl IS '근태코드값';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.hltm_dcd IS '반차구분코드';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.sttg_ymd IS '시작년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.fnsh_ymd IS '종료년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.sttg_hms IS '시작시각';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.fnsh_hms IS '종료시각';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.snct_id IS '결재ID';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.dllz_cd_nm IS '근태코드명';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.vctn_ndd IS '휴가일수';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.wrpx_emn IS '대직자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.spcm_adt_yn IS '특명감사여부';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.bdp_etl_base_ymd IS 'ETCL기준년월일';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.bdp_etl_job_ts IS 'ETCL작업일시';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uaie54d.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uaie54d OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uaie54d TO qidp;


-- qidp.tb_uda_uap103d definition



CREATE TABLE qidp.tb_uda_uap103d (
	assz_orgn_sys_cd_con varchar(6) NOT NULL, -- 자산화원천시스템코드내용
	athr_sqn numeric(5) NOT NULL, -- 권한순번
	assz_snct_gear_cprt_id varchar(50) NULL, -- 자산화결재연동조합ID
	assz_snct_id varchar(50) NULL, -- 자산화결재ID
	assz_athr_mdfc_tgt_nm varchar(10) NULL, -- 자산화권한변경대상명
	assz_athr_mdfc_tgt_id varchar(6) NULL, -- 자산화권한변경대상ID
	assz_athr_grnt_yn bpchar(1) NULL, -- 자산화권한부여여부
	assz_athr_mdfc_rsnm varchar(10) NULL, -- 자산화권한변경사유명
	assz_athr_mdrs_dtl_con varchar(200) NULL, -- 자산화권한변경사유상세내용
	assz_athr_mdfr_emn bpchar(6) NULL, -- 자산화권한변경자직원번호
	assz_athr_mdfc_ts timestamp NULL, -- 자산화권한변경일시
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap103d_pk PRIMARY KEY (assz_orgn_sys_cd_con, athr_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uap103d IS 'UDA자산화포탈권한상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uap103d.athr_sqn IS '권한순번';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_snct_gear_cprt_id IS '자산화결재연동조합ID';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_snct_id IS '자산화결재ID';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdfc_tgt_nm IS '자산화권한변경대상명';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdfc_tgt_id IS '자산화권한변경대상ID';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_grnt_yn IS '자산화권한부여여부';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdfc_rsnm IS '자산화권한변경사유명';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdrs_dtl_con IS '자산화권한변경사유상세내용';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdfr_emn IS '자산화권한변경자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103d.assz_athr_mdfc_ts IS '자산화권한변경일시';
COMMENT ON COLUMN qidp.tb_uda_uap103d.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap103d.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103d.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap103d.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103d.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap103d.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap103d.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap103d.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap103d OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap103d TO qidp;


-- qidp.tb_uda_uap103h definition



CREATE TABLE qidp.tb_uda_uap103h (
	assz_orgn_sys_cd_con varchar(6) NOT NULL, -- 자산화원천시스템코드내용
	athr_sqn numeric(5) NOT NULL, -- 권한순번
	prhs_sqn numeric(5) NOT NULL, -- 이력순번
	assz_snct_gear_cprt_id varchar(50) NULL, -- 자산화결재연동조합ID
	assz_snct_id varchar(50) NULL, -- 자산화결재ID
	assz_athr_mdfc_tgt_nm varchar(10) NULL, -- 자산화권한변경대상명
	assz_athr_mdfc_tgt_id varchar(6) NULL, -- 자산화권한변경대상ID
	assz_athr_grnt_yn bpchar(1) NULL, -- 자산화권한부여여부
	assz_athr_mdfc_rsnm varchar(10) NULL, -- 자산화권한변경사유명
	assz_athr_mdrs_dtl_con varchar(200) NULL, -- 자산화권한변경사유상세내용
	assz_athr_mdfr_emn bpchar(6) NULL, -- 자산화권한변경자직원번호
	assz_athr_mdfc_ts timestamp NULL, -- 자산화권한변경일시
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap103h_pk PRIMARY KEY (assz_orgn_sys_cd_con, athr_sqn, prhs_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uap103h IS 'UDA자산화포탈권한변경이력';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uap103h.athr_sqn IS '권한순번';
COMMENT ON COLUMN qidp.tb_uda_uap103h.prhs_sqn IS '이력순번';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_snct_gear_cprt_id IS '자산화결재연동조합ID';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_snct_id IS '자산화결재ID';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdfc_tgt_nm IS '자산화권한변경대상명';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdfc_tgt_id IS '자산화권한변경대상ID';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_grnt_yn IS '자산화권한부여여부';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdfc_rsnm IS '자산화권한변경사유명';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdrs_dtl_con IS '자산화권한변경사유상세내용';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdfr_emn IS '자산화권한변경자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103h.assz_athr_mdfc_ts IS '자산화권한변경일시';
COMMENT ON COLUMN qidp.tb_uda_uap103h.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap103h.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103h.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap103h.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103h.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap103h.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap103h.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap103h.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap103h OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap103h TO qidp;


-- qidp.tb_uda_uap103m definition



CREATE TABLE qidp.tb_uda_uap103m (
	assz_orgn_sys_cd_con varchar(6) NOT NULL, -- 자산화원천시스템코드내용
	assz_athr_tcd bpchar(2) NULL, -- 자산화권한유형코드
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap103m_pk PRIMARY KEY (assz_orgn_sys_cd_con)
);
COMMENT ON TABLE qidp.tb_uda_uap103m IS 'UDA자산화포탈권한기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap103m.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uap103m.assz_athr_tcd IS '자산화권한유형코드';
COMMENT ON COLUMN qidp.tb_uda_uap103m.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap103m.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap103m.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap103m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap103m.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap103m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap103m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap103m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap103m TO qidp;


-- qidp.tb_uda_uap104d definition



CREATE TABLE qidp.tb_uda_uap104d (
	assz_snct_id varchar(50) NOT NULL, -- 자산화결재ID
	snct_sqn numeric(5) NOT NULL, -- 결재순번
	snct_emn bpchar(6) NULL, -- 결재직원번호
	assz_snpn_dcd bpchar(1) NULL, -- 자산화결재자구분코드
	snct_ts timestamp NULL, -- 결재일시
	snct_opnn_con varchar(1000) NULL, -- 결재의견내용
	assz_snct_stnm varchar(50) NULL, -- 자산화결재상태명
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap104d_pk PRIMARY KEY (assz_snct_id, snct_sqn)
);
COMMENT ON TABLE qidp.tb_uda_uap104d IS 'UDA자산화포탈결재상세';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap104d.assz_snct_id IS '자산화결재ID';
COMMENT ON COLUMN qidp.tb_uda_uap104d.snct_sqn IS '결재순번';
COMMENT ON COLUMN qidp.tb_uda_uap104d.snct_emn IS '결재직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104d.assz_snpn_dcd IS '자산화결재자구분코드';
COMMENT ON COLUMN qidp.tb_uda_uap104d.snct_ts IS '결재일시';
COMMENT ON COLUMN qidp.tb_uda_uap104d.snct_opnn_con IS '결재의견내용';
COMMENT ON COLUMN qidp.tb_uda_uap104d.assz_snct_stnm IS '자산화결재상태명';
COMMENT ON COLUMN qidp.tb_uda_uap104d.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap104d.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104d.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap104d.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104d.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap104d.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap104d.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap104d.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap104d OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap104d TO qidp;


-- qidp.tb_uda_uap104l definition



CREATE TABLE qidp.tb_uda_uap104l (
	assz_snct_id varchar(50) NOT NULL, -- 자산화결재ID
	assz_snct_tgt_id varchar(20) NOT NULL, -- 자산화결재대상ID
	assz_lnlf_cyl_tgt_yn bpchar(1) NULL, -- 자산화수명주기대상여부
	assz_lnlf_cyl_ymd timestamp NULL, -- 자산화수명주기년월일
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap104l_pk PRIMARY KEY (assz_snct_id, assz_snct_tgt_id)
);
COMMENT ON TABLE qidp.tb_uda_uap104l IS 'UDA자산화포탈결재대상내역';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap104l.assz_snct_id IS '자산화결재ID';
COMMENT ON COLUMN qidp.tb_uda_uap104l.assz_snct_tgt_id IS '자산화결재대상ID';
COMMENT ON COLUMN qidp.tb_uda_uap104l.assz_lnlf_cyl_tgt_yn IS '자산화수명주기대상여부';
COMMENT ON COLUMN qidp.tb_uda_uap104l.assz_lnlf_cyl_ymd IS '자산화수명주기년월일';
COMMENT ON COLUMN qidp.tb_uda_uap104l.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap104l.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap104l OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap104l TO qidp;


-- qidp.tb_uda_uap104m definition



CREATE TABLE qidp.tb_uda_uap104m (
	assz_snct_id varchar(50) NOT NULL, -- 자산화결재ID
	assz_snct_bwcd bpchar(3) NULL, -- 자산화결재업무코드
	snct_ttl_nm varchar(100) NULL, -- 결재제목명
	assz_snct_stnm varchar(50) NULL, -- 자산화결재상태명
	snct_rqst_emn bpchar(6) NULL, -- 결재요청직원번호
	snct_rqst_ts timestamp NULL, -- 결재요청일시
	snct_rqst_con varchar(4000) NULL, -- 결재요청내용
	snct_emn bpchar(6) NULL, -- 결재직원번호
	snct_ts timestamp NULL, -- 결재일시
	assz_frst_rcps_emn bpchar(6) NULL, -- 자산화최초접수자직원번호
	assz_frst_rcip_ts timestamp NULL, -- 자산화최초접수일시
	assz_orgn_sys_cd_con varchar(6) NULL, -- 자산화원천시스템코드내용
	assz_dcmn_clsf_id varchar(50) NULL, -- 자산화문서분류ID
	assz_file_grp_id varchar(50) NULL, -- 자산화파일그룹아이디
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT tb_uda_uap104m_pk PRIMARY KEY (assz_snct_id)
);
COMMENT ON TABLE qidp.tb_uda_uap104m IS 'UDA자산화포탈결재기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_snct_id IS '자산화결재ID';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_snct_bwcd IS '자산화결재업무코드';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_ttl_nm IS '결재제목명';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_snct_stnm IS '자산화결재상태명';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_rqst_emn IS '결재요청직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_rqst_ts IS '결재요청일시';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_rqst_con IS '결재요청내용';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_emn IS '결재직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104m.snct_ts IS '결재일시';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_frst_rcps_emn IS '자산화최초접수자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_frst_rcip_ts IS '자산화최초접수일시';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_orgn_sys_cd_con IS '자산화원천시스템코드내용';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_dcmn_clsf_id IS '자산화문서분류ID';
COMMENT ON COLUMN qidp.tb_uda_uap104m.assz_file_grp_id IS '자산화파일그룹아이디';
COMMENT ON COLUMN qidp.tb_uda_uap104m.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap104m.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap104m.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap104m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap104m.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap104m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap104m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap104m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap104m TO qidp;


-- qidp.tb_uda_uap105m definition



CREATE TABLE qidp.tb_uda_uap105m (
	assz_snct_bwcd bpchar(3) NOT NULL, -- 자산화결재업무코드
	rcps_emn bpchar(6) NULL, -- 접수자직원번호
	assz_mnmm_snln_jbcl_dcd bpchar(4) NULL, -- 자산화최소결재선직급구분코드
	apof_cmsn_yn bpchar(1) NULL, -- 전결권자위임여부
	rbcd bpchar(4) NULL, -- 등록부점코드
	rgsr_emn bpchar(6) NULL, -- 등록자직원번호
	rgsn_ts timestamp NULL, -- 등록일시
	edtr_emn bpchar(6) NULL, -- 수정자직원번호
	amnn_ts timestamp NULL, -- 수정일시
	del_yn bpchar(1) NULL, -- 삭제여부
	uda_sys_lsmd_id varchar(50) NOT NULL, -- 비정형데이터자산화시스템최종변경ID
	uda_sys_lsmd_ts timestamp NOT NULL, -- 비정형데이터자산화시스템최종변경일시
	CONSTRAINT newtable_pk PRIMARY KEY (assz_snct_bwcd)
);
COMMENT ON TABLE qidp.tb_uda_uap105m IS 'UDA자산화포탈결재선기본';

-- Column comments

COMMENT ON COLUMN qidp.tb_uda_uap105m.assz_snct_bwcd IS '자산화결재업무코드';
COMMENT ON COLUMN qidp.tb_uda_uap105m.rcps_emn IS '접수자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap105m.assz_mnmm_snln_jbcl_dcd IS '자산화최소결재선직급구분코드';
COMMENT ON COLUMN qidp.tb_uda_uap105m.apof_cmsn_yn IS '전결권자위임여부';
COMMENT ON COLUMN qidp.tb_uda_uap105m.rbcd IS '등록부점코드';
COMMENT ON COLUMN qidp.tb_uda_uap105m.rgsr_emn IS '등록자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap105m.rgsn_ts IS '등록일시';
COMMENT ON COLUMN qidp.tb_uda_uap105m.edtr_emn IS '수정자직원번호';
COMMENT ON COLUMN qidp.tb_uda_uap105m.amnn_ts IS '수정일시';
COMMENT ON COLUMN qidp.tb_uda_uap105m.del_yn IS '삭제여부';
COMMENT ON COLUMN qidp.tb_uda_uap105m.uda_sys_lsmd_id IS '비정형데이터자산화시스템최종변경ID';
COMMENT ON COLUMN qidp.tb_uda_uap105m.uda_sys_lsmd_ts IS '비정형데이터자산화시스템최종변경일시';

-- Permissions

ALTER TABLE qidp.tb_uda_uap105m OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_uda_uap105m TO qidp;


-- qidp.tb_user_manage definition



CREATE TABLE qidp.tb_user_manage (
	emp_no varchar(20) NOT NULL, -- 직원번호
	passwd varchar(200) NOT NULL, -- 비밀번호
	"role" varchar(20) DEFAULT 'NORMAL'::character varying NULL, -- 권한(일반, 관리자, 슈퍼관리자)
	first_allow_ip varchar(45) NULL, -- 로그인 허용IP1
	second_allow_ip varchar(45) NULL, -- 로그인 허용IP2
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	emp_role bpchar(1) DEFAULT '3'::bpchar NULL,
	CONSTRAINT pk_tb_user_manage PRIMARY KEY (emp_no)
);
COMMENT ON TABLE qidp.tb_user_manage IS '사용자관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_user_manage.emp_no IS '직원번호';
COMMENT ON COLUMN qidp.tb_user_manage.passwd IS '비밀번호';
COMMENT ON COLUMN qidp.tb_user_manage."role" IS '권한(일반, 관리자, 슈퍼관리자)';
COMMENT ON COLUMN qidp.tb_user_manage.first_allow_ip IS '로그인 허용IP1';
COMMENT ON COLUMN qidp.tb_user_manage.second_allow_ip IS '로그인 허용IP2';
COMMENT ON COLUMN qidp.tb_user_manage.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_user_manage.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_user_manage.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_user_manage.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_user_manage.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_user_manage.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_user_manage OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_user_manage TO qidp;


-- qidp.tb_anonymized_data_detail definition



CREATE TABLE qidp.tb_anonymized_data_detail (
	anonymized_data_id varchar(50) NOT NULL, -- 비식별화데이터 ID
	seq int4 NOT NULL, -- 비식별화데이터 상세 seq
	deid_data_id int4 NOT NULL, -- 비식별화 항목 ID
	normalized_data text NOT NULL, -- 비식별 데이터
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL, -- 등록시간
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정시간
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT pk_anonymized_data_detail PRIMARY KEY (anonymized_data_id, seq),
	CONSTRAINT fk_anonymized_data_detail FOREIGN KEY (anonymized_data_id) REFERENCES qidp.tb_anonymized_data(anonymized_data_id) ON DELETE CASCADE
);
COMMENT ON TABLE qidp.tb_anonymized_data_detail IS '비식별화데이터 상세 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_anonymized_data_detail.anonymized_data_id IS '비식별화데이터 ID';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.seq IS '비식별화데이터 상세 seq';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.deid_data_id IS '비식별화 항목 ID';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.normalized_data IS '비식별 데이터';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.registered_at IS '등록시간';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.updated_at IS '수정시간';
COMMENT ON COLUMN qidp.tb_anonymized_data_detail.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_anonymized_data_detail OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_anonymized_data_detail TO qidp;


-- qidp.tb_assetization_transmission definition



CREATE TABLE qidp.tb_assetization_transmission (
	transmission_id varchar(20) NOT NULL, -- 자산화결과전송 ID
	batch_integrated_id varchar(50) NOT NULL, -- 배치통합 ID
	mapping_system_id varchar(20) NOT NULL, -- 도착지 연계시스템 ID
	source_system varchar(100) NULL, -- 출발지 원천시스템
	integration_task_code varchar(20) NULL, -- 연동업무(수기등록(MDR), 문서폐기(DEL), 일배치(BAT) 등)
	transmitted_at timestamp NULL, -- 전송일시
	transmission_status varchar(20) NULL, -- 전송상태(SUCCESS/FAIL)
	error_log text NULL, -- 에러로그
	registered_branch varchar(50) NOT NULL, -- 등록부점
	registered_by varchar(50) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT pk_ast_trans PRIMARY KEY (transmission_id),
	CONSTRAINT fk_ast_mapping FOREIGN KEY (mapping_system_id) REFERENCES qidp.tb_interface_system(interface_id)
);
COMMENT ON TABLE qidp.tb_assetization_transmission IS '자산화결과 전송 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_assetization_transmission.transmission_id IS '자산화결과전송 ID';
COMMENT ON COLUMN qidp.tb_assetization_transmission.batch_integrated_id IS '배치통합 ID';
COMMENT ON COLUMN qidp.tb_assetization_transmission.mapping_system_id IS '도착지 연계시스템 ID';
COMMENT ON COLUMN qidp.tb_assetization_transmission.source_system IS '출발지 원천시스템';
COMMENT ON COLUMN qidp.tb_assetization_transmission.integration_task_code IS '연동업무(수기등록(MDR), 문서폐기(DEL), 일배치(BAT) 등)';
COMMENT ON COLUMN qidp.tb_assetization_transmission.transmitted_at IS '전송일시';
COMMENT ON COLUMN qidp.tb_assetization_transmission.transmission_status IS '전송상태(SUCCESS/FAIL)';
COMMENT ON COLUMN qidp.tb_assetization_transmission.error_log IS '에러로그';
COMMENT ON COLUMN qidp.tb_assetization_transmission.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_assetization_transmission.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_assetization_transmission.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_assetization_transmission.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_assetization_transmission.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_assetization_transmission.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_assetization_transmission OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_assetization_transmission TO qidp;


-- qidp.tb_code_mid_group definition



CREATE TABLE qidp.tb_code_mid_group (
	group_code varchar(50) NOT NULL, -- 대분류 코드
	mid_code varchar(50) NOT NULL, -- 중분류 코드
	mid_code_name varchar(255) NOT NULL, -- 중분류 코드명
	description text NULL, -- 설명
	sort_order int4 DEFAULT 0 NULL, -- 정렬 순서
	use_yn bpchar(1) DEFAULT 'Y'::bpchar NULL, -- 사용여부
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_code_mid_group_pkey PRIMARY KEY (group_code, mid_code),
	CONSTRAINT tb_code_mid_group_group_code_fkey FOREIGN KEY (group_code) REFERENCES qidp.tb_code_group(group_code) ON DELETE CASCADE
);
COMMENT ON TABLE qidp.tb_code_mid_group IS '중분류코드 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_code_mid_group.group_code IS '대분류 코드';
COMMENT ON COLUMN qidp.tb_code_mid_group.mid_code IS '중분류 코드';
COMMENT ON COLUMN qidp.tb_code_mid_group.mid_code_name IS '중분류 코드명';
COMMENT ON COLUMN qidp.tb_code_mid_group.description IS '설명';
COMMENT ON COLUMN qidp.tb_code_mid_group.sort_order IS '정렬 순서';
COMMENT ON COLUMN qidp.tb_code_mid_group.use_yn IS '사용여부';
COMMENT ON COLUMN qidp.tb_code_mid_group.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_code_mid_group.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_code_mid_group.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_code_mid_group.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_code_mid_group.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_code_mid_group.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_code_mid_group OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_code_mid_group TO qidp;


-- qidp.tb_common_code definition



CREATE TABLE qidp.tb_common_code (
	group_code varchar(50) NOT NULL, -- 대분류 코드
	mid_code varchar(50) NOT NULL, -- 중분류 코드
	code varchar(20) NOT NULL, -- 소분류 코드
	parent_code varchar(20) NULL, -- 상위 코드
	"name" varchar(255) NOT NULL, -- 소분류 코드명
	description text NULL, -- 설명
	sort_order int4 DEFAULT 0 NULL, -- 정렬 순서
	use_yn bpchar(1) DEFAULT 'Y'::bpchar NULL, -- 사용여부
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(50) NULL, -- 등록자
	registered_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 등록일시
	updated_by varchar(50) NULL, -- 수정자
	updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 삭제여부
	CONSTRAINT tb_common_code_pkey PRIMARY KEY (group_code, mid_code, code),
	CONSTRAINT tb_common_code_group_code_mid_code_fkey FOREIGN KEY (group_code,mid_code) REFERENCES qidp.tb_code_mid_group(group_code,mid_code) ON DELETE CASCADE
);
COMMENT ON TABLE qidp.tb_common_code IS '소분류코드 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_common_code.group_code IS '대분류 코드';
COMMENT ON COLUMN qidp.tb_common_code.mid_code IS '중분류 코드';
COMMENT ON COLUMN qidp.tb_common_code.code IS '소분류 코드';
COMMENT ON COLUMN qidp.tb_common_code.parent_code IS '상위 코드';
COMMENT ON COLUMN qidp.tb_common_code."name" IS '소분류 코드명';
COMMENT ON COLUMN qidp.tb_common_code.description IS '설명';
COMMENT ON COLUMN qidp.tb_common_code.sort_order IS '정렬 순서';
COMMENT ON COLUMN qidp.tb_common_code.use_yn IS '사용여부';
COMMENT ON COLUMN qidp.tb_common_code.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_common_code.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_common_code.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_common_code.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_common_code.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_common_code.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_common_code OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_common_code TO qidp;


-- qidp.tb_deidentification_regex definition



CREATE TABLE qidp.tb_deidentification_regex (
	regex_id int4 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1 NO CYCLE) NOT NULL, -- 정규식 ID
	deid_data_id int4 NOT NULL, -- 비식별 항목 ID (FK)
	regex_pattern text NOT NULL, -- 정규표현식
	pattern_order int4 DEFAULT 1 NULL, -- 적용 우선순위
	registered_branch varchar(50) NULL, -- 등록 부서
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제 여부
	fix_yn bpchar(1) DEFAULT 'N'::bpchar NULL, -- 고정 여부
	CONSTRAINT tb_deidentification_regex_del_yn_check CHECK ((del_yn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
	CONSTRAINT tb_deidentification_regex_pkey PRIMARY KEY (regex_id),
	CONSTRAINT fk_regex_data FOREIGN KEY (deid_data_id) REFERENCES qidp.tb_deidentification_data(deid_data_id)
);
COMMENT ON TABLE qidp.tb_deidentification_regex IS '자산화 비식별화 정규식 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_deidentification_regex.regex_id IS '정규식 ID';
COMMENT ON COLUMN qidp.tb_deidentification_regex.deid_data_id IS '비식별 항목 ID (FK)';
COMMENT ON COLUMN qidp.tb_deidentification_regex.regex_pattern IS '정규표현식';
COMMENT ON COLUMN qidp.tb_deidentification_regex.pattern_order IS '적용 우선순위';
COMMENT ON COLUMN qidp.tb_deidentification_regex.registered_branch IS '등록 부서';
COMMENT ON COLUMN qidp.tb_deidentification_regex.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_deidentification_regex.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_deidentification_regex.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_deidentification_regex.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_deidentification_regex.del_yn IS '삭제 여부';
COMMENT ON COLUMN qidp.tb_deidentification_regex.fix_yn IS '고정 여부';

-- Permissions

ALTER TABLE qidp.tb_deidentification_regex OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_deidentification_regex TO qidp;


-- qidp.tb_file_info definition



CREATE TABLE qidp.tb_file_info (
	file_id bigserial NOT NULL, -- 파일아이디
	file_group_id bigserial NOT NULL, -- 파일그룹 아이디
	document_id varchar(20) NULL, -- 문서 아이디 (배치 후 생성될 예정)
	file_name varchar(255) NOT NULL, -- 파일명
	file_path varchar(255) NOT NULL, -- 파일경로
	file_type varchar(100) NULL, -- 파일타입
	file_size int8 NULL, -- 파일사이즈
	registered_branch varchar(50) NOT NULL, -- 등록부점
	registered_by varchar(50) NOT NULL, -- 등록자
	registered_at timestamp NOT NULL, -- 등록일시
	updated_by varchar(50) NOT NULL, -- 수정자
	updated_at timestamp NOT NULL, -- 수정일시
	del_yn varchar(1) DEFAULT 'N'::character varying NOT NULL, -- 삭제여부
	CONSTRAINT "PK_TB_FILE_INFO" PRIMARY KEY (file_id, file_group_id),
	CONSTRAINT "FK_tb_file_group_TO_tb_file_info_1" FOREIGN KEY (file_group_id) REFERENCES qidp.tb_file_group(file_group_id)
);
COMMENT ON TABLE qidp.tb_file_info IS '파일 관리 상세 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_file_info.file_id IS '파일아이디';
COMMENT ON COLUMN qidp.tb_file_info.file_group_id IS '파일그룹 아이디';
COMMENT ON COLUMN qidp.tb_file_info.document_id IS '문서 아이디 (배치 후 생성될 예정)';
COMMENT ON COLUMN qidp.tb_file_info.file_name IS '파일명';
COMMENT ON COLUMN qidp.tb_file_info.file_path IS '파일경로';
COMMENT ON COLUMN qidp.tb_file_info.file_type IS '파일타입';
COMMENT ON COLUMN qidp.tb_file_info.file_size IS '파일사이즈';
COMMENT ON COLUMN qidp.tb_file_info.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_file_info.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_file_info.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_file_info.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_file_info.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_file_info.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_file_info OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_file_info TO qidp;


-- qidp.tb_user_source_system definition



CREATE TABLE qidp.tb_user_source_system (
	emp_no varchar(20) NOT NULL, -- 직원번호
	source_system varchar(100) NOT NULL, -- 원천시스템
	registered_branch varchar(50) NULL, -- 등록부점
	registered_by varchar(100) NOT NULL, -- 등록자
	registered_at timestamp DEFAULT now() NOT NULL, -- 등록일시
	updated_by varchar(100) NULL, -- 수정자
	updated_at timestamp NULL, -- 수정일시
	del_yn bpchar(1) DEFAULT 'N'::bpchar NOT NULL, -- 삭제여부
	CONSTRAINT pk_tb_user_source_system PRIMARY KEY (emp_no, source_system),
	CONSTRAINT fk_user_source_user FOREIGN KEY (emp_no) REFERENCES qidp.tb_user_manage(emp_no)
);
COMMENT ON TABLE qidp.tb_user_source_system IS '사용자별 허용 원천시스템 관리 테이블';

-- Column comments

COMMENT ON COLUMN qidp.tb_user_source_system.emp_no IS '직원번호';
COMMENT ON COLUMN qidp.tb_user_source_system.source_system IS '원천시스템';
COMMENT ON COLUMN qidp.tb_user_source_system.registered_branch IS '등록부점';
COMMENT ON COLUMN qidp.tb_user_source_system.registered_by IS '등록자';
COMMENT ON COLUMN qidp.tb_user_source_system.registered_at IS '등록일시';
COMMENT ON COLUMN qidp.tb_user_source_system.updated_by IS '수정자';
COMMENT ON COLUMN qidp.tb_user_source_system.updated_at IS '수정일시';
COMMENT ON COLUMN qidp.tb_user_source_system.del_yn IS '삭제여부';

-- Permissions

ALTER TABLE qidp.tb_user_source_system OWNER TO qidp;
GRANT ALL ON TABLE qidp.tb_user_source_system TO qidp;




CREATE OR REPLACE FUNCTION qidp.get_next_seq(p_seq_name character varying, p_digit integer)
 RETURNS character varying
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    today_str VARCHAR(8);
    next_val INT;
BEGIN
    today_str := TO_CHAR(NOW(), 'YYYYMMDD');

    -- 오늘 날짜의 시퀀스가 없으면 초기화
    INSERT INTO tb_sequence_mng (seq_name, yyyymmdd, current_value, step)
    VALUES (p_seq_name, today_str, 1, 1)
    ON CONFLICT (seq_name, yyyymmdd) DO UPDATE
    SET current_value = tb_sequence_mng.current_value + 1,
        update_time = NOW()
    RETURNING tb_sequence_mng.current_value INTO next_val;

    -- 자리수 맞춰서 조합 (LPAD)
    RETURN 
	    CASE
	        WHEN p_seq_name = 'training_model_id' THEN
	            'Jeff_' || today_str || '_' || 
					LPAD(next_val::TEXT, GREATEST(2, LENGTH(next_val::TEXT)), '0')
			WHEN p_seq_name = 'batch_integrated_id' THEN
	            today_str || 'SYSTEM' || LPAD(next_val::TEXT, p_digit, '0')
	        ELSE
	        	  today_str || LPAD(next_val::TEXT, p_digit, '0')
    END;
    -- RETURN today_str || LPAD(next_val::TEXT, p_digit, '0');
END;
$function$
;

-- Permissions

ALTER FUNCTION qidp.get_next_seq(varchar, int4) OWNER TO qidp;
GRANT ALL ON FUNCTION qidp.get_next_seq(varchar, int4) TO qidp;


-- Permissions

GRANT ALL ON SCHEMA qidp TO qidp;
