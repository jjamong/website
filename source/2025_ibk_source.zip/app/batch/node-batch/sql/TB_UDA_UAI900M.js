const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertBatchJob(
  assz_btch_tcd,
  assz_trms_tgt_sys_dcd,
  acmp_ymd,
  btch_id,
  assz_orgn_sys_cd_con,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  eror_vl,
  assz_eror_con,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO TB_UDA_UAI900M(
        assz_btch_acmp_id
        ,assz_btch_tcd
        ,assz_trms_tgt_sys_dcd
        ,acmp_ymd
        ,btch_id
        ,assz_orgn_sys_cd_con
        ,assz_btch_pcsn_stg_dcd
        ,assz_btch_pcsn_tcd
        ,eror_vl
        ,assz_eror_con
        ,acmp_sttg_ts
        ,acmp_fnsh_ts
        ,uda_sys_lsmd_id
        ,uda_sys_lsmd_ts
      )
		  VALUES (
        (select coalesce($3::TEXT||$5 ||lpad((max(substring(assz_btch_acmp_id,15,6)::integer)+1) ::text ,6,'0'), $3::TEXT||$5 ||'000001')
							from TB_UDA_UAI900M
							where assz_orgn_sys_cd_con = $5
							and  acmp_ymd = $3),
        $1, $2, $3, $4,
        $5, $6, $7, $8,
        $9, current_timestamp, current_timestamp, $10,current_timestamp
      )
      RETURNING assz_btch_acmp_id;
		`,
      [
        assz_btch_tcd,
        assz_trms_tgt_sys_dcd,
        acmp_ymd,
        btch_id,
        assz_orgn_sys_cd_con,
        assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd,
        eror_vl,
        assz_eror_con,
        uda_sys_lsmd_id,
      ]
    );
    return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateBatchJob(
  assz_btch_acmp_id,
  assz_btch_tcd,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai010l
			SET assz_btch_tcd= coalesce($2,assz_btch_tcd)
			  , assz_btch_pcsn_stg_dcd= coalesce($3,assz_btch_pcsn_stg_dcd)
			  , assz_btch_pcsn_tcd= coalesce($4,assz_btch_pcsn_tcd)
			  , eror_vl= coalesce($5,eror_vl)
			  , assz_eror_con= coalesce($6,assz_eror_con)
			  , acmp_fnsh_ts=CURRENT_TIMESTAMP
			WHERE assz_btch_acmp_id=$1;
		`,
      [
        assz_btch_acmp_id,
        assz_btch_tcd,
        assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result.rows[0].btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateBatchRst(assz_btch_acmp_id, eror_vl, ASSZ_EROR_CON) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE TB_UDA_UAI900M
			SET eror_vl= coalesce($2,eror_vl)
			  , ASSZ_EROR_CON= case when ASSZ_EROR_CON is null then $3
			                      else ASSZ_EROR_CON ||CHR(13)||$3
			                  end
			WHERE assz_btch_acmp_id=$1;
		`,
      [assz_btch_acmp_id, eror_vl, ASSZ_EROR_CON]
    );
    return result;
  } finally {
    client.release();
  }
}

async function updateBatchFinishTime(
  assz_btch_acmp_id,
  assz_btch_tcd,
  assz_trms_tgt_sys_dcd
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      update tb_uda_uai900m
      set
        acmp_fnsh_ts = CURRENT_TIMESTAMP
        ,assz_btch_pcsn_stg_dcd = '05'
      where assz_btch_acmp_id = $1
      and assz_btch_tcd = $2
      and assz_trms_tgt_sys_dcd = $3
		`,
      [assz_btch_acmp_id, assz_btch_tcd, assz_trms_tgt_sys_dcd]
    );
    return result;
  } finally {
    client.release();
  }
}

async function insertSendBatchJob(
  assz_btch_acmp_id,
  assz_btch_tcd,
  assz_trms_tgt_sys_dcd,
  acmp_ymd,
  btch_id,
  assz_orgn_sys_cd_con,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  eror_vl,
  assz_eror_con,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      //   `
      //   INSERT INTO TB_UDA_UAI900M(
      //     assz_btch_acmp_id
      //     ,assz_btch_tcd
      //     ,assz_trms_tgt_sys_dcd
      //     ,acmp_ymd
      //     ,btch_id
      //     ,assz_orgn_sys_cd_con
      //     ,assz_btch_pcsn_stg_dcd
      //     ,assz_btch_pcsn_tcd
      //     ,eror_vl
      //     ,assz_eror_con
      //     ,acmp_sttg_ts
      //     ,acmp_fnsh_ts
      //     ,uda_sys_lsmd_id
      //     ,uda_sys_lsmd_ts
      //   )
      //   VALUES (
      //     $1, $2, $3, $4,
      //     $5, $6, $7, $8,
      //     $9, $10,current_timestamp, current_timestamp, $11,current_timestamp
      //   )
      // `,
      `
      INSERT INTO TB_UDA_UAI900M(
          assz_btch_acmp_id
          ,assz_btch_tcd
          ,assz_trms_tgt_sys_dcd
          ,acmp_ymd
          ,btch_id
          ,assz_orgn_sys_cd_con
          ,assz_btch_pcsn_stg_dcd
          ,assz_btch_pcsn_tcd
          ,eror_vl
          ,assz_eror_con
          ,acmp_sttg_ts
          ,acmp_fnsh_ts
          ,uda_sys_lsmd_id
          ,uda_sys_lsmd_ts
      )
      VALUES ($1, $2, $3, $4,$5, $6, $7, $8,$9, $10,current_timestamp, current_timestamp, $11,current_timestamp)
      ON CONFLICT (assz_btch_acmp_id,assz_btch_tcd,assz_trms_tgt_sys_dcd)
      DO UPDATE 
      SET 
          acmp_ymd				        = $4
          ,btch_id				        = $5
          ,assz_orgn_sys_cd_con	  = $6
          ,assz_btch_pcsn_stg_dcd = $7
          ,assz_btch_pcsn_tcd		  = $8
          ,eror_vl				        = $9
          ,assz_eror_con			    = $10
          ,acmp_sttg_ts			      = Current_timestamp
          ,acmp_fnsh_ts			      = Current_timestamp
          ,uda_sys_lsmd_id		    = $11
          ,uda_sys_lsmd_ts  		  = Current_timestamp    
    `,
      [
        assz_btch_acmp_id,
        assz_btch_tcd,
        assz_trms_tgt_sys_dcd,
        acmp_ymd,
        btch_id,
        assz_orgn_sys_cd_con,
        assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd,
        eror_vl,
        assz_eror_con,
        uda_sys_lsmd_id,
      ]
    );
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertBatchJob,
  updateBatchJob,
  updateBatchRst,
  dbEnd,
  updateBatchFinishTime,
  insertSendBatchJob,
};
