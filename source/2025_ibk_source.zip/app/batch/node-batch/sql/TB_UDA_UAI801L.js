const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function selectMetaOne(assz_btch_acmp_id, assz_cfbo_idnt_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			SELECT 
			  assz_btch_acmp_id
			, assz_meta_pcsn_sqn
			, assz_cfbo_idnt_id
			, orgn_data_rgsr_id
			,	TO_CHAR(rgsn_ts,'YYYY-MM-DD') || ' 00:00:00' as rgsn_ts
			,	TO_CHAR(amnn_ts,'YYYY-MM-DD') || ' 00:00:00' as amnn_ts
			,	assz_orgn_pcsn_dcd
			, assz_dcmn_clsf_id
			, assz_fmts_base_orgn_idnt_id
			, conn_ttl_nm
			, rgsr_dept_id
			, inq_nbi
			, vrsn_no
			, suco_dcmn_shrn_yn
			, suco_oppb_info_con
			, uda_sys_lsmd_id
			, uda_sys_lsmd_ts
			FROM TB_UDA_UAI801L
			WHERE assz_btch_acmp_id = $1
			AND assz_cfbo_idnt_id = $2
			`,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  assz_fmts_base_orgn_idnt_id,
  conn_ttl_nm,
  rgsr_dept_id,
  inq_nbi,
  vrsn_no,
  suco_dcmn_shrn_yn,
  suco_oppb_info_con,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI801L(
      assz_btch_acmp_id
    , assz_trms_tgt_sys_dcd
    , assz_btch_tcd
    , assz_meta_pcsn_sqn
    , assz_cfbo_idnt_id
    , orgn_data_rgsr_id
    , rgsn_ts
    , amnn_ts
    , assz_orgn_pcsn_dcd
    , assz_dcmn_clsf_id
    , assz_fmts_base_orgn_idnt_id
    , conn_ttl_nm
    , rgsr_dept_id
    , inq_nbi
    , vrsn_no
    , suco_dcmn_shrn_yn
    , suco_oppb_info_con
    , assz_pcsn_file_path_nm
    , uda_sys_lsmd_id
    , uda_sys_lsmd_ts
    )
		VALUES (
		  $1
      , '01'
      , '01'
		  , (
			   SELECT  coalesce(max(assz_meta_pcsn_sqn)+1,1)
				 FROM TB_UDA_UAI801L
				 WHERE assz_btch_acmp_id =$1::VARCHAR
				)
			,	$2
      , $3
      , TO_TIMESTAMP($4,'YYYYMMDDHH24MISS')
      , TO_TIMESTAMP($5,'YYYYMMDDHH24MISS')
      , $6
      , $7
      , $8
      , $9
      , $10
      , $11
      , $12
      , $13
      , $14
      , $15
      , $16
      , Current_timestamp
      );
		`,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        rgsr_dept_id,
        inq_nbi,
        vrsn_no,
        suco_dcmn_shrn_yn,
        suco_oppb_info_con,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		    SELECT
          TA.assz_btch_acmp_id
        , TA.assz_cfbo_idnt_id
        , TB.rgsn_ts
        , TB.file_nm               
        , TB.file_sqn              
        , TB.assz_orcp_file_path_nm     
        , TB.atch_yn               
        , TB.atch_sqn              
        , TB.assz_pcsn_file_path_nm               
        , TB.atch_nm
        , TB.assz_meta_pcsn_sqn 
        , TA.assz_unfc_id
        FROM TB_UDA_UAI000M TA left join TB_UDA_UAI802l TB on TA.assz_unfc_id = TB.assz_unfc_id and TA.assz_btch_acmp_id = TB.assz_btch_acmp_id
        WHERE TA.assz_btch_acmp_id = $1
        AND TA.assz_pcsn_tcd = 'C'
        AND TA.eror_vl = '0000'
	    `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNm(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
				SELECT substring(TA.file_nm FROM '^[^\\.]+') as doc_nm
				FROM TB_UDA_UAI910L TA ,TB_UDA_UAI001D TB
				WHERE TB.assz_btch_acmp_id = $1
				AND TA.assz_btch_acmp_id = TB.assz_btch_acmp_id
				AND TA.assz_cfbo_idnt_id = TB.assz_cfbo_idnt_id
				AND TA.assz_unfc_id = TB.assz_unfc_id
	    `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateUnfcId(
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
				UPDATE TB_UDA_UAI801L SET ASSZ_UNFC_ID = $1 WHERE ASSZ_BTCH_ACMP_ID = $2 AND ASSZ_CFBO_IDNT_ID = $3
			`,
      [assz_unfc_id, assz_btch_acmp_id, assz_cfbo_idnt_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  dbEnd,
  insertMeta,
  selectMeta,
  selectMetaDocNm,
  selectMetaOne,
  updateUnfcId,
};
