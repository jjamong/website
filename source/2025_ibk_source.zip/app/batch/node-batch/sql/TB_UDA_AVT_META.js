const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function dbEnd() {
  pool.end();
}

async function selectAvtMetaIIS(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT
          TA.assz_unfc_id as assz_unfc_id
        , TA.assz_unfc_id  as file_nm
        , TA.assz_cfbo_idnt_id as assz_cfbo_idnt_id
        , TA.flsz_vl as flsz_vl
        , 'pdf' as file_type
        , TA.assz_pcsn_tcd as assz_pcsn_tcd
        , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as rgsn_ts
        , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as amnn_ts
        , TB.cnvs_grp_cd
        , TB.assz_dcmn_clsf_id
        , TB.conn_ttl_nm as conn_ttl_nm
        , TB.assz_fund_dcmn_dcd
        , TB.assz_fund_new_abl_yn
        , TB.sale_fnsh_ymd
        , TB.atch_nm as trth_file_nm
        from tb_uda_uai000m TA 
        left join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where TA.assz_btch_acmp_id = $1
        and TA.eror_vl in ('0000')
        order by TA.assz_unfc_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtFileIIS(assz_btch_acmp_id, basDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
          '/data/asset/iis/iis/${basDt}/origin/' || TA.assz_unfc_id || '.pdf' as  file_nm,
          '/data/asset/iis/iis/${basDt}/json/' || TA.assz_unfc_id || '.json' as json_nm	
        from tb_uda_uai000m TA
        where
        TA.assz_btch_acmp_id = $1
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TA.eror_vl = '0000'
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtMetaIISRange(startDt, endDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT
          TA.assz_unfc_id as assz_unfc_id
        , TA.assz_unfc_id as file_nm
        , TA.assz_cfbo_idnt_id as assz_cfbo_idnt_id
        , TA.flsz_vl as flsz_vl
        , 'pdf' as file_type
        , 'C' as assz_pcsn_tcd
        , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as rgsn_ts
        , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as amnn_ts
        , TB.cnvs_grp_cd
        , TB.assz_dcmn_clsf_id
        , TB.conn_ttl_nm as conn_ttl_nm
        , TB.assz_fund_dcmn_dcd
        , TB.assz_fund_new_abl_yn
        , TB.sale_fnsh_ymd
        , TB.atch_nm
        FROM tb_uda_uai000m TA 
        LEFT JOIN tb_uda_uai074m TB ON TA.assz_unfc_id = TB.assz_unfc_id
        WHERE (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        AND TA.eror_vl in ('0000')
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
        order by TA.assz_unfc_id
      `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtFileIISRange(startDt, endDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
        '/data/asset/iis/iis/origin/' || TA.assz_unfc_id || '.pdf' as  file_nm
        , '/data/asset/iis/iis/json/' || TA.assz_unfc_id || '.json' as json_nm	
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai074m TB ON TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
        AND TA.eror_vl in ('0000')
    `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtMetaCSM(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT
          TA.assz_unfc_id as doc_id
        , TA.assz_unfc_id as doc_nm
        , TA.assz_cfbo_idnt_id as ori_doc_key
        , TA.flsz_vl as file_size
        , 'pdf' as file_type
        , '' as url
        , TA.assz_pcsn_tcd as pr_gubun
        , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
        , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
        , TB.atch_yn as att_file_yn
        , TB.atch_sqn as att_file_seq
        , TB.conn_ttl_nm as link_file_nm
        , '' as suco_oppb_info_con
        , '' as suco_dcmn_shrn_yn
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id
        WHERE TA.assz_btch_acmp_id = $1
        AND TA.eror_vl in ('0000')
        order by TA.assz_unfc_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtFileCSM(assz_btch_acmp_id, basDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
            '/data/asset/csm/csm/${basDt}/pdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
          , '/data/asset/csm/csm/${basDt}/json/' || TA.assz_unfc_id || '.json' AS json_nm
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE TA.assz_btch_acmp_id = $1
        AND TA.eror_vl in ('0000')
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
        order by TA.assz_unfc_id
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtMetaCSMRange(fromDt, toDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT
          TA.assz_unfc_id as doc_id
        , TA.assz_unfc_id as doc_nm
        , TA.assz_cfbo_idnt_id as ori_doc_key
        , TA.flsz_vl as file_size
        , 'pdf' as file_type
        , '' as url
        , 'C' as pr_gubun
        , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
        , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
        , TB.atch_yn as att_file_yn
        , TB.atch_sqn as att_file_seq
        , TB.conn_ttl_nm as link_file_nm
        , '' as suco_oppb_info_con
        , '' as suco_dcmn_shrn_yn
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id
        WHERE (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        AND TA.eror_vl in ('0000')
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
        ORDER BY TA.assz_unfc_id
      `,
      [fromDt, toDt]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtFileCSMRange(startDt, endDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
            '/data/asset/csm/csm/pdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
          , '/data/asset/csm/csm/json/' || TA.assz_unfc_id || '.json' AS json_nm
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        AND TA.eror_vl in ('0000')
        AND TA.assz_pcsn_tcd != 'D' -- 제외 처리
    `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
  }
}

// 은행상품설명서
async function selectAvtMakeEPN(assz_btch_acmp_id, assz_btch_acmp_id2) {
  const client = await pool.connect();
  try {
    let asszBtchAcmpIdList = [assz_btch_acmp_id, assz_btch_acmp_id2];
    let asszBtchAcmpIdStr = `(\'${asszBtchAcmpIdList
      .filter((d, i) => d != "")
      .join("', '")}\')`;

    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , TA.assz_pcsn_tcd as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm
      , case when TA.eror_vl != '9999' then 
                case when TB.atch_yn = 'Y' 
                        then TB.conn_ttl_nm ||'_'|| TB.atch_nm
                        else TB.conn_ttl_nm
                end
              else '' 
        end as link_file_nm
      , TB.assz_dcmn_clsf_id as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where TA.assz_btch_acmp_id IN ${asszBtchAcmpIdStr}
      and TA.eror_vl = '0000'
      and TB.assz_dcmn_clsf_id != '130078140181' /* AVT 전송배치에서 130078140181(퇴직연금) 제외 */
      order by TA.assz_unfc_id, TB.amnn_ts
      `
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function selectAvtFileEPN(assz_btch_acmp_id, assz_btch_acmp_id2, basDt) {
  const client = await pool.connect();

  try {
    let asszBtchAcmpIdList = [assz_btch_acmp_id, assz_btch_acmp_id2];
    let asszBtchAcmpIdStr = `(\'${asszBtchAcmpIdList
      .filter((d, i) => d != "")
      .join("', '")}\')`;
    const result = await client.query(
      `
        select
          '/data/asset/kms/wpt/epnt/${basDt}/originpdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
        , '/data/asset/kms/wpt/epnt/${basDt}/json/' || TA.assz_unfc_id || '.json' as json_nm
        from tb_uda_uai000m TA
        left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where TA.assz_btch_acmp_id IN ${asszBtchAcmpIdStr}
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TB.assz_dcmn_clsf_id != '130078140181' /* AVT 전송배치에서 130078140181(퇴직연금) 제외 */
        and TA.eror_vl in ('0000')
    `
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtMakeEPNRange(startDt, endDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , 'C' as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm
      , case when TA.eror_vl != '9999' then 
                case when TB.atch_yn = 'Y' 
                        then TB.conn_ttl_nm ||'_'|| TB.atch_nm
                        else TB.conn_ttl_nm
                end
              else '' 
        end as link_file_nm
      , TB.assz_dcmn_clsf_id as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
      and TA.assz_pcsn_tcd != 'D' -- 제외 처리
      and TA.eror_vl in ('0000')
      and TB.assz_dcmn_clsf_id != '130078140181' /* AVT 전송배치에서 130078140181(퇴직연금) 제외 */
      order by TA.assz_unfc_id, TB.amnn_ts
      `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectAvtFileEPNRange(startDt, endDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
          '/data/asset/kms/wpt/epnt/originpdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
        , '/data/asset/kms/wpt/epnt/json/' || TA.assz_unfc_id || '.json' as json_nm
        from tb_uda_uai000m TA
        left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TB.assz_dcmn_clsf_id != '130078140181' /* AVT 전송배치에서 130078140181(퇴직연금) 제외 */
        and TA.eror_vl = '0000'
    `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
  }
}

module.exports = {
  dbEnd,
  selectAvtMetaIIS,
  selectAvtFileIIS,
  selectAvtFileIISRange,
  selectAvtMetaIISRange,
  selectAvtMetaCSM,
  selectAvtFileCSM,
  selectAvtMetaCSMRange,
  selectAvtFileCSMRange,
  selectAvtMakeEPN,
  selectAvtFileEPN,
  selectAvtMakeEPNRange,
  selectAvtFileEPNRange,
};
