const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  assz_mnl_id,
  assz_mnl_grp_id,
  assz_cmpe_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  sub_ttl_nm,
  url_adr,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai803l
      (assz_btch_acmp_id
      , assz_trms_tgt_sys_dcd
      , assz_btch_tcd
      , assz_meta_pcsn_sqn
      , assz_cfbo_idnt_id
      , assz_unfc_id
      , assz_mnl_id
      , assz_mnl_grp_id
      , assz_cmpe_id
      , file_nm
      , file_sqn
      , assz_orcp_file_path_nm
      , orgn_data_rgsr_id
      , rgsn_ts
      , amnn_ts
      , assz_orgn_pcsn_dcd
      , atch_yn
      , atch_sqn
      , assz_dcmn_clsf_id
      , sub_ttl_nm
      , conn_ttl_nm
      , url_adr
      , assz_pcsn_file_path_nm
      , uda_sys_lsmd_id
      , uda_sys_lsmd_ts
      )
      VALUES(
        $1
      , '01'
      , '01' 
      ,  (select  coalesce(max(assz_meta_pcsn_sqn)+1,1)
            from tb_uda_uai803l
            where assz_btch_acmp_id =$1::VARCHAR)
      , $2
      , $3
      , $4
      , $5
      , $6
      , $7
      , $8
      , $9
      , $10
      , TO_TIMESTAMP($11,'YYYYMMDDHH24MISS') 
      , TO_TIMESTAMP($12,'YYYYMMDDHH24MISS')
      , $13
      , $14
      , $15
      , $16
      , $17
      , $18
      , $19
      , $20
      , $21
      , Current_timestamp);      
		`,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        assz_mnl_id,
        assz_mnl_grp_id,
        assz_cmpe_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        sub_ttl_nm,
        url_adr,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function updateMeta(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      UPDATE tb_uda_uai003m
         SET assz_unfc_id =$3
       WHERE assz_btch_acmp_id=$1 
         AND assz_meta_pcsn_sqn    =$2;
    `,
      [assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateMetaFileNm(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai003m a 
			   SET atch_nm = 	 case when a.grp_id = 'B1093' Then conn_ttl_nm
						                    else (select max(conn_ttl_nm) 
						                          from TB_UDA_UAI003M z 
						                          where  z.assz_btch_acmp_id = a.assz_btch_acmp_id
							  		                  and z.mnl_id = a.mnl_id
									                    and z.grp_id ='B1093')
								          end
			 WHERE assz_btch_acmp_id=$1;
		`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      //     `
      //     SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, assz_mnl_id, assz_mnl_grp_id, assz_cmpe_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, conn_ttl_nm, assz_pcsn_file_path_nm, url_adr, atch_nm, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts
      //       FROM tb_uda_uai803l a
      //      where assz_btch_acmp_id =$1
      //      and eror_vl ='0000'
      // 			and  assz_orgn_pcsn_dcd in ('C','U')
      //       and not exists  ( select  1 from tb_uda_uai803l z where  z.eror_vl !='0000' and z.assz_mnl_id  = a.assz_mnl_id and z.assz_btch_acmp_id =a.assz_btch_acmp_id )
      //       and not exists  ( select  1 from TB_UDA_UAI901L z where  z.eror_vl !='0000' and z.assz_cfbo_idnt_id  = a.assz_mnl_id and z.assz_btch_acmp_id =a.assz_btch_acmp_id )
      //      order by assz_btch_acmp_id,assz_mnl_id,file_sqn;
      // `,
      `
      SELECT a.assz_btch_acmp_id, a.assz_meta_pcsn_sqn, a.assz_unfc_id, a.assz_mnl_id, a.assz_mnl_grp_id, a.assz_cmpe_id, a.file_nm, a.file_sqn, a.assz_orcp_file_path_nm, a.orgn_data_rgsr_id
      , a.rgsn_ts, a.amnn_ts, a.assz_orgn_pcsn_dcd, a.atch_yn, a.atch_sqn, a.assz_dcmn_clsf_id, a.conn_ttl_nm, a.assz_pcsn_file_path_nm, a.url_adr
      , a.sub_ttl_nm , a.uda_sys_lsmd_id, a.uda_sys_lsmd_ts
        FROM tb_uda_uai803l a
        inner join tb_uda_uai000m b on (a.assz_unfc_id = b.assz_unfc_id and b.assz_btch_acmp_id = $1)        
       where a.assz_btch_acmp_id =$1
        and  b.eror_vl ='0000'
		    and  a.assz_orgn_pcsn_dcd in ('C','U')
        and not exists  ( select  1 from TB_UDA_UAI901L z where  z.eror_vl !='0000' and z.assz_cfbo_idnt_id  = a.assz_mnl_id and z.assz_btch_acmp_id =a.assz_btch_acmp_id )
       order by assz_btch_acmp_id,assz_mnl_id,file_sqn;     
      `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta02(assz_btch_acmp_id, mnl_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      //     `
      //     SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, mnl_id, grp_id, cmpe_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, conn_ttl_nm, assz_pcsn_file_path_nm, url_adr, atch_nm, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts
      //     ,coalesce(atch_nm,'') as dcmn_nm
      //       FROM tb_uda_uai003m
      //      where assz_btch_acmp_id =$1
      //        and mnl_id =$2
      //      order by assz_btch_acmp_id,grp_id,file_sqn;
      // `,
      `
      SELECT 
        assz_btch_acmp_id
        , assz_meta_pcsn_sqn
        , assz_unfc_id
        , assz_mnl_id
        , assz_mnl_grp_id
        , assz_cmpe_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , assz_pcsn_file_path_nm
        , url_adr
        , sub_ttl_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts
        , coalesce(sub_ttl_nm,'') as dcmn_nm
        FROM tb_uda_uai803l
       where assz_btch_acmp_id =$1
         and assz_mnl_id = $2
       order by assz_btch_acmp_id,assz_mnl_grp_id,file_sqn;  
  `,
      [assz_btch_acmp_id, mnl_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  selectMeta,
  selectMeta02,
  updateMeta,
  updateMetaFileNm,
  dbEnd,
};
