const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertLdgrWPT(
  pool,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  assz_fmts_base_orgn_idnt_id,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  rgsr_dept_id,
  inq_nbi,
  vrsn_no,
  suco_dcmn_shrn_yn,
  suco_oppb_info_con,
  assz_orcp_file_path_nm,
  atch_yn,
  atch_nm,
  atch_sqn,
  uda_sys_lsmd_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			INSERT INTO tb_uda_uai001m
			(
				  assz_unfc_id
				, assz_cfbo_idnt_id
				, assz_fmts_base_orgn_idnt_id
				, orgn_data_rgsr_id
				, rgsn_ts
				, amnn_ts
				, assz_orgn_pcsn_dcd
				, assz_dcmn_clsf_id
				, conn_ttl_nm
				, rgsr_dept_id
				, inq_nbi
				, vrsn_no
				, suco_dcmn_shrn_yn
				, suco_oppb_info_con
				, assz_orcp_file_path_nm
				, atch_yn
				, atch_nm
				, atch_sqn
				, uda_sys_lsmd_id
				, uda_sys_lsmd_ts
			)
			VALUES(
				  $1
				, $2
				, $3
				, $4
				, TO_TIMESTAMP($5,'YYYYMMDDHH24MISS') --rgsn_ts
				, TO_TIMESTAMP($6,'YYYYMMDDHH24MISS') --amnn_ts
				, $7
				, $8
				, $9
				, $10
				, $11
				, $12
				, $13
				, $14
				, $15
				, $16
				, $17
				, $18
				, $19
				, current_timestamp
				);

			`,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        assz_fmts_base_orgn_idnt_id,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        rgsr_dept_id,
        inq_nbi,
        vrsn_no,
        suco_dcmn_shrn_yn,
        suco_oppb_info_con,
        assz_orcp_file_path_nm,
        atch_yn,
        atch_nm,
        atch_sqn,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

async function selectMetaOne(assz_btch_acmp_id, assz_cfbo_idnt_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, rgsr_id, 
			TO_CHAR(rgsn_ts,'YYYY-MM-DD') || ' 00:00:00' as rgsn_ts,
			TO_CHAR(amnn_ts,'YYYY-MM-DD') || ' 00:00:00' as amnn_ts,
			assz_orgn_pcsn_dcd, assz_dcmn_clsf_id, assz_fmts_base_orgn_idnt_id, conn_ttl_nm, rgsr_dept_id, inq_nbi, vrsn_no, suco_oppb_info_con, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts, suco_dcmn_shrn_yn
			FROM tb_uda_uai001m
			where assz_btch_acmp_id = $1
			and assz_cfbo_idnt_id = $2
			`,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectMetaOnePerm(assz_btch_acmp_id, assz_cfbo_idnt_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, rgsr_id, TA.rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, assz_dcmn_clsf_id, assz_fmts_base_orgn_idnt_id, conn_ttl_nm, rgsr_dept_id, inq_nbi, vrsn_no, suco_oppb_info_con, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts, suco_dcmn_shrn_yn
			FROM tb_uda_uai001m TA left join tb_uda_uai102m TD on TA.assz_cfbo_idnt_id = TD.wpt_dcmn_id 
			where assz_btch_acmp_id = $1
			and assz_cfbo_idnt_id = $2
			and TD.wpt_rtpl_grp_id = '3'
			`,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  assz_fmts_base_orgn_idnt_id,
  conn_ttl_nm,
  rgsr_dept_id,
  inq_nbi,
  vrsn_no,
  suco_oppb_info_con,
  eror_vl,
  ASSZ_EROR_CON,
  uda_sys_lsmd_id,
  suco_dcmn_shrn_yn
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI001M(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, assz_dcmn_clsf_id, assz_fmts_base_orgn_idnt_id, conn_ttl_nm, rgsr_dept_id, inq_nbi, vrsn_no, suco_oppb_info_con,  eror_vl, ASSZ_EROR_CON, uda_sys_lsmd_id,suco_dcmn_shrn_yn)
		VALUES ($1,
		          (select  coalesce(max(assz_meta_pcsn_sqn)+1,1)
							from TB_UDA_UAI001M
							where assz_btch_acmp_id =$1::VARCHAR),
							$2,$3,TO_TIMESTAMP($4,'YYYYMMDDHH24MISS'),TO_TIMESTAMP($5,'YYYYMMDDHH24MISS'),$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17);
		`,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        rgsr_dept_id,
        inq_nbi,
        vrsn_no,
        suco_oppb_info_con,
        eror_vl,
        ASSZ_EROR_CON,
        uda_sys_lsmd_id,
        suco_dcmn_shrn_yn,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id, fileTyp) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
				a.assz_btch_acmp_id
				,a.assz_cfbo_idnt_id
				,a.rgsr_id
				,a.rgsn_ts
				,a.amnn_ts
				,a.assz_orgn_pcsn_dcd
				,a.assz_dcmn_clsf_id
				,a.assz_fmts_base_orgn_idnt_id
				,a.conn_ttl_nm
				,a.rgsr_dept_id
				,a.inq_nbi
				,a.vrsn_no
				,a.suco_oppb_info_con  
				,b.file_nm               
				,b.file_sqn              
				,b.assz_orcp_file_path_nm     
				,b.atch_yn               
				,b.atch_sqn              
				,b.assz_pcsn_file_path_nm               
				,b.atch_nm
				,b.assz_meta_pcsn_sqn 
				,b.assz_unfc_id
				from TB_UDA_UAI001D B
					, TB_UDA_UAI001M A
				where A.assz_btch_acmp_id =$1
				and   A.assz_orgn_pcsn_dcd = 'C'
				and B.assz_btch_acmp_id = A.assz_btch_acmp_id 
				and A.assz_cfbo_idnt_id = B.assz_cfbo_idnt_id
				and b.file_nm ilike '%'||$2||'%'
				and b.eror_vl ='0000'
				and a.eror_vl ='0000'
				order by a.assz_btch_acmp_id,a.assz_cfbo_idnt_id,b.file_sqn,b.atch_yn,b.atch_sqn;
	    `,
      [assz_btch_acmp_id, fileTyp]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta10(assz_btch_acmp_id, fileTyp) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
				a.assz_btch_acmp_id
				,a.assz_cfbo_idnt_id
				,a.rgsr_id
				,a.rgsn_ts
				,a.amnn_ts
				,a.assz_orgn_pcsn_dcd
				,a.assz_dcmn_clsf_id
				,a.assz_fmts_base_orgn_idnt_id
				,a.conn_ttl_nm
				,a.rgsr_dept_id
				,a.inq_nbi
				,a.vrsn_no
				,a.suco_oppb_info_con  
				,b.file_nm               
				,b.file_sqn              
				,b.assz_orcp_file_path_nm     
				,b.atch_yn               
				,b.atch_sqn              
				,b.assz_pcsn_file_path_nm               
				,b.atch_nm
				,b.assz_meta_pcsn_sqn 
				,b.assz_unfc_id
				from TB_UDA_UAI001D B
					, TB_UDA_UAI001M A
				where A.assz_btch_acmp_id =$1
				and   A.assz_orgn_pcsn_dcd = 'C'
				and B.assz_btch_acmp_id = A.assz_btch_acmp_id 
				and A.assz_cfbo_idnt_id = B.assz_cfbo_idnt_id
				and b.file_nm ilike '%'||$2||'%'
				and b.eror_vl ='0000'
				and a.eror_vl ='0000'
				and b.assz_unfc_id is not null  
				order by a.assz_btch_acmp_id,a.assz_cfbo_idnt_id,b.file_sqn,b.atch_yn,b.atch_sqn;
	    `,
      [assz_btch_acmp_id, fileTyp]
    );

    return result;
  } finally {
    client.release();
  }
}
async function selectMeta02(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			SELECT
				TA.assz_btch_acmp_id
			, TB.assz_unfc_id
			, TA.assz_cfbo_idnt_id
			, TA.orgn_data_rgsr_id 
			, TA.rgsn_ts
			, TA.amnn_ts
			, TA.assz_orgn_pcsn_dcd
			, coalesce(TA.assz_dcmn_clsf_id,'') as assz_dcmn_clsf_id
			, TA.assz_fmts_base_orgn_idnt_id
			, TA.conn_ttl_nm
			, TA.rgsr_dept_id
			, TA.inq_nbi
			, TA.vrsn_no
			, TA.suco_oppb_info_con  
			, TB.assz_meta_pcsn_sqn    
			, TB.file_nm               
			, TB.file_sqn              
			, TB.assz_orcp_file_path_nm   
			, TB.atch_yn                
			, TB.atch_sqn              
			, TB.atch_nm
			, 'http://workportal.ibk.co.kr/wpt_gcp/lightpack/actiondoc/boardItem/readBoardItemView.do?boardId='|| TA.assz_dcmn_clsf_id ||'&itemId=' || TA.assz_cfbo_idnt_id ||'&searchConditionString=&popupYn=true' as url_adr
			, TB.uda_sys_lsmd_id
			, coalesce
				(
						case when atch_yn ='Y' then regexp_replace(TB.atch_nm,'\\.[^.]*$','')
									else TA.conn_ttl_nm
						end,''
				) as dcmn_nm
			FROM TB_UDA_UAI801l TA, TB_UDA_UAI802l TB
			WHERE TA.assz_btch_acmp_id = $1
			AND assz_orgn_pcsn_dcd in ( 'C' ,'U')
			AND TB.assz_btch_acmp_id = TA.assz_btch_acmp_id
			AND TA.assz_cfbo_idnt_id = TB.assz_cfbo_idnt_id
			AND TB.assz_unfc_id = $2
			order by  assz_btch_acmp_id,assz_cfbo_idnt_id,file_sqn,atch_yn,atch_sqn;
	    `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNm(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		select substring(a.file_nm from '^[^\\.]+') as doc_nm
		from TB_UDA_UAI910L a ,TB_UDA_UAI001D m2 
		where  m2.assz_btch_acmp_id = $1
		and a.assz_btch_acmp_id = m2.assz_btch_acmp_id
		and a.assz_cfbo_idnt_id = m2.assz_cfbo_idnt_id
		and a.assz_unfc_id = m2.assz_unfc_id
	`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}
async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  selectMeta,
  selectMeta02,
  selectMeta10,
  selectMetaDocNm,
  dbEnd,
  selectMetaOne,
  selectMetaOnePerm,
  /////////////NEW//////////////
  insertLdgrWPT,
};
