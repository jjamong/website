const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertImgLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_page_no,
  assz_img_no,
  assz_img_tppo_xcr_vl,
  assz_img_tppo_ycr_vl,
  assz_img_lwen_xcr_vl,
  assz_img_lwen_ycr_vl,
  assz_img_pcsn_acmp_rslt_dcd,
  eror_vl,
  ASSZ_EROR_CON,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  assz_img_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();

  // console.log(
  //   assz_btch_acmp_id,
  //   "][",
  //   assz_unfc_id,
  //   "][",
  //   assz_page_no,
  //   "][",
  //   assz_img_no,
  //   "][",
  //   assz_img_tppo_xcr_vl,
  //   "][",
  //   assz_img_tppo_ycr_vl,
  //   "][",
  //   assz_img_lwen_xcr_vl,
  //   "][",
  //   assz_img_lwen_ycr_vl,
  //   "][",
  //   assz_img_pcsn_acmp_rslt_dcd,
  //   "][",
  //   eror_vl,
  //   "][",
  //   ASSZ_EROR_CON,
  //   "][",
  //   acmp_sttg_ts,
  //   "][",
  //   acmp_fnsh_ts,
  //   "][",
  //   assz_img_file_path_nm,
  //   "][",
  //   uda_sys_lsmd_id
  // );

  if (assz_page_no == "") assz_page_no = 0;
  if (assz_img_no == "") assz_img_no = 0;
  if (assz_img_tppo_xcr_vl == "") assz_img_tppo_xcr_vl = 0;
  if (assz_img_tppo_ycr_vl == "") assz_img_tppo_ycr_vl = 0;
  if (assz_img_lwen_xcr_vl == "") assz_img_lwen_xcr_vl = 0;
  if (assz_img_lwen_ycr_vl == "") assz_img_lwen_ycr_vl = 0;

  if (eror_vl == "") eror_vl = null;
  if (ASSZ_EROR_CON == "") ASSZ_EROR_CON = null;
  if (acmp_sttg_ts == "") acmp_sttg_ts = null;
  if (acmp_fnsh_ts == "") acmp_fnsh_ts = null;
  if (assz_img_file_path_nm == "") assz_img_file_path_nm = null;

  try {
    const result = await client.query(
      ` 
      INSERT INTO TB_UDA_UAI902L
      (assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, img_sqn, assz_unfc_id, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, assz_img_pcsn_acmp_rslt_dcd, eror_vl, ASSZ_EROR_CON, acmp_sttg_ts, acmp_fnsh_ts, assz_img_file_path_nm, uda_sys_lsmd_id, uda_sys_lsmd_ts)
      VALUES($1::varchar, '01','01', (
      select coalesce(max(assz_meta_pcsn_sqn),1) from TB_UDA_UAI901L where assz_btch_acmp_id=$1::varchar and assz_unfc_id = $2::varchar
      ), (select coalesce(max(img_sqn)+1,1) from TB_UDA_UAI902L where assz_btch_acmp_id =$1::varchar and assz_unfc_id = $2::varchar) ,$2::varchar, $3, $4, $5, $6, $7 , $8, $9, $10, $11, $12, $13, $14, $15, current_timestamp)
		RETURNING img_sqn;
		`,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_page_no,
        assz_img_no,
        assz_img_tppo_xcr_vl,
        assz_img_tppo_ycr_vl,
        assz_img_lwen_xcr_vl,
        assz_img_lwen_ycr_vl,
        assz_img_pcsn_acmp_rslt_dcd,
        eror_vl,
        ASSZ_EROR_CON,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        assz_img_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );
    return result;
    //return result.rows[0].btch_acmp_id;
  } finally {
    client.release();
  }
}

async function selectImgLog(assz_btch_acmp_id, eror_vl) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT a.assz_btch_acmp_id, a.assz_unfc_id, img_sqn, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, a.assz_img_pcsn_acmp_rslt_dcd, a.eror_vl, a.ASSZ_EROR_CON, a.acmp_sttg_ts, a.acmp_fnsh_ts, a.assz_img_file_path_nm, a.uda_sys_lsmd_id, a.uda_sys_lsmd_ts, b.assz_cfbo_idnt_id
      FROM TB_UDA_UAI902L a
        LEFT join TB_UDA_UAI901L b
        	ON a.assz_btch_acmp_id  = b.assz_btch_acmp_id
          AND a.assz_unfc_id = b.assz_unfc_id
      where a.assz_btch_acmp_id =  $1 
      and   a.eror_vl = $2
      order by a.assz_unfc_id,img_sqn
		`,
      [assz_btch_acmp_id, eror_vl]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectImgLog02(assz_btch_acmp_id, eror_vl) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_unfc_id, img_sqn, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, assz_img_pcsn_acmp_rslt_dcd, eror_vl, ASSZ_EROR_CON, acmp_sttg_ts, acmp_fnsh_ts, assz_img_file_path_nm, uda_sys_lsmd_id, uda_sys_lsmd_ts
      ,coalesce((select atch_yn from TB_UDA_UAI901L z where z.assz_btch_acmp_id  =  y.assz_btch_acmp_id and z.assz_unfc_id=y.assz_unfc_id),'N') as atch_yn
      ,coalesce((select z.assz_orcp_file_path_nm from TB_UDA_UAI901L z where z.assz_btch_acmp_id  =  y.assz_btch_acmp_id and z.assz_unfc_id=y.assz_unfc_id),'') as assz_orcp_file_path_nm
      FROM TB_UDA_UAI902L y
      where assz_btch_acmp_id =  $1 
      and   eror_vl = $2
      order by assz_unfc_id,img_sqn
		`,
      [assz_btch_acmp_id, eror_vl]
    );
    return result;
  } finally {
    client.release();
  }
}

async function updateImgLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  img_sqn,
  assz_page_no,
  assz_img_no,
  assz_img_tppo_xcr_vl,
  assz_img_tppo_ycr_vl,
  assz_img_lwen_xcr_vl,
  assz_img_lwen_ycr_vl,
  assz_img_pcsn_acmp_rslt_dcd,
  eror_vl,
  ASSZ_EROR_CON,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  assz_img_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `UPDATE TB_UDA_UAI902L
          SET 
             assz_page_no = coalesce($4,assz_page_no)
            , assz_img_no = coalesce($5,assz_img_no)
            , assz_img_tppo_xcr_vl = coalesce($6,assz_img_tppo_xcr_vl)
            , assz_img_tppo_ycr_vl = coalesce($7,assz_img_tppo_ycr_vl)
            , assz_img_lwen_xcr_vl = coalesce($8,assz_img_lwen_xcr_vl)
            , assz_img_lwen_ycr_vl = coalesce($9,assz_img_lwen_ycr_vl)
            , assz_img_pcsn_acmp_rslt_dcd = coalesce($10,assz_img_pcsn_acmp_rslt_dcd)
            , eror_vl                   = coalesce($11,eror_vl)
            , ASSZ_EROR_CON               = coalesce($12,ASSZ_EROR_CON)
            , acmp_sttg_ts= case when $13::timestamp is null then acmp_sttg_ts else  $13::timestamp end
            , acmp_fnsh_ts= case when $14::timestamp is null then acmp_fnsh_ts else  $14::timestamp end
            , assz_img_file_path_nm     = coalesce($15,assz_img_file_path_nm)
            , uda_sys_lsmd_id                   = coalesce($16,uda_sys_lsmd_id)
          where assz_btch_acmp_id =  $1 and assz_unfc_id =$2 and img_sqn =$3;
		`,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        img_sqn,
        assz_page_no,
        assz_img_no,
        assz_img_tppo_xcr_vl,
        assz_img_tppo_ycr_vl,
        assz_img_lwen_xcr_vl,
        assz_img_lwen_ycr_vl,
        assz_img_pcsn_acmp_rslt_dcd,
        eror_vl,
        ASSZ_EROR_CON,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        assz_img_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateDpLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  img_sqn,
  assz_img_pcsn_acmp_rslt_dcd,
  eror_vl,
  ASSZ_EROR_CON,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  assz_img_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `UPDATE TB_UDA_UAI902L
          SET 
              assz_img_pcsn_acmp_rslt_dcd = coalesce($4,assz_img_pcsn_acmp_rslt_dcd)
            , eror_vl                   = coalesce($5,eror_vl)
            , ASSZ_EROR_CON               = coalesce($6,ASSZ_EROR_CON)
            , acmp_sttg_ts= case when $7::timestamp is null then acmp_sttg_ts else  $7::timestamp end
            , acmp_fnsh_ts= case when $8::timestamp is null then acmp_fnsh_ts else  $8::timestamp end
            , assz_img_file_path_nm     = coalesce($9,assz_img_file_path_nm)
            , uda_sys_lsmd_id                   = coalesce($10,uda_sys_lsmd_id)
          where assz_btch_acmp_id =  $1 and assz_unfc_id =$2 and img_sqn =$3;
		`,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        img_sqn,
        assz_img_pcsn_acmp_rslt_dcd,
        eror_vl,
        ASSZ_EROR_CON,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        assz_img_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  selectImgLog,
  selectImgLog02,
  insertImgLog,
  updateImgLog,
  updateDpLog,
  dbEnd,
};
