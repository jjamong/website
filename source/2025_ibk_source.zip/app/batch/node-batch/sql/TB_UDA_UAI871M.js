const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  assz_fmts_base_orgn_idnt_id,
  conn_ttl_nm,
  rgsr_dept_id,
  use_sttg_ymd,
  use_fnsh_ymd,
  sale_info_con,
  assz_dcmn_clsf_con,
  atch_nm,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai871m(
        assz_btch_acmp_id
        , assz_trms_tgt_sys_dcd
        , assz_btch_tcd
        , assz_meta_pcsn_sqn
        , assz_cfbo_idnt_id
        , assz_unfc_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , assz_fmts_base_orgn_idnt_id
        , conn_ttl_nm
        , rgsr_dept_id
        , use_sttg_ymd
        , use_fnsh_ymd
        , sale_info_con
        , assz_dcmn_clsf_con
        , atch_nm
        , assz_pcsn_file_path_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts)
      VALUES(
        $1 -- assz_btch_acmp_id
        , '01'
        , '01'
        , (select  coalesce(max(assz_meta_pcsn_sqn)+1,1)
            from tb_uda_uai871m
            where assz_btch_acmp_id = $1::VARCHAR) -- assz_meta_pcsn_sqn
        , $2 -- assz_cfbo_idnt_id
        , $3 -- assz_unfc_id
        , $4 -- file_nm
        , $5 -- file_sqn
        , $6 -- assz_orcp_file_path_nm
        , $7 -- orgn_data_rgsr_id
        , $8 -- rgsn_ts
        , $9 -- amnn_ts
        , $10 -- assz_orgn_pcsn_dcd
        , $11 -- atch_yn
        , $12 -- atch_sqn
        , $13 -- assz_dcmn_clsf_id
        , $14 -- assz_fmts_base_orgn_idnt_id
        , $15 -- conn_ttl_nm
        , $16 -- rgsr_dept_id
        , coalesce(to_char(to_date($17, 'YYYY-MM-DD'), 'YYYYMMDD'), null) -- use_sttg_ymd,
        , coalesce(to_char(to_date($18, 'YYYY-MM-DD'), 'YYYYMMDD'), null) -- use_fnsh_ymd,
        , $19 -- sale_info_con
        , $20 -- assz_dcmn_clsf_con
        , $21 -- atch_nm
        , $22 -- assz_pcsn_file_path_nm
        , $23 -- uda_sys_lsmd_id
        , Current_timestamp
      );
      `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        rgsr_dept_id,
        use_sttg_ymd,
        use_fnsh_ymd,
        sale_info_con,
        assz_dcmn_clsf_con,
        atch_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT 
        TA.assz_btch_acmp_id
        , TA.assz_meta_pcsn_sqn
        , TA.assz_cfbo_idnt_id
        , TA.assz_unfc_id
        , TA.file_nm
        , TA.file_sqn
        , TA.assz_orcp_file_path_nm
        , TA.orgn_data_rgsr_id
        , TA.rgsn_ts
        , TA.amnn_ts
        , TA.assz_orgn_pcsn_dcd
        , TA.atch_yn
        , TA.atch_sqn
        , TA.assz_dcmn_clsf_id
        , TA.assz_fmts_base_orgn_idnt_id
        , TA.conn_ttl_nm
        , TA.rgsr_dept_id
        , TA.use_sttg_ymd
        , TA.use_fnsh_ymd
        , TA.sale_info_con
        , TA.assz_dcmn_clsf_con
        , TA.atch_nm
        , TA.assz_pcsn_file_path_nm
        , TA.uda_sys_lsmd_id
        , TA.uda_sys_lsmd_ts
      FROM tb_uda_uai871m TA
      join tb_uda_uai000m TB on TA.assz_btch_acmp_id = TB.assz_btch_acmp_id and TA.assz_unfc_id = TB.assz_unfc_id
      where TA.assz_btch_acmp_id = $1
        and TA.assz_orgn_pcsn_dcd in ('C','U')
        and TB.eror_vl ='0000'
      order by TA.assz_btch_acmp_id,TA.assz_cfbo_idnt_id,TA.file_sqn;
  `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

async function selectMetaOne(pool, assz_btch_acmp_id, assz_unfc_id) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
        *
        from TB_UDA_UAI871M TA
        join tb_uda_uai000m TB on TA.assz_btch_acmp_id = TB.assz_btch_acmp_id and TA.assz_unfc_id = TB.assz_unfc_id
        where TA.assz_btch_acmp_id = $1        -- 자산화배치수행ID
        and TA.assz_unfc_id = $2 
        and TB.eror_vl = '0000'              -- 오류가 아닌 정상인 경우
        order by TA.assz_btch_acmp_id, TA.assz_unfc_id
      `,
      [assz_btch_acmp_id, assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

module.exports = {
  insertMeta,
  selectMeta,
  dbEnd,
  selectMetaOne,
};
