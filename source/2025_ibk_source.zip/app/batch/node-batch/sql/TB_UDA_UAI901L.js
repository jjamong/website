const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function updateExists(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update TB_UDA_UAI901L set assz_prec_pcsn_stg_dcd = '02', eror_vl = '0000'
      where assz_prec_pcsn_stg_dcd = '04'
      and assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return;
  } finally {
    client.release();
  }
}

async function insertLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  atch_yn,
  assz_pcsn_tgt_tcd,
  assz_prec_pcsn_stg_dcd,
  assz_pcsn_tcd,
  assz_img_pcsn_yn,
  assz_img_pcsn_acmp_sttg_ts,
  assz_img_pcsn_acmp_fnsh_ts,
  assz_img_pcsn_acmp_rslt_dcd,
  assz_conv_pcsn_tcd,
  assz_conv_acmp_sttg_ts,
  assz_conv_acmp_fnsh_ts,
  assz_conv_file_path_nm,
  assz_orcp_file_strc_tcd,
  orcp_file_assz_job_sttg_ts,
  orcp_file_assz_job_fnsh_ts,
  assz_orcp_file_path_nm,
  eror_vl,
  assz_eror_con,
  uda_sys_lsmd_id,
  assz_file_unfc_yn
) {
  const client = await pool.connect();

  try {
    await client.query(
      `
      INSERT INTO TB_UDA_UAI901L(
        assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, assz_unfc_id, assz_cfbo_idnt_id, atch_yn,
        assz_pcsn_tgt_tcd, assz_prec_pcsn_stg_dcd, assz_pcsn_tcd, assz_img_pcsn_yn,
        assz_img_pcsn_acmp_sttg_ts, assz_img_pcsn_acmp_fnsh_ts, assz_img_pcsn_acmp_rslt_dcd, assz_conv_pcsn_tcd,
        assz_conv_acmp_sttg_ts, assz_conv_acmp_fnsh_ts, assz_conv_file_path_nm, assz_orcp_file_strc_tcd,
        orcp_file_assz_job_sttg_ts, orcp_file_assz_job_fnsh_ts, assz_orcp_file_path_nm, eror_vl,
        assz_eror_con, uda_sys_lsmd_id, assz_file_unfc_yn, uda_sys_lsmd_ts
      ) VALUES (
        $1, '01','01', 
        (select  coalesce(max(assz_meta_pcsn_sqn)+1,1) from TB_UDA_UAI901L where assz_btch_acmp_id =$1::VARCHAR),
        $2, $3::TEXT, $4,
        $5, $6, $7, $8,
        $9, $10, $11, $12,
        $13, $14, $15, $16,
        $17, $18, $19::TEXT, $20,
        $21, $22, $23, current_timestamp
      )
      `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        atch_yn,
        assz_pcsn_tgt_tcd,
        assz_prec_pcsn_stg_dcd,
        assz_pcsn_tcd,
        assz_img_pcsn_yn,
        assz_img_pcsn_acmp_sttg_ts,
        assz_img_pcsn_acmp_fnsh_ts,
        assz_img_pcsn_acmp_rslt_dcd,
        assz_conv_pcsn_tcd,
        assz_conv_acmp_sttg_ts,
        assz_conv_acmp_fnsh_ts,
        assz_conv_file_path_nm,
        assz_orcp_file_strc_tcd,
        orcp_file_assz_job_sttg_ts,
        orcp_file_assz_job_fnsh_ts,
        assz_orcp_file_path_nm,
        eror_vl,
        assz_eror_con,
        uda_sys_lsmd_id,
        assz_file_unfc_yn,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

async function selectLog(assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT 
            a.assz_btch_acmp_id,
            a.assz_unfc_id,
            a.assz_cfbo_idnt_id,
            a.atch_yn,
            a.assz_pcsn_tgt_tcd,
            a.assz_prec_pcsn_stg_dcd, 
            a.assz_pcsn_tcd,
            a.assz_img_pcsn_yn,
            a.assz_img_pcsn_acmp_sttg_ts,
            a.assz_img_pcsn_acmp_fnsh_ts,
            a.assz_img_pcsn_acmp_rslt_dcd,
            a.assz_conv_pcsn_tcd,
            a.assz_conv_acmp_sttg_ts,
            a.assz_conv_acmp_fnsh_ts,
            a.assz_conv_file_path_nm,
            a.assz_orcp_file_strc_tcd,
            a.orcp_file_assz_job_sttg_ts,
            a.orcp_file_assz_job_fnsh_ts,
            a.assz_orcp_file_path_nm,
            a.eror_vl,
            a.assz_eror_con,
            a.uda_sys_lsmd_id
            FROM TB_UDA_UAI901L a
        WHERE a.assz_btch_acmp_id = $1
        AND a.assz_prec_pcsn_stg_dcd = $2
        AND a.eror_vl = $3
        and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
        order by a.assz_btch_acmp_id,a.assz_unfc_id
    `,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectLog03(assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT 
        a.assz_btch_acmp_id,
        a.assz_unfc_id,
        a.assz_cfbo_idnt_id,
        a.atch_yn,
        a.assz_pcsn_tgt_tcd,
        a.assz_prec_pcsn_stg_dcd, 
        a.assz_pcsn_tcd,
        a.assz_img_pcsn_yn,
        a.assz_img_pcsn_acmp_sttg_ts,
        a.assz_img_pcsn_acmp_fnsh_ts,
        a.assz_img_pcsn_acmp_rslt_dcd,
        a.assz_conv_pcsn_tcd,
        a.assz_conv_acmp_sttg_ts,
        a.assz_conv_acmp_fnsh_ts,
        a.assz_conv_file_path_nm,
        a.assz_orcp_file_strc_tcd,
        a.orcp_file_assz_job_sttg_ts,
        a.orcp_file_assz_job_fnsh_ts,
        a.assz_orcp_file_path_nm,
        a.eror_vl,
        a.ASSZ_EROR_CON,
        a.uda_sys_lsmd_id,
        TO_CHAR(b.amnn_ts,'YYYY') as year,
        assz_dcmn_clsf_id
        FROM TB_UDA_UAI901L a left join tb_uda_uai803l b on a.assz_btch_acmp_id = b.assz_btch_acmp_id and a.assz_unfc_id  = b.assz_unfc_id
        WHERE a.assz_btch_acmp_id      = $1
        AND a.assz_prec_pcsn_stg_dcd   =$2
        AND a.EROR_VL           = $3
        and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
        order by a.assz_btch_acmp_id,a.assz_unfc_id 
		`,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

async function selectLog04(assz_btch_acmp_id, assz_pcsn_tgt_tcd) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      ` 
       SELECT 
			 assz_btch_acmp_id,
			 assz_unfc_id,
			 assz_cfbo_idnt_id,
			 a.assz_cfbo_idnt_id as file_nm,
			 atch_yn,
			 assz_pcsn_tgt_tcd,
			 assz_prec_pcsn_stg_dcd,
			 assz_pcsn_tcd,
			 assz_img_pcsn_yn,
			 assz_img_pcsn_acmp_sttg_ts,
			 assz_img_pcsn_acmp_fnsh_ts,
			 assz_img_pcsn_acmp_rslt_dcd, 
			 assz_conv_pcsn_tcd,
			 assz_conv_acmp_sttg_ts,
			 assz_conv_acmp_fnsh_ts,
			 assz_conv_file_path_nm,
			 assz_orcp_file_strc_tcd,
			 orcp_file_assz_job_sttg_ts,
			 orcp_file_assz_job_fnsh_ts,
			 assz_orcp_file_path_nm,
			 eror_vl,
			 ASSZ_EROR_CON,
			 uda_sys_lsmd_id,
			 ASSZ_FILE_UNFC_YN,
			 (select min(z.rgsn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as rgsn_ts,
			 (select max(z.amnn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as amnn_ts,
			 (select max(z.url_adr) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as url_adr,
			(select max(z.SUB_TTL_NM) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as atch_nm
			FROM TB_UDA_UAI901L a
			WHERE a.assz_btch_acmp_id =$1
              and a.assz_pcsn_tcd in ('C', 'U')
			  AND a.EROR_VL           ='0000'
			  and a.assz_prec_pcsn_stg_dcd =$2
			  and a.ASSZ_FILE_UNFC_YN ='Y'
			  and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
			order by a.assz_btch_acmp_id,a.assz_unfc_id
		`,
      [assz_btch_acmp_id, assz_pcsn_tgt_tcd]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

async function selectLog05(assz_btch_acmp_id, assz_pcsn_tgt_tcd) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      ` 
       SELECT 
			 assz_btch_acmp_id,
			 assz_unfc_id,
			 assz_cfbo_idnt_id,
			 a.assz_cfbo_idnt_id as file_nm,
			 atch_yn,
			 assz_pcsn_tgt_tcd,
			 assz_prec_pcsn_stg_dcd,
			 assz_pcsn_tcd,
			 assz_img_pcsn_yn,
			 assz_img_pcsn_acmp_sttg_ts,
			 assz_img_pcsn_acmp_fnsh_ts,
			 assz_img_pcsn_acmp_rslt_dcd, 
			 assz_conv_pcsn_tcd,
			 assz_conv_acmp_sttg_ts,
			 assz_conv_acmp_fnsh_ts,
			 assz_conv_file_path_nm,
			 assz_orcp_file_strc_tcd,
			 orcp_file_assz_job_sttg_ts,
			 orcp_file_assz_job_fnsh_ts,
			 assz_orcp_file_path_nm,
			 eror_vl,
			 ASSZ_EROR_CON,
			 uda_sys_lsmd_id,
			 ASSZ_FILE_UNFC_YN,
			 (select min(z.rgsn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as rgsn_ts,
			 (select max(z.amnn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as amnn_ts,
			 (select max(z.url_adr) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as url_adr,
			 (select max(z.assz_dcmn_clsf_id) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as assz_dcmn_clsf_id,       
			 (select max(z.sub_ttl_nm) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as atch_nm,
       (select max(z.conn_ttl_nm) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id)  as dcmn_nm,      
			 to_char((select min(z.rgsn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id),'YYYYMMDDHH24MISS')  as rgsn_ts_2,
			 to_char((select max(z.amnn_ts) from 	tb_uda_uai803l z where z.assz_mnl_id = a.assz_cfbo_idnt_id and z.assz_btch_acmp_id = a.assz_btch_acmp_id),'YYYYMMDDHH24MISS')  as amnn_ts_2
			FROM TB_UDA_UAI901L a
			WHERE a.assz_btch_acmp_id =$1
              and a.assz_pcsn_tcd in ('C', 'U')
			  AND a.EROR_VL           ='0000'
			  and a.assz_prec_pcsn_stg_dcd =$2
			  and a.ASSZ_FILE_UNFC_YN ='Y'
			  and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
        and not exists (select 1 from TB_UDA_UAI901L z where z.EROR_VL != '0000' and  z.assz_cfbo_idnt_id =  a.assz_cfbo_idnt_id and a.assz_btch_acmp_id =z.assz_btch_acmp_id)
        and not exists ( --찾은 대상이 우리측에 등되어있는지 찾기
              select 1  from TB_UDA_UAI901L Z where z.assz_btch_acmp_id  =  a.assz_btch_acmp_id and  z.assz_cfbo_idnt_id = a.assz_cfbo_idnt_id 
        and exists --이전키로 이전 대상찾기
            (select 1 from TB_UDA_UAI902L y where y.assz_btch_acmp_id  =  z.assz_btch_acmp_id and y.assz_unfc_id = z.assz_unfc_id and  y.EROR_VL != '0000' )
        )
			order by a.assz_btch_acmp_id,a.assz_unfc_id
		`,
      [assz_btch_acmp_id, assz_pcsn_tgt_tcd]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

async function selectLog07(assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT 
        a.assz_btch_acmp_id,
        a.assz_unfc_id,
        a.assz_cfbo_idnt_id,
        a.atch_yn,
        a.assz_pcsn_tgt_tcd,
        a.assz_prec_pcsn_stg_dcd, 
        a.assz_pcsn_tcd,
        a.assz_img_pcsn_yn,
        a.assz_img_pcsn_acmp_sttg_ts,
        a.assz_img_pcsn_acmp_fnsh_ts,
        a.assz_img_pcsn_acmp_rslt_dcd,
        a.assz_conv_pcsn_tcd,
        a.assz_conv_acmp_sttg_ts,
        a.assz_conv_acmp_fnsh_ts,
        a.assz_conv_file_path_nm,
        a.assz_orcp_file_strc_tcd,
        a.orcp_file_assz_job_sttg_ts,
        a.orcp_file_assz_job_fnsh_ts,
        a.assz_orcp_file_path_nm,
        a.eror_vl,
        a.ASSZ_EROR_CON,
        a.uda_sys_lsmd_id,
        TO_CHAR(b.amnn_ts,'YYYY') as year,
        assz_dcmn_clsf_id
        FROM TB_UDA_UAI901L a left join tb_uda_uai871m b on a.assz_btch_acmp_id = b.assz_btch_acmp_id and a.assz_unfc_id  = b.assz_unfc_id
        WHERE a.assz_btch_acmp_id      = $1
        AND a.assz_prec_pcsn_stg_dcd   =$2
        AND a.EROR_VL           = $3
        and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
        order by a.assz_btch_acmp_id,a.assz_unfc_id 
		`,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

async function updateLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_prec_pcsn_stg_dcd,
  assz_img_pcsn_yn,
  assz_img_pcsn_acmp_sttg_ts,
  assz_img_pcsn_acmp_fnsh_ts,
  assz_img_pcsn_acmp_rslt_dcd,
  assz_conv_pcsn_tcd,
  assz_conv_acmp_sttg_ts,
  assz_conv_acmp_fnsh_ts,
  assz_conv_file_path_nm,
  assz_orcp_file_strc_tcd,
  orcp_file_assz_job_sttg_ts,
  orcp_file_assz_job_fnsh_ts,
  assz_orcp_file_path_nm,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    UPDATE TB_UDA_UAI901L
      SET  
         assz_prec_pcsn_stg_dcd=coalesce($3,assz_prec_pcsn_stg_dcd)
        ------------------------------------------------
        ,assz_img_pcsn_yn=coalesce($4,assz_img_pcsn_yn)
        ,assz_img_pcsn_acmp_sttg_ts=case when $5::timestamp is null then assz_img_pcsn_acmp_fnsh_ts else  $5::timestamp end
        ,assz_img_pcsn_acmp_fnsh_ts=case when $6::timestamp is null then assz_img_pcsn_acmp_fnsh_ts else  $6::timestamp end
        ,assz_img_pcsn_acmp_rslt_dcd=coalesce($7,assz_img_pcsn_acmp_rslt_dcd)
        ------------------------------------------------
        ,assz_conv_pcsn_tcd=coalesce($8,assz_conv_pcsn_tcd)
        ,assz_conv_acmp_sttg_ts=case when $9::timestamp is null then assz_conv_acmp_sttg_ts else  $9::timestamp end
        ,assz_conv_acmp_fnsh_ts=case when $10::timestamp is null then assz_conv_acmp_fnsh_ts else $10::timestamp end
        ,assz_conv_file_path_nm=coalesce($11,assz_conv_file_path_nm)
        ------------------------------------------------
        ,assz_orcp_file_strc_tcd=coalesce($12,assz_orcp_file_strc_tcd)
        ,orcp_file_assz_job_sttg_ts=case when $13::timestamp is null then orcp_file_assz_job_sttg_ts else $13::timestamp end
        ,orcp_file_assz_job_fnsh_ts=case when $14::timestamp is null then orcp_file_assz_job_fnsh_ts else $14::timestamp end
        ,assz_orcp_file_path_nm=coalesce($15,assz_orcp_file_path_nm)
        ------------------------------------------------
        ,eror_vl=coalesce($16,eror_vl)
        ,ASSZ_EROR_CON=coalesce($17,ASSZ_EROR_CON)
        ------------------------------------------------
        ,uda_sys_lsmd_ts = current_timestamp
      WHERE assz_btch_acmp_id = $1 
        AND assz_unfc_id = $2;
    `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_prec_pcsn_stg_dcd,
        assz_img_pcsn_yn,
        assz_img_pcsn_acmp_sttg_ts,
        assz_img_pcsn_acmp_fnsh_ts,
        assz_img_pcsn_acmp_rslt_dcd,
        assz_conv_pcsn_tcd,
        assz_conv_acmp_sttg_ts,
        assz_conv_acmp_fnsh_ts,
        assz_conv_file_path_nm,
        assz_orcp_file_strc_tcd,
        orcp_file_assz_job_sttg_ts,
        orcp_file_assz_job_fnsh_ts,
        assz_orcp_file_path_nm,
        eror_vl,
        assz_eror_con,
      ]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLog02(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_prec_pcsn_stg_dcd,
  assz_conv_pcsn_tcd,
  assz_conv_acmp_sttg_ts,
  assz_conv_acmp_fnsh_ts,
  assz_conv_file_path_nm,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    //console.log("assz_img_pcsn_acmp_sttg_ts", assz_img_pcsn_acmp_sttg_ts);

    const result = await client.query(
      `
		UPDATE TB_UDA_UAI901L
			SET  
				 assz_prec_pcsn_stg_dcd=coalesce($3,assz_prec_pcsn_stg_dcd)
				,assz_conv_pcsn_tcd=coalesce($4,assz_conv_pcsn_tcd)
				,assz_conv_acmp_sttg_ts=case when $5::timestamp is null then assz_conv_acmp_sttg_ts else $5::timestamp end
				,assz_conv_acmp_fnsh_ts=case when $6::timestamp is null then assz_conv_acmp_fnsh_ts else $6::timestamp end
				,assz_conv_file_path_nm=coalesce($7,assz_conv_file_path_nm)
				,eror_vl=coalesce($8,eror_vl)
				,assz_eror_con=coalesce($9,assz_eror_con)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_cfbo_idnt_id=$2
		    and ASSZ_FILE_UNFC_YN ='Y'
		`,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_prec_pcsn_stg_dcd,
        assz_conv_pcsn_tcd,
        assz_conv_acmp_sttg_ts,
        assz_conv_acmp_fnsh_ts,
        assz_conv_file_path_nm,
        eror_vl,
        assz_eror_con,
      ]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLogErr(assz_btch_acmp_id, unfcId, eror_vl, ASSZ_EROR_CON) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		UPDATE TB_UDA_UAI901L
			SET  
				 eror_vl=coalesce($3,eror_vl)
				,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_unfc_id=$2;
		`,
      [assz_btch_acmp_id, unfcId, eror_vl, ASSZ_EROR_CON]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLogErrTest(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
update TB_UDA_UAI901L
   set eror_vl ='0000'
where assz_btch_acmp_id =$1
and   eror_vl ='0220'

		`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLogErrTest(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
update TB_UDA_UAI901L
   set eror_vl ='0000'
where assz_btch_acmp_id =$1
and   eror_vl ='0220'

		`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLogErr02(
  assz_btch_acmp_id,
  assz_unfc_id,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        		UPDATE TB_UDA_UAI901L
			SET  
				 eror_vl=coalesce($3,eror_vl)
				,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_cfbo_idnt_id in (select distinct z.assz_cfbo_idnt_id from TB_UDA_UAI901L z where z.assz_unfc_id  = $2 and z.assz_btch_acmp_id =$1)
		`,
      [assz_btch_acmp_id, assz_unfc_id, eror_vl, assz_eror_con]
    );

    return result;
  } finally {
    client.release();
  }
}
async function selectlog02(assz_btch_acmp_id, assz_prec_pcsn_stg_dcd) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
		select
		 a.assz_btch_acmp_id
		,a.assz_cfbo_idnt_id
		,a.rgsr_id
		,a.rgsn_ts
		,a.amnn_ts
		,a.orgn_pcds_con
		,a.dcmn_clsf_id
		,a.fmtb_orgn_idnt_id
		,a.conn_ttl_nm
		,a.rgsr_dept_id
		,a.inq_nbi
		,a.vrsn_no
		,a.suco_oppb_info_con
		,b.file_nm
		,b.file_sqn
		,b.file_path_nm
		,b.rgsn_ts as add_rgsn_ts
		,b.atch_yn
		,b.atch_sqn
		,b.pcsn_flpt_vl
		,b.meta_sqn
		from TB_UDA_UAI001D B
		   , TB_UDA_UAI001M A
		   , TB_UDA_UAI901L C
		where A.assz_btch_acmp_id =$1
		and B.assz_btch_acmp_id = A.assz_btch_acmp_id
		and A.assz_cfbo_idnt_id = B.assz_cfbo_idnt_id
		and b.assz_btch_acmp_id = C.assz_btch_acmp_id
		and b.assz_unfc_id = c.assz_unfc_id
		and c.assz_prec_pcsn_stg_dcd =$2
		order by a.assz_btch_acmp_id,a.assz_cfbo_idnt_id,b.file_sqn,b.atch_yn,b.atch_sqn;
	`,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateLogErr03(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  eror_vl,
  ASSZ_EROR_CON
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		UPDATE TB_UDA_UAI901L
			SET  
				 eror_vl=coalesce($3,eror_vl)
				,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_cfbo_idnt_id=$2;
		`,
      [assz_btch_acmp_id, assz_cfbo_idnt_id, eror_vl, ASSZ_EROR_CON]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateLogErr04(
  assz_btch_acmp_id,
  assz_unfc_id,
  eror_vl,
  ASSZ_EROR_CON
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		UPDATE TB_UDA_UAI901L
			SET  
				 eror_vl=coalesce($3,eror_vl)
				,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_unfc_id=$2;
		`,
      [assz_btch_acmp_id, assz_unfc_id, eror_vl, ASSZ_EROR_CON]
    );

    return result;
  } finally {
    client.release();
  }
}
async function deleteLog(
  assz_btch_acmp_id,
  assz_unfc_id,
  eror_vl,
  ASSZ_EROR_CON
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		UPDATE TB_UDA_UAI901L
			SET  
				 eror_vl=coalesce($3,eror_vl)
				,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
			WHERE assz_btch_acmp_id=$1 
			  AND assz_unfc_id=$2;
		`,
      [assz_btch_acmp_id, assz_unfc_id, eror_vl, ASSZ_EROR_CON]
    );

    return result;
  } finally {
    client.release();
  }
}

// 자산화 로그 조회 (지식샘)
async function selectLogKms(
  assz_btch_acmp_id,
  assz_prec_pcsn_stg_dcd,
  eror_vl,
  gubun
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      ` 
        select 
          a.*
          ${
            gubun == "html"
              ? ",TO_CHAR(b.amnn_ts,'YYYY') as year"
              : ",TO_CHAR(b.apnd_file_rgsn_ts,'YYYY') as year"
          }
          
        from TB_UDA_UAI901L a
        inner join TB_UDA_UAI005M b on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
        and a.assz_btch_acmp_id = $1
        and a.assz_prec_pcsn_stg_dcd = $2
        and a.eror_vl = $3
	and b.assz_orgn_pcsn_dcd != 'D'
        ${
          gubun == "html"
            ? "and a.assz_pcsn_tgt_tcd = 'ML'"
            : "and a.assz_pcsn_tgt_tcd != 'ML'"
        }
        order by a.assz_btch_acmp_id, a.assz_unfc_id
    `,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd, eror_vl]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectTxtCpLog(
  assz_btch_acmp_id,
  assz_prec_pcsn_stg_dcd,
  eror_vl
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT assz_btch_acmp_id
      ,assz_unfc_id 
      ,assz_conv_file_path_nm
      FROM TB_UDA_UAI901L a  WHERE ( assz_unfc_id) in (
		      SELECT assz_unfc_id 
          FROM TB_UDA_UAI910L
          WHERE ASSZ_BTCH_ACMP_ID = $1 
          AND assz_pcsn_tcd = 'D'
          AND assz_cfbo_idnt_id =$2 )
      AND eror_vl ='0000'
			ORDER BY a.assz_btch_acmp_id,a.assz_unfc_id
		`,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

// 기본 - 카드몰,
async function selectLog06(assz_btch_acmp_id, assz_prec_pcsn_stg_dcd) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `SELECT 
			 assz_btch_acmp_id,
			 assz_unfc_id,
			 assz_cfbo_idnt_id,
			 a.assz_cfbo_idnt_id as file_nm,
			 atch_yn,
			 assz_pcsn_tgt_tcd,
			 assz_prec_pcsn_stg_dcd,
			 assz_pcsn_tcd,
			 assz_img_pcsn_yn,
			 assz_img_pcsn_acmp_sttg_ts,
			 assz_img_pcsn_acmp_fnsh_ts,
			 assz_img_pcsn_acmp_rslt_dcd, 
			 assz_conv_pcsn_tcd,
			 assz_conv_acmp_sttg_ts,
			 assz_conv_acmp_fnsh_ts,
			 assz_conv_file_path_nm,
			 assz_orcp_file_strc_tcd,
			 orcp_file_assz_job_sttg_ts,
			 orcp_file_assz_job_fnsh_ts,
			 assz_orcp_file_path_nm,
			 eror_vl,
			 ASSZ_EROR_CON,
			 uda_sys_lsmd_id,
			 ASSZ_FILE_UNFC_YN
			FROM TB_UDA_UAI901L a
			WHERE a.assz_btch_acmp_id =$1
              and a.assz_pcsn_tcd in ('C', 'U')
			  AND a.EROR_VL           ='0000'
			  and a.assz_prec_pcsn_stg_dcd =$2
			  and a.ASSZ_FILE_UNFC_YN ='Y'
			  and not exists (select 1 from TB_UDA_UAI910L z where z.assz_btch_acmp_id = a.assz_btch_acmp_id and z.assz_unfc_id=a.assz_unfc_id )
			order by a.assz_btch_acmp_id,a.assz_unfc_id
		`,
      [assz_btch_acmp_id, assz_prec_pcsn_stg_dcd]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;///
  } finally {
    client.release();
  }
}

module.exports = {
  insertLog,
  selectLog,
  selectLog03,
  selectLog04,
  selectLog05,
  selectLog06,
  selectLog07,
  updateLog,
  updateLog02,
  updateLogErr,
  updateLogErr02,
  updateLogErr03,
  updateLogErr04,
  selectlog02,
  deleteLog,
  selectLogKms,
  selectTxtCpLog,
  dbEnd,
  updateLogErrTest,
  updateExists,
};
