const dayjs = require("dayjs");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

/**
 *
 * @param {*} assz_unfc_id
 * @returns
 */
async function getUnfcIdFromIdntId(
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  atch_sqn
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    let sql = `
      select
        TA.assz_unfc_id,
        TA.assz_orgn_file_encp_rnnm_vl,
        TA.assz_pcsn_tcd,
        TB.assz_orgn_pcsn_dcd
        from tb_uda_uai000m TA
    `;

    if (assz_orgn_sys_cd_con == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }

    sql += `
        where TA.assz_cfbo_idnt_id = $1
          and TB.atch_sqn = $3
          and TA.assz_unfc_id like 'UDA' || $2 || '%'
      `;
    const result = await client.query(sql, [
      assz_cfbo_idnt_id,
      assz_orgn_sys_cd_con,
      atch_sqn,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 재수행건 중복방지를 위한 같은 년월일 포함 조회
 */
async function getUnfcIdFromTodayCheckId(
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  assz_fmts_base_orgn_idnt_id,
  file_sqn,
  atch_sqn,
  basDt
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    let sql = `
      select
        TA.assz_unfc_id,
        TA.assz_orgn_file_encp_rnnm_vl,
        TA.assz_pcsn_tcd,
        TB.assz_orgn_pcsn_dcd
        from tb_uda_uai000m TA
    `;

    if (assz_orgn_sys_cd_con == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }

    sql += `
        where 1=1
          and TA.assz_unfc_id like 'UDA' || $1 || '%'
          and TA.assz_cfbo_idnt_id = $2
          ${assz_fmts_base_orgn_idnt_id ? "and TB.assz_fmts_base_orgn_idnt_id = '" + assz_fmts_base_orgn_idnt_id + "'" : ''}
          and TB.file_sqn = $3
          and TB.atch_sqn = $4
          and substring(TA.assz_btch_acmp_id, 0, 9) = $5
      `;
    const result = await client.query(sql, [
      assz_orgn_sys_cd_con,
      assz_cfbo_idnt_id,
      file_sqn,
      atch_sqn,
      basDt,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}



/**
 *
 * @param {*} assz_unfc_id
 * @returns
 */
async function checkUnfcId(assz_fmts_base_orgn_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
          select
          assz_orgn_pcsn_dcd,
          assz_unfc_id
          from
          (
          -- 'U' 케이스 먼저찾기
          select
          'U' as assz_orgn_pcsn_dcd,
          assz_unfc_id
          from tb_uda_uai000m
          where assz_cfbo_idnt_id = $1
        )     
    `,
      [assz_fmts_base_orgn_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateFileInfo(
  assz_unfc_id,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI000M
          SET flsz_vl = $2,
          assz_orgn_file_encp_rnnm_vl = $3,
          uda_sys_lsmd_ts = Current_timestamp
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, flsz_vl, assz_orgn_file_encp_rnnm_vl]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateBatchId(assz_unfc_id, assz_btch_acmp_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI000M SET assz_btch_acmp_id = $2
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateErorVl(assz_unfc_id, eror_vl, assz_eror_con) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI000M SET eror_vl = $2, assz_eror_con = $3
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, eror_vl, assz_eror_con]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 자산화 상태코드 변경
async function updateAsszScd(assz_unfc_id, assz_scd, assz_pcsn_file_path_nm) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI000M SET assz_scd = $2, assz_pcsn_file_path_nm = $3
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_scd, assz_pcsn_file_path_nm]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 자산화 상태코드만 변경
async function updateOnlyAsszScd(assz_unfc_id, assz_scd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      UPDATE TB_UDA_UAI000M 
      SET assz_scd = $2
      WHERE assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_scd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_orgn_sys_cd_con
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function chkDupByAsszCfboIdntId(assz_orgn_sys_cd_con, assz_cfbo_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select 
          *
        from tb_uda_uai000m
        where 1=1
        and SUBSTRING(assz_unfc_id, 4, 6) = $1
        and assz_cfbo_idnt_id = $2
    `,
      [assz_orgn_sys_cd_con, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function chkDupByAsszCfboIdntIdAndStus(assz_cfbo_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select 
          assz_unfc_id
          ,assz_pcsn_tcd
          ,eror_vl
        from tb_uda_uai000m
        where assz_cfbo_idnt_id = $1
    `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateLdgrStusBatId(
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  assz_pcsn_tcd,
  assz_btch_acmp_id
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        update tb_uda_uai000m
        set 
          assz_pcsn_tcd = $3
          ,assz_btch_acmp_id = $4
        where assz_orgn_sys_cd_con = $1
        and assz_cfbo_idnt_id = $2
      `,
      [
        assz_orgn_sys_cd_con,
        assz_cfbo_idnt_id,
        assz_pcsn_tcd,
        assz_btch_acmp_id,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// ASSZ_UNFC_ID 기준 단건가져오기
async function selectOneByUnfcId(assz_unfc_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT 
          assz_unfc_id
        , base_ymd
        , sqn
        , assz_btch_acmp_id
        , assz_orgn_sys_cd_con
        , assz_cfbo_idnt_id
        , atch_yn
        , atch_sqn
        , assz_orcp_unfc_id
        , dcmn_nm
        , file_nm
        , assz_pcsn_tgt_tcd
        , assz_pcsn_tcd
        , flsz_vl
        , assz_orgn_file_encp_rnnm_vl
        , rgsn_ts
        , amnn_ts
        , eror_vl
        , assz_eror_con
        , del_yn
        , del_ymd
        , sys_lsmd_id
        , sys_lsmd_ts
        , url_adr
        FROM tb_uda_uai000m
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function updateLdgrBatId(assz_unfc_id, assz_btch_acmp_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI000M 
        SET assz_btch_acmp_id = $2
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNm(assz_btch_acmp_id, basDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
          '/data/asset/kms/wpt/${basDt}/originpdf/' || TA.assz_unfc_id || '.pdf'  AS file_nm
        , '/data/asset/kms/wpt/${basDt}/json/' ||  TA.assz_unfc_id || '.json' as json_nm
        FROM tb_uda_uai000m TA left join TB_UDA_UAI001M TB on TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE TA.assz_btch_acmp_id = $1
        AND TA.assz_scd = '10'
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        AND not exists (select 1 from tb_uda_uai000m where assz_cfbo_idnt_id = TA.assz_cfbo_idnt_id and eror_vl not in ('0000','9999'))
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 업무포탈 년도별
 * @param {} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmRange(startDt, endDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
            '/data/asset/kms/wpt/originpdf/' || TA.assz_unfc_id || '.pdf'  AS file_nm
          , '/data/asset/kms/wpt/json/' ||  TA.assz_unfc_id || '.json' as json_nm
        from tb_uda_uai000m TA 
        left join TB_UDA_UAI001M TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and TA.assz_scd = '10'
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and not exists (select 1 from tb_uda_uai000m where assz_cfbo_idnt_id = TA.assz_cfbo_idnt_id and eror_vl not in ('0000','9999'))
    `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmCsm(assz_btch_acmp_id, basDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
            '/data/asset/csm/csm/${basDt}/pdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
          , '/data/asset/csm/csm/${basDt}/json/' || TA.assz_unfc_id || '.json' AS json_nm
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE TA.assz_btch_acmp_id = $1
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TA.eror_vl in ('0000', '9999')
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} fronDt
 * @param {*} toDt
 * @returns
 */
async function selectMetaDocNmCsmRange(fromDt, toDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
            '/data/asset/csm/csm/pdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
          , '/data/asset/csm/csm/json/' || TA.assz_unfc_id || '.json' AS json_nm
        FROM tb_uda_uai000m TA
        LEFT JOIN tb_uda_uai072m TB ON TA.assz_unfc_id = TB.assz_unfc_id 
        WHERE (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TA.eror_vl in ('0000', '9999')
    `,
      [fromDt, toDt]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmIis(assz_btch_acmp_id, basDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
          '/data/asset/iis/iis/${basDt}/origin/' || TB.file_nm || '.pdf' as  file_nm,
          '/data/asset/iis/iis/${basDt}/json/' || TB.file_nm || '.json' as json_nm	
        from tb_uda_uai000m TA
      	left join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where 1=1
        and TA.assz_btch_acmp_id = $1
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TA.eror_vl = '0000'
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmIisRange(pool, fromDt, toDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
          '/data/asset/iis/iis/origin/' || TA.assz_unfc_id || '.pdf' as  file_nm,
          '/data/asset/iis/iis/json/' || TA.assz_unfc_id || '.json' as json_nm	
        from tb_uda_uai000m TA
        left join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TA.eror_vl = '0000'
    `,
      [fromDt, toDt]
    );
    return result;
  } finally {
    client.release();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmEpn(
  assz_btch_acmp_id,
  assz_btch_acmp_id2,
  basDt
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    let asszBtchAcmpIdList = [assz_btch_acmp_id, assz_btch_acmp_id2];
    let asszBtchAcmpIdStr = `(\'${asszBtchAcmpIdList
      .filter((d, i) => d != "")
      .join("', '")}\')`;
    const result = await client.query(
      `
        select
          '/data/asset/kms/wpt/epnt/${basDt}/originpdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
        , '/data/asset/kms/wpt/epnt/${basDt}/json/' || TA.assz_unfc_id || '.json' as json_nm
        from tb_uda_uai000m TA
        left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where TA.assz_btch_acmp_id IN ${asszBtchAcmpIdStr}
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TB.assz_dcmn_clsf_id not in ('130078140181', '130078140216') /* GAI 전송배치에서 130078140181(퇴직연금), 130078140216(신탁) 제외 */
        and TA.eror_vl = '0000'
    `
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} fromDt
 * @param {*} toDt
 * @returns
 */
async function selectMetaDocNmEpnRange(fromDt, toDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
          '/data/asset/kms/wpt/epnt/originpdf/' || TA.assz_unfc_id || '.pdf' AS file_nm
        , '/data/asset/kms/wpt/epnt/json/' || TA.assz_unfc_id || '.json' as json_nm
        from tb_uda_uai000m TA
        left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and TB.assz_dcmn_clsf_id not in ('130078140181', '130078140216') /* GAI 전송배치에서 130078140181(퇴직연금), 130078140216(신탁) 제외 */
        and TA.eror_vl = '0000'
    `,
      [fromDt, toDt]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 변경상태 없을 경우 수행정보 변경 (내규, 카드몰)
async function updateNoChange(assz_unfc_id, assz_btch_acmp_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
        update tb_uda_uai000m
                set   uda_sys_lsmd_ts = Current_timestamp
                    , assz_btch_acmp_id = $2
                    , base_ymd = $3
                    , sqn = $4
        where assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id, modBaseYmd, modSqn]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 단건조회, 원천별식별키, 파일시퀀스, 원천처리구분코드
async function selectOne(assz_orgn_sys_cd_con, assz_cfbo_idnt_id, atch_sqn) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    let sql = `
      SELECT
        TA.assz_unfc_id,
        TA.assz_orgn_file_encp_rnnm_vl
        FROM TB_UDA_UAI000M TA
    `;

    if (assz_orgn_sys_cd_con == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (assz_orgn_sys_cd_con == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }

    sql += `
        WHERE TA.assz_cfbo_idnt_id = $1
            AND TB.atch_sqn = $2 
            AND TA.assz_pcsn_tcd in ('C','U')
      `;

    const result = await client.query(sql, [assz_cfbo_idnt_id, atch_sqn]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// C, U 단건조회
async function selectOneForUpdate(assz_cfbo_idnt_id, atch_sqn) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
            SELECT
            assz_unfc_id
            FROM TB_UDA_UAI000M 
            WHERE assz_cfbo_idnt_id = $1
            AND atch_sqn = $2 
            AND assz_pcsn_tcd in ('C','U')
        `,
      [assz_cfbo_idnt_id, atch_sqn]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 챗봇 단건조회
async function selectOneOch(assz_cfbo_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select 
          assz_unfc_id
        , assz_pcsn_tcd
        , assz_orgn_file_encp_rnnm_vl
        from tb_uda_uai000m
        where assz_cfbo_idnt_id = $1
	and assz_unfc_id like '%CHBOCH%'
        limit 1 
    `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 수정
async function updateOriginMaster(
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_scd,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  assz_pcsn_file_path_nm,
  eror_vl,
  assz_eror_con,
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    if (typeof assz_pcsn_file_path_nm == "undefined") {
      assz_pcsn_file_path_nm = null;
    }

    const result = await client.query(
      `
        update tb_uda_uai000m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_pcsn_tcd = 'U'
          , assz_btch_acmp_id = $2
          , assz_scd = $3
          , flsz_vl = $4
          , assz_orgn_file_encp_rnnm_vl = $5
          , assz_pcsn_file_path_nm = coalesce($6, assz_pcsn_file_path_nm)
          , eror_vl = $7
          , assz_eror_con = $8
        where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        assz_scd,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        assz_pcsn_file_path_nm,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장마스터 수정(내규)
async function updateOriginMasterIea(
  assz_unfc_id,
  assz_btch_acmp_id,
  eror_vl,
  assz_eror_con
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    if (typeof assz_pcsn_file_path_nm == "undefined") {
      assz_pcsn_file_path_nm = null;
    }

    const result = await client.query(
      `
        update tb_uda_uai000m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_pcsn_tcd = 'N' -- 변경없음
          , assz_btch_acmp_id = $2
          , MDFC_YMD = to_char(now(),'YYYYMMDD')          
          , eror_vl = $3
          , assz_eror_con = $4
        where assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id, eror_vl, assz_eror_con]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터 삭제 (기존 원장마스터의 추가정보메타까지 전체 삭제) (지식샘)
async function deleteAddInfoKms(
  assz_cfbo_idnt_id,
  assz_btch_acmp_id,
  assz_scd
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai000m
            set uda_sys_lsmd_ts = current_timestamp
                , mdfc_ymd = to_char(now(),'YYYYMMDD')
                , assz_pcsn_tcd = 'D'
                , assz_btch_acmp_id = $2
                , assz_scd = $3  
        where 1=1
        and SUBSTRING(assz_btch_acmp_id, 9, 6) = 'AIKKMS'
        and split_part(assz_cfbo_idnt_id, '_', 1) = $1
      `,
      [assz_cfbo_idnt_id, assz_btch_acmp_id, assz_scd]
    );
  } finally {
    client.release();
  }
}

/**
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function chkDupByMnlAsszCfboIdntId(assz_cfbo_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      select 
        A.assz_unfc_id
        ,A.assz_scd
        ,A.assz_cfbo_idnt_id
        ,A.rgsn_ymd
        ,A.mdfc_ymd
        ,A.assz_pcsn_tcd
        ,A.eror_vl
        ,A.assz_eror_con
        ,A.assz_pcsn_file_path_nm
        ,A.flsz_vl
        ,A.assz_orgn_file_encp_rnnm_vl
        ,A.assz_btch_acmp_id
        ,B.file_nm
        ,B.file_sqn
        ,B.assz_orcp_file_path_nm
        ,B.orgn_data_rgsr_id
        ,B.rgsn_ts
        ,B.amnn_ts
        ,B.assz_orgn_pcsn_dcd
        ,B.atch_yn
        ,B.atch_sqn
        ,B.assz_dcmn_clsf_id
        ,B.conn_ttl_nm
        ,B.url_adr
      from tb_uda_uai000m A
      inner join tb_uda_uai003m B on (A.assz_unfc_id = B.assz_unfc_id)
      where B.assz_cfbo_idnt_id = $1
    `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
async function selectMetaSuccess(assz_btch_acmp_id, sysName, eror_vl) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  try {
    let sql = `
      select
          TA.assz_unfc_id,
          TA.uda_sys_lsmd_id,
	        TA.assz_cfbo_idnt_id,
          ${sysName == 'IISIIS' ? 'TB.file_nm,' : ''}
	        TA.eror_vl
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = ANY($3) -- 성공 건
          and TA.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
          and TA.assz_btch_acmp_id = $1
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $2
      `;
    const result = await client.query(sql, [
      assz_btch_acmp_id,
      sysName,
      erorVlIn,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function checkFmtsBaseUnfcId(assz_fmts_base_orgn_idnt_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT
      assz_unfc_id
      from TB_UDA_UAI000M
      where assz_cfbo_idnt_id = 
      (
	      SELECT
	      assz_cfbo_idnt_id 
	      FROM tb_uda_uai001m
	      WHERE assz_fmts_base_orgn_idnt_id = $1
	      ORDER BY amnn_ts desc
	      limit 1 
      )
      `,
      [assz_fmts_base_orgn_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function checkFmtsBaseUnfcIdEpn(
  assz_fmts_base_orgn_idnt_id,
  assz_cfbo_idnt_id
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT
        assz_unfc_id
      from TB_UDA_UAI000M
      where assz_cfbo_idnt_id in
      (
          SELECT
            assz_cfbo_idnt_id 
          FROM tb_uda_uai071m
          WHERE assz_fmts_base_orgn_idnt_id = $1
          and assz_cfbo_idnt_id != $2
          and assz_orgn_pcsn_dcd != 'D'
          ORDER BY amnn_ts desc
      )
      `,
      [assz_fmts_base_orgn_idnt_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
async function selectMetaSuccessReGen(sysName, eror_vl) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  try {
    let sql = `
      select
          TA.assz_unfc_id
          ,TA.uda_sys_lsmd_id
          ,substr(TA.assz_btch_acmp_id,0,9) as basdt
	        ,TA.assz_cfbo_idnt_id
	        ,TA.eror_vl 
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = ANY($2) -- 성공 건
          and TA.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $1
      `;
    const result = await client.query(sql, [sysName, erorVlIn]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터, 메타 조회 - 수명주기
async function selectMetaSuccessLifecycle(assz_btch_acmp_id, sysName, eror_vl) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  // 수명주기에 필요한 등록자부서ID, 등록자ID, 등록일시
  let sqlLifecycleColumn = "";
  if (sysName == "KMSWPT" || sysName == "KMSEPN" || sysName == "KMSPLZ") {
    sqlLifecycleColumn = `
      TB.rgsr_dept_id,
      TB.orgn_data_rgsr_id,
      TB.rgsn_ts,
    `;
  } else if (
    sysName == "CSMCSM" ||
    sysName == "IEMIEB" ||
    sysName == "IISIIS" ||
    sysName == "AIKKMS"
  ) {
    sqlLifecycleColumn = `
      '' AS rgsr_dept_id,
      TB.orgn_data_rgsr_id,
      TB.rgsn_ts,
    `;
  } else if (sysName == "IEMIEA") {
    sqlLifecycleColumn = `
      '' AS rgsr_dept_id,
      '' AS orgn_data_rgsr_id,
      '' AS rgsn_ts,
    `;
  }

  try {
    let sql = `
      select
          TA.assz_unfc_id,
          TA.uda_sys_lsmd_id,
          ${sqlLifecycleColumn}
          TA.assz_pcsn_tcd
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = ANY($3) -- 성공 건
          and TA.assz_pcsn_tcd in ('C', 'D') -- C는 수명주기 저장, D는 문서 폐기처리
          and TA.assz_btch_acmp_id = $1
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $2
      `;
    const result = await client.query(sql, [
      assz_btch_acmp_id,
      sysName,
      erorVlIn,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
async function selectMetaSuccessMaskingAll(sysName) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  //const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  try {
    let sql = `
      select
          TA.assz_unfc_id,
          TA.uda_sys_lsmd_id,
	        TA.assz_cfbo_idnt_id,
	        TA.eror_vl                    
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = '0000' -- 성공 건
          and TA.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $1
      `;
    const result = await client.query(sql, [sysName]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

module.exports = {
  checkUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  getUnfcIdFromTodayCheckId,
  updateBatchId,
  updateErorVl,
  updateAsszScd,
  chkDupByAsszCfboIdntId,
  chkDupByAsszCfboIdntIdAndStus,
  updateLdgrStusBatId,
  updateLdgrBatId,
  selectMetaDocNm,
  updateNoChange,
  selectOne,
  selectOneForUpdate,
  selectMetaDocNmCsm,
  selectMetaDocNmCsmRange,
  selectOneOch,
  selectMetaDocNmRange,
  selectMetaDocNmEpn,
  selectMetaDocNmEpnRange,
  selectMetaDocNmIis,
  selectMetaDocNmIisRange,
  updateOriginMaster,
  updateOriginMasterIea,
  deleteAddInfoKms,
  chkDupByMnlAsszCfboIdntId,
  updateOnlyAsszScd,
  selectMetaSuccess,
  checkFmtsBaseUnfcId,
  selectOneByUnfcId,
  checkFmtsBaseUnfcIdEpn,
  selectMetaSuccessReGen,
  selectMetaSuccessLifecycle,
  selectMetaSuccessMaskingAll,
};
