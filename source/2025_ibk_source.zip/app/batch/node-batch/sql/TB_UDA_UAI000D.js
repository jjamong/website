const dayjs = require("dayjs");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

// 원장 결과 삭제
async function deleteAssDtl(assz_unfc_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        delete from tb_uda_uai000d
        where 1=1
        and assz_unfc_id = $1
      `,
      [assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *
 * @param {*} assz_unfc_id
 * @param {*} assz_rslt_dtl_sqn
 * @param {*} assz_pcsn_rslt_tcd
 * @param {*} assz_con
 * @param {*} assz_page_no
 * @param {*} assz_no
 * @param {*} assz_pcsn_file_path_nm
 * @param {*} uda_sys_lsmd_id
 * @returns
 */
async function insertAssDtl(
  assz_unfc_id,
  assz_rslt_dtl_sqn,
  assz_pcsn_rslt_tcd,
  assz_page_no,
  assz_no,
  assz_pcsn_file_path_nm,
  assz_con,
  assz_img_tppo_xcr_vl,
  assz_img_tppo_ycr_vl,
  assz_img_lwen_xcr_vl,
  assz_img_lwen_ycr_vl,
  uda_sys_lsmd_id
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        insert into tb_uda_uai000d (
          assz_unfc_id,
          assz_rslt_dtl_sqn,
          assz_pcsn_rslt_tcd,
          assz_page_no,
          assz_no,
          assz_pcsn_file_path_nm,
          assz_con,
          assz_img_tppo_xcr_vl,
          assz_img_tppo_ycr_vl,
          assz_img_lwen_xcr_vl,
          assz_img_lwen_ycr_vl,
          uda_sys_lsmd_id,
          uda_sys_lsmd_ts
        ) VALUES (
          $1, -- assz_unfc_id,
          $2, -- assz_rslt_dtl_sqn,
          $3, -- assz_pcsn_rslt_tcd,
          $4, -- assz_page_no,
          $5, -- assz_no,
          $6, -- assz_pcsn_file_path_nm,
          $7, -- assz_con,
          $8, -- assz_img_tppo_xcr_vl,
          $9, -- assz_img_tppo_ycr_vl,
          $10, -- assz_img_lwen_xcr_vl,
          $11, -- assz_img_lwen_ycr_vl,
          $12, -- uda_sys_lsmd_id,
          current_timestamp -- uda_sys_lsmd_ts
        );
    `,
      [
        assz_unfc_id,
        assz_rslt_dtl_sqn,
        assz_pcsn_rslt_tcd,
        assz_page_no,
        assz_no,
        assz_pcsn_file_path_nm,
        assz_con,
        assz_img_tppo_xcr_vl,
        assz_img_tppo_ycr_vl,
        assz_img_lwen_xcr_vl,
        assz_img_lwen_ycr_vl,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * @returns
 */
async function getAssDtlSeq(assz_unfc_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      select coalesce(max(assz_rslt_dtl_sqn),0) as idx from tb_uda_uai000d where assz_unfc_id = $1;
      `,
      [assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

module.exports = {
  deleteAssDtl,
  insertAssDtl,
  getAssDtlSeq,
};
