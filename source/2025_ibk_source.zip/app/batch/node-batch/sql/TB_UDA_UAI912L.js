const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertImgAst(
  assz_btch_acmp_id,
  assz_unfc_id,
  img_sqn,
  assz_page_no,
  assz_img_no,
  assz_img_tppo_xcr_vl,
  assz_img_tppo_ycr_vl,
  assz_img_lwen_xcr_vl,
  assz_img_lwen_ycr_vl,
  assz_img_file_nm,
  assz_img_con,
  assz_img_pcsn_tcd,
  assz_pcsn_file_path_nm,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO TB_UDA_UAI912L
      (assz_btch_acmp_id, assz_trms_tgt_sys_dcd,
        assz_btch_tcd, 
        assz_meta_pcsn_sqn, img_sqn, assz_unfc_id, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, ASSZ_IMG_FILE_NM, ASSZ_IMG_CON, assz_img_pcsn_tcd, assz_pcsn_file_path_nm, acmp_sttg_ts, acmp_fnsh_ts, uda_sys_lsmd_id,uda_sys_lsmd_ts)
      VALUES($1,
        '01',
        '01',
        (
        select coalesce(max(assz_meta_pcsn_sqn),1) from TB_UDA_UAI901L where assz_btch_acmp_id=$1::varchar and assz_unfc_id = $2::varchar
        ), $3, $2, $4, $5, $6, $7, $8, $9,$10, $11, $12, $13,$14, $15, $16, Current_timestamp);
		`,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        img_sqn,
        assz_page_no,
        assz_img_no,
        assz_img_tppo_xcr_vl,
        assz_img_tppo_ycr_vl,
        assz_img_lwen_xcr_vl,
        assz_img_lwen_ycr_vl,
        assz_img_file_nm,
        assz_img_con,
        assz_img_pcsn_tcd,
        assz_pcsn_file_path_nm,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
  }
}
async function selectFilePathNm(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_unfc_id, img_sqn, assz_page_no, assz_img_no, assz_img_tppo_xcr_vl, assz_img_tppo_ycr_vl, assz_img_lwen_xcr_vl, assz_img_lwen_ycr_vl, assz_img_file_nm, assz_img_con, assz_img_pcsn_tcd, assz_pcsn_file_path_nm, acmp_sttg_ts, acmp_fnsh_ts, uda_sys_lsmd_id, uda_sys_lsmd_ts
      FROM TB_UDA_UAI912L
		  where  assz_btch_acmp_id = $1
      and  assz_unfc_id = $2
  `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}
async function dbEnd() {
  pool.end();
}

module.exports = {
  insertImgAst,
  selectFilePathNm,
  dbEnd,
};
