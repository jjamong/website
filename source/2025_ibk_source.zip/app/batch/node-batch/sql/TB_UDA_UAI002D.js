const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  rgsr_id,
  rgsn_ts,
  atch_yn,
  atch_sqn,
  assz_pcsn_file_path_nm,
  atch_nm,
  uda_sys_lsmd_id,
  eror_vl,
  ASSZ_EROR_CON
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI001D(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, assz_unfc_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, atch_yn, atch_sqn, assz_pcsn_file_path_nm, atch_nm, uda_sys_lsmd_id,eror_vl,ASSZ_EROR_CON)
		VALUES ($1,
		          (select  coalesce(max(assz_meta_pcsn_sqn)+1,1)
							from TB_UDA_UAI001D
							where assz_btch_acmp_id =$1::VARCHAR),
							$2,$3,$4,$5,$6,$7,TO_TIMESTAMP($8,'YYYYMMDDHH24MISS'),$9,$10,$11,$12,$13,$14,$15);
		`,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        rgsr_id,
        rgsn_ts,
        atch_yn,
        atch_sqn,
        assz_pcsn_file_path_nm,
        atch_nm,
        uda_sys_lsmd_id,
        eror_vl,
        ASSZ_EROR_CON,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function updateMeta(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai001d
			   SET assz_unfc_id =$3
			 WHERE assz_btch_acmp_id=$1 
			   AND assz_meta_pcsn_sqn    =$2;
		`,
      [assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  updateMeta,
  dbEnd,
};
