async function insertMeta(
  pool,
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  cnvs_grp_cd,
  assz_fund_dcmn_dcd,
  assz_fund_new_abl_yn,
  sale_fnsh_ymd,
  trth_file_nm,
  eror_vl,
  assz_eror_con,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI011M(
      assz_btch_acmp_id
    , assz_meta_pcsn_sqn
    , assz_unfc_id
    , assz_cfbo_idnt_id
    , file_nm
    , file_sqn
    , assz_orcp_file_path_nm
    , rgsr_id
    , rgsn_ts
    , amnn_ts
    , assz_orgn_pcsn_dcd
    , atch_yn, atch_sqn
    , assz_dcmn_clsf_id
    , conn_ttl_nm, cnvs_grp_cd
    , assz_fund_dcmn_dcd
    , assz_fund_new_abl_yn
    , sale_fnsh_ymd
    , trth_file_nm
    , assz_pcsn_file_path_nm
    , eror_vl
    , assz_eror_con
    , uda_sys_lsmd_id
    )
    VALUES (
        $1
      , (select  coalesce(max(assz_meta_pcsn_sqn)+1,1) from TB_UDA_UAI011M where assz_btch_acmp_id =$1::VARCHAR)
      , $2,$3,$4,$5,$6,$7
      , TO_TIMESTAMP($8,'YYYYMMDDHH24MISS')
      , TO_TIMESTAMP($9,'YYYYMMDDHH24MISS')
      , $10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)
    `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        cnvs_grp_cd,
        assz_fund_dcmn_dcd,
        assz_fund_new_abl_yn,
        sale_fnsh_ymd,
        trth_file_nm,
        null,
        eror_vl,
        assz_eror_con,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

async function updateError(
  pool,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  targetPath,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        update tb_uda_uai011m set assz_pcsn_file_path_nm = $3, eror_vl = $4, assz_eror_con = $5
        where assz_btch_acmp_id = $1 and assz_cfbo_idnt_id = $2
      `,
      [assz_btch_acmp_id, assz_cfbo_idnt_id, targetPath, eror_vl, assz_eror_con]
    );
  } finally {
    client.release();
  }
}

async function selectFilePath(pool, assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select assz_pcsn_file_path_nm from tb_uda_uai011m where assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

// 메인메타 조회
async function selectMeta(pool, assz_btch_acmp_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        SELECT 
          assz_btch_acmp_id
        , assz_meta_pcsn_sqn
        , assz_unfc_id
        , assz_cfbo_idnt_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , cnvs_grp_cd
        , assz_fund_dcmn_dcd
        , assz_fund_new_abl_yn
        , sale_fnsh_ymd
        , trth_file_nm
        , assz_pcsn_file_path_nm
        , eror_vl
        , assz_eror_con
        FROM tb_uda_uai011m
        WHERE assz_btch_acmp_id = $1
        AND eror_vl = '0000'
        order BY assz_btch_acmp_id, assz_cfbo_idnt_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

module.exports = {
  insertMeta,
  updateError,
  selectFilePath,
  selectMeta,
};
