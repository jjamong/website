const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_dcmn_clsf_id,
  assz_chb_conn_url_adr,
  assz_chb_frtm_conn_url_adr,
  assz_chb_sctm_conn_url_adr,
  assz_chb_thtm_conn_url_adr,
  assz_chb_fotm_conn_url_adr,
  assz_qstn_con,
  assz_rply_con,
  assz_pcsn_file_path_nm,
  eror_vl,
  assz_eror_con,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
INSERT INTO tb_uda_uai009m
  (
    assz_btch_acmp_id,
    assz_meta_pcsn_sqn,
    assz_unfc_id, 
    assz_cfbo_idnt_id, 
    rgsr_id, 
    rgsn_ts, 
    amnn_ts, 
    assz_dcmn_clsf_id, 
    assz_chb_conn_url_adr, 
    assz_chb_frtm_conn_url_adr,
    assz_chb_sctm_conn_url_adr,
    assz_chb_thtm_conn_url_adr,
    assz_chb_fotm_conn_url_adr,
    assz_qstn_con, 
    assz_rply_con, 
    assz_pcsn_file_path_nm, 
    eror_vl, 
    assz_eror_con, 
    uda_sys_lsmd_id
  )
VALUES(
    $1
  , (select coalesce(max(assz_meta_pcsn_sqn)+1,1) from tb_uda_uai009m where assz_btch_acmp_id =$1::VARCHAR)
  , $2, $3, $4
  , TO_TIMESTAMP($5,'YYYYMMDDHH24MISS')
  , TO_TIMESTAMP($6,'YYYYMMDDHH24MISS')
  ,$7,$8,$9, $10,$11, $12, $13, $14, $15, $16, $17, $18);
		`,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_dcmn_clsf_id,
        assz_chb_conn_url_adr,
        assz_chb_frtm_conn_url_adr,
        assz_chb_sctm_conn_url_adr,
        assz_chb_thtm_conn_url_adr,
        assz_chb_fotm_conn_url_adr,
        assz_qstn_con,
        assz_rply_con,
        assz_pcsn_file_path_nm,
        eror_vl,
        assz_eror_con,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function updateMeta(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai009m
			   SET assz_unfc_id =$3
			 WHERE assz_btch_acmp_id=$1 
			   AND assz_meta_pcsn_sqn    =$2;
		`,
      [assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_unfc_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, rgsn_ts, amnn_ts, assz_chb_conn_url_adr, assz_pcsn_file_path_nm, uda_sys_lsmd_id
        FROM tb_uda_uai009m
       where assz_btch_acmp_id =$1
       order by assz_btch_acmp_id, assz_meta_pcsn_sqn;
  `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta02(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, mnl_id, grp_id, cmpe_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, conn_ttl_nm, assz_pcsn_file_path_nm, url_adr, atch_nm, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts
        FROM tb_uda_uai009m
       where assz_btch_acmp_id =$1
         and assz_unfc_id =$2
       order by assz_btch_acmp_id,file_sqn;
  `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  selectMeta,
  selectMeta02,
  updateMeta,
  dbEnd,
};
