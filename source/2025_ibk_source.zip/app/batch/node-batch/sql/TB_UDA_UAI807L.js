const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_dcmn_clsf_id,
  assz_chb_conn_url_adr,
  assz_chb_frtm_conn_url_adr,
  assz_chb_sctm_conn_url_adr,
  assz_chb_thtm_conn_url_adr,
  assz_chb_fotm_conn_url_adr,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
INSERT INTO tb_uda_uai807L
  (
    assz_btch_acmp_id,
    assz_trms_tgt_sys_dcd,
    assz_btch_tcd,
    assz_meta_pcsn_sqn,
    assz_unfc_id, 
    assz_cfbo_idnt_id, 
    orgn_data_rgsr_id, 
    rgsn_ts, 
    amnn_ts, 
    assz_dcmn_clsf_id, 
    url_adr, 
    assz_chb_frtm_conn_url_adr,
    assz_chb_sctm_conn_url_adr,
    assz_chb_thtm_conn_url_adr,
    assz_chb_fotm_conn_url_adr,
    assz_pcsn_file_path_nm, 
    uda_sys_lsmd_id,
    uda_sys_lsmd_ts
  )
VALUES(
    $1
  , '01'
  , '01'
  , (select coalesce(max(assz_meta_pcsn_sqn)+1,1) from tb_uda_uai807l where assz_btch_acmp_id =$1::VARCHAR)
  , $2
  , $3
  , $4
  , TO_TIMESTAMP($5,'YYYYMMDDHH24MISS')
  , TO_TIMESTAMP($6,'YYYYMMDDHH24MISS')
  , $7
  , $8
  , $9
  , $10
  , $11
  , $12
  , $13
  , $14
  , current_timestamp
  );
                `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_dcmn_clsf_id,
        assz_chb_conn_url_adr,
        assz_chb_frtm_conn_url_adr,
        assz_chb_sctm_conn_url_adr,
        assz_chb_thtm_conn_url_adr,
        assz_chb_fotm_conn_url_adr,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function updateMeta(assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
                        UPDATE tb_uda_uai009m
                           SET assz_unfc_id =$3
                         WHERE assz_btch_acmp_id=$1 
                           AND assz_meta_pcsn_sqn    =$2;
                `,
      [assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
       SELECT assz_btch_acmp_id, assz_unfc_id, assz_meta_pcsn_sqn, assz_cfbo_idnt_id, rgsn_ts, amnn_ts, url_adr, assz_pcsn_file_path_nm, assz_dcmn_clsf_id
       FROM tb_uda_uai807L
       where assz_btch_acmp_id =$1
       order by assz_btch_acmp_id, assz_meta_pcsn_sqn;
  `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaRange(startDt, endDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
       SELECT a.assz_btch_acmp_id, a.assz_unfc_id, assz_meta_pcsn_sqn, a.assz_cfbo_idnt_id, rgsn_ts, amnn_ts, url_adr, b.assz_pcsn_file_path_nm, assz_dcmn_clsf_id
       FROM tb_uda_uai000M a
       inner join tb_uda_uai807L b on a.assz_unfc_id = b.assz_unfc_id and a.assz_btch_acmp_id = b.assz_btch_acmp_id
       where (amnn_ts >= $1 AND amnn_ts <= $2)
       order by a.assz_btch_acmp_id, b.assz_meta_pcsn_sqn;
  `,
      [startDt, endDt]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMeta02(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, mnl_id, grp_id, cmpe_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, conn_ttl_nm, assz_pcsn_file_path_nm, url_adr, atch_nm, eror_vl, assz_eror_con, hdlr_id, pcsn_ts
        FROM tb_uda_uai009m
       where assz_btch_acmp_id =$1
         and assz_unfc_id =$2
       order by assz_btch_acmp_id,file_sqn;
  `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

async function updateBatchId(assz_unfc_id, assz_btch_acmp_id) {
  const { Pool } = require("pg");
  const config = require("../../node-batch/config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  console.log(`${assz_btch_acmp_id} ${assz_unfc_id}`);

  try {
    const result = await client.query(
      `
        UPDATE TB_UDA_UAI009M SET assz_btch_acmp_id = $2
        WHERE assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

module.exports = {
  insertMeta,
  selectMeta,
  selectMetaRange,
  selectMeta02,
  updateMeta,
  dbEnd,
  updateBatchId,
};
