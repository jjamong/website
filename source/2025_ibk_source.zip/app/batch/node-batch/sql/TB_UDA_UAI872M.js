// TB_UDA_UAI005M 카드몰 (CSM > CSM)
const { Pool } = require("pg");
const config = require("../config");
const pool2 = new Pool(config.db);

// 메인메타 조회
async function selectMeta(pool, assz_btch_acmp_id) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
        *
      from TB_UDA_UAI000M TA
      join tb_uda_UAI072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      where TA.assz_btch_acmp_id = $1        -- 자산화배치수행ID
        and TB.file_nm ~* '\\.(pdf|jpg|png)$'     -- 파일의 확장자 체크
        and TA.eror_vl = '0000'              -- 오류가 아닌 정상인 경우
        order by TA.assz_btch_acmp_id, TA.assz_cfbo_idnt_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}
// 메인메타 조회
async function selectMetaOne(pool, assz_btch_acmp_id, assz_cfbo_idnt_id) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
        *
        from TB_UDA_UAI000M TA
      join tb_uda_UAI072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      where TA.assz_btch_acmp_id = $1        -- 자산화배치수행ID
        and TB.file_nm ~* '\\.(pdf|jpg|png)$'     -- 파일의 확장자 체크
        and TA.assz_cfbo_idnt_id = $2 
        and TA.eror_vl = '0000'              -- 오류가 아닌 정상인 경우
      `,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

// 메인메타 저장
async function insertMeta(
  pool,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  file_nm,
  file_sqn,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        INSERT INTO TB_UDA_UAI872M (
          assz_btch_acmp_id,
          assz_trms_tgt_sys_dcd,
          assz_btch_tcd,
          assz_meta_pcsn_sqn,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          assz_pcsn_file_path_nm,
          uda_sys_lsmd_id,
          uda_sys_lsmd_ts
        ) VALUES (
          $1,
          '01','01',
          (select  coalesce(max(assz_meta_pcsn_sqn)+1,1) from TB_UDA_UAI872M where assz_btch_acmp_id =$1::VARCHAR),
          $2, $3, $4, $5, $6,
          TO_TIMESTAMP($7,'YYYYMMDDHH24MISS'), TO_TIMESTAMP($8,'YYYYMMDDHH24MISS'),
          $9, $10, $11, $12, $13, $14, $15, current_timestamp
        )
      `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

// 추가메타저장
async function insertInfoMeta(
  pool,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  isnc_tgt_con,
  card_kind_con,
  isnc_intt_con,
  fee_cndt_con,
  cdis_info_con,
  card_ftpm_trfc_con,
  anf_con,
  assz_card_alnc_cd_nm,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        INSERT INTO TB_UDA_UAI872D
        (
            assz_btch_acmp_id,
            assz_trms_tgt_sys_dcd,
            assz_btch_tcd,
            assz_meta_pcsn_sqn,
            file_sqn,
            assz_cfbo_idnt_id,
            assz_unfc_id,
            isnc_tgt_con,
            card_kind_con,
            isnc_intt_con,
            fee_cndt_con,
            cdis_info_con,
            card_ftpm_trfc_con,
            anf_con,
            assz_card_alnc_cd_nm,
            assz_pcsn_file_path_nm,
            uda_sys_lsmd_id,
            uda_sys_lsmd_ts
        )
        VALUES(
            $1
          , '01'
          , '01'
          , (select  coalesce(max(assz_meta_pcsn_sqn)+1,1) from TB_UDA_UAI872D where assz_btch_acmp_id =$1::VARCHAR)
          , (select  coalesce(max(assz_meta_pcsn_sqn)+1,1) from TB_UDA_UAI872D where assz_btch_acmp_id =$1::VARCHAR)
          , $2
          , $3
          , $4
          , $5
          , $6
          , $7
          , $8
          , $9
          , $10
          , $11
          , $12
          , $13
          , current_timestamp
        )
      `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        isnc_tgt_con,
        card_kind_con,
        isnc_intt_con,
        fee_cndt_con,
        cdis_info_con,
        card_ftpm_trfc_con,
        anf_con,
        assz_card_alnc_cd_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

// 자산화처리파일경로명 수정
async function updateAsszPcsnFilePathNmMeta(
  pool,
  assz_btch_acmp_id,
  assz_meta_pcsn_sqn,
  assz_pcsn_file_path_nm
) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      update tb_uda_uai005m
        set assz_pcsn_file_path_nm = $3
      where 1=1
        and assz_btch_acmp_id = $1 
        and assz_meta_pcsn_sqn = $2;
    `,
      [assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_pcsn_file_path_nm]
    );

    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

// 메타(Jeff) 조회
async function selectMetaJeff(assz_btch_acmp_id, assz_cfbo_idnt_id) {
  const client = await pool2.connect();
  try {
    const result = await client.query(
      `select
        *
        from TB_UDA_UAI005M
        where 1=1
        and assz_btch_acmp_id = $1        -- 자산화배치수행ID
        and assz_cfbo_idnt_id = $2        -- 자산화원천별식별ID
      `,
      [assz_btch_acmp_id, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 에러 업데이트
async function updateError(
  pool,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  targetPath,
  eror_vl,
  assz_eror_con
) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        update tb_uda_uai011m set assz_pcsn_file_path_nm = $3, eror_vl = $4, assz_eror_con = $5
        where assz_btch_acmp_id = $1 and assz_cfbo_idnt_id = $2
      `,
      [assz_btch_acmp_id, assz_cfbo_idnt_id, targetPath, eror_vl, assz_eror_con]
    );
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

module.exports = {
  selectMeta,
  selectMetaOne,
  insertMeta,
  updateAsszPcsnFilePathNmMeta,
  selectMetaJeff,
  updateError,
  insertInfoMeta,
};
