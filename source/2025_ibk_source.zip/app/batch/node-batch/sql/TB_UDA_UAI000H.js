const dayjs = require("dayjs");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

async function insertHistory(assz_unfc_id, assz_pcsn_tcd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai000h
      (assz_unfc_id, base_ymd, sqn, assz_btch_acmp_id, assz_pcsn_tcd, sys_lsmd_id)
      SELECT
        assz_unfc_id
      , base_ymd
      , sqn
      , assz_btch_acmp_id
      , $2
      , sys_lsmd_id
      FROM tb_uda_uai000m
      WHERE assz_unfc_id = $1
      ON CONFLICT (assz_unfc_id, base_ymd, sqn)
      DO NOTHING;
      `,
      [assz_unfc_id, assz_pcsn_tcd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function insertHistoryFirst(
  assz_unfc_id,
  base_ymd,
  sqn,
  assz_btch_acmp_id,
  assz_pcsn_tcd,
  sys_lsmd_id
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai000h
      (assz_unfc_id, base_ymd, sqn, assz_btch_acmp_id, assz_pcsn_tcd, sys_lsmd_id, sys_lsmd_ts)
      VALUES($1, $2, $3, $4, $5, $6, CURRENT_TIMESTAMP)
      `,
      [
        assz_unfc_id,
        base_ymd,
        sqn,
        assz_btch_acmp_id,
        assz_pcsn_tcd,
        sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

module.exports = {
  insertHistory,
  insertHistoryFirst,
};
