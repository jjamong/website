const { Pool } = require("pg");
const config = require("../config");
const { writeLog } = require("../log");
const pool = new Pool(config.db);
//업무포탈
async function selectMakeWptMeta(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT
          TA.assz_unfc_id as doc_id
        , TA.assz_unfc_id  as doc_nm
        , TA.assz_cfbo_idnt_id as ori_doc_key
        , TA.flsz_vl as file_size
        , 'pdf' as file_type
        , 'http://workportal.ibk.co.kr/wpt_gcp/lightpack/actiondoc/boardItem/readBoardItemView.do?boardId='|| TB.assz_dcmn_clsf_id ||'&itemId=' || TB.assz_cfbo_idnt_id ||'&searchConditionString=&popupYn=true' AS url
        , case when TA.assz_pcsn_tcd = 'U' then 'C' else TA.assz_pcsn_tcd end as pr_gubun
        , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
        , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
        , TB.atch_yn as att_file_yn
        , TB.atch_sqn as att_file_seq
        , case when TA.eror_vl != '9999' then 
                  case when TB.atch_yn = 'Y' 
                          then TB.conn_ttl_nm ||'_'|| substring(TB.atch_nm from '^(.*)\\.[^\\.]+$')
                          else TB.conn_ttl_nm
                  end
              else '' 
          end as link_file_nm
        , coalesce(TB.suco_oppb_info_con,'') as suco_oppb_info_con
        , TB.suco_dcmn_shrn_yn as suco_dcmn_shrn_yn
        from tb_uda_uai000m TA left join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
        where TA.assz_btch_acmp_id = $1
        and eror_vl = '0000'
        and not exists (select 1 from tb_uda_uai000m where assz_cfbo_idnt_id = TA.assz_cfbo_idnt_id and eror_vl not in ('0000','9999'))
        order by TB.amnn_ts
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

//업무포탈
async function selectMakeWptMetaTemp(startDt, endDt) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , 'http://workportal.ibk.co.kr/wpt_gcp/lightpack/actiondoc/boardItem/readBoardItemView.do?boardId='|| TB.assz_dcmn_clsf_id ||'&itemId=' || TB.assz_cfbo_idnt_id ||'&searchConditionString=&popupYn=true' AS url
      , 'C' as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , case when TA.eror_vl != '9999' then 
        case when TB.atch_yn = 'Y' 
                        then TB.conn_ttl_nm ||'_'|| TB.atch_nm ||'_'|| TB.atch_sqn || '_pdf'
                        else TB.conn_ttl_nm ||'_pdf' 
                  end
      else '' end as link_file_nm
      , coalesce(TB.suco_oppb_info_con,'') as suco_oppb_info_con
      , case when TB.suco_dcmn_shrn_yn is null then (select suco_dcmn_pbpt_yn from  tb_uda_uai200M z where TB.assz_cfbo_idnt_id = z.assz_cfbo_idnt_id)
                        when TB.suco_dcmn_shrn_yn = ''    then (select suco_dcmn_pbpt_yn from  tb_uda_uai200M z where TB.assz_cfbo_idnt_id = z.assz_cfbo_idnt_id)
                      else TB.suco_dcmn_shrn_yn
                    end suco_dcmn_shrn_yn
      from tb_uda_uai000m TA 
        left join TB_UDA_UAI001M TB on TA.assz_unfc_id = TB.assz_unfc_id 
        where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
        and eror_vl = '0000'
        and TA.assz_pcsn_tcd != 'D' -- 제외 처리
        and not exists (select 1 from tb_uda_uai000m where assz_cfbo_idnt_id = TA.assz_cfbo_idnt_id and eror_vl not in ('0000','9999'))
      order by TB.amnn_ts
     `,
      [startDt, endDt]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

//업무포탈
async function selectMakeWptMeta2(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , substring(TB.file_nm from '^(.*)\\.[^\\.]+$')  as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , substring(TB.file_nm from '\\.([^.]+)$') as file_type
      , 'http://workportal.ibk.co.kr/wpt_gcp/lightpack/actiondoc/boardItem/readBoardItemView.do?boardId='|| TC.assz_dcmn_clsf_id ||'&itemId=' || TC.assz_cfbo_idnt_id ||'&searchConditionString=&popupYn=true' AS url
      , case when TA.assz_pcsn_tcd = 'U' then 'C' else TA.assz_pcsn_tcd end as pr_gubun
      , to_char(TA.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TA.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TA.atch_yn
      , TA.atch_sqn
      , case when TA.eror_vl != '9999' then 
        case when TB.atch_yn = 'Y' 
                        then TC.conn_ttl_nm ||'_'|| TB.atch_nm ||'_'|| TB.atch_sqn || '_pdf'
                        else TC.conn_ttl_nm ||'_pdf' 
                  end
      else '' end as link_file_nm
      , coalesce(TC.suco_oppb_info_con,'') as suco_oppb_info_con
      , case when TC.suco_dcmn_shrn_yn is null then (select suco_dcmn_pbpt_yn from  tb_uda_uai200M z where TC.assz_cfbo_idnt_id = z.assz_cfbo_idnt_id)
                        when TC.suco_dcmn_shrn_yn = ''    then (select suco_dcmn_pbpt_yn from  tb_uda_uai200M z where TC.assz_cfbo_idnt_id = z.assz_cfbo_idnt_id)
                      else TC.suco_dcmn_shrn_yn
                    end suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai001d TB on TA.assz_unfc_id = TB.assz_unfc_id and TA.assz_btch_acmp_id = TB.assz_btch_acmp_id and TA.assz_cfbo_idnt_id = TB.assz_cfbo_idnt_id
      left join tb_uda_uai001m TC on TB.assz_btch_acmp_id = TC.assz_btch_acmp_id and TB.assz_cfbo_idnt_id = TC.assz_cfbo_idnt_id
      left join tb_uda_uai102m TD on TA.assz_cfbo_idnt_id = TD.wpt_dcmn_id 
      where TA.assz_btch_acmp_id = $1
      and TA.eror_vl in ('0000', '9999')
       and TD.wpt_rtpl_grp_id = '3'
      `,
      [assz_btch_acmp_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 지식샘
async function selectMakeKmsMeta(assz_btch_acmp_id, type = "meta") {
  const client = await pool.connect();
  let sqlWith = `
    with base as (
      -- HTML
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,substring(b.assz_orcp_file_path_nm from '[^/]+$') as doc_nm
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,lower(substring(b.assz_orcp_file_path_nm from '\\.([^./]+)$')) as ext
        ,trim(b.url_adr) as url
        ,a.assz_pcsn_tcd as pr_gubun
        ,to_char(b.rgsn_ts,'YYYY-MM-DD HH24:MI:SS') as create_at
        ,to_char(b.amnn_ts,'YYYY-MM-DD HH24:MI:SS') as update_at
        ,a.eror_vl
        ,b.atch_sqn
        ,b.sb_ttl_nm
        ,b.atch_nm
        ,concat_ws('_', b.conn_ttl_nm, b.tab_nm, b.sb_ttl_nm, nullif(b.qstn_id, '')) as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai005m b
        on a.assz_unfc_id = b.assz_unfc_id
      where 1=1
      ${type == "gai" ? `and a.assz_pcsn_tcd != 'D' -- 제외 처리` : ""}
      and a.eror_vl in ('0011', '0012')
      and atch_key_vl = ''
      and a.assz_btch_acmp_id = $1

      union all

      -- FILE
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,substring(b.file_nm from '[^/]+$') as doc_nm
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,lower(substring(b.file_nm from '\.([^./]+)$')) as ext
        ,trim(b.url_adr) as url
        ,a.assz_pcsn_tcd as pr_gubun
        ,'' as create_at
        ,to_char(b.apnd_file_rgsn_ts,'YYYY-MM-DD HH24:MI:SS') as update_at
        ,a.eror_vl
        ,b.atch_sqn
        ,b.sb_ttl_nm
        ,b.atch_nm
        ,(
          select max(d.conn_ttl_nm) from tb_uda_uai005m d
            where 1=1
            and d.assz_cfbo_idnt_id = b.assz_cfbo_idnt_id
          ) || '_' || regexp_replace(atch_nm, '\\.[^.]+$', '')
        as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai005m b
        on a.assz_unfc_id = b.assz_unfc_id
        and a.assz_cfbo_idnt_id = b.assz_cfbo_idnt_id || '_' || b.atch_key_vl
      where 1=1
      ${type == "gai" ? `and a.assz_pcsn_tcd != 'D' -- 제외 처리` : ""}
      and a.eror_vl in ('0000')
      and atch_key_vl != ''
      and a.assz_btch_acmp_id = $1
    )
  `;
  let sql = "";
  if (type == "meta") {
    sql = `${sqlWith}
      select
        assz_unfc_id as doc_id
        ,assz_unfc_id as doc_nm
        ,ori_doc_key
        ,file_size
        ,'pdf' file_type
        ,url
        ,pr_gubun
        ,create_at
        ,update_at
        -- 첨부파일 여부
        ,case
          when ext in ('html') then 'N'
          else 'Y'
        end as att_file_yn
        ,atch_sqn as att_file_seq
        -- 링크파일명
        ,link_file_nm
        ,'' as suco_oppb_info_con
        ,'' as suco_dcmn_shrn_yn
      from base;
    `;
  } else if (type == "gai") {
    sql = `${sqlWith}
      select
        assz_btch_acmp_id
        ,assz_unfc_id
        ,ext
        ,atch_sqn
        ,eror_vl
      from base;
    `;
  }

  try {
    const result = await client.query(sql, [assz_btch_acmp_id]);
    return result;
  } finally {
    client.release();
  }
}

// 지식샘
async function selectMakeKmsMetaRange(type = "meta", startDt, endDt) {
  const client = await pool.connect();
  let sqlWith = `
    with base as (
      -- HTML
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,substring(b.assz_orcp_file_path_nm from '[^/]+$') as doc_nm
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,lower(substring(b.assz_orcp_file_path_nm from '\\.([^./]+)$')) as ext
        ,trim(b.url_adr) as url
        ,'C' as pr_gubun
        ,to_char(b.rgsn_ts,'YYYY-MM-DD HH24:MI:SS') as create_at
        ,to_char(b.amnn_ts,'YYYY-MM-DD HH24:MI:SS') as update_at
        ,a.eror_vl
        ,b.atch_sqn
        ,b.sb_ttl_nm
        ,b.atch_nm
        ,concat_ws('_', b.conn_ttl_nm, b.tab_nm, b.sb_ttl_nm, nullif(b.qstn_id, '')) as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai005m b
        on a.assz_unfc_id = b.assz_unfc_id
      where 1=1
      and a.assz_pcsn_tcd != 'D' -- 제외 처리
      and a.eror_vl in ('0011', '0012')
      and atch_key_vl = ''
      and (SUBSTRING(a.assz_btch_acmp_id, 0, 9) >= $1 and SUBSTRING(a.assz_btch_acmp_id, 0, 9) < $2)

      union all
      
      -- FILE
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,substring(b.file_nm from '[^/]+$') as doc_nm
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,lower(substring(b.file_nm from '\.([^./]+)$')) as ext
        ,trim(b.url_adr) as url
        ,'C' as pr_gubun
        ,to_char(b.apnd_file_rgsn_ts,'YYYY-MM-DD HH24:MI:SS') as create_at
        ,'' as update_at
        ,a.eror_vl
        ,b.atch_sqn
        ,b.sb_ttl_nm
        ,b.atch_nm
        ,(
          select max(d.conn_ttl_nm) from tb_uda_uai005m d
            where 1=1
            and d.assz_cfbo_idnt_id = b.assz_cfbo_idnt_id
          ) || '_' || regexp_replace(atch_nm, '\\.[^.]+$', '')
        as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai005m b
        on a.assz_unfc_id = b.assz_unfc_id
        and a.assz_cfbo_idnt_id = b.assz_cfbo_idnt_id || '_' || b.atch_key_vl
      where 1=1
      and a.assz_pcsn_tcd != 'D' -- 제외 처리
      and a.eror_vl in ('0000')
      and atch_key_vl != ''
      and (SUBSTRING(a.assz_btch_acmp_id, 0, 9) >= $1 and SUBSTRING(a.assz_btch_acmp_id, 0, 9) < $2)
    )
  `;
  let sql = "";
  if (type == "meta") {
    sql = `${sqlWith}
      select
        assz_unfc_id as doc_id
        ,assz_unfc_id as doc_nm
        ,ori_doc_key
        ,file_size
        ,'pdf' file_type
        ,url
        ,pr_gubun
        ,create_at
        ,update_at
        -- 첨부파일 여부
        ,case
          when ext in ('html') then 'N'
          else 'Y'
        end as att_file_yn
        ,atch_sqn as att_file_seq
        -- 링크파일명
        ,link_file_nm
        ,'' as suco_oppb_info_con
        ,'' as suco_dcmn_shrn_yn
      from base;
    `;
  } else if (type == "gai") {
    sql = `${sqlWith}
      select
        assz_btch_acmp_id
        ,assz_unfc_id
        ,ext
        ,atch_sqn
        ,eror_vl
      from base;
    `;
  }

  try {
    const result = await client.query(sql, [startDt, endDt]);
    return result;
  } finally {
    client.release();
  }
}

//업무메뉴얼
async function selectMakeIebMeta(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      select 
        A.assz_unfc_id as doc_id
        , trim( A.assz_cfbo_idnt_id)  as doc_nm
        , A.assz_cfbo_idnt_id as ori_doc_key 
        , A.flsz_vl as file_size
        , 'pdf' as file_type     
        , (select replace(max(Z.url_adr),CHR(13),'') from       tb_uda_uai803l Z where Z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as url_adr
        ,  A.assz_pcsn_tcd as pr_gubun 
        , (select to_char(min(z.rgsn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai803l Z where z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as rgsn_ts
        , (select to_char(max(z.amnn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai803l Z where z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as amnn_ts
        , 'N' as att_file_yn
        , 0 as att_file_seq
        , (select max(Z.conn_ttl_nm) from tb_uda_uai803l Z where Z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id) as link_file_nm      
      from tb_uda_uai000m A
      where 1=1                 
      and A.eror_vl = '0003'
      and A.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

//업무메뉴얼
async function selectMakeIebMetaByBaseYmd(base_ymd) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      select 
        A.assz_unfc_id as doc_id
        , trim( A.assz_cfbo_idnt_id)  as doc_nm
        , A.assz_cfbo_idnt_id as ori_doc_key 
        , A.flsz_vl as file_size
        , 'pdf' as file_type     
        , (select replace(max(Z.url_adr),CHR(13),'') from       tb_uda_uai003m Z where Z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as url_adr
        ,  A.assz_pcsn_tcd as pr_gubun 
        , (select to_char(min(z.rgsn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai003m Z where z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as rgsn_ts
        , (select to_char(max(z.amnn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai003m Z where z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as amnn_ts
        , 'N' as att_file_yn
        , 0 as att_file_seq
        , (select max(Z.conn_ttl_nm) from tb_uda_uai003m Z where Z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id) as link_file_nm      
      from tb_uda_uai000m A
      where 1=1                 
      and A.eror_vl = '0003'
      and A.assz_orgn_sys_cd_con = 'IEMIEB'        
      and A.base_ymd = $1
      `,
      [base_ymd]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 내규시스템
async function selectMakeIeaMeta(assz_btch_acmp_id, type = "meta") {
  const client = await pool.connect();
  let sqlWith = `
    with base as (
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,'pdf' as file_type
        ,null as url
        ,a.assz_pcsn_tcd as pr_gubun
        ,'' as create_at
        ,'' as update_at
        ,'N' as atch_yn
        ,'0' as atch_sqn
        ,b.conn_ttl_nm as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai004m b on a.assz_unfc_id = b.assz_unfc_id
      where 1=1
        ${
          type == "gai"
            ? `and a.assz_pcsn_tcd not in ('D', 'N') -- 제외 처리`
            : `and a.assz_pcsn_tcd not in ('N') -- 제외 처리`
        }
        and SUBSTRING(a.assz_unfc_id, 4, 6) = 'IEMIEA'
        and a.eror_vl in ('0000', '0004')
        and a.assz_btch_acmp_id = $1
    )
  `;
  let sql = "";
  if (type == "meta") {
    sql = `${sqlWith}
      select
        assz_unfc_id as doc_id -- 문서 ID
        ,assz_unfc_id as doc_nm -- 문서명
        ,ori_doc_key -- 원천식별 Key
        ,file_size -- 파일크기
        ,file_type -- 파일타입
        ,url -- URL
        ,pr_gubun -- 처리구분
        ,create_at -- 원천시스템 문서 생성일
        ,update_at -- 원천시스템 문서 수정일
        ,atch_yn as att_file_yn -- 첨부파일 여부
        ,atch_sqn as att_file_seq -- 첨부파일 SEQ
        ,link_file_nm -- 링크로 연결된 파일명
        ,'' as suco_oppb_info_con -- 자회사 공개 정보
        ,'' as suco_dcmn_shrn_yn -- 당행근무 자회사직원 문서공유 여부
      from base;
    `;
  } else if (type == "gai") {
    sql = `${sqlWith}
      select
        assz_btch_acmp_id
        ,assz_unfc_id
      from base;
    `;
  }

  try {
    const result = await client.query(sql, [assz_btch_acmp_id]);
    return result;
  } finally {
    client.release();
  }
}

// 내규시스템
async function selectMakeIeaMetaRange(type = "meta", startDt, endDt) {
  const client = await pool.connect();
  let sqlWith = `
    with base as (
      select
        a.assz_btch_acmp_id
        ,a.assz_unfc_id
        ,a.assz_cfbo_idnt_id  as ori_doc_key
        ,a.flsz_vl as file_size
        ,'pdf' as file_type
        ,null as url
        ,'C' as pr_gubun
        ,'' as create_at
        ,'' as update_at
        ,'N' as atch_yn
        ,'0' as atch_sqn
        ,b.conn_ttl_nm as link_file_nm
      from tb_uda_uai000m a
      inner join tb_uda_uai004m b on a.assz_unfc_id = b.assz_unfc_id
      where 1=1
        and a.assz_pcsn_tcd not in ('D', 'N') -- 제외 처리
        and SUBSTRING(a.assz_unfc_id, 4, 6) = 'IEMIEA'
        and a.eror_vl in ('0000', '0004')
        and (SUBSTRING(a.assz_btch_acmp_id, 0, 9) >= $1 and SUBSTRING(a.assz_btch_acmp_id, 0, 9) < $2)
    )
  `;
  let sql = "";
  if (type == "meta") {
    sql = `${sqlWith}
      select
        assz_unfc_id as doc_id -- 문서 ID
        ,assz_unfc_id as doc_nm -- 문서명
        ,ori_doc_key -- 원천식별 Key
        ,file_size -- 파일크기
        ,file_type -- 파일타입
        ,url -- URL
        ,pr_gubun -- 처리구분
        ,create_at -- 원천시스템 문서 생성일
        ,update_at -- 원천시스템 문서 수정일
        ,atch_yn as att_file_yn -- 첨부파일 여부
        ,atch_sqn as att_file_seq -- 첨부파일 SEQ
        ,link_file_nm -- 링크로 연결된 파일명
        ,'' as suco_oppb_info_con -- 자회사 공개 정보
        ,'' as suco_dcmn_shrn_yn -- 당행근무 자회사직원 문서공유 여부
      from base;
    `;
  } else if (type == "gai") {
    sql = `${sqlWith}
      select
        assz_btch_acmp_id
        ,assz_unfc_id
      from base;
    `;
  }

  try {
    const result = await client.query(sql, [startDt, endDt]);
    return result;
  } finally {
    client.release();
  }
}

// 챗봇
async function selectMakeOchMeta(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
    select    
      TA.assz_unfc_id as doc_id
    , TA.assz_cfbo_idnt_id as doc_nm
    , TA.assz_cfbo_idnt_id as ori_doc_key
    , TA.flsz_vl as file_size
    , 'pdf' as file_type
    , TA.url_adr as url
    , assz_pcsn_tcd as pr_gubun
    , to_char(TA.rgsn_ts,'YYYY-MM-DD HH24:MI:SS') as create_at 
    , to_char(TA.amnn_ts,'YYYY-MM-DD HH24:MI:SS') as update_at
    , 'N' as att_file_yn
    , 0 as att_file_seq
    , TA.assz_cfbo_idnt_id as link_file_nm 
    from TB_UDA_UAI000M TA
    where TA.assz_btch_acmp_id = $1
    and TA.assz_pcsn_tcd in ('C','U')
          `,
      [assz_btch_acmp_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateUai22(assz_btch_acmp_id1, assz_btch_acmp_id2) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
update TB_UDA_UAI910L
   set assz_btch_acmp_id =$2
where assz_btch_acmp_id =$1

        `,
      [assz_btch_acmp_id1, assz_btch_acmp_id2]
    );
    return result;
  } finally {
    client.release();
  }
}

async function updateUai01(assz_btch_acmp_id1, assz_btch_acmp_id2) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
update TB_UDA_UAI001M
   set assz_btch_acmp_id =$2
where assz_btch_acmp_id =$1

        `,
      [assz_btch_acmp_id1, assz_btch_acmp_id2]
    );
    return result;
  } finally {
    client.release();
  }
}
async function updateUai02(assz_btch_acmp_id1, assz_btch_acmp_id2) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
update TB_UDA_UAI001D
   set assz_btch_acmp_id =$2
where assz_btch_acmp_id =$1
        `,
      [assz_btch_acmp_id1, assz_btch_acmp_id2]
    );
    return result;
  } finally {
    client.release();
  }
}
async function updateUai20(assz_btch_acmp_id1, assz_btch_acmp_id2) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
update TB_UDA_UAI901L
   set assz_btch_acmp_id =$2
where assz_btch_acmp_id =$1
        `,
      [assz_btch_acmp_id1, assz_btch_acmp_id2]
    );
    return result;
  } finally {
    client.release();
  }
}
async function updateUaiDel22(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
       update TB_UDA_UAI910L a
            set del_yn = 'Y'
             where a.assz_btch_acmp_id =$1
                          and a.assz_unfc_id  not in ( select max(assz_unfc_id) from TB_UDA_UAI910L z where z.assz_cfbo_idnt_id = a.assz_cfbo_idnt_id and a.assz_btch_acmp_id =z.assz_btch_acmp_id)
        `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 카드몰
async function selectMakeCsmMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , TA.assz_pcsn_tcd as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm as link_file_nm
      , '' as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      where TA.assz_btch_acmp_id = $1
      and TA.eror_vl in ('0000')
      order by TA.assz_unfc_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function selectMakeCsmMetaRange(fromDt, toDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , 'C' as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm as link_file_nm
      , '' as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
      and TA.assz_pcsn_tcd != 'D' -- 제외 처리
      and TA.eror_vl in ('0000')
      order by TA.assz_unfc_id
      `,
      [fromDt, toDt]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 은행상품설명서
async function selectMakeEpnMeta(assz_btch_acmp_id, assz_btch_acmp_id2) {
  const client = await pool.connect();
  try {
    let asszBtchAcmpIdList = [assz_btch_acmp_id, assz_btch_acmp_id2];
    let asszBtchAcmpIdStr = `(\'${asszBtchAcmpIdList
      .filter((d, i) => d != "")
      .join("', '")}\')`;
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , TA.assz_pcsn_tcd as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm
      , case when TA.eror_vl != '9999' then 
                case when TB.atch_yn = 'Y' 
                        then TB.conn_ttl_nm ||'_'|| TB.atch_nm
                        else TB.conn_ttl_nm
                end
              else '' 
        end as link_file_nm
      , TB.assz_dcmn_clsf_id as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where TA.assz_btch_acmp_id IN ${asszBtchAcmpIdStr}
      and TA.eror_vl = '0000'
      and TB.assz_dcmn_clsf_id not in ('130078140181', '130078140216') /* GAI 전송배치에서 130078140181(퇴직연금), 130078140216(신탁) 제외 */
      order by TB.amnn_ts
      `
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 은행상품설명서
async function selectMakeEpnMetaRange(fromDt, toDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.assz_unfc_id as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , 'C' as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm
      , case when TA.eror_vl != '9999' then 
                case when TB.atch_yn = 'Y' 
                        then TB.conn_ttl_nm ||'_'|| TB.atch_nm
                        else TB.conn_ttl_nm
                end
              else '' 
        end as link_file_nm
      , TB.assz_dcmn_clsf_id as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
      and TA.assz_pcsn_tcd != 'D' -- 제외 처리
      and TA.eror_vl = '0000'
      and TB.assz_dcmn_clsf_id not in ('130078140181', '130078140216') /* GAI 전송배치에서 130078140181(퇴직연금), 130078140216(신탁) 제외 */
      order by TB.amnn_ts
      `,
      [fromDt, toDt]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 펀드
async function selectMakeIisMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TB.file_nm as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , TA.assz_pcsn_tcd as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm as link_file_nm
      , '' as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where TA.assz_btch_acmp_id = $1
      and TA.eror_vl in ('0000')
      order by TA.assz_unfc_id
      `,
      [assz_btch_acmp_id]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

// 펀드
async function selectMakeIisMetaRange(fromDt, toDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT
        TA.assz_unfc_id as doc_id
      , TA.file_nm as doc_nm
      , TA.assz_cfbo_idnt_id as ori_doc_key
      , TA.flsz_vl as file_size
      , 'pdf' as file_type
      , '' as url
      , 'C' as pr_gubun
      , to_char(TB.rgsn_ts, 'YYYY-MM-DD HH24:MI:SS') as create_at
      , to_char(TB.amnn_ts, 'YYYY-MM-DD HH24:MI:SS') as update_at
      , TB.atch_yn as att_file_yn
      , TB.atch_sqn as att_file_seq
      , TB.conn_ttl_nm as link_file_nm
      , '' as suco_oppb_info_con
      , '' as suco_dcmn_shrn_yn
      from tb_uda_uai000m TA
      left join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id 
      where (TB.amnn_ts >= $1 AND TB.amnn_ts <= $2)
      and TA.assz_pcsn_tcd != 'D' -- 제외 처리
      and TA.eror_vl in ('0000')
      order by TA.assz_unfc_id
      `,
      [fromDt, toDt]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

/**
 *
 * @param {*} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmOch(assz_btch_acmp_id, basDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
       SELECT 
       file_nm as doc_nm
       FROM TB_UDA_UAI000M TA
       WHERE TA.assz_btch_acmp_id = $1
       AND TA.eror_vl in ('0000')
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 업무매뉴얼
async function selectMakeIebMetaTemp(startDt, endDt) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      /*
      `
      select 
        A.assz_unfc_id as doc_id
        , trim( A.assz_cfbo_idnt_id)  as doc_nm
        , A.assz_cfbo_idnt_id as ori_doc_key 
        , A.flsz_vl as file_size
        , 'pdf' as file_type     
        , (select replace(max(Z.url_adr),CHR(13),'') from       tb_uda_uai003m Z where Z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as url_adr
        ,  A.assz_pcsn_tcd as pr_gubun --지식샘 전체삭제후 신규 프로세스
        , (select to_char(min(z.rgsn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai003m Z where z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as rgsn_ts
        , (select to_char(max(z.amnn_ts),'YYYY-MM-DD HH24:MI:SS') from  tb_uda_uai003m Z where z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as amnn_ts
        , 'N' as att_file_yn
        , 0 as att_file_seq
        , (select max(Z.conn_ttl_nm) from tb_uda_uai003m Z where Z.mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id) as link_file_nm       
      from tb_uda_uai000m A
      where 1=1                 
      and A.eror_vl = '0003'
      and A.assz_orgn_sys_cd_con = 'IEMIEB'       
      and (A.amnn_ts >= $1 and A.amnn_ts < $2)       
      `,*/
      `
      select 
        A.assz_unfc_id as doc_id
        , trim( A.assz_cfbo_idnt_id)  as doc_nm
        , A.assz_cfbo_idnt_id as ori_doc_key 
        , A.flsz_vl as file_size
        , 'pdf' as file_type     
        , (select replace(max(Z.url_adr),CHR(13),'') from tb_uda_uai803l Z where Z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as url_adr
        , 'C' as pr_gubun --지식샘 전체삭제후 신규 프로세스
        , (select to_char(min(z.rgsn_ts),'YYYY-MM-DD HH24:MI:SS') from tb_uda_uai803l Z where z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as rgsn_ts
        , (select to_char(max(z.amnn_ts),'YYYY-MM-DD HH24:MI:SS') from tb_uda_uai803l Z where z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id)  as amnn_ts
        , 'N' as att_file_yn
        , 0 as att_file_seq
        , (select max(Z.conn_ttl_nm) from tb_uda_uai803l Z where Z.assz_mnl_id = A.assz_cfbo_idnt_id and Z.assz_btch_acmp_id = A.assz_btch_acmp_id) as link_file_nm       
      from tb_uda_uai000m A
      join tb_uda_uai003m B on (A.assz_unfc_id = B.assz_unfc_id )
      where 1=1                 
      and A.eror_vl = '0003'
      and A.assz_unfc_id like 'UDAIEMIEB'||'%'
      and A.assz_pcsn_tcd != 'D'
      and (to_char(B.amnn_ts,'YYYYMMDD') >= replace($1,'-','') and to_char(B.amnn_ts,'YYYYMMDD') < replace($2,'-','')) 
      `,
      [startDt, endDt]
    );
    return result;
    //return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

/**
 * 업무매뉴얼 년도별
 * @param {} assz_btch_acmp_id
 * @param {*} basDt
 * @returns
 */
async function selectMetaDocNmIebRange(startDt, endDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      /*
      `
        select
                            '/data/bdpetl/send/gai/gai/ieb/'|| TA.base_ymd || '/' ||TA.file_nm as file_nm
                ,'/data/bdpetl/send/gai/gai/ieb/'|| TA.base_ymd || '/' || replace(TA.file_nm,'.pdf','.json') as json_nm        
          ,'/data/bdpetl/send/gai/gai/ieb/'|| TA.base_ymd || '/' || TA.assz_unfc_id || '.pdf' as new_file_nm
          ,'/data/bdpetl/send/gai/gai/ieb/'|| TA.base_ymd || '/' || TA.assz_unfc_id || '.json' as new_json_nm        
        from tb_uda_uai000m TA
        where TA.eror_vl in ('0003')
        and assz_orgn_sys_cd_con = 'IEMIEB'       
        and (TA.amnn_ts >= $1 and TA.amnn_ts < $2)        
    `,*/
      /* `
        select
          '/data/bdpetl/send/gai/gai/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/' ||A.assz_unfc_id||'.pdf' as file_nm
          ,'/data/bdpetl/send/gai/gai/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/' ||A.assz_unfc_id||'.json'  as json_nm        
          ,'/data/bdpetl/send/gai/gai/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/' ||A.assz_unfc_id ||'.pdf' as new_file_nm
          ,'/data/bdpetl/send/gai/gai/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/' ||A.assz_unfc_id ||'.json' as new_json_nm       
        from tb_uda_uai000m A
        join tb_uda_uai003m B on (A.assz_unfc_id = B.assz_unfc_id )        
        where A.eror_vl in ('0003')
        and A.assz_unfc_id like 'UDAIEMIEB'||'%'       
        and A.assz_pcsn_tcd != 'D'
        and (to_char(B.amnn_ts,'YYYYMMDD') >= replace($1,'-','') and to_char(B.amnn_ts,'YYYYMMDD') < replace($2,'-','')) 
    `,*/
      `
        select
          '/data/asset/iem/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/originpdf/' ||A.assz_unfc_id||'.pdf' as file_nm
          ,'/data/asset/iem/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/json/' ||A.assz_unfc_id||'.json'  as json_nm        
          ,'/data/asset/iem/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/originpdf/' ||A.assz_unfc_id ||'.pdf' as new_file_nm
          ,'/data/asset/iem/ieb/'|| substr(trim(A.assz_btch_acmp_id),1,8) || '/json/' ||A.assz_unfc_id ||'.json' as new_json_nm  
        from tb_uda_uai000m A
        join tb_uda_uai003m B on (A.assz_unfc_id = B.assz_unfc_id )        
        where A.eror_vl in ('0003')
        and A.assz_unfc_id like 'UDAIEMIEB'||'%'       
        and A.assz_pcsn_tcd != 'D'
        and (to_char(B.amnn_ts,'YYYYMMDD') >= replace($1,'-','') and to_char(B.amnn_ts,'YYYYMMDD') < replace($2,'-','')) 
    `,
      [startDt, endDt]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *  기준일자 마지막 배치아이디 가져오기
 */
async function selectLastBatchIdByBasdt(basDt, systemName) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
                          assz_btch_acmp_id
        from tb_uda_uai000m TA
        where base_ymd = $1
        and assz_orgn_sys_cd_con = $2
    `,
      [basDt, systemName]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 *  원장에서 최근(MAX) 배치아이디 가져오기
 */
async function getMaxBatchId(systemName) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
                            max(assz_btch_acmp_id) as assz_btch_acmp_id
        from tb_uda_uai000m
        where assz_unfc_id like 'UDA'||$1||'%'
    `,
      [systemName]
    );
    return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
    pool.end();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  selectMakeWptMeta,
  selectMakeKmsMeta,
  selectMakeKmsMetaRange,
  selectMakeIebMeta,
  selectMakeIeaMeta,
  selectMakeIeaMetaRange,
  selectMakeOchMeta,
  updateUai01,
  updateUai02,
  updateUai20,
  updateUai22,
  updateUaiDel22,
  dbEnd,
  selectMakeWptMeta2,
  selectMakeCsmMeta,
  selectMakeCsmMetaRange,
  selectMakeEpnMeta,
  selectMakeEpnMetaRange,
  selectMetaDocNmOch,
  selectMakeWptMetaTemp,
  selectMakeIebMetaTemp,
  selectMetaDocNmIebRange,
  selectLastBatchIdByBasdt,
  selectMakeIebMetaByBaseYmd,
  selectMakeIisMeta,
  selectMakeIisMetaRange,
  getMaxBatchId,
};
