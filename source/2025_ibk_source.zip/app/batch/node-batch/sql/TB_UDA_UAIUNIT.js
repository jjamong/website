const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

// 메인메타 성공(HTML생성된 것만) 조회
async function aikkmsSelectMetaSuccess() {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
          *,
          substring(assz_btch_acmp_id, 0, 9) as base_dt
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b
          on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
        and a.eror_vl in ('0011', '0012') -- HTML생성한 것만(지식샘-질문답변형, 지식샘-소제목형)
        -- and substring(a.assz_btch_acmp_id, 0, 9) = '20250913'
        -- and a.assz_unfc_id = 'UDAAIKKMS0000001294'
      `,
      []
    );
    return result;
  } finally {
    client.release();
  }
}


/**
 * TB_DOCUMNET 에 머지하는 쿼리
 * @param {*} pool
 * @param {*} assz_btch_acmp_id
 * @returns
 */
async function mergeDocument() {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        WITH upsert AS(
          INSERT INTO tb_document (
            document_id
            , document_name
            , original_doc_type
            , source_system
            , classification
            , registration_type
            , registered_by
            , registered_branch
            , registered_at
            , assetization_status
            , assetized_at
            , updated_at
            , assz_cfbo_idnt_id
            , chunked_file_path
          )
        SELECT doc.assz_unfc_id AS document_id
          , doc.document_name
          , doc.original_doc_type
          , doc.assz_orgn_sys_cd_con AS source_system
          , doc.assz_dcmn_clsf_id AS classification
          , doc.registration_type AS registration_type
          , CASE WHEN doc.orgn_data_rgsr_id IS NULL OR doc.orgn_data_rgsr_id = '' THEN NULL
        ELSE LPAD(doc.orgn_data_rgsr_id, 6, '0')
        END                                                                                                     AS registered_by
          , registered_branch
          , doc.amnn_ts::timestamp(0)                            AS registered_at
          , assetization_status
          , doc.uda_sys_lsmd_ts::timestamp(0)                    AS assetized_at
          , null                                                                                                        AS updated_at
          , assz_cfbo_idnt_id
          , chunked_file_path
        FROM (
          -- 업무포탈(시행문)
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSWPT'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd                                                    AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , b.assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
            JOIN tb_uda_uai001m b /* UDA시행문메타기본 */
              ON a.assz_unfc_id = b.assz_unfc_id
            LEFT OUTER JOIN tb_uda_uai101m c
              ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1
                
          UNION ALL

          -- 상품플라자
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSPLZ'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd                                                    AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , ''                                                                AS assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/epnt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
          JOIN tb_uda_uai071m b /* UDA업무포탈상품설명서메타기본 */ 
            ON a.assz_unfc_id = b.assz_unfc_id /* PLZ EPN 구분값 조건 추가 */
            AND a.assz_unfc_id LIKE '%KMSPLZ%' /* 임시 */
          LEFT OUTER JOIN tb_uda_uai101m c
            ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 상품설명서
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSEPN'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd                                                    AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , ''                                                                AS assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/epnt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
            JOIN tb_uda_uai071m b /* UDA업무포탈상품설명서메타기본 */ 
              ON a.assz_unfc_id = b.assz_unfc_id /* PLZ EPN 구분값 조건 추가 */
              AND a.assz_unfc_id LIKE '%KMSEPN%' /* 임시 */
            LEFT OUTER JOIN tb_uda_uai101m c
              ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1
          
          UNION ALL

          -- FAQ
          SELECT a.assz_unfc_id
              , a.assz_cfbo_idnt_id                 AS document_name
              , 'ETC'                            AS original_doc_type
              , 'CHBOCH'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , b.orgn_data_rgsr_id
              , c.trth_work_brcd                                        AS registered_branch
              , b.amnn_ts
              , a.uda_sys_lsmd_ts
              , ''                                                              AS assz_cfbo_idnt_id
              , '' as chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai007m b /* UDA챗봇FAQ메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
                LEFT OUTER JOIN tb_uda_uaie01m c
                  ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1
          
          UNION ALL

          -- 카드몰
          SELECT a.assz_unfc_id
              , b.conn_ttl_nm                    AS document_name
              , CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                      ELSE 'ETC'
                  END                             AS original_doc_type
              , 'CSMCSM'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , b.orgn_data_rgsr_id
              , c.trth_work_brcd                                        AS registered_branch
              , b.amnn_ts
              , a.uda_sys_lsmd_ts
              , ''                                                              AS assz_cfbo_idnt_id
              , '/data/asset/csm/csm/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai072m b /* UDA카드상품설명서메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
                LEFT OUTER JOIN tb_uda_uaie01m c
                  ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1

          UNION ALL
    
          -- 지식샘
          SELECT a.assz_unfc_id
            , CASE WHEN b.atch_key_vl != '' THEN SUBSTRING(b.atch_nm from '^(.*)\.[^\.]+$')
                    ELSE b.conn_ttl_nm 
                END                             AS document_name
            , CASE WHEN b.file_nm IS NULL OR b.file_nm = '' THEN 'HTML'
                  ELSE CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                            ELSE 'ETC'
                        END 
              END                             AS original_doc_type
            , 'AIKKMS'                         AS assz_orgn_sys_cd_con
            , (REGEXP_SPLIT_TO_ARRAY(b.assz_dcmn_clsf_id, '/'))[
                ARRAY_LENGTH(REGEXP_SPLIT_TO_ARRAY(b.assz_dcmn_clsf_id, '/'), 1)
            ]                                AS assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd                                  AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , ''                                                                AS assz_cfbo_idnt_id
            , '/data/asset/aik/kms/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai005m b /* UDA지식샘메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002', '0013', '0014')
          -- and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 펀드
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                         AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'IISIIS'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd                                  AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , ''                                                                AS assz_cfbo_idnt_id
            , '/data/asset/iis/iis/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai074m b /* UDA펀드투자설명서메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1

          UNION ALL
          
          -- 내규
          SELECT a.assz_unfc_id
              , b.conn_ttl_nm                    AS document_name
              , 'HWP'                            AS original_doc_type
              , 'IEMIEA'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , ''                               AS orgn_data_rgsr_id
              , ''                                                              AS registered_branch
              , NULL                             AS amnn_ts
              , a.uda_sys_lsmd_ts
              , ''                                                              AS assz_cfbo_idnt_id
              , '/data/asset/iem/iea/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai004m b /* UDA내규메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 업무메뉴얼
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'IEMIEB'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd                                  AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , ''                                                                AS assz_cfbo_idnt_id
            , '/data/asset/iem/ieb/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai003m b /* UDA업무매뉴얼메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          -- and a.assz_btch_acmp_id = $1

        ) AS doc
        LEFT OUTER JOIN tb_uda_uaie01m emp 
            ON LPAD(doc.orgn_data_rgsr_id, 6, '0') = emp.emn
        ON CONFLICT (document_id, source_system)
        DO UPDATE 
        SET 
            document_name = EXCLUDED.document_name
          , original_doc_type = EXCLUDED.original_doc_type
          , classification = EXCLUDED.classification
          , registration_type = EXCLUDED.registration_type
          , registered_by =     EXCLUDED.registered_by
          , registered_branch = EXCLUDED.registered_branch
          , registered_at =     EXCLUDED.registered_at
          , assetization_status =       EXCLUDED.assetization_status
          , assetized_at        =       EXCLUDED.assetized_at
          , assz_cfbo_idnt_id = EXCLUDED.assz_cfbo_idnt_id
          , chunked_file_path = EXCLUDED.chunked_file_path
          , del_yn = EXCLUDED.del_yn
              RETURNING xmin
      )
      select count(*) FILTER (where xmin = 0) AS inserted_count,
            count(*) FILTER (where xmin <> 0) AS updated_count
      from upsert; 
      `,
      []
    );

    const { inserted_count, updated_count } = result.rows[0];
    writeLog(
      `(#)UPSERT RESULT----------------------------------`
    );
    writeLog(`(#)INSERT COUNT : ${inserted_count}`);
    writeLog(`(#)UPDATE COUNT : ${updated_count}`);
    writeLog(`(#)---------------------------------------------------------`);
    return result;
  } finally {
    client.release();
  }
}

async function resetOriginResultSelectMetaSuccess(
  sysName,
  eror_vl
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  try {
    let sql = `
      select
          TA.assz_unfc_id,
          TA.uda_sys_lsmd_id,
                TA.assz_cfbo_idnt_id
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = ANY($2) -- 성공 건
          and TA.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $1
      `;
    const result = await client.query(sql, [
      sysName,
      erorVlIn,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장 마스터, 메타 조회 - 수명주기
async function selectMetaSuccessLifecycle(sysName, eror_vl) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  // 성공건 in에 배열로 넣도록 배열 설정
  const erorVlIn = eror_vl.split(",").map((v) => v.trim());

  // 수명주기에 필요한 등록자부서ID, 등록자ID, 등록일시
  let sqlLifecycleColumn = "";
  if (sysName == "KMSWPT" || sysName == "KMSEPN" || sysName == "KMSPLZ") {
    sqlLifecycleColumn = `
      TB.rgsr_dept_id,
      TB.orgn_data_rgsr_id,
      TB.rgsn_ts,
    `;
  } else if (
    sysName == "CSMCSM" ||
    sysName == "IEMIEB" ||
    sysName == "IISIIS" ||
    sysName == "AIKKMS"
  ) {
    sqlLifecycleColumn = `
      '' AS rgsr_dept_id,
      TB.orgn_data_rgsr_id,
      TB.rgsn_ts,
    `;
  } else if (sysName == "IEMIEA") {
    sqlLifecycleColumn = `
      '' AS rgsr_dept_id,
      '' AS orgn_data_rgsr_id,
      '' AS rgsn_ts,
    `;
  }

  try {
    let sql = `
      select
          TA.assz_unfc_id,
          TA.uda_sys_lsmd_id,
          ${sqlLifecycleColumn}
          TA.assz_pcsn_tcd
      from tb_uda_uai000m TA
    `;
    if (sysName == "KMSWPT") {
      sql += `
        join tb_uda_uai001m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSEPN") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "CSMCSM") {
      sql += `
        join tb_uda_uai072m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEB") {
      sql += `
        join tb_uda_uai003m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IISIIS") {
      sql += `
        join tb_uda_uai074m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "IEMIEA") {
      sql += `
        join tb_uda_uai004m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    } else if (sysName == "AIKKMS") {
      sql += `
        join tb_uda_uai005m TB on TA.assz_unfc_id = TB.assz_unfc_id
      `;
    }
    sql += `
        where 1=1
          and TA.eror_vl = ANY($2) -- 성공 건
          and SUBSTRING(TA.assz_unfc_id, 4, 6) = $1
      `;
    const result = await client.query(sql, [
      sysName,
      erorVlIn,
    ]);
    return result;
  } finally {
    client.release();
    pool.end();
  }
};


async function dbEnd() {
  pool.end();
}

module.exports = {
  aikkmsSelectMetaSuccess,
  resetOriginResultSelectMetaSuccess,
  mergeDocument,
  selectMetaSuccessLifecycle,
  dbEnd,
};
