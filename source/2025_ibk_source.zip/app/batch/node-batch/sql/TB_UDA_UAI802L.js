const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  rgsn_ts,
  atch_yn,
  atch_sqn,
  atch_nm,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO TB_UDA_UAI802L(
          assz_btch_acmp_id
        , assz_trms_tgt_sys_dcd
        , assz_btch_tcd
        , assz_meta_pcsn_sqn
        , assz_cfbo_idnt_id
        , assz_unfc_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , rgsn_ts
        , atch_yn
        , atch_sqn
        , atch_nm
        , assz_pcsn_file_path_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts
      )
		  VALUES (
          $1
        , '01'
        , '01'
        , (
           SELECT coalesce(max(assz_meta_pcsn_sqn)+1,1)
					 FROM TB_UDA_UAI802L
					 WHERE assz_btch_acmp_id =$1::VARCHAR
           )
        , $2
        , $3
        , $4
        , $5
        , $6
        , TO_TIMESTAMP($7,'YYYYMMDDHH24MISS')
        , $8
        , $9
        , $10
        , $11
        , $12
        , current_timestamp
      );
		  `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        rgsn_ts,
        atch_yn,
        atch_sqn,
        atch_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  dbEnd,
};
