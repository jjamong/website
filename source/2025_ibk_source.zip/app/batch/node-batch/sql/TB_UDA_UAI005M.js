const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

// 메인메타 성공(HTML생성된 것만) 조회
async function selectMetaSuccess(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
          *
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b
          on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
        and b.assz_orgn_pcsn_dcd != 'D' -- 삭제된 건 제외
        and a.eror_vl in ('0011', '0012') -- HTML생성한 것만(지식샘-질문답변형, 지식샘-소제목형)
        and a.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 원장메타 저장
async function insertMeta(
  assz_unfc_id, // 자산화통합ID
  assz_cfbo_idnt_id, // 자산화원천식별ID
  assz_cnfg_id, // 자산화구성ID
  assz_sbtl_id, // 자산화부제ID
  assz_sbtl_con, // 자산화부제내용
  url_adr, // URL주소
  qstn_id, // 질문ID
  assz_qstn_con, // 자산화질문내용
  rply_id, // 답변ID
  assz_rply_con, // 자산화답변내용
  orgn_data_rgsr_id, // 원천데이터등록자ID
  rgsn_ts, // 등록일시
  amnn_ts, // 수정일시
  assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
  assz_dcmn_clsf_id, // 자산화문서분류ID
  conn_ttl_nm, // 콘텐츠제목명
  tab_nm, // 탭명
  sb_ttl_nm, // 부제목명
  file_yn, // 파일여부
  file_nm, // 파일명
  atch_key_vl, // 첨부파일KEY값
  apnd_file_rgsn_ts, // 첨부파일등록일시
  atch_yn, // 첨부파일여부
  atch_sqn, // 첨부파일순번
  atch_nm, // 첨부파일명
  assz_orcp_file_path_nm, // 자산화원본파일경로명
  uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
      insert into tb_uda_uai005m (
        assz_unfc_id,
        assz_cfbo_idnt_id,
        assz_cnfg_id,
        assz_sbtl_id,
        assz_sbtl_con,
        url_adr,
        qstn_id,
        assz_qstn_con,
        rply_id,
        assz_rply_con,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        tab_nm,
        sb_ttl_nm,
        file_yn,
        file_nm,
        atch_key_vl,
        apnd_file_rgsn_ts,
        atch_yn,
        atch_sqn,
        atch_nm,
        assz_orcp_file_path_nm,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1, -- assz_unfc_id
        $2, -- assz_cfbo_idnt_id
        $3, -- assz_cnfg_id
        $4, -- assz_sbtl_id
        $5, -- assz_sbtl_con
        $6, -- url_adr
        $7, -- qstn_id
        $8, -- assz_qstn_con
        $9, -- rply_id
        $10, -- assz_rply_con
        $11, -- orgn_data_rgsr_id
        to_timestamp($12,'yyyymmddhh24miss'), -- rgsn_ts
        to_timestamp($13,'yyyymmddhh24miss'), -- amnn_ts
        $14, -- assz_orgn_pcsn_dcd
        $15, -- assz_dcmn_clsf_id
        $16, -- conn_ttl_nm
        $17, -- tab_nm
        $18, -- sb_ttl_nm
        $19, -- file_yn
        $20, -- file_nm
        $21, -- atch_key_vl
        to_timestamp($22,'yyyymmddhh24miss'), -- apnd_file_rgsn_ts
        $23, -- atch_yn
        $24, -- atch_sqn
        $25, -- atch_nm
        $26, -- assz_orcp_file_path_nm
        $27, -- uda_sys_lsmd_id
        current_timestamp -- uda_sys_lsmd_ts
      );
		  `,
      [
        assz_unfc_id, // 자산화통합ID
        assz_cfbo_idnt_id, // 자산화원천식별ID
        assz_cnfg_id, // 자산화구성ID
        assz_sbtl_id, // 자산화부제ID
        assz_sbtl_con, // 자산화부제내용
        url_adr, // URL주소
        qstn_id, // 질문ID
        assz_qstn_con, // 자산화질문내용
        rply_id, // 답변ID
        assz_rply_con, // 자산화답변내용
        orgn_data_rgsr_id, // 원천데이터등록자ID
        rgsn_ts, // 등록일시
        amnn_ts, // 수정일시
        assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
        assz_dcmn_clsf_id, // 자산화문서분류ID
        conn_ttl_nm, // 콘텐츠제목명
        tab_nm, // 탭명
        sb_ttl_nm, // 부제목명
        file_yn, // 파일여부
        file_nm, // 파일명
        atch_key_vl, // 첨부파일KEY값
        apnd_file_rgsn_ts, // 첨부파일등록일시
        atch_yn, // 첨부파일여부
        atch_sqn, // 첨부파일순번
        atch_nm, // 첨부파일명
        assz_orcp_file_path_nm, // 자산화원본파일경로명
        uda_sys_lsmd_id, // 비정형데이터자산화시스템최종변경ID
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

// 원장메타 수정
async function updateMeta(
  assz_unfc_id,
  assz_sbtl_con, // 자산화부제내용
  url_adr, // URL주소
  assz_qstn_con, // 자산화질문내용
  assz_rply_con, // 자산화답변내용
  orgn_data_rgsr_id, // 원천데이터등록자ID
  rgsn_ts, // 등록일시
  amnn_ts, // 수정일시
  conn_ttl_nm, // 콘텐츠제목명
  tab_nm, // 탭명
  sb_ttl_nm, // 부제목명
  file_yn, // 파일여부
  assz_orcp_file_path_nm // 자산화처리파일경로명
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai005m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_orgn_pcsn_dcd = 'U'
          , assz_sbtl_con = $2
          , url_adr = $3
          , assz_qstn_con = $4
          , assz_rply_con = $5
          , orgn_data_rgsr_id = $6
          , rgsn_ts = to_timestamp($7,'yyyymmddhh24miss')
          , amnn_ts = to_timestamp($8,'yyyymmddhh24miss')
          , conn_ttl_nm = $9
          , tab_nm = $10
          , sb_ttl_nm = $11
          , file_yn = $12
          , assz_orcp_file_path_nm = $13
        where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        assz_sbtl_con, // 자산화부제내용
        url_adr, // URL주소
        assz_qstn_con, // 자산화질문내용
        assz_rply_con, // 자산화답변내용
        orgn_data_rgsr_id, // 원천데이터등록자ID
        rgsn_ts, // 등록일시
        amnn_ts, // 수정일시
        conn_ttl_nm, // 콘텐츠제목명
        tab_nm, // 탭명
        sb_ttl_nm, // 부제목명
        file_yn, // 파일여부
        assz_orcp_file_path_nm, // 자산화처리파일경로명
      ]
    );
  } finally {
    client.release();
  }
}

// 원장메타 삭제
async function deleteMeta(assz_unfc_id) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai005m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_orgn_pcsn_dcd = 'D'
        where assz_unfc_id = $1
      `,
      [assz_unfc_id]
    );
  } finally {
    client.release();
  }
}

// 메타로그 저장
async function insertMetaLog(
  assz_btch_acmp_id, // 자산화배치수행ID
  assz_cfbo_idnt_id, // 자산화원천식별ID
  assz_unfc_id, // 자산화통합ID
  assz_cnfg_id, // 자산화구성ID
  assz_sbtl_id, // 자산화부제ID
  assz_sbtl_con, // 자산화부제내용
  url_adr, // URL주소
  qstn_id, // 질문ID
  assz_qstn_con, // 자산화질문내용
  rply_id, // 답변ID
  assz_rply_con, // 자산화답변내용
  orgn_data_rgsr_id, // 원천데이터등록자ID
  rgsn_ts, // 등록일시
  amnn_ts, // 수정일시
  assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
  assz_dcmn_clsf_id, // 자산화문서분류ID
  conn_ttl_nm, // 콘텐츠제목명
  tab_nm, // 탭명
  sb_ttl_nm, // 부제목명
  file_yn, // 파일여부
  file_nm, // 파일명
  atch_key_vl, // 첨부파일KEY값
  apnd_file_rgsn_ts, // 첨부파일등록일시
  atch_yn, // 첨부파일여부
  atch_sqn, // 첨부파일순번
  atch_nm, // 첨부파일명
  assz_pcsn_file_path_nm, // 자산화처리파일경로명
  uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
      INSERT INTO TB_UDA_UAI805L (
        assz_btch_acmp_id,
        assz_trms_tgt_sys_dcd,
        assz_btch_tcd,
        assz_meta_pcsn_sqn,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        assz_cnfg_id,
        assz_sbtl_id,
        assz_sbtl_con,
        url_adr,
        qstn_id,
        assz_qstn_con,
        rply_id,
        assz_rply_con,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        tab_nm,
        sb_ttl_nm,
        file_yn,
        file_nm,
        atch_key_vl,
        apnd_file_rgsn_ts,
        atch_yn,
        atch_sqn,
        atch_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1, -- assz_btch_acmp_id
        '01',
        '01',
        (select coalesce(max(assz_meta_pcsn_sqn)+1,1)
          from TB_UDA_UAI805L
          where assz_btch_acmp_id =$1::VARCHAR), -- assz_meta_pcsn_sqn, -- assz_meta_pcsn_sqn
        $2, -- assz_cfbo_idnt_id
        $3, -- assz_unfc_id
        $4, -- assz_cnfg_id
        $5, -- assz_sbtl_id
        $6, -- assz_sbtl_con
        $7, -- url_adr
        $8, -- qstn_id
        $9, -- assz_qstn_con
        $10, -- rply_id
        $11, -- assz_rply_con
        $12, -- orgn_data_rgsr_id
        to_timestamp($13,'yyyymmddhh24miss'), -- rgsn_ts
        to_timestamp($14,'yyyymmddhh24miss'), -- amnn_ts
        $15, -- assz_orgn_pcsn_dcd
        $16, -- assz_dcmn_clsf_id
        $17, -- conn_ttl_nm
        $18, -- tab_nm
        $19, -- sb_ttl_nm
        $20, -- file_yn
        $21, -- file_nm
        $22, -- atch_key_vl
        to_timestamp($23,'yyyymmddhh24miss'), -- apnd_file_rgsn_ts
        $24, -- atch_yn
        $25, -- atch_sqn
        $26, -- atch_nm
        $27, -- assz_pcsn_file_path_nm
        $28, -- uda_sys_lsmd_id
        current_timestamp -- uda_sys_lsmd_ts
      )
    `,
      [
        assz_btch_acmp_id, // 자산화배치수행ID
        assz_cfbo_idnt_id, // 자산화원천식별ID
        assz_unfc_id, // 자산화통합ID
        assz_cnfg_id, // 자산화구성ID
        assz_sbtl_id, // 자산화부제ID
        assz_sbtl_con, // 자산화부제내용
        url_adr, // URL주소
        qstn_id, // 질문ID
        assz_qstn_con, // 자산화질문내용
        rply_id, // 답변ID
        assz_rply_con, // 자산화답변내용
        orgn_data_rgsr_id, // 원천데이터등록자ID
        rgsn_ts, // 등록일시
        amnn_ts, // 수정일시
        assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
        assz_dcmn_clsf_id, // 자산화문서분류ID
        conn_ttl_nm, // 콘텐츠제목명
        tab_nm, // 탭명
        sb_ttl_nm, // 부제목명
        file_yn, // 파일여부
        file_nm, // 파일명
        atch_key_vl, // 첨부파일KEY값
        apnd_file_rgsn_ts, // 첨부파일등록일시
        atch_yn, // 첨부파일여부
        atch_sqn, // 첨부파일순번
        atch_nm, // 첨부파일명
        assz_pcsn_file_path_nm, // 자산화처리파일경로명
        uda_sys_lsmd_id, // 비정형데이터자산화시스템최종변경ID
      ]
    );
  } finally {
    client.release();
  }
}

// 추가정보메타의 원천식별ID로 원장의 처리유형코드 가져오기
async function selectMetaMasterTcd(assz_cfbo_idnt_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select 
          a.assz_pcsn_tcd,
          a.assz_cfbo_idnt_id
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b on a.assz_unfc_id = b.assz_unfc_id 
        where 1=1
        and SUBSTRING(a.assz_unfc_id, 4, 6) = 'AIKKMS'
        and b.atch_key_vl = '' -- 첨부파일이 아닌 html파일만
        and split_part(a.assz_cfbo_idnt_id, '_', 1) = $1
        limit 1 
    `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 추가정보메타 조회
async function selectAddInfo(assz_cfbo_idnt_id, atch_key) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select 
          a.assz_btch_acmp_id
          ,a.assz_unfc_id
          ,a.assz_pcsn_tcd
          ,b.atch_sqn
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
		    and SUBSTRING(a.assz_unfc_id, 4, 6) = 'AIKKMS'
        and split_part(a.assz_cfbo_idnt_id, '_', 1) = $1
        and split_part(a.assz_cfbo_idnt_id, '_', 2) = $2
    `,
      [assz_cfbo_idnt_id, atch_key]
    );
    return result;
  } finally {
    client.release();
  }
}

// 추가정보메타 성공(HTML제외) 조회
async function selectAddInfoMetaSuccess(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
          *
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b
          on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
          and a.eror_vl = '0000'-- HTML제외한 것만(0000 첨부파일)
          and a.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 추가정보메타 성공 단건 조회
async function selectAddInfoMetaSuccessOne(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
          a.assz_btch_acmp_id
          ,a.assz_unfc_id
          ,regexp_replace(b.atch_nm,'\\.[^.]*$','') as dcmn_nm
          ,b.apnd_file_rgsn_ts
        from tb_uda_uai000m a
        inner join tb_uda_uai005m b
          on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
          and a.eror_vl = '0000'-- HTML제외한 것만(0000 첨부파일)
          and a.assz_btch_acmp_id = $1
          and a.assz_unfc_id = $2
      `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

// 추가정보메타 삭제 (원천식별키와 매칭된 전체 파일)
async function deleteAddInfoMeta(assz_cfbo_idnt_id) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai005m
          set uda_sys_lsmd_ts = current_timestamp
              ,assz_orgn_pcsn_dcd = 'D'
        where 1=1
        and split_part(assz_cfbo_idnt_id, '_', 1) = $1
        and atch_sqn != '0'
      `,
      [assz_cfbo_idnt_id]
    );
  } finally {
    client.release();
  }
}

// 원장추가정보메타 수정
async function updateAddInfoMeta(
  assz_unfc_id,
  file_nm, // 파일명
  atch_key_vl, // 첨부파일KEY값
  apnd_file_rgsn_ts, // 첨부파일등록일시
  atch_yn, // 첨부파일여부
  atch_sqn, // 첨부파일순번
  atch_nm, // 첨부파일명
  assz_orcp_file_path_nm // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai005m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_orgn_pcsn_dcd = 'U'
          , file_nm = $2
          , atch_key_vl = $3
          , apnd_file_rgsn_ts = to_timestamp($4,'yyyymmddhh24miss')
          , atch_yn = $5
          , atch_sqn = $6
          , atch_nm = $7
          , assz_orcp_file_path_nm = $8
        where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        file_nm, // 파일명
        atch_key_vl, // 첨부파일KEY값
        apnd_file_rgsn_ts, // 첨부파일등록일시
        atch_yn, // 첨부파일여부
        atch_sqn, // 첨부파일순번
        atch_nm, // 첨부파일명
        assz_orcp_file_path_nm, // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
      ]
    );
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  selectMetaSuccess,
  insertMeta,
  updateMeta,
  deleteMeta,
  insertMetaLog,
  selectMetaMasterTcd,
  selectAddInfo,
  selectAddInfoMetaSuccess,
  selectAddInfoMetaSuccessOne,
  updateAddInfoMeta,
  deleteAddInfoMeta,
  dbEnd,
};
