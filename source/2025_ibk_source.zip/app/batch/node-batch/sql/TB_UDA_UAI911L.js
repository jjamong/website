const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function selectAsszCfboIdntId(assz_btch_acmp_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      select
        group_id
        ,assz_rslt_dtl_sqn
        ,assz_pcsn_file_path_nm
        ,assz_unfc_id
        ,file_sqn
      from (
        select
          (select assz_cfbo_idnt_id from TB_UDA_UAI910L where assz_btch_acmp_id = TA.assz_btch_acmp_id and assz_unfc_id = TA.assz_unfc_id ) as group_id,
          TA.assz_rslt_dtl_sqn,
          TA.assz_pcsn_file_path_nm
          ,TA.assz_unfc_id
          ,(select file_sqn from tb_uda_uai803l where assz_btch_acmp_id = TA.assz_btch_acmp_id and assz_unfc_id = TA.assz_unfc_id ) as file_sqn    
        from
          TB_UDA_UAI911L TA
        where
          assz_btch_acmp_id = $1
      ) M    
      order by M.group_id, M.file_sqn asc, M.assz_rslt_dtl_sqn asc    
    `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function insertAstDtl(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_pcsn_rslt_tcd,
  assz_con,
  assz_page_no,
  assz_no,
  assz_pcsn_file_path_nm,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO TB_UDA_UAI911L (
        assz_btch_acmp_id,
        assz_trms_tgt_sys_dcd,
        assz_btch_tcd, 
        assz_meta_pcsn_sqn,
        assz_rslt_dtl_sqn,
        assz_unfc_id,
        assz_pcsn_rslt_tcd,
        assz_con,
        assz_page_no,
        assz_no,
        assz_pcsn_file_path_nm,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1::varchar, -- assz_btch_acmp_id,
        '01',
        '01',
        (
        select coalesce(max(assz_meta_pcsn_sqn),1) from TB_UDA_UAI901L where assz_btch_acmp_id=$1::varchar and assz_unfc_id = $2::varchar
        ),
        (select coalesce(max(assz_rslt_dtl_sqn)+1,1) from TB_UDA_UAI911L where assz_btch_acmp_id =$1::varchar and assz_unfc_id = $2::varchar),
        $2::varchar, -- assz_unfc_id,
        $3, -- assz_pcsn_rslt_tcd,
        $4, -- assz_con,
        $5, -- assz_page_no,
        $6, -- assz_no,
        $7, -- assz_pcsn_file_path_nm,
        $8, -- acmp_sttg_ts,
        $9, -- acmp_fnsh_ts,
        $10, -- uda_sys_lsmd_id,
        current_timestamp -- uda_sys_lsmd_ts
      )
      RETURNING assz_rslt_dtl_sqn;
    `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_pcsn_rslt_tcd,
        assz_con,
        assz_page_no,
        assz_no,
        assz_pcsn_file_path_nm,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertAstDtl,
  dbEnd,
  selectAsszCfboIdntId,
};
