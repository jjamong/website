const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

// 메타로그 저장
async function insertMeta(
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
      INSERT INTO TB_UDA_UAI004M (
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1, -- assz_unfc_id
        $2, -- assz_cfbo_idnt_id
        $3, -- file_nm
        $4, -- file_sqn
        $5, -- assz_orcp_file_path_nm
        $6, -- orgn_data_rgsr_id
        $7, -- rgsn_ts
        $8, -- amnn_ts
        $9, -- assz_orgn_pcsn_dcd
        $10, -- atch_yn
        $11, -- atch_sqn
        $12, -- assz_dcmn_clsf_id
        $13, -- conn_ttl_nm
        $14, -- uda_sys_lsmd_id
        current_timestamp -- uda_sys_lsmd_ts
      )
		`,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

async function selectMeta02(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, assz_cfbo_idnt_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, conn_ttl_nm, assz_pcsn_file_path_nm, atch_nm, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts
            ,coalesce(conn_ttl_nm,'') as dcmn_nm
        FROM tb_uda_uai004m 
       where assz_btch_acmp_id =$1
         and assz_unfc_id =$2 
       order by assz_btch_acmp_id,file_sqn;
  `,
      [assz_btch_acmp_id, assz_unfc_id]
    );

    return result;
  } finally {
    client.release();
  }
}

// 메타 성공 조회
async function selectMetaSuccess(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select
        *
      from tb_uda_uai004m
      where 1=1
      and eror_vl = '0000'-- 성공 건
      and assz_orgn_pcsn_dcd in ('C', 'U') -- N, D 제외
      and assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 메타 성공, 라인그리기 후 PDF변환 실패한 건만 조회
async function selectDrawLineFailMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select
        *
          from tb_uda_uai000m a
          inner join tb_uda_uai004m b on a.assz_btch_acmp_id = b.assz_btch_acmp_id and a.assz_unfc_id = b.assz_unfc_id
          where 1=1
      and a.assz_orgn_sys_cd_con = 'IEMIEA'
      and a.eror_vl = '0210'
      and a.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertMeta,
  selectMeta02,
  selectMetaSuccess,
  selectDrawLineFailMeta,
  dbEnd,
};
