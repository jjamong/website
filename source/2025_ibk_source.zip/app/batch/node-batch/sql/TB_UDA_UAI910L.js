const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function selectExists(assz_btch_acmp_id, assz_unfc_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
        1
        from TB_UDA_UAI910L
        where assz_btch_acmp_id = $1
        and assz_unfc_id = $2
		`,
      [assz_btch_acmp_id, assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// tb_uda_uai910l 각 원천별 자산화 결과 로그 적재하는 함수
async function insertAst(
  assz_btch_acmp_id,
  assz_unfc_id,
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  dcmn_nm,
  file_nm,
  assz_pcsn_tgt_tcd,
  assz_pcsn_tcd,
  flsz_vl,
  assz_file_type_cd,
  ASSZ_ACS_ATHR_CON,
  assz_src_id,
  assz_pcsn_file_path_nm,
  url_adr,
  cret_ts,
  amnn_ts,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  del_yn,
  del_ymd,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO TB_UDA_UAI910L(assz_btch_acmp_id, assz_trms_tgt_sys_dcd, assz_btch_tcd, assz_meta_pcsn_sqn, assz_unfc_id, assz_orgn_sys_cd_con, assz_cfbo_idnt_id, dcmn_nm, file_nm, assz_pcsn_tgt_tcd, assz_pcsn_tcd, flsz_vl, assz_file_type_cd, ASSZ_ACS_ATHR_CON, assz_src_id, assz_pcsn_file_path_nm, url_adr, cret_ts, amnn_ts, acmp_sttg_ts, acmp_fnsh_ts, del_yn, del_ymd, uda_sys_lsmd_id, uda_sys_lsmd_ts)
      VALUES ($1,'01','01',(
      select coalesce(max(assz_meta_pcsn_sqn),1) from TB_UDA_UAI901L where assz_btch_acmp_id=$1::varchar and assz_unfc_id = $2::varchar
      ),$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,current_timestamp)
		  `,
      [
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_orgn_sys_cd_con,
        assz_cfbo_idnt_id,
        dcmn_nm,
        file_nm,
        assz_pcsn_tgt_tcd,
        assz_pcsn_tcd,
        flsz_vl,
        assz_file_type_cd,
        ASSZ_ACS_ATHR_CON,
        assz_src_id,
        assz_pcsn_file_path_nm,
        url_adr,
        cret_ts,
        amnn_ts,
        acmp_sttg_ts,
        acmp_fnsh_ts,
        del_yn,
        del_ymd,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNm(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      ` 
		select substring(a.file_nm from '^(.*)\\.[^.]+$') as doc_nm
		from TB_UDA_UAI910L a 
		where  a.assz_btch_acmp_id = $1
      and  a.assz_pcsn_tcd in ('C', 'U')
	`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNm2(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      ` 
		select substring(a.file_nm from '^(.*)\\.[^.]+$') as doc_nm
		from TB_UDA_UAI910L a 
		where  a.assz_btch_acmp_id = $1
      and  a.assz_pcsn_tcd in ('C', 'U')
	`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectFilePathNm(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		select a.assz_pcsn_file_path_nm as file_path
    ,a.assz_unfc_id as assz_unfc_id
		from TB_UDA_UAI910L a 
		where  a.assz_btch_acmp_id = $1
      and  a.assz_pcsn_tcd in ('C', 'U')
	`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectFilePathNm02(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
		select a.assz_cfbo_idnt_id as file_nm
               ,a.assz_unfc_id as assz_unfc_id
               ,a.assz_cfbo_idnt_id as assz_cfbo_idnt_id
		from TB_UDA_UAI910L a 
		where  a.assz_btch_acmp_id = $1
          and  a.assz_pcsn_tcd in ('C', 'U')
	      and exists (select 1 from tb_uda_uai003m z where z.grp_id ='B1093'  and  z.assz_unfc_id  = a.assz_unfc_id)
	`,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNmIeb(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        trim(A.assz_cfbo_idnt_id)  as doc_nm,
        trim(A.assz_unfc_id)  as assz_unfc_id
      from tb_uda_uai000m A
      where 1=1 	        
      and A.assz_btch_acmp_id = $1
      and A.eror_vl  = '0003'
      and A.assz_unfc_id like 'UDAIEMIEB'||'%'
      `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function selectMetaDocNmIebByBaseYmd(base_ymd) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        trim(A.assz_cfbo_idnt_id)  as doc_nm,
        trim(A.assz_unfc_id)  as assz_unfc_id
      from tb_uda_uai000m A
      where 1=1 	        
      and A.base_ymd = $1
      and A.eror_vl  = '0003'
      and A.assz_orgn_sys_cd_con = 'IEMIEB'         
      `,
      [base_ymd]
    );

    return result;
  } finally {
    client.release();
  }
}

async function updateErr01(
  assz_btch_acmp_id,
  assz_unfc_id,
  eror_vl,
  ASSZ_EROR_CON
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    UPDATE TB_UDA_UAI910L
      SET  
         eror_vl=coalesce($3,eror_vl)
        ,ASSZ_EROR_CON=coalesce($4,ASSZ_EROR_CON)
      WHERE assz_btch_acmp_id= $1 
      AND assz_unfc_id= $2;
    `,
      [assz_btch_acmp_id, assz_unfc_id, eror_vl, ASSZ_EROR_CON]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  insertAst,
  selectMetaDocNm,
  selectMetaDocNm2,
  selectMetaDocNmIeb,
  selectFilePathNm,
  selectFilePathNm02,
  dbEnd,
  selectExists,
  selectMetaDocNmIebByBaseYmd,
};
