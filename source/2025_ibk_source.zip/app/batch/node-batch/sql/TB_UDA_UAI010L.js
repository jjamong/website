const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertBatchJob(
  acmp_ymd,
  btch_id,
  assz_orgn_sys_cd_con,
  assz_btch_tcd,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  eror_vl,
  assz_eror_con,
  acmp_sttg_ts,
  acmp_fnsh_ts,
  uda_sys_lsmd_id_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
    INSERT INTO tb_uda_uai900m
    (assz_btch_acmp_id, acmp_ymd, btch_id, assz_orgn_sys_cd_con, assz_btch_tcd, assz_btch_pcsn_stg_dcd, assz_btch_pcsn_tcd, eror_vl, assz_eror_con, acmp_sttg_ts, acmp_fnsh_ts, uda_sys_lsmd_id, uda_sys_lsmd_ts)
    VALUES((select  coalesce($1::TEXT||$3 ||lpad((max(substring(assz_btch_acmp_id,15,6)::integer)+1) ::text ,6,'0'), $1::TEXT||$3 ||'000001')
							from tb_uda_uai900m
							where assz_orgn_sys_cd_con =$3
							and   acmp_ymd =$1)
							,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11, Current_timestamp)
		RETURNING assz_btch_acmp_id;
		`,
      [
        acmp_ymd,
        btch_id,
        assz_orgn_sys_cd_con,
        assz_btch_tcd,
        assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd,
        eror_vl,
        assz_eror_con,
        acmp_sttg_ts,
        uda_sys_lsmd_idsh_ts,
        uda_sys_lsmd_id,
      ]
    );
    return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateBatchJob(
  assz_btch_acmp_id,
  assz_btch_tcd,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai010l
			SET assz_btch_tcd= coalesce($2,assz_btch_tcd)
			  , assz_btch_pcsn_stg_dcd= coalesce($3,assz_btch_pcsn_stg_dcd)
			  , assz_btch_pcsn_tcd= coalesce($4,assz_btch_pcsn_tcd)
			  , eror_vl= coalesce($5,eror_vl)
			  , assz_eror_con= coalesce($6,assz_eror_con)
			  , acmp_fnsh_ts=CURRENT_TIMESTAMP
			WHERE assz_btch_acmp_id=$1;
		`,
      [
        assz_btch_acmp_id,
        assz_btch_tcd,
        assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result.rows[0].btch_acmp_id;
  } finally {
    client.release();
  }
}

async function updateBatchRst(assz_btch_acmp_id, eror_vl, ASSZ_EROR_CON) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
			UPDATE tb_uda_uai010l
			SET eror_vl= coalesce($2,eror_vl)
			  , ASSZ_EROR_CON= case when ASSZ_EROR_CON is null then $3
			                      else ASSZ_EROR_CON ||CHR(13)||$3
			                  end
			WHERE assz_btch_acmp_id=$1;
		`,
      [assz_btch_acmp_id, eror_vl, ASSZ_EROR_CON]
    );
    return result;
  } finally {
    client.release();
  }
}
async function dbEnd() {
  pool.end();
}

module.exports = {
  insertBatchJob,
  updateBatchJob,
  updateBatchRst,
  dbEnd,
};
