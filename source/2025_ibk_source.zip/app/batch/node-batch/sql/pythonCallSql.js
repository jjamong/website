const imgLogInsert = require("../sql/TB_UDA_UAI902L"); //업무포탈 첨부파일 메타
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

/*----------------------imgLogInsert insert ----------------------*/
async function fnImgLogInsert(data) {
  // writeLog(
  //   "----------------------------imgLogInsert()시작----------------------------"
  // );
  try {
    let [
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_page_no,
      assz_img_no,
      assz_img_tppo_xcr_vl,
      assz_img_tppo_ycr_vl,
      assz_img_lwen_xcr_vl,
      assz_img_lwen_ycr_vl,
      assz_img_pcsn_acmp_rslt_dcd, //01:IMG, 02:IMG+TEXT (임의로 코드생성)
      eror_vl, //0000 정상 에러는 임의 코드 생성
      ASSZ_EROR_CON,
      acmp_sttg_ts,
      acmp_fnsh_ts,
      assz_img_file_path_nm,
      uda_sys_lsmd_id,
    ] = data.split("^|");

    //파일정보가 없어서 NULL로 처리
    await imgLogInsert.insertImgLog(
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_page_no,
      assz_img_no,
      assz_img_tppo_xcr_vl,
      assz_img_tppo_ycr_vl,
      assz_img_lwen_xcr_vl,
      assz_img_lwen_ycr_vl,
      assz_img_pcsn_acmp_rslt_dcd,
      eror_vl,
      ASSZ_EROR_CON,
      acmp_sttg_ts,
      acmp_fnsh_ts,
      assz_img_file_path_nm,
      uda_sys_lsmd_id
    );
  } catch (err) {
    writeLog(`imgLogInsert:${err.message}`);
  }
  // writeLog(
  //   "----------------------------imgLogInsert()종료----------------------------"
  // );
}

(async () => {
  const clcd = process.argv[2];
  const data = process.argv[3];

  if (clcd == "01") {
    await fnImgLogInsert(data);
    await imgLogInsert.dbEnd();
  } else if (clcd == "99") {
    writeLog(`pdfToImg:${data}`);
  }
})();
