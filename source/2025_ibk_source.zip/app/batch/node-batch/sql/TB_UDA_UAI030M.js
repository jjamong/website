const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

async function insertMeta(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  assz_fmts_base_orgn_idnt_id,
  conn_ttl_nm,
  use_sttg_ymd,
  use_fnsh_ymd,
  sale_info_con,
  assz_dcmn_clsf_con,
  atch_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai871m(
        assz_btch_acmp_id
        , assz_meta_pcsn_sqn
        , assz_trms_tgt_sys_dcd
        , assz_btch_tcd
        , assz_cfbo_idnt_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , assz_fmts_base_orgn_idnt_id
        , conn_ttl_nm
        , use_sttg_ymd
        , use_fnsh_ymd
        , sale_info_con
        , assz_dcmn_clsf_con
        , atch_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts)
      VALUES(
        $1 -- assz_btch_acmp_id
        , '01'
        , '01'
        , (select  coalesce(max(assz_meta_pcsn_sqn)+1,1)
            from tb_uda_uai871m
            where assz_btch_acmp_id = $1::VARCHAR) -- assz_meta_pcsn_sqn
        , $2 -- assz_cfbo_idnt_id
        , $3 -- file_nm
        , $4 -- file_sqn
        , $5 -- assz_orcp_file_path_nm
        , $6 -- orgn_data_rgsr_id
        , $7 -- rgsn_ts
        , $8 -- amnn_ts
        , $9 -- assz_orgn_pcsn_dcd
        , $10 -- atch_yn
        , $11 -- atch_sqn
        , $12 -- assz_dcmn_clsf_id
        , $13 -- assz_fmts_base_orgn_idnt_id
        , $14 -- conn_ttl_nm
        , $15 -- use_sttg_ymd
        , $16 -- use_fnsh_ymd
        , $17 -- sale_info_con
        , $18 -- assz_dcmn_clsf_con
        , $19 -- atch_nm
        , $20 -- uda_sys_lsmd_id
        , Current_timestamp
      );
      `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        use_sttg_ymd,
        use_fnsh_ymd,
        sale_info_con,
        assz_dcmn_clsf_con,
        atch_nm,
        uda_sys_lsmd_id,
      ]
    );

    return true;
  } finally {
    client.release();
  }
}

async function selectMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      SELECT assz_btch_acmp_id, assz_meta_pcsn_sqn, assz_unfc_id, assz_cfbo_idnt_id, file_nm, file_sqn, assz_orcp_file_path_nm, rgsr_id, rgsn_ts, amnn_ts, assz_orgn_pcsn_dcd, atch_yn, atch_sqn, assz_dcmn_clsf_id, assz_fmts_base_orgn_idnt_id, conn_ttl_nm, rgsr_dept_id, assz_pcsn_file_path_nm, atch_nm, eror_vl, assz_eror_con, uda_sys_lsmd_id, uda_sys_lsmd_ts
        FROM tb_uda_uai030m
      where assz_btch_acmp_id =$1
        and assz_orgn_pcsn_dcd in ('C','U')
				and eror_vl ='0000'
      order by assz_btch_acmp_id,assz_cfbo_idnt_id,file_sqn;
  `,
      [assz_btch_acmp_id]
    );

    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

async function selectMetaOne(pool, assz_btch_acmp_id, assz_unfc_id) {
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `select
        *
        from TB_UDA_UAI030M
        where assz_btch_acmp_id = $1        -- 자산화배치수행ID
        and assz_unfc_id = $2 
        and eror_vl = '0000'              -- 오류가 아닌 정상인 경우
        order by assz_btch_acmp_id, assz_unfc_id
      `,
      [assz_btch_acmp_id, assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) pool.end();
  }
}

module.exports = {
  insertMeta,
  selectMeta,
  dbEnd,
  selectMetaOne,
};
