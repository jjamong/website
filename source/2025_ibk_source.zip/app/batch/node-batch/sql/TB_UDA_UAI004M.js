const { Pool } = require("pg");
const config = require("../config");
const pool = new Pool(config.db);

// 자산화결과기본(원장) 조회
async function selectOrginRecent() {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
          a.*,
          b.assz_orcp_file_path_nm,
          b.assz_dcmn_clsf_id,
          b.conn_ttl_nm
        from tb_uda_uai000m a
        inner join tb_uda_uai004m b on a.assz_unfc_id = b.assz_unfc_id
        where 1=1
        and SUBSTRING(a.assz_unfc_id, 4, 6) = 'IEMIEA'
        and assz_pcsn_tcd != 'D' -- 삭제된 것은 제외
      `,
      []
    );
    return result;
  } finally {
    client.release();
  }
}

// 원장메타 저장
async function insertMeta(
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  assz_orcp_file_path_nm,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
      INSERT INTO TB_UDA_UAI004M (
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        assz_orcp_file_path_nm,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1, -- assz_unfc_id
        $2, -- assz_cfbo_idnt_id
        $3, -- file_nm
        $4, -- assz_orcp_file_path_nm
        $5, -- assz_orgn_pcsn_dcd
        $6, -- assz_dcmn_clsf_id
        $7, -- conn_ttl_nm
        $8, -- uda_sys_lsmd_id
        current_timestamp -- uda_sys_lsmd_ts
      )
		`,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        assz_orcp_file_path_nm,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        uda_sys_lsmd_id,
      ]
    );
    return true;
  } finally {
    client.release();
  }
}

// 원장메타 수정
async function updateMeta(
  assz_unfc_id,
  file_nm,
  assz_orcp_file_path_nm,
  assz_dcmn_clsf_id,
  conn_ttl_nm
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai004m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_orgn_pcsn_dcd = 'U'
          , file_nm = $2
          , assz_orcp_file_path_nm = $3
          , assz_dcmn_clsf_id = $4
          , conn_ttl_nm = $5
        where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        file_nm,
        assz_orcp_file_path_nm,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
      ]
    );
  } finally {
    client.release();
  }
}

// 원장메타 삭제
async function deleteMeta(assz_unfc_id) {
  const client = await pool.connect();
  try {
    await client.query(
      `
        update tb_uda_uai004m
        set 
          uda_sys_lsmd_ts = current_timestamp
          , assz_orgn_pcsn_dcd = 'D'
        where assz_unfc_id = $1
      `,
      [assz_unfc_id]
    );
  } finally {
    client.release();
  }
}

// 메타로그 저장
async function insertMetaLog(
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  assz_unfc_id,
  file_nm,
  assz_orcp_file_path_nm,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  assz_pcsn_file_path_nm,
  uda_sys_lsmd_id
) {
  const client = await pool.connect();
  try {
    await client.query(
      `
      INSERT INTO TB_UDA_UAI804L (
        assz_btch_acmp_id,
        assz_trms_tgt_sys_dcd,
        assz_btch_tcd,
        assz_meta_pcsn_sqn,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        assz_orcp_file_path_nm,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
        uda_sys_lsmd_ts
      ) VALUES (
        $1,
        '01',
        '01',
        (select coalesce(max(assz_meta_pcsn_sqn)+1,1)
          from TB_UDA_UAI804L
          where assz_btch_acmp_id =$1::VARCHAR), -- assz_meta_pcsn_sqn,
        $2, -- assz_cfbo_idnt_id,
        $3, -- assz_unfc_id
        $4, -- file_nm,
        $5, -- assz_orcp_file_path_nm,
        $6, -- assz_orgn_pcsn_dcd,
        $7, -- assz_dcmn_clsf_id,
        $8, -- conn_ttl_nm,
        $9, -- assz_pcsn_file_path_nm
        $10, -- uda_sys_lsmd_id,
        current_timestamp -- uda_sys_lsmd_ts
      )
    `,
      [
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        assz_orcp_file_path_nm,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        assz_pcsn_file_path_nm,
        uda_sys_lsmd_id,
      ]
    );
  } finally {
    client.release();
  }
}

// 메타 성공 조회
async function selectMetaSuccess(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select
        a.assz_unfc_id,
        a.assz_cfbo_idnt_id,
        assz_orcp_file_path_nm,
        file_nm,
        a.uda_sys_lsmd_id
      from tb_uda_uai000m a
      inner join tb_uda_uai004m b
      on a.assz_unfc_id = b.assz_unfc_id
      where 1=1
      and SUBSTRING(a.assz_unfc_id, 4, 6) = 'IEMIEA'
      and a.eror_vl in ('0000') -- 성공 건
      and a.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
      and a.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

// 메타 라인그리기 후 PDF변환 실패한 건만 조회
async function selectDrawLineFailMeta(assz_btch_acmp_id) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
	      select
	        a.assz_unfc_id,
	        a.assz_cfbo_idnt_id,
	        assz_orcp_file_path_nm,
	        file_nm
	      from tb_uda_uai000m a
	      inner join tb_uda_uai004m b
	      on a.assz_unfc_id = b.assz_unfc_id
	      where 1=1
	      and SUBSTRING(a.assz_unfc_id, 4, 6) = 'IEMIEA'
	      and a.eror_vl = '0210' -- PDF변환실패 건
	      and a.assz_pcsn_tcd in ('C', 'U') -- N, D 제외
        and a.assz_btch_acmp_id = $1
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function dbEnd() {
  pool.end();
}

module.exports = {
  selectOrginRecent,
  insertMeta,
  updateMeta,
  deleteMeta,
  insertMetaLog,
  selectMetaSuccess,
  selectDrawLineFailMeta,
  dbEnd,
};
