const fs = require("fs");
const axios = require("axios");
const { spawnSync } = require("child_process");

const util = require("../util");
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그
const dbMetaMain = require("../sql/TB_UDA_UAI803L"); //업무 메뉴얼 메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbAssetRlt = require("../sql/TB_UDA_UAI910L"); //자산화 처리로그
const dbImgRlt = require("../sql/TB_UDA_UAI912L");
const { selectAsszCfboIdntId } = require("../sql/TB_UDA_UAI911L"); // json 목록에서 group_id 추출
const { pg, cg } = require("../guardComm").initGuard();
const {
  checkUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  updateBatchId,
  updateErorVl,
  chkDupByAsszCfboIdntId,
  chkDupByAsszCfboIdntIdAndStus,
  updateLdgrStusBatId,
  updateLdgrBatId,
  chkDupByMnlAsszCfboIdntId,
  updateOnlyAsszScd,
} = require("../sql/TB_UDA_UAI000M");
const {
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  insertLdgrRecvPool,
  updateLdgrSelfPool,
  updateLdgrRecvPool,
  getFileInfo,
  updateLdgrBatIdStatus,
  updateLdgrDupCreateData,
  insertLdgrForSendData,
  insertLdgrSelfPoolByJsonMerge01,
  moveAssetData,
  updateLdgrByJsonMerge01,
  chkAllDataStatus,
  sync,
  finFileCheck,
  finFileCreate,
  updateLdgrByJsonMerge02,
  ldgrDataByAsszCfboIdntId,
  getldgrDataByBatchId,
  recvMetaFileCheck,
  getAsszUnfcIdByIeb,
  selectUai022mByFileRename,
  fileRename,
  selectByFileRenameBaseYmd,
  updateLdgrUpdateFileNmSelfPool,
  insertLdgrMaster,
  insertLdgrManual,
  updateLdgrMnl,
  updateLdgrMaster01,
  updateLdgrMnlMaster01,
  updateLdgrByJsonMerge01_01,
  updateLdgrMnlForNormalcy,
  selectByFileRenameByBatchId,
  batchStart,
  getBatchId,
  selectTxtFileCopyToLearn,
  getSafeBaseDt,
  mergeDocument,
  updateLdgrMaster02,
} = require("./common");
const { insertHistory, insertHistoryFirst } = require("../sql/TB_UDA_UAI000H");

const dayjs = require("dayjs");
const path = require("path");

//입력값 체크 pcsnClCd=01:날짜처리 , basDt = 날짜
const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const in_assz_btch_acmp_id = process.argv[4];
const asszPcsnFilePath = `/data/asset/iem/ieb/${basDt}/originpdf/`;

if (pcsnClCd !== "01") {
  writeLog("error node iemieb.js clcd(처리구분:01) YYYYMMDD");
}

if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("error node iemieb.js YYYYMMDD");
  process.exit(1);
}

function masterMetaSort(fullPath, index) {
  const meta = fs.readFileSync(fullPath, "utf-8");
  let lines = meta.split("\n");

  return lines.sort((a, b) => {
    const aFields = a.split("^|");
    const bFields = b.split("^|");

    const aKey = aFields[index] || "";
    const bKey = bFields[index] || "";

    return aKey.localeCompare(bKey);
  });
}

/*----------------------DRM해제 작업----------------------*/

async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );

  const dirs = ["origin", "att"]; //DRM해제할 디렉토리 목록
  let result = "";

  for (const dir of dirs) {
    const fullPath = `/data/asset/iem/ieb/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    writeLog(`ok ${fullPath}`);

    try {
      result = await util.executeCommand(command, "/app/drm");
    } catch (err) {
      writeLog(`오류: ${fullPath}:${err}`);
      continue; //오류 skip
    }

    writeLog(result);
  }

  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

/*----------------------시행문 파일 copy.----------------------*/
async function fileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------fileCopy()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  let dupCnt = 0; //원천데이터 C상태로 들어왔을때 기존에 같은 건이 있는 원천데이터 건수
  let noDataCntByDel = 0; //D일때 삭제건 식별키 찾을 수 없음"
  let noDataCntByUpdate = 0; //U일때 식별키 찾을 수 없음
  let updateCntByUpdate = 0;

  // const addInfo = await fs.readFileSync(
  //   `/data/bdpetl/recv/iem/ieb/${basDt}/meta/MetaFile${basDt}`,
  //   "utf8"
  // );
  //const lines_m = addInfo.split("\n");

  let lines_m = masterMetaSort(
    `/data/bdpetl/recv/iem/ieb/${basDt}/meta/MetaFile${basDt}`,
    3
  );

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "IEMIEB");
  let idx = result.rows[0].idsqn;

  for (const line of lines_m) {
    if (line.trim() === "") continue;
    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      orgn_data_rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_orgn_pcsn_dcd,
      atch_yn,
      atch_sqn,
      assz_dcmn_clsf_id,
      conn_ttl_nm,
      //atch_nm,
      sub_ttl_nm,
      url_adr,
    ] = line.split("^|");
    totalCnt++;

    let [assz_mnl_id, assz_mnl_grp_id, assz_cmpe_id] =
      assz_cfbo_idnt_id.split("_");

    const ext1 = path.extname(file_nm);
    const name1 = path.basename(file_nm, ext1);
    assz_cfbo_idnt_id = assz_cfbo_idnt_id.replace(/^\uFEFF/, "");
    assz_mnl_id = assz_mnl_id.replace(/^\uFEFF/, "");

    if (file_sqn == "" || file_sqn == null || file_sqn == "null") {
      file_sqn = 0;
    }
    if (atch_sqn == "" || atch_sqn == null || atch_sqn == "null") {
      atch_sqn = 0;
    }

    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`meta 파일명 없음 ${assz_cfbo_idnt_id}`);
      failCnt++;
      continue;
    } else {
      const ext = path.extname(file_nm).toLowerCase();
      const name = path.basename(file_nm, ext);

      let assz_unfc_id = "";
      //-------------------
      //첫데이터 넣을때
      if (basDt == "20250604") {
        assz_orgn_pcsn_dcd = "C"; //첫데이터로 일괄  C상태로 넣을때 사용
      }
      //-------------------
      const filename = `/data/bdpetl/recv/iem/ieb/${basDt}/file/${file_nm}`;
      //writeLog(`원천식별키:::::::::${assz_cfbo_idnt_id}`);
      if (!fs.existsSync(filename)) {
        writeLog(`----파일없음:${assz_cfbo_idnt_id}`);
        ////process.exit(1);

        let ldgrInfoResult = await chkDupByMnlAsszCfboIdntId(assz_cfbo_idnt_id);
        if (ldgrInfoResult.rowCount == 0) {
          assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
          const convFilename = `${assz_unfc_id}${ext}`;
          //원장마스터 인서트
          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_EXCEPTION,
            assz_cfbo_idnt_id,
            null,
            null,
            assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
            EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR,
            `${asszPcsnFilePath}${file_nm}`, //assz_pcsn_file_path_nm,
            null,
            null,
            assz_btch_acmp_id,
            "UDAIEBDASSETR001"
          );

          //업무별원장 인서트
          await insertLdgrManual(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            file_nm,
            file_sqn,
            assz_orcp_file_path_nm,
            orgn_data_rgsr_id,
            rgsn_ts,
            amnn_ts,
            assz_orgn_pcsn_dcd,
            atch_yn,
            atch_sqn,
            assz_dcmn_clsf_id,
            conn_ttl_nm,
            url_adr,
            "UDAIEBDASSETR001",
            sub_ttl_nm
          );
        } else {
          //원장마스터 업데이트
          writeLog(
            `----파일없음 > 식별ID(assz_cfbo_idnt_id):${assz_cfbo_idnt_id}`
          );
          await updateLdgrMaster02(
            null,
            ldgrInfoResult.rows[0].assz_unfc_id,
            assz_btch_acmp_id,
            filename,
            COMMON_CODES.ASSZ_SCD_EXCEPTION, //"20",
            EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
            EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR
          );
          //원장업무매뉴얼 업데이트
          await updateLdgrMnlMaster01(
            null,
            ldgrInfoResult.rows[0].assz_unfc_id,
            file_nm,
            file_sqn,
            assz_orcp_file_path_nm,
            orgn_data_rgsr_id,
            rgsn_ts,
            amnn_ts,
            assz_orgn_pcsn_dcd,
            assz_dcmn_clsf_id,
            conn_ttl_nm,
            url_adr,
            sub_ttl_nm
          );
        }

        //히스토리 인서트 없음
        failCnt++;
        continue;
      }
      const fileInfo = await getFileInfo(filename);
      // 삭제건 먼저처리
      if (assz_orgn_pcsn_dcd === "D") {
        writeLog(`D일때 원천식별키:${assz_cfbo_idnt_id}`);
        let ldgrInfoResult = await chkDupByMnlAsszCfboIdntId(assz_cfbo_idnt_id);
        if (ldgrInfoResult.rowCount == 0) {
          writeLog("D일때 삭제건 식별키 찾을 수 없음");
          noDataCntByDel++;
          failCnt++;
          assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
          const convFilename = `${assz_unfc_id}${ext}`;

          //원장마스터 인서트
          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_EXCEPTION,
            assz_cfbo_idnt_id,
            null,
            null,
            assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_UNSUCCESS,
            EROR_CODES.EROR_VL_UNSUCCESS_STR,
            `${asszPcsnFilePath}${file_nm}`, //assz_pcsn_file_path_nm,
            String(fileInfo.size), //파일크기
            fileInfo.md5, //자산화원천파일암호화난수값
            assz_btch_acmp_id,
            "UDAIEBDASSETR001"
          );

          //업무별원장 인서트
          await insertLdgrManual(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            file_nm,
            file_sqn,
            assz_orcp_file_path_nm,
            orgn_data_rgsr_id,
            rgsn_ts,
            amnn_ts,
            assz_orgn_pcsn_dcd,
            atch_yn,
            atch_sqn,
            assz_dcmn_clsf_id,
            conn_ttl_nm,
            url_adr,
            "UDAIEBDASSETR001",
            sub_ttl_nm
          );
          //히스토리 인서트 없음
          continue;
        } else {
          writeLog("D일때 삭제건 식별키 있는경우");
          //해당건을 찾았을때 원장테이블에 삭제로 변경
          assz_unfc_id = ldgrInfoResult.rows[0].assz_unfc_id;

          //'D'  로 변경
          //원장마스터 업데이트
          await updateLdgrSelfPool(
            assz_unfc_id,
            assz_btch_acmp_id,
            COMMON_CODES.ASSZ_SCD_DELETE
          ); //01 값 확인필요
          //원장업무매뉴얼 업데이트
          await updateLdgrMnl(assz_unfc_id, "D");
          //히스토리 인서트 없음
        }
      } else {
        if (assz_orgn_pcsn_dcd === "U") {
          //원장테이블에서 원천식별키로 검색해서 있는경우 'U'로 업데이트,배치아이디 업데이트
          //원장테이블 배치아이디,상태값 업데이트
          //히스토리 인서트
          let ldgrInfoResult = await chkDupByMnlAsszCfboIdntId(
            assz_cfbo_idnt_id
          );

          if (ldgrInfoResult.rowCount == 0) {
            writeLog("U일때 식별키 찾을 수 없음");
            noDataCntByUpdate++;
            failCnt++;
            assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
            const convFilename = `${assz_unfc_id}${ext}`;
            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              //COMMON_CODES.ASSZ_SCD_INIT, //"00",
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //20250923 변경하라고 함
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_UNSUCCESS2,
              EROR_CODES.EROR_VL_UNSUCCESS2_STR,
              `${asszPcsnFilePath}${file_nm}`, //assz_pcsn_file_path_nm,
              String(fileInfo.size), //파일크기
              fileInfo.md5, //자산화원천파일암호화난수값
              assz_btch_acmp_id,
              "UDAIEBDASSETR001"
            );

            //업무별원장 인서트
            await insertLdgrManual(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              url_adr,
              "UDAIEBDASSETR001",
              sub_ttl_nm
            );
            //히스토리 인서트 없음
            continue;
          } else {
            //writeLog(`U일때 RESULT:${ldgrInfoResult}`);
            //writeLog(`U일때 로우카운트:${ldgrInfoResult.rowCount}`);
            writeLog(
              `U일때 assz_unfc_id:${ldgrInfoResult.rows[0].assz_unfc_id}`
            );
            writeLog(
              `U일때 assz_cfbo_idnt_id:${ldgrInfoResult.rows[0].assz_cfbo_idnt_id}`
            );
            assz_unfc_id = ldgrInfoResult.rows[0].assz_unfc_id;

            //const filename = `/data/bdpetl/recv/iem/ieb/${basDt}/file/${file_nm}`;
            //원장마스터 업데이트
            await updateLdgrMaster01(
              null,
              assz_unfc_id,
              assz_btch_acmp_id,
              filename,
              COMMON_CODES.ASSZ_SCD_INIT, //"00",
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR
            );
            //원장업무매뉴얼 업데이트
            await updateLdgrMnlMaster01(
              null,
              assz_unfc_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              url_adr,
              sub_ttl_nm
            );

            //히스토리 인서트 없음
            writeLog("U일때 해당건 업데이트");
          }
        } else if (assz_orgn_pcsn_dcd === "C") {
          let ldgrInfoResult = await chkDupByMnlAsszCfboIdntId(
            assz_cfbo_idnt_id
          );

          //원천에서 들어온건이 자산화처리유형코드가 'C'일때 원장에서 해당건이 있는 지 확인(원천식별아이디)
          if (ldgrInfoResult.rowCount > 0) {
            //해당건이 있으면 해당건 원장테이블 배치아이디 업데이트
            //원장테이블 배치아이디 업데이트 후 정상적으로 진행
            assz_unfc_id = ldgrInfoResult.rows[0].assz_unfc_id;
            writeLog(
              `원천데이타 생성(C) 상태의 건이 중복건이 있음(원천식별아이디):${assz_cfbo_idnt_id}`
            );
            //await updateLdgrBatId(assz_unfc_id, assz_btch_acmp_id);
            await updateLdgrDupCreateData(
              null,
              ldgrInfoResult.rows[0].assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_INIT, //"00",
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR
            );

            //원장업무매뉴얼 업데이트
            await updateLdgrMnlMaster01(
              null,
              assz_unfc_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              url_adr,
              sub_ttl_nm
            );
            dupCnt++;
            //successCnt++;
            writeLog(
              `원장테이블 기존에 있는건을 업데이트 (updateLdgrDupCreateData):${assz_cfbo_idnt_id}`
            );
            //writeLog(`히스토리는 생성 안함 continue 실행:${assz_cfbo_idnt_id}`);
            //히스토리는 생성 안하는걸로 정함
          } else {
            assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
            const convFilename = `${assz_unfc_id}${ext}`;
            //const filename = `/data/bdpetl/recv/iem/ieb/${basDt}/file/${file_nm}`;
            //const fileInfo = await getFileInfo(filename);

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_INIT, //"00",
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR,
              `${asszPcsnFilePath}${file_nm}`, //assz_pcsn_file_path_nm,
              String(fileInfo.size), //파일크기
              fileInfo.md5, //자산화원천파일암호화난수값
              assz_btch_acmp_id,
              "UDAIEBDASSETR001"
            );

            //업무별원장 인서트
            await insertLdgrManual(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              url_adr,
              "UDAIEBDASSETR001",
              sub_ttl_nm
            );
            //히스토리 인서트 없음
            writeLog(`원장테이블 신규건 생성:${assz_unfc_id}`);
          }
        }
      }

      let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분

      try {
        await fs.accessSync(filename);
      } catch (err) {
        writeLog(`파일없음: ${filename}`);
        //process.exit(1);
        await dbMetaMain.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          assz_mnl_id,
          assz_mnl_grp_id,
          assz_cmpe_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          sub_ttl_nm,
          url_adr,
          "",
          "UDAIEBDASSETR001"
        );

        failCnt++;

        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR
        );

        continue; //파일없으면 skip
      }

      let chgFullPath = "";

      if (atch_yn === "Y") {
        chgFullPath = `/data/asset/iem/ieb/${basDt}/${dirGb}/${name}_ATT_${atch_Sqn}${ext}`;
      } else {
        chgFullPath = `/data/asset/iem/ieb/${basDt}/${dirGb}/${file_nm}`;
      }

      try {
        await fs.copyFileSync(filename, chgFullPath);
      } catch (err) {
        writeLog(`파일copy실패: ${filename}:${chgFullPath}`);
        await dbMetaMain.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          assz_mnl_id,
          assz_mnl_grp_id,
          assz_cmpe_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          sub_ttl_nm,
          url_adr,
          chgFullPath,
          "UDAIEBDASSETR001"
        );
        failCnt++;

        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_COPY_FAILED,
          EROR_CODES.EROR_VL_COPY_FAILED_STR
        );

        //자산화상태코드 예외로 변경해야함----------------------
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
        //---------------------------------------------------
        //process.exit(1);
        continue; //파일없으면 skip
      }

      let errCd = EROR_CODES.EROR_VL_SUCCESS;
      let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

      //자산화 대상 파일 아님.
      if (!isUseFile(file_nm)) {
        errCd = EROR_CODES.EROR_VL_NON_TARGET;
        errStr = EROR_CODES.EROR_VL_NON_TARGET_STR;
        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_NON_TARGET,
          EROR_CODES.EROR_VL_NON_TARGET_STR
        );

        //자산화상태코드 예외로 변경해야함----------------------
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
        //---------------------------------------------------

        failCnt++;
      } else {
        successCnt++;
      }

      writeLog(`copy 성공 ${filename}`);
      await dbMetaMain.insertMeta(
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        assz_mnl_id,
        assz_mnl_grp_id,
        assz_cmpe_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        sub_ttl_nm,
        url_adr,
        chgFullPath,
        "UDAIEBDASSETR001"
      );
    }
  }
  writeLog(
    "----------------------------원장테이블 검증 건수 시작----------------------------"
  );
  writeLog(`생성건 원장에 데이터가 있음: ${dupCnt}`);
  writeLog(`삭제건 원장에 데이터가 없음: ${noDataCntByDel}`);
  writeLog(`수정건 원장에 데이터가 없음: ${noDataCntByUpdate}`);
  writeLog(`수정건 원장에 데이터가 있음: ${updateCntByUpdate}`);

  writeLog(
    "----------------------------원장테이블 검증 건수 종료----------------------------"
  );
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "fileCopy");
  writeLog(
    "----------------------------fileCopy()종료----------------------------"
  );
}

async function htp(data) {
  const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
  const command = data.command;
  writeLog(`command:::::::::::::${command}`);
  let command1 = command.split(" ")[0];
  let args = command
    .split(" ")
    .slice(1)
    .map((item) => item.replace(/"/g, ""));
  writeLog(`command1:::::::::::::${command1}`);
  writeLog(`args:::::::::::::${args}`);

  let result = {};
  let { error, stdout, stderr } = spawnSync(command1, args);

  if (error) {
    writeLog(`에러:${error.message}`);
    result = {
      assz_btch_acmp_id: data.assz_btch_acmp_id,
      assz_mnl_id: data.assz_mnl_id,
      assz_unfc_id: data.assz_unfc_id,
      success: false,
      errCd: EROR_CODES.EROR_VL_HTP_FAILED,
      errStr: `hwptoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
      chgFilePath: data.chgFilePath,
      astpCd: data.astpCd,
      strDate: strDate,
    };

    return result;
  }
  if (stderr) {
    writeLog(`stderr:${stderr}`);
    result = {
      assz_btch_acmp_id: data.assz_btch_acmp_id,
      assz_mnl_id: data.assz_mnl_id,
      assz_unfc_id: data.assz_unfc_id,
      success: false,
      errCd: EROR_CODES.EROR_VL_HTP_FAILED,
      errStr: `hwptoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
      chgFilePath: data.chgFilePath,
      astpCd: data.astpCd,
      strDate: strDate,
    };
  }
  writeLog(`stdout:${stdout}`);
  if (stdout.includes("[Success]")) {
    writeLog(`변환성공: ${data.assz_pcsn_file_path_nm}`);
    result = {
      assz_btch_acmp_id: data.assz_btch_acmp_id,
      assz_mnl_id: data.assz_mnl_id,
      assz_unfc_id: data.assz_unfc_id,
      success: true,
      errCd: EROR_CODES.EROR_VL_SUCCESS, //"0000",
      errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
      chgFilePath: data.chgFilePath,
      astpCd: data.astpCd,
      strDate: strDate,
    };
  } else if (stdout.includes(`[Fail]`)) {
    writeLog(`변환실패 [Fail 출력됨]: ${data.assz_pcsn_file_path_nm}`);
    result = {
      assz_btch_acmp_id: data.assz_btch_acmp_id,
      assz_mnl_id: data.assz_mnl_id,
      assz_unfc_id: data.assz_unfc_id,
      success: false,
      errCd: EROR_CODES.EROR_VL_HTP_FAILED,
      errStr: `hwptoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
      chgFilePath: data.chgFilePath,
      astpCd: data.astpCd,
      strDate: strDate,
    };
  } else {
    writeLog(`결과미확인: ${data.assz_pcsn_file_path_nm}`);
    result = {
      assz_btch_acmp_id: data.assz_btch_acmp_id,
      assz_mnl_id: data.assz_mnl_id,
      assz_unfc_id: data.assz_unfc_id,
      success: false,
      errCd: EROR_CODES.EROR_VL_HTP_FAILED,
      errStr: "hwptoPdf 변환실패 [Fail 출력됨:결과미확인]",
      chgFilePath: data.chgFilePath,
      astpCd: data.astpCd,
      strDate: strDate,
    };
  }

  return result;
}

/*----------------------hwptoPdf----------------------*/
async function hwptoPdf(assz_btch_acmp_id) {
  writeLog(
    "----------------------------hwptoPdf()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(50);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let assz_mnl_id = "";
  //조회
  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const rmd of metaData.rows) {
    const oriFileName = path.basename(rmd.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (ext === ".hwp") {
      chgFileName = oriFileName.replace(".hwp", ".pdf");
    } else {
      failCnt++;
      continue;
    }
    const chgFilePath = `/data/asset/iem/ieb/${basDt}/pdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (path.extname(oriFileName).toLowerCase() === ".hwp") {
      let connTtlNm = rmd.conn_ttl_nm;
      connTtlNm = connTtlNm.replace(/"/g, '\\"');
      let command = `python3 /app/hwp2pdfv2/hwp2pdfsetTitle.py "${rmd.assz_pcsn_file_path_nm}" "/data/asset/iem/ieb/${basDt}/pdf" "${connTtlNm}"`;
      command = command.replace(/`/g, "\\`");
      astpCd = "HW";
      writeLog(`command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: astpCd,
        command: command,
        chgFilePath: chgFilePath,
        assz_pcsn_file_path_nm: rmd.assz_pcsn_file_path_nm,
        assz_mnl_id: rmd.assz_mnl_id,
        assz_unfc_id: rmd.assz_unfc_id,
      });
    } else if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      astpCd = "PD";
      try {
        await fs.copyFileSync(rmd.assz_pcsn_file_path_nm, chgFilePath);
        writeLog(`PDF 복사 완료:${chgFilePath} `);
        successCnt++;
      } catch (err) {
        writeLog(`PDF 복사 실패 : ${rmd.assz_pcsn_file_path_nm}`, err);
        //errCd = "0220";
        //errStr = `PDF 파일 원본 폴더 복사 실패 : ${rmd.assz_pcsn_file_path_nm}`;
        errCd = EROR_CODES.EROR_VL_HTP_PDF_COPY_FAILED;
        errStr = EROR_CODES.EROR_VL_HTP_PDF_COPY_FAILED_STR;
        failCnt++;
      }
      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

      await dbAssetLog.insertLog(
        rmd.assz_btch_acmp_id,
        rmd.assz_unfc_id,
        rmd.assz_mnl_id,
        rmd.atch_yn,
        astpCd, //assz_pcsn_tgt_tcd,
        "02",
        "C",
        "N",
        null,
        null,
        null,
        "CH",
        null,
        null,
        null,
        "MU",
        strDate,
        endDate,
        chgFilePath,
        errCd, //에러 0000
        errStr,
        "UDAIEBDASSETR001",
        null
      );
      /*
      await dbAssetLog.insertLog(
        rmd.assz_btch_acmp_id,
        rmd.assz_unfc_id,
        rmd.assz_mnl_id, //assz_cfbo_idnt_id
        rmd.atch_yn,
        astpCd, //HW      HWP PD  PDF ML  HTML assz_pcsn_tgt_tcd
        "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환) assz_prec_pcsn_stg_dcd
        "C", //C 신규 U 수정 D삭제 assz_pcsn_tcd
        "N", //이미지처리여부 assz_img_pcsn_yn
        null, //assz_img_pcsn_acmp_sttg_ts
        null, //assz_img_pcsn_acmp_fnsh_ts
        null, //assz_img_pcsn_acmp_rslt_dcd
        "CH", //CH변환 , NO(NONE) assz_conv_pcsn_tcd
        null, //assz_conv_acmp_sttg_ts
        null, //assz_conv_acmp_fnsh_ts
        null, //assz_conv_file_path_nm
        "MU", //SI(단일 문서),MU(멀티 통합 문서 assz_orcp_file_strc_tcd
        strDate, //원본변환시작일시 orcp_file_assz_job_sttg_ts
        endDate, //원본변환종료일시 orcp_file_assz_job_fnsh_ts
        chgFilePath, //assz_orcp_file_path_nm
        errCd, //에러 0000
        errStr,
        null, //acmp_sttg_ts
        null, //acmp_fnsh_ts
        "UDAIEBDASSETR001", //hdlr_id
        null //unfc_yn
      );*/
      await updateErorVl(rmd.assz_unfc_id, errCd, errStr);
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    await dbAssetLog.insertLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      result.assz_mnl_id,
      "N",
      "HW", //assz_pcsn_tgt_tcd,
      "02",
      "C",
      "N",
      null,
      null,
      null,
      "CH",
      null,
      null,
      null,
      "MU",
      result.strDate,
      endDate,
      result.chgFilePath,
      result.errCd, //에러 0000
      result.errStr,
      "UDAIEBDASSETR001",
      null
    );
    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "hwptoPdf");

  writeLog(
    "----------------------------hwptoPdf()종료----------------------------"
  );
}

/*----------------------pdftoText----------------------*/
async function pdftoText(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );
  const { spawnSync } = require("child_process");

  const targetDir = `/data/asset/iem/ieb/${basDt}/pdf`;
  const outputDir = `/data/asset/iem/ieb/${basDt}/txt`;
  //const files = fs.readdirSync(targetDir);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  //.pdf 파일만 필터링
  //  const pdfFiles = files.filter(
  //    (file) => path.extname(file).toLowerCase() === ".pdf"
  //  );

  const logData = await dbAssetLog.selectLog03(assz_btch_acmp_id, "02", "0000");
  //pdftotxt 변환
  for (const rld of logData.rows) {
    const oriFileName = path.basename(rld.assz_orcp_file_path_nm);

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    //const pdfFilePath = path.join(targetDir, file);
    const txtFileName = oriFileName.replace(".pdf", ".txt"); //확장자변경
    const txtOutFullPath = `${outputDir}/${txtFileName}`; //확장자변경
    const command = `python3 /app/pdftotxt/pdftotxt.py "${rld.assz_orcp_file_path_nm}" "${txtOutFullPath}"`;

    let command1 = command.split(" ")[0];
    let args = command
      .split(" ")
      .slice(1)
      .map((item) => item.replace(/"/g, ""));

    writeLog(`command 실행: ${command}`);
    totalCnt++;

    let errCd = "0000";
    let errStr = "";

    try {
      let result = {};
      let { error, stdout, stderr } = spawnSync(command1, args);

      if (error) {
        writeLog(`에러:${error.message}`);
        //reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        //return;
        throw new Error(`${error}`);
      }
      writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        writeLog(`변환성공: ${oriFileName}`);
        successCnt++;
        //resolve();
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`변환실패 [Fail 출력됨]: ${oriFileName}`);
        errCd = EROR_CODES.EROR_VL_PTT_FAILED;
        errStr = `변환실패 [Fail 출력됨]: ${oriFileName}`;
        failCnt++;
        //resolve();
      } else {
        writeLog(`결과미확인: ${oriFileName}`);
        //reject(new Error(`stdout에서 성공/실패 정보 없음`));
        throw new Error(`stdout에서 성공/실패 정보 없음`);
      }
    } catch (err) {
      writeLog(`pdftoText 변환 실패: ${oriFileName}`);
      errCd = EROR_CODES.EROR_VL_PTT_FAILED;
      errStr = `pdftoText 변환 실패: ${oriFileName}`;
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      rld.assz_btch_acmp_id,
      rld.assz_unfc_id,
      "04",
      null,
      null,
      null,
      null,
      null,
      staDate, //변환시작일시
      endDate, //변환종료일시
      txtOutFullPath,
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

/*----------------------pdftoImg----------------------*/
async function pdftoImg(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoImg()시작----------------------------"
  );
  const { exec } = require("child_process");
  const targetDir = `/data/asset/iem/ieb/${basDt}/pdf`;
  const outFolder = `/data/asset/iem/ieb/${basDt}/dp`;

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const logData = await dbAssetLog.selectLog04(assz_btch_acmp_id, "82");

  for (const ld of logData.rows) {
    let errCd = "0000";
    let errStr = "";

    const pdfFilePath = path.join(targetDir, `${ld.assz_cfbo_idnt_id}.pdf`);

    totalCnt++;
    // writeLog(`pdfFilePath:::::${pdfFilePath}`);
    // writeLog(`outFolder:::::${outFolder}`);
    // writeLog(`assz_btch_acmp_id:::::${ld.assz_btch_acmp_id}`);
    // writeLog(`assz_unfc_id:::::${ld.assz_unfc_id}`);
    // writeLog(`uda_sys_lsmd_id:::::${ld.uda_sys_lsmd_id}`);
    const command = `python3 /app/pdftoimg/pdftoimg.py "${pdfFilePath}" "${outFolder}" "${ld.assz_btch_acmp_id}" "${ld.assz_unfc_id}" "${ld.uda_sys_lsmd_id}"`;

    writeLog(`command 실행: ${command}`);
    try {
      await new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
          if (error) {
            writeLog(`에러:${error.message}`);
            reject(error); //resolve(); //에러나도 넘어가게끔 하려면
            return;
          }
          if (stderr) {
            writeLog(`stderr:${stderr}`);
            reject(stderr); //resolve(); //에러나도 넘어가게끔 하려면
            return;
          }
          writeLog(`stdout:${stdout}`);
          if (stdout.includes("[Success]")) {
            writeLog(`변환성공: ${pdfFilePath}`);
            successCnt++;
            resolve();
          } else if (stdout.includes(`[Fail]`)) {
            writeLog(`변환실패 [Fail 출력됨]: ${pdfFilePath}`);
            errCd = EROR_CODES.EROR_VL_PTI_FAILED;
            errStr = `pdf to Img 변환 실패: ${pdfFilePath}`;
            failCnt++;
            resolve();
          } else {
            writeLog(`결과미확인: ${pdfFilePath}`);
            reject(new Error(`stdout에서 성공/실패 정보 없음`));
          }
        });
      });
    } catch (err) {
      writeLog(`pdf to Img 변환 실패: ${pdfFilePath} :${err}`);
      errCd = EROR_CODES.EROR_VL_PTI_FAILED;
      errStr = `pdf to Img 변환 실패: ${pdfFilePath}`;
    }

    if (errCd != "0000") {
      await dbAssetLog.updateLogErr02(
        ld.assz_btch_acmp_id,
        ld.assz_unfc_id,
        errCd,
        errStr
      );
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoImg");
  writeLog(
    "----------------------------pdftoImg()종료----------------------------"
  );
}

/*----------------------jsonMerge----------------------*/
async function jsonMerge01(assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge01()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const outFolder = `/data/asset/iem/ieb/${basDt}/json`;
  const oriJsonFiles = await dbAssetLog.selectLog05(assz_btch_acmp_id, "83");
  const sourcePdfFolder = `/data/asset/iem/ieb/${basDt}/pdf`;

  for (const oriJsonFile of oriJsonFiles.rows) {
    totalCnt++;
    const fileName = `${oriJsonFile.file_nm}.json`;
    const pdfFilePath = path.join(outFolder, fileName);

    const realPdfFileName = `${oriJsonFile.file_nm}.pdf`;
    const realPdfFilePath = path.join(sourcePdfFolder, realPdfFileName);

    const startDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    const imgJsonFiles = await dbImgRlt.selectFilePathNm(
      assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id
    );
    const imgJsonList = imgJsonFiles.rows.map(
      (row) => row.assz_pcsn_file_path_nm
    );

    let errCd = "0000";
    let errStr = "";

    try {
      mergeJsonFiles(pdfFilePath, imgJsonList);
      writeLog(`jsonMerge01 변환 성공!!!: ${pdfFilePath}`);
      successCnt++;
      const fileStat = fs.statSync(pdfFilePath);
      const fileSize = Math.floor(fileStat.size / 1024);

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      // 성공 로그 insert
      await dbAssetRlt.insertAst(
        oriJsonFile.assz_btch_acmp_id,
        oriJsonFile.assz_unfc_id,
        "IEMIEB",
        oriJsonFile.assz_cfbo_idnt_id,
        oriJsonFile.dcmn_nm,
        fileName,
        oriJsonFile.assz_pcsn_tgt_tcd,
        oriJsonFile.assz_pcsn_tcd,
        fileSize,
        "PD",
        null,
        null,
        pdfFilePath,
        oriJsonFile.url_adr,
        oriJsonFile.rgsn_ts,
        oriJsonFile.amnn_ts,
        startDate,
        endDate,
        "N",
        null,
        oriJsonFile.uda_sys_lsmd_id,
        errCd,
        errStr,
        "Y"
      );
      //여기까지 기존소스 성공------------------------------------------

      //원장에 넣는 로직 시작------------------------------------------

      //unfc_yn = 'Y' 를 넣을때 원장테이블에 한건 쌓기(자산화처리유형코드 : 0003)
      let batchId = oriJsonFile.assz_btch_acmp_id;
      let fileInfo = await getFileInfo(realPdfFilePath);
      let assz_pcsn_tcd = "";
      // let ldgrInfoResult = await chkDupByAsszCfboIdntId(
      //   "IEMIEB",
      //   oriJsonFile.assz_cfbo_idnt_id
      // );
      writeLog(
        `oriJsonFile.assz_cfbo_idnt_id::::::${oriJsonFile.assz_cfbo_idnt_id}`
      );
      let ldgrInfoResult = await chkDupByMnlAsszCfboIdntId(
        oriJsonFile.assz_cfbo_idnt_id
      );
      //let fileNameCreate = oriJsonFile.assz_cfbo_idnt_id + ".pdf";
      let fileNameCreate = oriJsonFile.assz_unfc_id + ".pdf";
      if (ldgrInfoResult.rowCount > 0) {
        writeLog(`머지된 pdf파일이 기존에 생성되었던건::::::::::::::::`);
        //머지된 pdf파일이 기존에 생성되었던건이면 원장정보를 업데이트한다.
        await updateLdgrByJsonMerge01(
          null,
          ldgrInfoResult.rows[0].assz_unfc_id,
          batchId,
          oriJsonFile.assz_cfbo_idnt_id,
          fileInfo.size, //파일크기
          fileInfo.md5 //자산화원천파일암호화난수값
        );

        //원장업무매뉴얼 업데이트
        await updateLdgrByJsonMerge01_01(
          null,
          ldgrInfoResult.rows[0].assz_unfc_id,
          batchId,
          oriJsonFile.assz_cfbo_idnt_id
        );
        writeLog(
          `updateLdgrByJsonMerge01(tb_uda_uai000m) > update execution :::: ${ldgrInfoResult.rows[0].assz_unfc_id}::${oriJsonFile.assz_cfbo_idnt_id}`
        );

        //히스토리인서트
        // await insertHistoryFirst(
        //   ldgrInfoResult.rows[0].assz_unfc_id,
        //   //dayjs().format("YYYYMMDD"),
        //   batchId.slice(0, 8),
        //   parseInt(batchId.slice(-6), 10),
        //   batchId,
        //   assz_pcsn_tcd,
        //   "UDAIEBDASSETR001"
        // );
      } else {
        writeLog(`머지된 pdf파일이 기존에 생성안되어있던건::::::::::::::::`);
        //원장마스터 인서트
        await insertLdgrMaster(
          null,
          oriJsonFile.assz_unfc_id,
          COMMON_CODES.ASSZ_SCD_INIT,
          oriJsonFile.assz_cfbo_idnt_id,
          null,
          null,
          oriJsonFile.assz_pcsn_tcd,
          "0003",
          "정상",
          `/data/asset/iem/ieb/${basDt}/originpdf/${oriJsonFile.assz_unfc_id}.pdf`, //assz_pcsn_file_path_nm,
          fileInfo.size,
          fileInfo.md5,
          batchId,
          "UDAIEBDASSETR001"
        );
        writeLog(
          `원장마스터 인서트 완료::::::::::::::::${oriJsonFile.assz_unfc_id}/${oriJsonFile.assz_cfbo_idnt_id}`
        );

        //업무별원장 인서트
        await insertLdgrManual(
          null,
          oriJsonFile.assz_unfc_id,
          oriJsonFile.assz_cfbo_idnt_id,
          fileNameCreate,
          "0", //file_sqn,
          null, //assz_orcp_file_path_nm,자산화원본파일경로명
          null, //orgn_data_rgsr_id 원천데이터등록자ID
          oriJsonFile.rgsn_ts_2,
          oriJsonFile.amnn_ts_2,
          oriJsonFile.assz_pcsn_tcd,
          "N",
          "0",
          oriJsonFile.assz_dcmn_clsf_id,
          oriJsonFile.dcmn_nm, //conn_ttl_nm
          oriJsonFile.url_adr,
          "UDAIEBDASSETR001",
          oriJsonFile.atch_nm // sub_ttl_nm
        );
        writeLog(
          `원장업무매뉴얼 인서트 완료::::::::::::::::${oriJsonFile.assz_unfc_id}/${oriJsonFile.assz_cfbo_idnt_id}`
        );

        //히스토리인서트 없음
      }

      //0003으로 된 정상 건들을 자산화상태코드 10 정상으로 변경
      await updateLdgrMnlForNormalcy(
        assz_btch_acmp_id,
        COMMON_CODES.ASSZ_SCD_SUCCESS
      );
    } catch (err) {
      //console.log("에러메세지:::" + err.message);
      //console.log("에러메세지2:::" + err);
      writeLog(`jsonMerge01 변환 실패: ${pdfFilePath}`);
      errCd = EROR_CODES.EROR_VL_JSON_FAILED;
      errStr = `jsonMerge01 변환 실패: ${pdfFilePath}:::::${err.message}`;
      failCnt++;

      await dbAssetLog.updateLog02(
        assz_btch_acmp_id,
        oriJsonFile.assz_cfbo_idnt_id,
        "84",
        null,
        null,
        null,
        null,
        errCd,
        errStr
      );
    }
  }

  let delAsszCfboIdntId = "";
  try {
    //삭제건관련
    const delList = await getldgrDataByBatchId(null, assz_btch_acmp_id);

    for (const delData of delList.rows) {
      delAsszCfboIdntId = delData.assz_cfbo_idnt_id;
      //전체가 D인지 확인
      let allStatusResult = await chkAllDataStatus(
        null,
        delData.assz_cfbo_idnt_id
      );
      let allStatusDelYn = allStatusResult.rows[0].statusyn;
      if (allStatusDelYn === "Y") {
        let asszUnfcIdldgrDataByAsszCfboIdntId = await ldgrDataByAsszCfboIdntId(
          null,
          delData.assz_cfbo_idnt_id
        );

        await updateLdgrByJsonMerge02(
          null,
          asszUnfcIdldgrDataByAsszCfboIdntId.rows[0].assz_unfc_id,
          assz_btch_acmp_id,
          delData.assz_cfbo_idnt_id,
          0, //파일크기
          0, //자산화원천파일암호화난수값
          "D"
        );

        //원장업무매뉴얼 업데이트
        await updateLdgrByJsonMerge01_01(
          null,
          asszUnfcIdldgrDataByAsszCfboIdntId.rows[0].assz_unfc_id,
          assz_btch_acmp_id,
          delData.assz_cfbo_idnt_id
        );

        writeLog(
          `delData > all assz_cfbo_idnt_id delete flag: ${delData.assz_cfbo_idnt_id}`
        );

        //히스토리 인서트
        // await insertHistoryFirst(
        //   asszUnfcIdldgrDataByAsszCfboIdntId.rows[0].assz_unfc_id,
        //   //dayjs().format("YYYYMMDD"),
        //   assz_btch_acmp_id.slice(0, 8),
        //   parseInt(assz_btch_acmp_id.slice(-6), 10),
        //   assz_btch_acmp_id,
        //   "D",
        //   "UDAIEBDASSETR001"
        // );
      }
    }
  } catch (err) {
    writeLog(
      `jsonMerge01 DELETE ERROR::::::${delAsszCfboIdntId}//${err.message}`
    );
    //errCd = "0510";
    //errStr = `jsonMerge01 DELETE ERROR::::::${err.message}`;
    // failCnt++;

    // await dbAssetLog.updateLog02(
    //   assz_btch_acmp_id,
    //   oriJsonFile.assz_cfbo_idnt_id,
    //   "84",
    //   null,
    //   null,
    //   null,
    //   null,
    //   errCd,
    //   errStr
    // );
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jsonMerge01");
  writeLog(
    "----------------------------jsonMerge01()종료----------------------------"
  );
}

async function makeMeta(assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeMeta()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDirSam = `/data/bdpetl/send/gai/gai/ieb/${basDt}`;
  const targetDirJaon = `/data/asset/iem/ieb/${basDt}/json`;
  //const targetPdfDirJaon = `/data/asset/iem/ieb/${basDt}/pdf`;
  const targetPdfDirJaon = `/data/asset/iem/ieb/${basDt}/originpdf`;

  try {
    let res = await dbGaiMeta.selectMakeIebMeta(assz_btch_acmp_id);
    //컬럼간 ^|, 행간 \n 문자열 생성

    const rowsFilter = res.rows.filter((row) => {
      totalCnt++;
      // if (fs.existsSync(`${targetDirJaon}/${row.ori_doc_key}.json`)) {
      //   const fileStat = fs.statSync(
      //     `${targetDirJaon}/${row.ori_doc_key}.json`
      //   );
      if (fs.existsSync(`${targetPdfDirJaon}/${row.ori_doc_key}.pdf`)) {
        const fileStat = fs.statSync(
          `${targetPdfDirJaon}/${row.ori_doc_key}.pdf`
        );
        row.fileSize = Math.floor(fileStat.size / 1024);
        //row.url = row.url.replace(/\r/g, "");
        return true;
      } else if (row.pr_gubun == "D") {
        writeLog(`삭제:[${row.doc_id}][${row.ori_doc_key}][${row.doc_nm}]`);
        return true;
        //failCnt++;
        //return false;
      } else {
        failCnt++;
        return false;
      }
    });
    let rows = rowsFilter
      .map((row) => {
        successCnt++;
        return [
          row.doc_id,
          //row.doc_nm,
          row.doc_id, //자산화아이디의 파일명
          row.ori_doc_key,
          row.fileSize,
          row.file_type,
          row.url_adr,
          row.pr_gubun,
          row.rgsn_ts,
          row.amnn_ts,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          "",
          "",
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";
      //totalCnt++;
      //sam 저장
      const filePath = path.join(targetDirSam, `${basDt}_Meta.sam`);
      writeLog(`sam 파일생성 시작`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료:${filePath}`);
      //successCnt++;
    } else {
      writeLog(`sam 파일생성 실패`);
      //failCnt++;
    }

    summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeMeta");
  } catch (err) {
    writeLog(`sam 파일생성 에러발생:${err}`);
    summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeMeta");
  }
  writeLog(
    "----------------------------makeMeta()종료----------------------------"
  );
}

/*----------------------GAI.----------------------*/
async function gaiFileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------gaiFileCopy()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const sourceDirs = [
    { path: `/data/asset/iem/ieb/${basDt}/json`, ext: "json" },
    //{ path: `/data/asset/iem/ieb/${basDt}/pdf`, ext: "pdf" },
    { path: `/data/asset/iem/ieb/${basDt}/originpdf`, ext: "pdf" },
  ];
  const targetDir = `/data/bdpetl/send/gai/gai/ieb/${basDt}`;

  for (const dirInfo of sourceDirs) {
    const dir = dirInfo.path;
    const ext = dirInfo.ext;
    try {
      //자산화된 파일명만 조회.
      const fileNmList = await dbAssetRlt.selectMetaDocNmIeb(assz_btch_acmp_id);

      for (const fnm of fileNmList.rows) {
        totalCnt++;
        const fileName = `${fnm.doc_nm.replace(/\.[^/.]+$/, "")}.${ext}`;
        const srcPath = path.join(dir, fileName);
        //const destPath = path.join(targetDir, fileName);
        const destPath = path.join(targetDir, `${fnm.assz_unfc_id}.${ext}`);
        try {
          await fs.copyFileSync(srcPath, destPath);
          writeLog(`COPY완료 : ${fileName}`);
          successCnt++;
        } catch (err) {
          writeLog(`Failed to copy ${fileName} ${srcPath} ${destPath}, ${err}`);
          failCnt++;
        }
      }
    } catch (err) {
      writeLog(`Failed to read directory ${dir}:${err}`);
    }
  }
  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "gaiFileCopy"
  );
  writeLog(
    "----------------------------gaiFileCopy()종료----------------------------"
  );
}

function isUseFile(fileName) {
  const USE_EXTS = new Set([".hwp", ".hwpx"]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

async function makeDir(sysDep1, sysDep3) {
  const dirs = [
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/att`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/dp`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/json`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/origin`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/pdf`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/txt`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/img`,
    `/data/asset/${sysDep1}/${sysDep3}/${basDt}/originpdf`,
    `/data/bdpetl/send/gai/gai/${sysDep3}/${basDt}`,
  ]; //생성 디렉토리 경로

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

async function pdfMerge(assz_btch_acmp_id) {
  const { spawnSync } = require("child_process");

  writeLog(
    "----------------------------pdfMerge()시작----------------------------"
  );

  const sourceDir = { path: `/data/asset/iem/ieb/${basDt}/pdf`, ext: "pdf" };

  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let metas = [];
  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "IEMIEB");
  let idx = result.rows[0].idsqn;

  for (const rmd of metaData.rows) {
    let group_id = rmd.assz_mnl_id;
    let file_nm = rmd.assz_pcsn_file_path_nm;
    let assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
    let bef_assz_unfc_id = rmd.assz_unfc_id;

    const ext = path.extname(file_nm);
    const name = path.join(
      sourceDir.path,
      path.basename(file_nm).replace(".hwp", ".pdf")
    );

    let c = metas.filter((d, i) => d.group_id == group_id);
    if (c == 0) {
      metas.push({
        group_id,
        assz_unfc_id,
        bef_assz_unfc_id,
        files: [name],
      });
    } else {
      metas = metas.map((d, i) => {
        if (d.group_id == group_id) {
          d.files.push(name);
        }
        return d;
      });
    }
  }

  let checkId = "";

  for (const rmd of metas) {
    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (checkId == rmd.group_id) {
      continue;
    }

    checkId = rmd.group_id;

    let oriFileName = rmd.group_id;

    const command = `python3 /app/hwpmergev2/pdf_merge.py '${JSON.stringify(
      rmd
    )}' '${sourceDir.path}' '${sourceDir.path}'`;

    let command1 = command.split(" ")[0];
    let args = command
      .split(" ")
      .slice(1)
      .map((item) => item.replace(/'/g, ""));

    writeLog(`command1 :::::: ${command1}`);
    writeLog(`args :::::: ${args}`);
    writeLog(`command 실행: ${command}`);
    totalCnt++;

    let errCd = EROR_CODES.EROR_VL_SUCCESS; //0000
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR; //정상

    try {
      let result = {};
      let { error, stdout, stderr } = spawnSync(command1, args);

      if (error) {
        writeLog(`에러:${error.message}`);
        //reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        //return;
        throw new Error(`${error}`);
      }
      writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        writeLog(`변환성공: ${oriFileName}`);
        successCnt++;
        //resolve();
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`변환실패 [Fail 출력됨]: ${oriFileName}`);
        errCd = EROR_CODES.EROR_VL_PTM_FAILED;
        errStr = `변환실패 [Fail 출력됨]: ${oriFileName}`;
        failCnt++;
        //resolve();
      } else {
        writeLog(`결과미확인: ${oriFileName}`);
        //reject(new Error(`stdout에서 성공/실패 정보 없음`));
        throw new Error(`stdout에서 성공/실패 정보 없음`);
      }
    } catch (err) {
      console.log(err);
      writeLog(`pdfMerge 변환 실패: ${oriFileName}`);
      errCd = EROR_CODES.EROR_VL_PTM_FAILED;
      errStr = `pdfMerge 변환 실패: ${oriFileName}`;
      failCnt++;
    }
    if (errCd != "0000") {
      await dbAssetLog.updateLogErr03(
        assz_btch_acmp_id,
        rmd.group_id,
        errCd,
        errStr
      );
    } else {
      //통합된 문서ID를 처리
      const chgFilePath = `${sourceDir.path}/${rmd.group_id}.pdf`;
      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      writeLog(`정상 원천식별아이디: ${rmd.group_id}`);
      //writeLog(`정상 자산화식별아이디: ${rmd.assz_unfc_id}`);

      await dbAssetLog.insertLog(
        assz_btch_acmp_id,
        rmd.assz_unfc_id,
        rmd.group_id,
        "N",
        "PD", //assz_pcsn_tgt_tcd,
        "82",
        "C",
        "N",
        null,
        null,
        null,
        "CH",
        null,
        null,
        null,
        "MU",
        staDate, //원본변환시작일시
        endDate, //원본변환종료일시
        chgFilePath,
        errCd, //에러 0000
        errStr,
        "UDAIEBDASSETR001",
        "Y"
      );
      await updateErorVl(rmd.assz_unfc_id, errCd, errStr);
    }
  }

  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "pdfMerge"
  );
  writeLog(
    "----------------------------pdfMerge()종료----------------------------"
  );
}

async function jsonMerge02(assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge02()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let totalCnt1 = 0;
  let failCnt1 = 0;
  let successCnt1 = 0;
  let successFailCnt1 = 0;

  const sourceDir = { path: `/data/asset/iem/ieb/${basDt}/json`, ext: "json" };

  const groups = await selectAsszCfboIdntId(assz_btch_acmp_id);
  writeLog(`selectAsszCfboIdntId 의 length : ${groups.rows.length}`);
  let mergedData = [];
  let groupMap = {};
  for (const group of groups.rows) {
    totalCnt1++;
    writeLog(
      `selectAsszCfboIdntId totalCnt1 : ${totalCnt1} ::  group_id = [${group.group_id}]  // assz_pcsn_file_path_nm=${group.assz_pcsn_file_path_nm}`
    );
    if (typeof groupMap[group.group_id] == "undefined") {
      groupMap[group.group_id] = [];
    }
    if (!groupMap[group.group_id].includes(group.assz_pcsn_file_path_nm)) {
      successCnt1++;
      groupMap[group.group_id].push(group.assz_pcsn_file_path_nm);
    } else {
      successFailCnt1++;
      writeLog(
        `jsonMerge02 > groupMap에서  가 true 인것::group_id = [${group.group_id}]  // assz_pcsn_file_path_nm=${group.assz_pcsn_file_path_nm}`
      );
    }
  }
  writeLog(`successFailCnt1::${successFailCnt1}`);
  for (const g of Object.keys(groupMap)) {
    mergedData = [];
    let page = 1;

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    let errCd = "0000";
    let errStr = "";

    for (const file of groupMap[g]) {
      const content = JSON.parse(fs.readFileSync(file));
      //writeLog(`file = [${file}]`);
      totalCnt++;
      if (typeof content.maxPage != "undefined") {
        //writeLog(`content maxPage not undefined======>>>>`);
        writeLog(`content maxPage = [${content.maxPage}]`);
        let eMaxPage = content.data[content.data.length - 1].page;
        let eMaxChunkSeq = content.data[content.data.length - 1].chunk_seq;
        if (content.maxPage > eMaxPage) {
          let e = {
            page: content.maxPage,
            chunk_seq: ++eMaxChunkSeq,
            chunk: "",
          };
          content.data.push(e);
        }
      }

      if (content.data != undefined) {
        writeLog(`content data not undefined======>>>>`);
        for (const entry of content.data) {
          mergedData.push({
            page: entry.page,
            chunk_seq: entry.chunk_seq,
            chunk: entry.chunk,
          });
        }
      }
    }

    //writeLog(JSON.stringify(mergedData, null, 2));
    // const jsonFileMergeNm = await getAsszUnfcIdByIeb(
    //   null,
    //   assz_btch_acmp_id,
    //   g
    // );
    if (mergedData.length > 1) {
      mergedData = mergedData.map((chunk, idx) => {
        if (idx != 0) {
          if (
            chunk.chunk_seq == 1 ||
            (chunk.chunk_seq != 1 && chunk.page != mergedData[idx - 1].page)
          ) {
            page++;
          }
        }
        return {
          page: page,
          chunk_seq: idx + 1,
          chunk: chunk.chunk,
        };
      });

      try {
        console.log("sourceDir.path===>>>" + sourceDir.path);
        fs.writeFileSync(
          path.join(sourceDir.path, g + ".json"),
          JSON.stringify({ data: mergedData }, null, 2),
          "utf-8"
        );
        successCnt++;
      } catch (err) {
        errCd = EROR_CODES.EROR_VL_JSONM_FAILED;
        errStr = "jsonMerge02 파일생성 오류";
        failCnt++;
      }

      const txtOutFullPath = `${sourceDir.path}/${g}.json`;

      writeLog(`file = [${sourceDir.path}][${g}.json]`);

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

      //writeLog(`assz_btch_acmp_id = [${assz_btch_acmp_id}]`);
      writeLog(`g = [${g}]`);

      await dbAssetLog.updateLog02(
        assz_btch_acmp_id,
        g,
        "83",
        null,
        staDate, //변환시작일시
        endDate, //변환종료일시
        txtOutFullPath,
        errCd,
        errStr
      );
    } else if (mergedData.length == 1) {
      try {
        fs.writeFileSync(
          path.join(sourceDir.path, g + ".json"),
          JSON.stringify({ data: mergedData }, null, 2),
          "utf-8"
        );
        successCnt++;
      } catch (err) {
        errCd = EROR_CODES.EROR_VL_JSONM_FAILED;
        errStr = "jsonMerge02 파일생성 오류";
        failCnt++;
      }

      const txtOutFullPath1 = `${sourceDir.path}/${g}.json`;

      writeLog(`file = [${sourceDir.path}][${g}.json]`);

      const endDate1 = dayjs().format("YYYY-MM-DD HH:mm:ss");

      writeLog(`assz_btch_acmp_id = [${assz_btch_acmp_id}]`);
      writeLog(`g = [${g}]`);

      await dbAssetLog.updateLog02(
        assz_btch_acmp_id,
        g,
        "83",
        null,
        staDate, //변환시작일시
        endDate1, //변환종료일시
        txtOutFullPath1,
        errCd,
        errStr
      );
    } else {
      failCnt1++;
    }
  }

  writeLog(`(#) ${totalCnt1},${failCnt1},${successCnt1}`);

  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "jsonMerge02"
  );
  writeLog(
    "----------------------------jsonMerge02()종료----------------------------"
  );
}

function isUseFile(fileName) {
  const USE_EXTS = new Set([".hwp", ".hwpx"]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

/*----------------------hwptoPdfOrigin----------------------*/
async function hwptoPdfOrigin(assz_btch_acmp_id) {
  writeLog(
    "----------------------------hwptoPdfOrigin()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(50);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let assz_mnl_id = "";
  //조회
  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const rmd of metaData.rows) {
    const oriFileName = path.basename(rmd.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (ext === ".hwp") {
      chgFileName = oriFileName.replace(".hwp", ".pdf");
    } else {
      writeLog(`(hwptoPdfOrigin)hwp가 아닌경우의 파일: ${oriFileName}`);
      failCnt++;
      continue;
    }
    const chgFilePath = `/data/asset/iem/ieb/${basDt}/pdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (path.extname(oriFileName).toLowerCase() === ".hwp") {
      let connTtlNm = rmd.conn_ttl_nm;
      connTtlNm = connTtlNm.replace(/"/g, '\\"');
      writeLog(`hwptoPdfOrigin > connTtlNm: ${connTtlNm}`);
      writeLog(
        `hwptoPdfOrigin > assz_pcsn_file_path_nm: ${rmd.assz_pcsn_file_path_nm}`
      );
      let command = `python3 /app/hwp2pdfv2/hwp2pdfsetTitle.py "${rmd.assz_pcsn_file_path_nm}" "/data/asset/iem/ieb/${basDt}/originpdf" "${connTtlNm}"`;
      command = command.replace(/`/g, "\\`");
      writeLog(`hwptoPdfOrigin > connTtlNm: ${connTtlNm}`);
      astpCd = "HW";
      writeLog(`(hwptoPdfOrigin)command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: astpCd,
        command: command,
        chgFilePath: chgFilePath,
        assz_pcsn_file_path_nm: rmd.assz_pcsn_file_path_nm,
        assz_mnl_id: rmd.assz_mnl_id,
        assz_unfc_id: rmd.assz_unfc_id,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      writeLog(`(hwptoPdfOrigin)tasks 반복후실패건 : ${result.assz_mnl_id}`);
      failCnt++;
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "hwptoPdfOrigin"
  );

  writeLog(
    "----------------------------hwptoPdfOrigin()종료----------------------------"
  );
}

async function pdfMergeOrigin(assz_btch_acmp_id) {
  const { spawnSync } = require("child_process");

  writeLog(
    "----------------------------pdfMergeOrigin()시작----------------------------"
  );

  //const sourceDir = { path: `/data/asset/iem/ieb/${basDt}/pdf`, ext: "pdf" };
  const sourceDir = {
    path: `/data/asset/iem/ieb/${basDt}/originpdf`,
    ext: "pdf",
  };

  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let metas = [];
  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "IEMIEB");
  let idx = result.rows[0].idsqn;

  for (const rmd of metaData.rows) {
    let group_id = rmd.assz_mnl_id;
    let file_nm = rmd.assz_pcsn_file_path_nm;
    let assz_unfc_id = await getUnfcId("IEMIEB", ++idx);
    let bef_assz_unfc_id = rmd.assz_unfc_id;

    const ext = path.extname(file_nm);
    const name = path.join(
      sourceDir.path,
      path.basename(file_nm).replace(".hwp", ".pdf")
    );

    let c = metas.filter((d, i) => d.group_id == group_id);
    if (c == 0) {
      metas.push({
        group_id,
        assz_unfc_id,
        bef_assz_unfc_id,
        files: [name],
      });
    } else {
      metas = metas.map((d, i) => {
        if (d.group_id == group_id) {
          d.files.push(name);
        }
        return d;
      });
    }
  }

  let checkId = "";

  for (let rmd of metas) {
    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (checkId == rmd.group_id) {
      continue;
    }

    checkId = rmd.group_id;

    let oriFileName = rmd.group_id;
    //let oriFileName = rmd.assz_unfc_id; //머지된 파일을 자산화아이디로 만들때 사용
    //rmd.group_id = rmd.assz_unfc_id;  //파이썬에서 group_id 로 머지된 파일명을 사용하고 있음 -> 자산화아이디로할경우 사용

    writeLog(`(pdfMergeOrigin) > oriFileName :::: ${oriFileName}`);
    writeLog(
      `(pdfMergeOrigin) > JSON.stringify(rmd) :::: ${JSON.stringify(rmd)}`
    );
    const command = `python3 /app/hwpmergev2/pdf_merge.py '${JSON.stringify(
      rmd
    )}' '${sourceDir.path}' '${sourceDir.path}'`;

    let command1 = command.split(" ")[0];
    let args = command
      .split(" ")
      .slice(1)
      .map((item) => item.replace(/'/g, ""));

    writeLog(`(pdfMergeOrigin)command 실행: ${command}`);
    totalCnt++;

    let errCd = EROR_CODES.EROR_VL_SUCCESS; //0000
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR; //정상

    try {
      let result = {};
      let { error, stdout, stderr } = spawnSync(command1, args);
      if (error) {
        writeLog(`(pdfMergeOrigin)에러:${error.message}`);
        //reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        //return;
        //writeLog(`stdout:${stdout}`);
        throw new Error(`${error}`);
      }
      if (stdout.includes("[Success]")) {
        //writeLog(`(pdfMergeOrigin)변환성공: ${oriFileName}`);
        successCnt++;
        //resolve();
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`(pdfMergeOrigin)변환실패 [Fail 출력됨]: ${oriFileName}`);
        errCd = EROR_CODES.EROR_VL_PTM_FAILED;
        errStr = `(pdfMergeOrigin)변환실패 [Fail 출력됨]: ${oriFileName}`;
        failCnt++;
        //resolve();
      } else {
        writeLog(`(pdfMergeOrigin)결과미확인: ${oriFileName}`);
        //reject(new Error(`(pdfMergeOrigin)stdout에서 성공/실패 정보 없음`));
        throw new Error(`(pdfMergeOrigin)stdout에서 성공/실패 정보 없음`);
      }
    } catch (err) {
      console.log(err);
      writeLog(`(pdfMergeOrigin)pdfMerge 변환 실패: ${oriFileName}`);
      errCd = EROR_CODES.EROR_VL_PTM_FAILED;
      errStr = `(pdfMergeOrigin)pdfMerge 변환 실패: ${oriFileName}`;
      failCnt++;
    }
    if (errCd != "0000") {
      await dbAssetLog.updateLogErr03(
        assz_btch_acmp_id,
        rmd.group_id,
        errCd,
        errStr
      );
    }
  }

  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "pdfMergeOrigin"
  );
  writeLog(
    "----------------------------pdfMergeOrigin()종료----------------------------"
  );
}

async function drawLine(assz_btch_acmp_id) {
  writeLog(
    "----------------------------drawline()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const path = require("path");
  //const addInfo = fs.readFileSync(`/data/bdpetl/recv/kms/wpt/${basDt}/meta/ACTION_DOC_FILE_INFO.dat`,"utf-8");

  //const lines_m = addInfo.split("\n");
  const lines_m = masterMetaSort(
    `/data/bdpetl/recv/iem/ieb/${basDt}/meta/MetaFile${basDt}`,
    3
  );

  const commands = [];

  for (const line of lines_m) {
    if (line.trim() === "") continue;
    /*
    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      rgsn_ts,
      atch_yn,
      atch_sqn,
      atch_nm,
    ] = line.split("^|");*/
    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_orgn_pcsn_dcd,
      atch_yn,
      atch_sqn,
      assz_dcmn_clsf_id,
      conn_ttl_nm,
      atch_nm,
      url_adr,
    ] = line.split("^|");
    //totalCnt++;

    if (file_sqn == "" || file_sqn == null || file_sqn == "null") {
      file_sqn = 0;
    }
    if (atch_sqn == "" || atch_sqn == null || atch_sqn == "null") {
      atch_sqn = 0;
    }

    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null ||
      !(
        path.extname(file_nm).toLowerCase() === ".hwp" ||
        path.extname(file_nm).toLowerCase() === ".hwpx" ||
        path.extname(file_nm).toLowerCase() === ".docx"
      )
    ) {
      continue;
    } else {
      const ext = path.extname(file_nm);
      const name = path.basename(file_nm, ext);

      let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분

      let chgFullPath = "";

      if (atch_yn === "Y") {
        chgFullPath = `/data/asset/iem/ieb/${basDt}/${dirGb}/${name}_ATT_${atch_sqn}${ext}`;
      } else {
        chgFullPath = `/data/asset/iem/ieb/${basDt}/${dirGb}/${file_nm}`;
      }
      if (fs.existsSync(chgFullPath)) {
        fs.copyFileSync(chgFullPath, `${chgFullPath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${chgFullPath}${ext}" "${chgFullPath}" 10`;

      commands.push({
        command: command,
        chgFullPath: chgFullPath,
        ext: ext,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => dl(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
      writeLog(`Drawline 성공 ${result.chgFullPath}`);
    } else {
      failCnt++;
      writeLog(`Drawline 실패: ${result.chgFullPath}`);
    }

    const tmpFilename = `${result.chgFullPath}${result.ext}`;

    if (fs.existsSync(tmpFilename)) {
      fs.unlinkSync(tmpFilename);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "drawline");
  writeLog(
    "----------------------------drawline()종료----------------------------"
  );
}

async function dl(data) {
  const command = data.command;

  let command1 = command.split(" ")[0];
  let args = command
    .split(" ")
    .slice(1)
    .map((item) => item.replace(/"/g, ""));

  let result = {};
  let { error, stdout, stderr } = spawnSync(command1, args);

  if (error) {
    result = {
      success: false,
      chgFullPath: data.chgFullPath,
      ext: data.ext,
    };
  }
  if (stderr) {
    if (!stderr.includes("Log4j")) {
      result = {
        success: false,
        chgFullPath: data.chgFullPath,
        ext: data.ext,
      };
    }
  }
  result = {
    success: true,
    chgFullPath: data.chgFullPath,
    ext: data.ext,
  };

  return result;
}

async function makeMetaRange(targetDt, startDt, endDt) {
  writeLog(
    "----------------------------makeMetaRange()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/ieb/${targetDt}`;

  try {
    const res = await dbGaiMeta.selectMakeIebMetaTemp(startDt, endDt);

    //컬럼간 ^|, 행간 \n 문자열 생성
    const rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          //row.doc_nm,
          row.doc_id,
          row.ori_doc_key,
          row.fileSize,
          row.file_type,
          row.url_adr,
          row.pr_gubun,
          row.rgsn_ts,
          row.amnn_ts,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          "",
          "",
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("\n");
    totalCnt++;
    //sam 저장
    const filePath = path.join(targetDir, `${targetDt}_Meta.sam`);
    fs.writeFileSync(filePath, rows, "utf8");
    writeLog(`sam 파일생성 완료:${filePath}`);
    successCnt++;
    summaryLog(totalCnt, successCnt, failCnt, "", "makeMetaRange");
  } catch (err) {
    writeLog(err);
    writeLog(`sam 파일생성 에러발생:${err}`);
    failCnt++;
    summaryLog(totalCnt, successCnt, failCnt, "", "makeMetaRange");
  }
  writeLog(
    "----------------------------makeMetaRange()종료----------------------------"
  );
}

async function gaiFileCopyRange(targetDt, startDt, endDt) {
  writeLog(
    "----------------------------gaiFileCopyRange()시작----------------------------"
  );

  let totalCnt = 0;
  let fileSuccessCnt = 0;
  let fileFailCnt = 0;
  let jsonSuccessCnt = 0;
  let jsonFailCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/ieb/${targetDt}`;

  try {
    //자산화된 파일명만 조회.
    const fileNmList = await dbGaiMeta.selectMetaDocNmIebRange(startDt, endDt);

    //console.log(`총 ${fileNmList.rows.length} 건`);
    for (const fnm of fileNmList.rows) {
      totalCnt++;
      const fileName = fnm.file_nm;
      const newFileName = fnm.new_file_nm;
      if (newFileName) {
        //const fileBaseName = path.basename(fileName);
        const fileBaseName = path.basename(newFileName);

        if (fs.existsSync(fileName)) {
          try {
            let sendFilePath = path.join(targetDir, fileBaseName);

            fs.copyFileSync(fileName, sendFilePath);

            writeLog(`COPY완료 : ${newFileName}`);
            fileSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${fileName}, ${err}`);
            fileFailCnt++;
          }
        } else {
          writeLog(`${fileName} 파일 없음`);
          fileFailCnt++;
        }
      } else {
        writeLog(`${fileName} 파일명 비어있음..`);
        fileFailCnt++;
      }

      const jsonName = fnm.json_nm;
      const newJsonName = fnm.new_json_nm;
      if (newJsonName) {
        //const jsonBaseName = path.basename(jsonName);
        const jsonBaseName = path.basename(newJsonName);

        if (fs.existsSync(jsonName)) {
          //let sendJsonPath = path.join(targetDir, jsonBaseName);
          try {
            let sendJsonPath = path.join(targetDir, jsonBaseName);
            fs.copyFileSync(jsonName, sendJsonPath);
            writeLog(`COPY완료 : ${sendJsonPath}`);
            jsonSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${jsonName}, ${err}`);
            jsonFailCnt++;
          }
        } else {
          writeLog(`${jsonName} 파일 없음`);
          jsonFailCnt++;
        }
      } else {
        writeLog(`${jsonName} 지원하지 않는 문서`);
        jsonFailCnt++;
      }
    }
  } catch (err) {
    writeLog(`Failed to read directory ${err}`);
  }

  console.log(`Total : ${totalCnt} 건`);
  console.log(`fileSuccess : ${fileSuccessCnt} 건`);
  console.log(`fileFail : ${fileFailCnt} 건`);
  console.log(`jsonSuccess : ${jsonSuccessCnt} 건`);
  console.log(`jsonFail : ${jsonFailCnt} 건`);

  summaryLog(totalCnt, jsonSuccessCnt, jsonFailCnt, "", "gaiFileCopyRange");
  writeLog(
    "----------------------------gaiFileCopyRange()종료----------------------------"
  );
}

/*----------------------mergeFileRename----------------------*/
async function mergeFileRename(assz_btch_acmp_id) {
  writeLog(
    "----------------------------mergeFileRename()시작----------------------------"
  );
  //대상 : originpdf 폴더
  //대상 : json 폴더
  let totalCnt = 0;
  let totalCnt2 = 0;
  let successCnt = 0;
  let failCnt = 0;

  const resultData = await selectUai022mByFileRename(null, assz_btch_acmp_id);
  let destFullPath = `/data/asset/iem/ieb/${basDt}/json/`;
  for (const rd of resultData.rows) {
    totalCnt++;
    await fileRename(
      rd.assz_pcsn_file_path_nm,
      `${destFullPath}${rd.assz_unfc_id}.json`
    );
  }
  writeLog("(#)json merge파일이름변경 총건수 : " + totalCnt);

  const resultData2 = await dbGaiMeta.selectMakeIebMeta(assz_btch_acmp_id);
  let pathPdf = `/data/asset/iem/ieb/${basDt}/originpdf/`;
  for (const rd2 of resultData2.rows) {
    totalCnt2++;
    await fileRename(
      `${pathPdf}${rd2.doc_nm}.pdf`,
      `${pathPdf}${rd2.doc_id}.pdf`
    );
  }
  writeLog("(#)pdf merge파일이름변경 총건수 : " + totalCnt2);
  writeLog(
    "----------------------------mergeFileRename()종료----------------------------"
  );
}

/*----------------------mergeFileRenameBaseYmd----------------------*/
async function mergeFileRenameBaseYmd() {
  writeLog(
    "----------------------------mergeFileRenameBaseYmd()시작----------------------------"
  );
  //대상 : originpdf 폴더
  //대상 : json 폴더
  //대상 : send 폴더
  let totalCnt = 0;
  let totalCnt2 = 0;
  let successCnt = 0;
  let failCnt = 0;

  const resultData = await selectByFileRenameBaseYmd(null, basDt);

  for (const rd of resultData.rows) {
    if (fs.existsSync(rd.old_pdf_file)) {
      await fileRename(rd.old_pdf_file, rd.new_pdf_file);
      await fileRename(rd.old_json_file, rd.new_json_file);
      await fileRename(rd.old_send_pdf_file, rd.new_send_pdf_file);
      await fileRename(rd.old_send_json_file, rd.new_send_json_file);
    }
  }
  //writeLog("(#)pdf merge파일이름변경 총건수 : " + totalCnt2);
  writeLog(
    "----------------------------mergeFileRenameBaseYmd()종료----------------------------"
  );
}

/*----------------------reCreateSamFile----------------------*/
async function reCreateSamFile() {
  writeLog(
    "----------------------------reCreateSamFile()시작----------------------------"
  );
  let totalCnt = 0;

  let lines_m = masterMetaSort(
    `/data/bdpetl/send/gai/gai/ieb/${basDt}/${basDt}_Meta.sam`,
    0
  );
  let dataRows = "";
  const rowCnt = lines_m.length;
  for (const line of lines_m) {
    if (line.trim() === "") continue;
    let [
      assz_unfc_id,
      file_nm,
      assz_cfbo_idnt_id,
      flsz_vl,
      file_type,
      link_url,
      assz_pcsn_tcd,
      rgsn_ts,
      amnn_ts,
      atch_yn,
      atch_sqn,
      conn_ttl_nm,
      etc_01,
      etc_02,
    ] = line.split("^|");
    totalCnt++;

    let rowData = "";
    if (rowCnt == totalCnt) {
      rowData = `${assz_unfc_id}^|${assz_unfc_id}^|${assz_cfbo_idnt_id}^|${flsz_vl}^|${file_type}^|${link_url}^|${assz_pcsn_tcd}^|${rgsn_ts}^|${amnn_ts}^|${atch_yn}^|${atch_sqn}^|${conn_ttl_nm}^|${etc_01}^|${etc_02}`;
    } else {
      rowData = `${assz_unfc_id}^|${assz_unfc_id}^|${assz_cfbo_idnt_id}^|${flsz_vl}^|${file_type}^|${link_url}^|${assz_pcsn_tcd}^|${rgsn_ts}^|${amnn_ts}^|${atch_yn}^|${atch_sqn}^|${conn_ttl_nm}^|${etc_01}^|${etc_02}\n`;
    }
    dataRows = dataRows + rowData;
  }

  let lines = dataRows.split("\n");
  //첫번째 데이터로 오르차순 정렬
  lines.sort((a, b) => {
    let numA = parseInt(a.split("^|")[0].match(/\d+/)[0], 10);
    let numB = parseInt(b.split("^|")[0].match(/\d+/)[0], 10);
    return numA - numB;
  });
  let sortedData = lines.join("\n");

  //sam 저장
  const filePath = path.join(
    `/data/bdpetl/send/gai/gai/ieb/${basDt}/`,
    `${basDt}_Meta.sam`
  );
  writeLog(`sam 파일생성 시작`);
  fs.writeFileSync(filePath, sortedData, "utf8");
  writeLog(`sam 파일생성 완료:${filePath}`);

  //writeLog("(#)pdf merge파일이름변경 총건수 : " + totalCnt2);
  writeLog(
    "----------------------------reCreateSamFile()종료----------------------------"
  );
}

/*----------------------ldgrIemIebFileNmAllUpdate----------------------*/
async function ldgrIemIebFileNmAllUpdate() {
  writeLog(
    "----------------------------ldgrIemIebFileNmAllUpdate()시작----------------------------"
  );
  await updateLdgrUpdateFileNmSelfPool("IEMIEB");

  writeLog(
    "----------------------------ldgrIemIebFileNmAllUpdate()종료----------------------------"
  );
}

/*----------------------reCreateSamFileAddParam----------------------*/
//20250101로 생성된 sam 파일을 ^| 추가가 필요할 경우 사용(이미생성된 SAM파일을 수정하는 방식)
async function reCreateSamFileAddParam() {
  writeLog(
    "----------------------------reCreateSamFileAddParam()시작----------------------------"
  );
  let totalCnt = 0;

  let lines_m = masterMetaSort(
    `/data/bdpetl/send/gai/gai/ieb/${basDt}/${basDt}_Meta.sam`,
    0
  );
  let dataRows = "";
  const rowCnt = lines_m.length;
  for (const line of lines_m) {
    if (line.trim() === "") continue;
    let [
      assz_unfc_id,
      file_nm,
      assz_cfbo_idnt_id,
      flsz_vl,
      file_type,
      link_url,
      assz_pcsn_tcd,
      rgsn_ts,
      amnn_ts,
      atch_yn,
      atch_sqn,
      conn_ttl_nm,
      etc_01,
      etc_02,
    ] = line.split("^|");
    totalCnt++;

    let rowData = "";
    if (rowCnt == totalCnt) {
      rowData = `${assz_unfc_id}^|${assz_unfc_id}^|${assz_cfbo_idnt_id}^|${flsz_vl}^|${file_type}^|${link_url}^|${assz_pcsn_tcd}^|${rgsn_ts}^|${amnn_ts}^|${atch_yn}^|${atch_sqn}^|${conn_ttl_nm}^|${etc_01}^|${etc_02}^|`;
    } else {
      rowData = `${assz_unfc_id}^|${assz_unfc_id}^|${assz_cfbo_idnt_id}^|${flsz_vl}^|${file_type}^|${link_url}^|${assz_pcsn_tcd}^|${rgsn_ts}^|${amnn_ts}^|${atch_yn}^|${atch_sqn}^|${conn_ttl_nm}^|${etc_01}^|${etc_02}^|\n`;
    }
    dataRows = dataRows + rowData;
  }

  let lines = dataRows.split("\n");
  //첫번째 데이터로 오르차순 정렬
  lines.sort((a, b) => {
    let numA = parseInt(a.split("^|")[0].match(/\d+/)[0], 10);
    let numB = parseInt(b.split("^|")[0].match(/\d+/)[0], 10);
    return numA - numB;
  });
  let sortedData = lines.join("\n");

  //sam 저장
  const filePath = path.join(
    `/data/bdpetl/send/gai/gai/ieb/${basDt}/`,
    `${basDt}_Meta.sam`
  );
  writeLog(`sam 파일생성 시작`);
  fs.writeFileSync(filePath, sortedData, "utf8");
  writeLog(`sam 파일생성 완료:${filePath}`);

  //writeLog("(#)pdf merge파일이름변경 총건수 : " + totalCnt2);
  writeLog(
    "----------------------------reCreateSamFileAddParam()종료----------------------------"
  );
}

/*----------------------mergeFileRenameProc----------------------*/
async function mergeFileRenameProc(assz_btch_acmp_id) {
  writeLog(
    "----------------------------mergeFileRenameProc()시작----------------------------"
  );
  //대상 : originpdf 폴더
  //대상 : json 폴더

  //const resultData = await selectByFileRenameByBaseYmd(null, basDt);
  const resultData = await selectByFileRenameByBatchId(null, assz_btch_acmp_id);

  for (const rd of resultData.rows) {
    if (fs.existsSync(rd.old_pdf_file)) {
      await fileRename(rd.old_pdf_file, rd.new_pdf_file);
      await fileRename(rd.old_json_file, rd.new_json_file);
    }
  }
  writeLog(
    "----------------------------mergeFileRenameProc()종료----------------------------"
  );
}

/*---------------------- 학습데이터 파일복사 ----------------------*/
async function moveToLearn(systemName, assz_btch_acmp_id) {
  writeLog(
    "----------------------------moveToLearn()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const resultData = await selectTxtFileCopyToLearn(
    null,
    systemName,
    assz_btch_acmp_id
  );

  for (const rd of resultData.rows) {
    totalCnt++;
    writeLog(`파일풀path:::${rd.srctxtfile}`);
    if (fs.existsSync(rd.srctxtfile)) {
      writeLog(`파일있음:::${rd.srctxtfile}`);
      try {
        if (!fs.existsSync(rd.tgtdir)) {
          writeLog(`폴더생성하기:::${rd.tgtdir}`);
          await fs.mkdirSync(`${rd.tgtdir}`, { recursive: true });
        }

        await fs.copyFileSync(rd.srctxtfile, rd.tgttxtfile);
        successCnt++;
      } catch (err) {
        failCnt++;
        writeLog(`폴더 생성 실패: ${rd.srctxtfile}:${rd.tgttxtfile}`);
      }
    } else {
      writeLog(`파일없음:::${rd.srctxtfile}`);
      failCnt++;
    }
  }
  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "moveToLearn"
  );
  writeLog(
    "----------------------------moveToLearn()종료----------------------------"
  );
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃iemieb 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃");
  if (pcsnClCd == "01") {
    let basePath = `/data/bdpetl/recv/iem/ieb/${basDt}/`;
    // 서버간 수신 파일 동기화
    await sync(basePath); //개발에서는 주석으로 막고 실행
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    //배치수행로그 입력 및 배치ID채번
    //const assz_btch_acmp_id = await batchStart();
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IEMIEB",
      "01", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB T3 지식샘
      "01" //assz_trms_tgt_sys_dcd
    );

    await makeDir("iem", "ieb");

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/iem/ieb/${basDt}/meta/MetaFile${basDt}`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/ieb", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }
    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 종료-------------------------------

    await fileCopy(assz_btch_acmp_id); // 메타 입력 및 파일 통합

    await drmUnlock(); //DRM해제

    await hwptoPdfOrigin(assz_btch_acmp_id); //단건으로 처리
    await pdfMergeOrigin(assz_btch_acmp_id); //이미지는 머지후 처리  20 82

    await drawLine();
    await hwptoPdf(assz_btch_acmp_id); //단건으로 처리
    await pdftoText(assz_btch_acmp_id); //단건으로 처리
    //-----------------------------------------------

    //-----------------------------------------------머지
    await pdfMerge(assz_btch_acmp_id); //이미지는 머지후 처리  20 82
    await pdftoImg(assz_btch_acmp_id); //머지된 pdf로 처리 20 82 --> 이미지처리 결과 업데이트
    await util.imgToDp2(assz_btch_acmp_id, "iemieb", basDt); //전체 (첨부,부속이미지)이미지를 텍스트로
    //-----------------------------------------------머지

    await util.runImgJeff(assz_btch_acmp_id, "iemieb", basDt); //DBselect 엔진호출   DBupdate Dbinsert
    await util.runJeff2(assz_btch_acmp_id, "iemieb", basDt);
    //-----------------------------------------------변경대상
    await jsonMerge02(assz_btch_acmp_id); //pdf jSON 병합    20 -  82   -> 84
    await jsonMerge01(assz_btch_acmp_id); //pdf jSON  img JSON 병합   20 84 -> 22

    await mergeFileRenameProc(assz_btch_acmp_id);

    await moveAssetData("/data/asset/iem/ieb", basDt);

    //000D에 인서트 청킹데이터 인서트(머지된파일)
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "iemieb",
      basDt,
      `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`
    );

    // 학습데이터 파일복사
    await moveToLearn("iemieb", assz_btch_acmp_id);

    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);

    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "iemieb",
      `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iemieb",
      `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`
    );

    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "03") {
    //기존이행된데이터들의 파일명변경 작업
    await mergeFileRenameBaseYmd();
    await reCreateSamFile();
  } else if (pcsnClCd == "05") {
    //20250101로 생성된 sam 파일을 ^| 추가가 필요할 경우 사용(이미생성된 SAM파일을 수정하는 방식)
    await reCreateSamFileAddParam();
  } else if (pcsnClCd == "77") {
    //03번의 mergeFileRenameBaseYmd(),reCreateSamFile() 일별로 돌리고 난후 실행해야함
    //await ldgrIemIebFileNmAllUpdate();
    //--------------------------------------
    // 서버간 파일 동기화
    //let basePath = `/data/bdpetl/recv/iem/ieb/${basDt}/`;
    //await sync(basePath);
    writeLog("=============>>basDt::::" + basDt);

    //000D에 인서트 청킹데이터 인서트(머지된파일)
    //await util.resetOriginResultReGen("iemieb", "0003");
    //await util.resetOriginResultReGen("iemieb", "0000");
    // 비식별화 데이터 생성
    //await util.insertMaskingDataMaskingAll("iemieb", batchId);

    // 비식별화 데이터 생성
    await util.insertMaskingData(
      "",
      "iemieb",
      `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      "",
      "iemieb",
      `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`
    );

    //배치수행 최종완료시간
    await dbBatch.updateBatchFinishTime("", "01", "01");
  } else if (pcsnClCd == "99") {
    //01번에 있던거 백업

    // 서버간 파일 동기화
    let basePath = `/data/bdpetl/recv/iem/ieb/${basDt}/`;
    await sync(basePath); //개발에서는 주석으로 막고 실행
    // finFile 체크
    await finFileCheck(basDt, basePath);

    await makeDir("iem", "ieb");

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/iem/ieb/${basDt}/meta/MetaFile${basDt}`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/ieb", basDt);
      process.exit(0);
    }
    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 종료-------------------------------

    const assz_btch_acmp_id = await batchStart(); //배치수행로그 입력 및 배치ID채번
    await fileCopy(assz_btch_acmp_id); // 메타 입력 및 파일 통합
    await drmUnlock(); //DRM해제

    await hwptoPdfOrigin(assz_btch_acmp_id); //단건으로 처리
    await pdfMergeOrigin(assz_btch_acmp_id); //이미지는 머지후 처리  20 82

    await drawLine();
    await hwptoPdf(assz_btch_acmp_id); //단건으로 처리
    await pdftoText(assz_btch_acmp_id); //단건으로 처리

    //-----------------------------------------------머지
    await pdfMerge(assz_btch_acmp_id); //이미지는 머지후 처리  20 82
    await pdftoImg(assz_btch_acmp_id); //머지된 pdf로 처리 20 82 --> 이미지처리 결과 업데이트
    await util.imgToDp2(assz_btch_acmp_id, "iemieb", basDt); //전체 (첨부,부속이미지)이미지를 텍스트로
    //-----------------------------------------------머지
    await util.runImgJeff(assz_btch_acmp_id, "iemieb", basDt); //DBselect 엔진호출   DBupdate Dbinsert
    await util.runJeff2(assz_btch_acmp_id, "iemieb", basDt);
    //-----------------------------------------------변경대상
    await jsonMerge02(assz_btch_acmp_id); //pdf jSON 병합    20 -  82   -> 84
    await jsonMerge01(assz_btch_acmp_id); //pdf jSON  img JSON 병합   20 84 -> 22
    await makeMeta(assz_btch_acmp_id);
    await gaiFileCopy(assz_btch_acmp_id);

    //--------------자산화아이디로 머지된파일의 정보 수정(기존은 물리적파일 생성후 자산화아이디가 생기기 때문에)
    //DB update --> 000m만 바뀌는 걸로 결정...추후 변경있을수 있음..20250813

    //머지된 물리적 파일명 리네임(이부분에서 실패하면 이기능 이후로만 다시 실행)
    await mergeFileRename(assz_btch_acmp_id);

    /*--------- 후처리 작업 ---------*/
    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/ieb", basDt);

    let sendPath = `/data/bdpetl/send/gai/gai/ieb/${basDt}/`;
    await sync(sendPath);
    // 원장 파일 동기화
    await moveAssetData("/data/asset/iem/ieb", basDt);

    //-----------------------------------------------
  }
  await dbAssetRlt.dbEnd();
  await dbGaiMeta.dbEnd();
  await dbAssetLog.dbEnd();
  await dbMetaMain.dbEnd();
  await dbBatch.dbEnd();
  await dbImgRlt.dbEnd();
  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃iemieb 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃");
}

main();
