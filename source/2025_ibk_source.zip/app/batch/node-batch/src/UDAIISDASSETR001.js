const fs = require("fs");
const util = require("../util");
const {
  getUnfcIdFromIdntId,
  getUnfcIdFromTodayCheckId,
  updateBatchId,
  updateErorVl,
  selectOneForUpdate,
  updateOriginMaster,
  selectOne,
  selectMetaDocNmIis,
  updateOnlyAsszScd,
} = require("../sql/TB_UDA_UAI000M");
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const { insertHistory } = require("../sql/TB_UDA_UAI000H");
const dbAssetLog = require("../sql/TB_UDA_UAI901L");
const dbImgRlt = require("../sql/TB_UDA_UAI912L");
const dbAssetRlt = require("../sql/TB_UDA_UAI910L");
const {
  COMMON_CODES,
  EROR_CODES,
  batchStart,
  getBatchId,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  updateLdgrUpdateSelfPool,
  updateLdgrDupCreateData,
  sync,
  finFileCheck,
  getFileInfo,
  finFileCreate,
  moveAssetData,
  insertLdgrIis,
  updateLdgrIis,
  insertLdgrMaster,
  mergeDocument,
  updateLdgrSelfPool,
  getSafeBaseDt,
  recvMetaFileCheck,
} = require("./common");
const dayjs = require("dayjs");
const { exec } = require("child_process");
const path = require("path");

const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbMetaMain = require("../sql/TB_UDA_UAI874M");
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

/*
  20250709
  CBKIM
  DB는 한번만 커넥션하고 pool을 인자로 던져서 처리하도록 변경
  ex) dbMetaMain.insertMeta(pool,...)
*/
const { Pool } = require("pg");
const config = require("../config");

const batchId = getBatchId(process.argv[1]);

async function makeDir(basDt) {
  const dirs = [
    `/data/asset/iis/iis/${basDt}/att`,
    `/data/asset/iis/iis/${basDt}/dp`,
    `/data/asset/iis/iis/${basDt}/json`,
    `/data/asset/iis/iis/${basDt}/origin`,
    `/data/asset/iis/iis/${basDt}/pdf`,
    `/data/asset/iis/iis/${basDt}/txt`,
    `/data/asset/iis/iis/${basDt}/img`,
    `/data/asset/iis/iis/att`,
    `/data/asset/iis/iis/dp`,
    `/data/asset/iis/iis/json`,
    `/data/asset/iis/iis/origin`,
    `/data/asset/iis/iis/pdf`,
    `/data/asset/iis/iis/txt`,
    `/data/asset/iis/iis/img`,
    `/data/bdpetl/send/gai/gai/iis/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*----------------------main meta insert ----------------------*/
async function mainMetaInsert(pool, basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------mainMetaInsert()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const sourceBase = `/data/bdpetl/recv/iis/iis/${basDt}/file`;
  const targetBase = `/data/asset/iis/iis/${basDt}/origin`;

  const masterInfo = fs.readFileSync(
    // `/data/potaltest/${basDt}/meta/AC_BOARD.dat`,
    `/data/asset/iis/iis/${basDt}/meta/fundMetaFile_conv.dat`,
    "utf-8"
  );
  const lines_m = masterInfo.split("\n");

  let result = await selectUnfcSeq(pool, "IISIIS");
  let idx = result.rows[0].idsqn;

  for (const line of lines_m) {
    if (line.trim() === "") continue;

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      orgn_data_rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_orgn_pcsn_dcd,
      atch_yn,
      atch_sqn,
      assz_dcmn_clsf_id,
      conn_ttl_nm,
      cnvs_grp_cd,
      assz_fund_dcmn_dcd,
      assz_fund_new_abl_yn,
      sale_fnsh_ymd,
      trth_file_nm,
    ] = line.split("^|");
    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`원천키없음 ${assz_cfbo_idnt_id}`);
      continue;
    } else {
      totalCnt++;

      let assz_unfc_id = null;
      let errCd = EROR_CODES.EROR_VL_SUCCESS;
      let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      let newFileNm = `${file_nm}.pdf`;
      const ext = path.extname(newFileNm).toLowerCase();

      let filename = "";

      let sourcePath = path.join(sourceBase, newFileNm);
      let targetPath = "";

      try {
        fs.accessSync(sourcePath);
      } catch (err) {
        writeLog(`파일없음: ${sourcePath}`);
        process.exit(1);
      }

      /**
       * fileinfo 저장, 파일크기, 난수값
       */
      const fileInfo = await getFileInfo(sourcePath);

      // 이미 수행한 건일경우
      const checkItem = await getUnfcIdFromTodayCheckId(
        "IISIIS",
        assz_cfbo_idnt_id,
        null,
        file_sqn,
        atch_sqn,
        basDt
      );

      writeLog(assz_orgn_pcsn_dcd);
      // 재수행 조건일 경우
      // 메타정보에 D케이스가 온다면 협의되지 않은건으로 재수행처리함 (D없음)
      if (
        checkItem.rows.filter((d, i) => d.assz_orgn_pcsn_dcd != "D").length > 0
      ) {
        writeLog(`이미 처리함 ${assz_cfbo_idnt_id} ${assz_btch_acmp_id}`);
        assz_unfc_id = checkItem.rows[0].assz_unfc_id;
        filename = `${newFileNm}`;
        targetPath = path.join(targetBase, filename);
        await updateBatchId(checkItem.rows[0].assz_unfc_id, assz_btch_acmp_id);
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_INIT);
        successCnt++;
      } else {
        // 삭제조건 신규가능여부 N, 판매종료년월일 < NOW
        if (
          "N" === assz_fund_new_abl_yn &&
          sale_fnsh_ymd < dayjs().format("YYYYMMDD")
        ) {
          let result = await getUnfcIdFromIdntId(
            "IISIIS",
            assz_cfbo_idnt_id,
            atch_sqn
          );

          if (result.rowCount == 0) {
            writeLog(`삭제건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);

            assz_unfc_id = await getUnfcId("IISIIS", ++idx);

            filename = `${newFileNm}`;
            targetPath = path.join(targetBase, filename);

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_UNSUCCESS,
              EROR_CODES.EROR_VL_UNSUCCESS_STR,
              targetPath, //assz_pcsn_file_path_nm,
              String(fileInfo.size),
              fileInfo.md5,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrIis(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              cnvs_grp_cd,
              assz_fund_dcmn_dcd,
              assz_fund_new_abl_yn,
              sale_fnsh_ymd,
              trth_file_nm,
              batchId
            );

            failCnt++;
            continue;
          } else {
            assz_unfc_id = result.rows[0].assz_unfc_id;
            await updateLdgrSelfPool(
              result.rows[0].assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_DELETE
            );
            successCnt++;
          }
        } else if ("C" === assz_orgn_pcsn_dcd) {
          assz_unfc_id = await getUnfcId("IISIIS", ++idx);

          filename = `${newFileNm}`;
          targetPath = path.join(targetBase, filename);

          //원장마스터 인서트
          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_INIT, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
            assz_cfbo_idnt_id,
            null,
            null,
            assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_SUCCESS,
            EROR_CODES.EROR_VL_SUCCESS_STR,
            targetPath, //assz_pcsn_file_path_nm,
            String(fileInfo.size),
            fileInfo.md5,
            assz_btch_acmp_id,
            batchId
          );

          //업무별원장 인서트
          await insertLdgrIis(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            file_nm,
            file_sqn,
            assz_orcp_file_path_nm,
            orgn_data_rgsr_id,
            rgsn_ts,
            amnn_ts,
            assz_orgn_pcsn_dcd,
            atch_yn,
            atch_sqn,
            assz_dcmn_clsf_id,
            conn_ttl_nm,
            cnvs_grp_cd,
            assz_fund_dcmn_dcd,
            assz_fund_new_abl_yn,
            sale_fnsh_ymd,
            trth_file_nm,
            batchId
          );
          successCnt++;
        } else if ("U" == assz_orgn_pcsn_dcd) {
          let result = await getUnfcIdFromIdntId(
            "IISIIS",
            assz_cfbo_idnt_id,
            atch_sqn
          );

          if (result.rowCount == 0) {
            writeLog(`업데이트건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);

            assz_unfc_id = await getUnfcId("IISIIS", ++idx);

            filename = `${newFileNm}`;
            targetPath = path.join(targetBase, filename);

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_UNSUCCESS2,
              EROR_CODES.EROR_VL_UNSUCCESS2_STR,
              targetPath, //assz_pcsn_file_path_nm,
              String(fileInfo.size),
              fileInfo.md5,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrIis(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              cnvs_grp_cd,
              assz_fund_dcmn_dcd,
              assz_fund_new_abl_yn,
              sale_fnsh_ymd,
              trth_file_nm,
              batchId
            );

            failCnt++;
            continue;
          } else {
            let cData = await selectOne("IISIIS", assz_cfbo_idnt_id, atch_sqn);
            assz_unfc_id = cData.rows[0].assz_unfc_id;
            filename = `${newFileNm}`;
            targetPath = path.join(targetBase, filename);
            writeLog(`Update! ${assz_unfc_id}`);

            // 'U' 로 변경
            // 원장마스터 수정
            await updateOriginMaster(
              assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_INIT,
              fileInfo.size, // 파일사이즈
              fileInfo.md5, // 파일해시
              "", // 자산화처리파일 경로명
              errCd, 
              errStr
            );

            // 업무원장 업데이트
            await updateLdgrIis(assz_unfc_id, "U");
            
            successCnt++;
          }
        }
      }

      try {
        targetPath = path.join(targetBase, filename);
        if (!fs.existsSync(targetPath)) {
          fs.copyFileSync(sourcePath, targetPath);
        }
      } catch (err) {
        writeLog(
          `${EROR_CODES.EROR_VL_COPY_FAILED_STR} ${sourcePath}:${targetPath}`
        );
        errCd = EROR_CODES.EROR_VL_COPY_FAILED;
        errStr = EROR_CODES.EROR_VL_COPY_FAILED_STR;
        // 배치메타저장
        await dbMetaMain.insertMeta(
          pool,
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          cnvs_grp_cd,
          assz_fund_dcmn_dcd,
          assz_fund_new_abl_yn,
          sale_fnsh_ymd,
          trth_file_nm,
          targetPath,
          batchId
        );

        failCnt++;

        await updateErorVl(assz_unfc_id, errCd, errStr);
        //자산화상태코드 예외로 변경해야함----------------------
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
        continue;
      }

      // 배치메타저장
      await dbMetaMain.insertMeta(
        pool,
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        cnvs_grp_cd,
        assz_fund_dcmn_dcd,
        assz_fund_new_abl_yn,
        sale_fnsh_ymd,
        trth_file_nm,
        targetPath,
        batchId
      );

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      // let astpCd = path.extname(filename).toLowerCase() === ".pdf" ? "PD" : "JG";
      let astpCd = "PD";

      await dbAssetLog.insertLog(
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        atch_yn,
        astpCd, //HW      HWP PD  PDF ML  HTML
        "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
        "C", //C 신규 U 수정 D삭제
        "N", //이미지처리여부
        null,
        null,
        null,
        "CH", //NO(None),CH(변환)
        null,
        null,
        null,
        "SI", //SI(단일 문서),MU(멀티 통합 문서)
        strDate, //원본변환시작일시
        endDate, //원본변환종료일시
        targetPath,
        errCd, //에러 0000
        errStr,
        batchId,
        "Y"
      );

      writeLog(`파일복사 성공 ${targetPath}`);
    }
  }
  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "mainMetaInsert"
  );

  writeLog(
    "----------------------------mainMetaInsert()종료----------------------------"
  );
}

/*----------------------DRM해제 작업----------------------*/

async function drmUnlock(basDt) {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );
  const dirs = ["origin"];
  let result = "";

  try {
    fs.mkdirSync(`/data/asset/iis/iis/${basDt}`, { recursive: true });
  } catch (err) {
    writeLog(`디렉터리 생성 실패 : /data/asset/iis/iis/${basDt}:${err}`);
  }
  for (const dir of dirs) {
    const fullPath = `/data/asset/iis/iis/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`drm오류: ${fullPath}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

/*----------------------PDF->IMG 추출----------------------*/
async function pdftoImg(basDt, assz_btch_acmp_id) {
  writeLog(
    "---------------------------- pdftoImg() 시작 ----------------------------"
  );

  // 기본 변수 셋팅
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);

  const imagepdfFolder = `/data/asset/iis/iis/${basDt}/origin`;
  const outFolder = `/data/asset/iis/iis/${basDt}/dp`;
  const commands = [];

  // UDA자산화처리로그 조회
  const logData = await dbAssetLog.selectLog06(assz_btch_acmp_id, "02");

  for (const ld of logData.rows) {
    // PDF일 경우
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);
    if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      let command = `python3 /app/pdftoimg/pdftoimg.py "${imagepdfFolder}/${oriFileName}" "${outFolder}" "${ld.assz_btch_acmp_id}" "${ld.assz_unfc_id}" "${ld.uda_sys_lsmd_id}"`;
      commands.push({
        assz_btch_acmp_id: ld.assz_btch_acmp_id,
        assz_unfc_id: ld.assz_unfc_id,
        oriFileName: oriFileName,
        header: ld,
        command: command,
      });
    }
  }

  // PDF->IMG 추출 모듈 실행
  const tasks = commands.map((data, idx) => limit(() => pti(data)));

  for await (const result of tasks) {
    let errCd = "0000";
    let errStr = "";

    totalCnt++;
    if (result.success) {
      errCd = EROR_CODES.EROR_VL_SUCCESS;
      errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      successCnt++;
    } else {
      errCd = EROR_CODES.EROR_VL_IMG_FAILED;
      errStr = EROR_CODES.EROR_VL_IMG_FAILED_STR;
      failCnt++;
    }
    await dbAssetLog.updateLog02(
      assz_btch_acmp_id,
      result.header.assz_cfbo_idnt_id,
      "03",
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
    await updateErorVl(result.assz_unfc_id, errCd, errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoImg");
  writeLog(
    "---------------------------- pdftoImg() 종료 ----------------------------"
  );
}

/*---------------------- PDF->IMG 추출 모듈 실행 ----------------------*/
async function pti(data) {
  return new Promise((resolve, reject) => {
    const command = data.command;
    writeLog(command);
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr);
        return;
      }
      if (stdout.includes("[Success]")) {
        writeLog(`추출성공: ${data.oriFileName}`);
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) errMsg = match[1];

        let errStr = `[Fail 출력됨]: ${data.oriFileName} / 사유 : ${errMsg}`;
        resolve({
          success: false,
          errCd: null,
          errStr: errStr,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
        });
      } else {
        writeLog(`pdftoImg 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

async function ptt(data) {
  const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

  return new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      let oriFileName = data.oriFileName;
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error);
        return;
      }
      writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        writeLog(`변환성공: ${oriFileName}`);
        resolve({
          success: true,
          txtOutFullPath: data.txtOutFullPath,
          errCd: "0000",
          errStr: "",
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) {
          errMsg = match[1];
        }
        writeLog(`변환실패 [Fail 출력됨]: ${oriFileName} / 사유 : ${errMsg}`);
        let errCd = "0410";
        let errStr =
          errMsg == "" ? `변환실패 [Fail 출력됨]: ${oriFileName}` : errMsg;
        resolve({
          success: false,
          errCd: errCd,
          errStr: errStr,
          txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else {
        writeLog(`결과미확인: ${oriFileName}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------pdftoText----------------------*/
async function pdftoText(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let outputDir = `/data/asset/iis/iis/${basDt}/txt`;
  fs.mkdirSync(outputDir, { recursive: true });

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let commands = [];

  const logData = await dbAssetLog.selectLog06(assz_btch_acmp_id, "03");
  //pdftotxt 변환
  for (const ld of logData.rows) {
    totalCnt++;
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);

    const txtFileName = oriFileName
      .replace(".pdf", ".txt")
      .replace(".PDF", ".txt"); //확장자변경
    const txtOutFullPath = `${outputDir}/${txtFileName}`;
    let command = `python3 /app/pdftotxt/pdftotxt.py "${ld.assz_orcp_file_path_nm}" "${txtOutFullPath}"`;
    command = command.replace(/`/g, "\\`");
    commands.push({
      assz_btch_acmp_id: ld.assz_btch_acmp_id,
      assz_unfc_id: ld.assz_unfc_id,
      oriFileName: oriFileName,
      header: ld,
      command: command,
      txtOutFullPath: txtOutFullPath,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => ptt(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      "04",
      null,
      null,
      null,
      null,
      null,
      result.staDate, //변환시작일시
      endDate, //변환종료일시
      result.txtOutFullPath,
      null,
      null,
      null,
      null,
      result.errCd,
      result.errStr
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

/*----------------------jsonMerge----------------------*/
async function jsonMerge(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge() 시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const outFolder = `/data/asset/iis/iis/${basDt}/json`;
  console.log(assz_btch_acmp_id);
  const oriJsonFiles = await dbAssetLog.selectLog06(assz_btch_acmp_id, "04");

  for (const oriJsonFile of oriJsonFiles.rows) {
    if (oriJsonFile.assz_pcsn_tgt_tcd != "PD") {
      writeLog("jsonMerge continue 원본이 PDF가 아닙니다.");
      continue;
    }
    totalCnt++;
    let file_path = oriJsonFile.assz_orcp_file_path_nm;
    writeLog(file_path);
    let fileNameExt = path.basename(file_path);
    let fileName = `${path.parse(fileNameExt).name}.json`;

    fs.writeFileSync(
      `/data/asset/iis/iis/${basDt}/json/${fileName}`,
      JSON.stringify({ data: [] }, null, 2),
      "utf-8"
    );

    const pdfFilePath = path.join(outFolder, fileName);

    const startDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    const imgJsonFiles = await dbImgRlt.selectFilePathNm(
      assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id
    );
    const imgJsonList = imgJsonFiles.rows.map(
      (row) => row.assz_pcsn_file_path_nm
    );

    let errCd = "0000";
    let errStr = "";

    try {
      mergeJsonFiles(pdfFilePath, imgJsonList);
      successCnt++;
      const fileStat = fs.statSync(pdfFilePath);
      const fileSize = Math.floor(fileStat.size / 1024);

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      // 성공 로그 insert
      await dbAssetRlt.insertAst(
        oriJsonFile.assz_btch_acmp_id,
        oriJsonFile.assz_unfc_id,
        "IISIIS",
        oriJsonFile.assz_cfbo_idnt_id,
        oriJsonFile.dcmn_nm,
        fileName,
        oriJsonFile.assz_pcsn_tgt_tcd,
        oriJsonFile.assz_pcsn_tcd,
        fileSize,
        "PD",
        null,
        null,
        pdfFilePath,
        oriJsonFile.url_adr,
        oriJsonFile.rgsn_ts,
        oriJsonFile.amnn_ts,
        startDate,
        endDate,
        "N",
        null,
        oriJsonFile.uda_sys_lsmd_id,
      );
    } catch (err) {
      console.log("에러메세지:::" + err);
      writeLog(`jsonMerge 변환 실패: ${pdfFilePath}`);
      errCd = "0510";
      errStr = `jsonMerge 변환 실패: ${pdfFilePath}:::::${err.message}`;
      failCnt++;
      
      await dbAssetLog.updateLog02(
        assz_btch_acmp_id,
        oriJsonFile.assz_cfbo_idnt_id,
        "84",
        null,
        null,
        null,
        null,
        errCd,
        errStr
      );
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jsonMerge");
  writeLog(
    "----------------------------jsonMerge() 종료----------------------------"
  );
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃ IISIIS 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃");

  if (process.argv.length < 4) {
    writeLog("node UDAIISDASSETR001.js 01 YYYYMMDD");
  }

  const pcsnClCd = process.argv[2];
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[3];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    process.exit(1);
  }
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const in_assz_btch_acmp_id = process.argv[4];

  const pool = new Pool(config.db);

  if (pcsnClCd == "01") {
    let basePath = `/data/bdpetl/recv/iis/iis/${basDt}/`;
    // 서버간 수신 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    // 배치수행로그 입력 및 배치ID채번
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IISIIS",
      "01", //01        수집 02 자산화 03       전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1        메타+파일 T2    DB T3   지식샘
      "01" //assz_tgt_sys_cd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/asset/iis/iis/${basDt}/meta/fundMetaFile_conv.dat`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/iis", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    await makeDir(basDt);

    await mainMetaInsert(pool, basDt, assz_btch_acmp_id);

    await drmUnlock(basDt);

    await pdftoImg(basDt, assz_btch_acmp_id);
    await pdftoText(basDt, assz_btch_acmp_id);

    await util.imgToDp2(assz_btch_acmp_id, "iisiis", basDt);

    await util.runImgJeff(assz_btch_acmp_id, "iisiis", basDt);
    await util.runJeff2(assz_btch_acmp_id, "iisiis", basDt);
    // json 결과 병합
    await jsonMerge(basDt, assz_btch_acmp_id);

    await moveAssetData("/data/asset/iis/iis", basDt);

    // //000D에 인서트 청킹데이터 인서트(머지된파일)
    await util.resetOriginResult(assz_btch_acmp_id, "iisiis", basDt, "0000");

    // 학습데이터 파일복사
    await util.moveToLearn("iisiis", assz_btch_acmp_id);

    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);

    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "iisiis",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iisiis",
      EROR_CODES.EROR_VL_SUCCESS
    );

    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    await dbBatch.updateBatchFinishTime(in_assz_btch_acmp_id, "01", "01");
  }

  await pool.end();
  await dbBatch.dbEnd();

  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃ IISIIS 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃");
}

main();
