const fs = require("fs");
const util = require("../util.js");
const path = require("path");
const dayjs = require("dayjs");
const {
  EROR_CODES,
  COMMON_CODES,
  selectCountLifecycle,
  insertLifecycle,
  discardDocument,
} = require("./common.js");
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const { writeLog, summaryLog } = require("../log.js"); // 로그 모듈
const db = require("../sql/TB_UDA_UAIUNIT.js");
const {
  deleteAssDtl,
  insertAssDtl,
  getAssDtlSeq,
} = require("../sql/TB_UDA_UAI000D");
const { selectMetaSuccess, updateAsszScd } = require("../sql/TB_UDA_UAI000M");

const { exec } = require("child_process");
// const batchId = getBatchId(process.argv[1]);
const pcsnClCd = process.argv[2];
const basDtArg = process.argv[3];



/*---------------------- HTML TO PDF (02생성) ----------------------*/
async function htmltoPdf() {
  writeLog(
    "----------------------------htmltoPdf()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 메인메타 성공(HTML생성된 것만) 조회
  const metaData = await db.aikkmsSelectMetaSuccess();
  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_cfbo_idnt_id,
      assz_unfc_id,
      assz_orcp_file_path_nm,
      base_dt,
    } = rowMetaData;


    const oriFileName = path.basename(assz_orcp_file_path_nm);
    const chgFileName = oriFileName.replace(".html", ".pdf");
    const chgFilePath = `/data/asset/aik/kms/${base_dt}/pdf/${chgFileName}`;
    const chgOriginFilePath = `/data/asset/aik/kms/${base_dt}/originpdf/${chgFileName}`;

    // 테스트일 경우
    let pythonPath = "python";
    if (pcsnClCd.includes("test")) {
      pythonPath = `/app/anaconda3/bin/python3`;
    }

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const command = `${pythonPath} /app/htmltopdf/htmltopdf.py "${assz_orcp_file_path_nm}" "/data/asset/aik/kms/${base_dt}/originpdf/${chgFileName}"`;
    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      assz_cfbo_idnt_id: assz_cfbo_idnt_id,
      chgFilePath: chgFilePath,
      chgOriginFilePath: chgOriginFilePath,
      assz_orcp_file_path_nm: assz_orcp_file_path_nm,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, "", "htmltoPdf");
  writeLog(
    "----------------------------htmltoPdf()종료----------------------------"
  );
}

// HTML TO PDF
async function htp(data) {
  return await new Promise((resolve, reject) => {
    exec(data.command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${error}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stderr}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stdout}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      } else {
        writeLog(`htmltoPdf 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

// 원장결과 재생성
async function resetOriginResult(assz_btch_acmp_id, sysName, eror_vl) {
  writeLog(
    `---------------------------resetOriginResult(${sysName}) 시작----------------------------`
  );

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  //const outputDir = `/data/asset/${sysDir}/${basDt}/json`;
  const outputDir = `/data/asset/${sysDir}/json`;

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccess(
    assz_btch_acmp_id,
    sysName.toUpperCase(),
    eror_vl
  );

  for (const rowMetaData of metaData.rows) {
    try {
      let outFullPath = `${outputDir}/${rowMetaData.assz_unfc_id}.json`;
      let erorVl = COMMON_CODES.ASSZ_SCD_SUCCESS;
      if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
        outFullPath = `${outputDir}/${rowMetaData.assz_cfbo_idnt_id}.json`;
        erorVl = COMMON_CODES.ASSZ_SCD_INIT;
      }
      let outOriginPdfFullPath = outFullPath
        .replaceAll("/json", "/originpdf")
        .replaceAll(".json", ".pdf");
      // 원장 자산화 상태코드 변경
      await updateAsszScd(
        rowMetaData.assz_unfc_id,
        erorVl,
        outOriginPdfFullPath
      ); // 000m originpdf 경로가 되어야한다
      const rawData = fs.readFileSync(outFullPath, "utf8");
      const jsonData = JSON.parse(rawData);

      // 원장 결과 삭제 후 저장
      await deleteAssDtl(rowMetaData.assz_unfc_id);

      let getAssDtlSeqData = await getAssDtlSeq(rowMetaData.assz_unfc_id);
      let assz_rslt_dtl_sqn = getAssDtlSeqData.rows[0].idx;

      if (
        Object.keys(jsonData).length === 0 ||
        Object.keys(jsonData.data).length === 0
      ) {
        // 원장 결과 저장
        await insertAssDtl(
          rowMetaData.assz_unfc_id,
          ++assz_rslt_dtl_sqn,
          "CK",
          0,
          0,
          outFullPath,
          "",
          0,
          0,
          0,
          0,
          rowMetaData.uda_sys_lsmd_id
        );
      } else {
        for (const ck of jsonData.data) {
          let { page, chunk_seq, chunk } = ck;
          const chunkChg = chunk.replace(/\u0000/g, "");
          // 원장 결과 저장
          await insertAssDtl(
            rowMetaData.assz_unfc_id,
            ++assz_rslt_dtl_sqn,
            "CK",
            page,
            chunk_seq,
            outFullPath,
            chunkChg,
            0,
            0,
            0,
            0,
            rowMetaData.uda_sys_lsmd_id
          );
        }
      }
    } catch (err) {
      writeLog(
        `자산화 원장 결과 ERROR  ${rowMetaData.assz_unfc_id}: ${err.message}`
      );
    }
  }

  writeLog(
    `---------------------------resetOriginResult(${sysName}) 종료----------------------------`
  );
}

// 수명주기 저장
async function lifecycleInsert(sysName, eror_vl) {
  writeLog(
    "----------------------------lifecycleInsert() 시작----------------------------"
  );

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }
  
  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await db.selectMetaSuccessLifecycle(
    sysName.toUpperCase(),
    eror_vl
  );

  for (const rowMetaData of metaData.rows) {
    try {
      // 수명주기 조회
      let result = await selectCountLifecycle(rowMetaData.assz_unfc_id);
      
      // 수명주기가 존재하지 않을 경우
      if (result.rows[0].count == 0) {
        if (rowMetaData.assz_pcsn_tcd == "C" || rowMetaData.assz_pcsn_tcd == "U" || rowMetaData.assz_pcsn_tcd == "N") {
          // 수명주기 저장
          await insertLifecycle(
            rowMetaData.assz_unfc_id,
            rowMetaData.orgn_data_rgsr_id,
            rowMetaData.rgsr_dept_id,
            rowMetaData.rgsn_ts
              ? rowMetaData.rgsn_ts
              : COMMON_CODES.DEFAULT_NULL_DATE,
            rowMetaData.uda_sys_lsmd_id
          );
        }

        if (rowMetaData.assz_pcsn_tcd == "D") {
          await discardDocument(rowMetaData.assz_unfc_id);
        }
      // 수명주기가 존재할 경우
      } else {
        // 문서 폐기처리
        if (rowMetaData.assz_pcsn_tcd == "D") {
          await discardDocument(rowMetaData.assz_unfc_id);
        }
      }
    } catch (err) {
      writeLog(`생명주기 저장 ERROR  : ${err.message}`);
    }
  }

  writeLog(
    "---------------------------lifecycleInsert() 종료----------------------------"
  );
}


/*---------------------- main 함수 ----------------------*/
async function main() {
  if (pcsnClCd == "01") {
  
  // 지식샘 html to json 전체 하기
  } else if (pcsnClCd == "aikkms_htmltojson_all") {
    await htmltoPdf();
  
    // 전체 문서 저장 (쿼리실행)
  } else if (pcsnClCd == "all_document_insert") {
    
    await db.mergeDocument();

    // 전체 원장 결과 테이블 저장
  } else if (pcsnClCd == "all_000d_insert") {
    // 내규
    //await resetOriginResult("iemiea", EROR_CODES.EROR_VL_SUCCESS);
    // 지식샘
    //const successCodeIn = `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS},${EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS}`;
    //await resetOriginResult("20250924AIKKMS000001", "aikkms", successCodeIn);
    // 시행문
    //await resetOriginResult("kmswpt", EROR_CODES.EROR_VL_SUCCESS);
    

    // 펀드
    //await resetOriginResult("20250924IISIIS000001", "iisiis", EROR_CODES.EROR_VL_SUCCESS);
    // 카드몰
    //await resetOriginResult("csmcsm", EROR_CODES.EROR_VL_SUCCESS);
    // 은행상품설명서
    //await resetOriginResult("kms/wpt/epn", EROR_CODES.EROR_VL_SUCCESS);
    // 플라자
    //await resetOriginResult("kms/wpt/plz", EROR_CODES.EROR_VL_SUCCESS);
    // 업무매뉴얼
    //await resetOriginResult("iemieb", `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`);

    // 전체 수명주기 저장
  } else if (pcsnClCd == "all_lifecycle_insert") {
    /*
    // 내규
    await lifecycleInsert("iemiea", `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_NOCHANGE_SUCCESS}`);
    // 지식샘
    const successCodeIn = `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS},${EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS}`;
    //await lifecycleInsert("aikkms", successCodeIn);
    // 시행문
    await lifecycleInsert("kmswpt", EROR_CODES.EROR_VL_SUCCESS);
    // 펀드
    await lifecycleInsert("iisiis", EROR_CODES.EROR_VL_SUCCESS);
    // 카드몰
    await lifecycleInsert("csmcsm", EROR_CODES.EROR_VL_SUCCESS);
    // 은행상품설명서
    await lifecycleInsert("kms/wpt/epn", EROR_CODES.EROR_VL_SUCCESS);
    // 플라자
    await lifecycleInsert("kms/wpt/plz", EROR_CODES.EROR_VL_SUCCESS);
    // 업무매뉴얼
    await lifecycleInsert("iemieb", `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_MSUCCESS}`);
    */
     
  }

  await db.dbEnd();

  return true;
}

main();
