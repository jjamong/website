const fs = require("fs");
const dayjs = require("dayjs");
const { getBatchId, batchStart, getSafeBaseDt } = require("./common");
const axios = require("axios");
const { Agent } = require("http");
const { writeLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

// util이 불려진 시점부터 instace 생성하고 30초마다 재생성 keepAlive 처리
let agent = createNewAgent();
let axiosInstance = createAxiosInstance(agent);

//startAgentResetLoop();

function createNewAgent() {
  return new Agent({
    keepAlive: true,
    //keepAliveMsecs: 30000,
    maxSockets: 5000,
    maxFreeSockets: 1000,
  });
}

function createAxiosInstance(agent) {
  return axios.create({
    httpAgent: agent,
    timeout: 0,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });
}

let META_INFOS = {};

function getMETA_INFOS(basDt) {
  return {
    BDP_UDA_CMIB01M: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/BDP_UDA_CMIB01M_${basDt}.dat_NEW`,
      cols: {
        0: "BRCD|VARCHAR",
        1: "LSMD_YMD|VARCHAR",
        2: "BZN|VARCHAR",
        3: "KRN_BRM|VARCHAR",
        4: "ENSN_BRM|VARCHAR",
        5: "ZPCD|VARCHAR",
        6: "BRNC_GU_BSC_ADR|VARCHAR",
        7: "BRNC_GU_DTL_ADR|VARCHAR",
        8: "BRNC_TEL_LLN|VARCHAR",
        9: "BRNC_TPN_TON|VARCHAR",
        10: "BRNC_TPN_SRN|VARCHAR",
        11: "RPRS_FAX_LLN|VARCHAR",
        12: "RPRS_FAX_TON|VARCHAR",
        13: "RPRS_FAX_SRN|VARCHAR",
        14: "FAX_LLN|VARCHAR",
        15: "FXN_TON|VARCHAR",
        16: "FXN_SRN|VARCHAR",
        17: "CLCN_TEL_LLN|VARCHAR",
        18: "CLCN_TEL_TON|VARCHAR",
        19: "CLCN_TEL_SRN|VARCHAR",
        20: "BRNC_SCD|VARCHAR",
        21: "OLD_GICD|VARCHAR",
        22: "NOEC_CD|VARCHAR",
        23: "BRNC_DCD|VARCHAR",
        24: "BRNC_LCTN_CD|VARCHAR",
        25: "COG_AREA_DCD|VARCHAR",
        26: "FXBR_DCD|VARCHAR",
        27: "FREX_BRCD|VARCHAR",
        28: "FEX_ONBR_YMD|VARCHAR",
        29: "MNEX_SCBR_YN|VARCHAR",
        30: "MNEX_SCBR_RGSN_YMD|VARCHAR",
        31: "FEX_CNTZ_BRCD|VARCHAR",
        32: "FRFN_CNBR_DCD|VARCHAR",
        33: "BOK_JRSD_UNCN_BRCD|VARCHAR",
        34: "PB_BRNC_YN|VARCHAR",
        35: "PB_BRNC_DCD|VARCHAR",
        36: "DREAM_ENPR_YN|VARCHAR",
        37: "RM_BRNC_YN|VARCHAR",
        38: "INDV_MAGR_CD|VARCHAR",
        39: "ENPR_MNAP_GRP_CD|VARCHAR",
        40: "RM_MNAP_GRP_CD|VARCHAR",
        41: "COH_LMT_AMT|NUMERIC",
        42: "INEL_MTBR_YN|VARCHAR",
        43: "EXMBR_YN|VARCHAR",
        44: "EXMBR_BRCD|VARCHAR",
        45: "IMDE_RCDE_BRNC_YN|VARCHAR",
        46: "OWN_DCD|VARCHAR",
        47: "ONL_NO|VARCHAR",
        48: "ONBR_YMD|VARCHAR",
        49: "CLSR_PBAN_YMD|VARCHAR",
        50: "CLOS_YMD|VARCHAR",
        51: "MBCD|VARCHAR",
        52: "UNFC_BRCD|VARCHAR",
        53: "RHDCD|VARCHAR",
        54: "JRSD_HQCD|VARCHAR",
        55: "BZSC_CD|VARCHAR",
        56: "TRSTL_MTHR_BRCD|VARCHAR",
        57: "RVST_MTBR_BRCD|VARCHAR",
        58: "BSHD_CD|VARCHAR",
        59: "RDSC_MTHR_BRCD|VARCHAR",
        60: "RNSS_MTHR_BRCD|VARCHAR",
        61: "ACON_BRCD|VARCHAR",
        62: "BOBM_NM|VARCHAR",
        63: "BRMG_EMN|VARCHAR",
        64: "EDPS_CSN|NUMERIC",
        65: "BRNC_BSOP_DCD|VARCHAR",
        66: "BKIN_GICD|VARCHAR",
        67: "BNCD|VARCHAR",
        68: "BOK_JRSD_SVBR_GICD|VARCHAR",
        69: "NW_ZPCD|VARCHAR",
        70: "BRNC_NW_BSC_ADR|VARCHAR",
        71: "BRNC_NW_DTL_ADR|VARCHAR",
        72: "HUB_EAI_RFLC_YN|VARCHAR",
        73: "PDF_EAI_RFLC_YN|VARCHAR",
        74: "BPM_EAI_RFLC_YN|VARCHAR",
        75: "OGZN_ATTCD|VARCHAR",
        76: "OGZN_KCD|VARCHAR",
        77: "BRNC_FGR6_KRN_NM|VARCHAR",
        78: "BRNC_FGR4_KRN_NM|VARCHAR",
        79: "BDP_ETL_BASE_YMD|VARCHAR",
        80: "BDP_ETL_JOB_TS|TIMESTAMP",
        81: "UDA_SYS_LSMD_ID|VARCHAR2",
        82: "UDA_SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIB01M",
    },
  };
}

async function upsertMeta(metaName, columns, rows) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();
  const tableName = META_INFOS[metaName].tableName;
  const numCols = columns.length;
  const values = [];

  try {
    const tuples = rows
      .map((row, rowIdx) => {
        const offset = rowIdx * numCols;

        row.forEach((val) => values.push(val));

        const placeholders = row
          .map((_, colIdx) => convertColumnType(offset, colIdx, metaName))
          .join(", ");
        return `(${placeholders})`;
      })
      .join(",\n");

    // console.log(tuples);
    let mergeSql = `
      MERGE INTO ${tableName} AS t
      USING (
        VALUES
        ${tuples}
      ) AS s(${columns.join(", ")})
    `;
    if (tableName == "TB_UDA_UAIE54D")
      mergeSql += `ON (t.${columns[0]} = s.${columns[0]} AND t.${columns[1]} = s.${columns[1]} AND t.${columns[2]} = s.${columns[2]} AND t.${columns[3]} = s.${columns[3]} AND t.${columns[4]} = s.${columns[4]} AND t.${columns[5]} = s.${columns[5]} AND t.${columns[6]} = s.${columns[6]} AND t.${columns[7]} = s.${columns[7]})`;
    else mergeSql += `ON (t.${columns[0]} = s.${columns[0]})`;
    mergeSql += `
      WHEN MATCHED THEN
        UPDATE SET
          ${columns
            .slice(1)
            .map((col) => `${col} = s.${col}`)
            .join(",\n      ")}
        WHEN NOT MATCHED THEN
          INSERT (${columns.join(", ")})
          VALUES (${columns.map((col) => `s.${col}`).join(", ")})
    `;
    // console.log(mergeSql);
    //console.log(tuples);
    //console.log(values.length);
    // console.log(values);
    await client.query(mergeSql, values);
  } catch (err) {
    writeLog(`${tableName} => 작업 상태 초기화 실패: ${err.message}`);
    // console.log(err);
  } finally {
    client.release();
    pool.end();
  }
}

function convertColumnType(offset, colIdx, metaName) {
  let str = `$${offset + colIdx + 1}`;
  let colType = META_INFOS[metaName].cols[colIdx].split("|")[1];
  let colName = META_INFOS[metaName].cols[colIdx].split("|")[0];

  if (colType) {
    if (colType == "TIMESTAMP")
      str = `TO_TIMESTAMP($${offset + colIdx + 1},'YYYYMMDDHH24MISS')`;
    if (colType == "DATE")
      str = `TO_DATE($${offset + colIdx + 1},'YYYY-MM-DD')`;
    if (colType == "NUMBER") str = `$${offset + colIdx + 1}::integer`;
    if (colType == "NUMERIC") str = `$${offset + colIdx + 1}::NUMERIC`;
  }

  // 20250618 BRCD lpad 처리
  if (colName === "BRCD") {
    str = `LPAD($${offset + colIdx + 1},4,'0')`;
  }

  return str;
}

(async () => {
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[2];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const batchId = getBatchId(process.argv[1]);

  const assz_btch_acmp_id = await batchStart(
    basDt,
    batchId,
    "TBB01M",
    "01", //01	수집 02	자산화 03	전송
    "02", //01	대기 02	수행 03	중단 04	오류 05	완료
    "T2", //T1	메타+파일 T2	DB T3	지식샘
    "01" //assz_tgt_sys_cd
  ); //배치수행로그 입력 및 배치ID채번

  META_INFOS = getMETA_INFOS(basDt);
  //console.log(META_INFOS);
  for (let meta of Object.keys(META_INFOS)) {
    //await parseMeta(meta, META_INFOS[meta].filePath);
    let content;
    try {
      content = fs.readFileSync(META_INFOS[meta].filePath, "utf8");
    } catch (e) {
      continue;
    }
    const lines = content.split("\n").filter((line) => line.trim() !== "");
    //console.log(lines.length);

    const rows = lines
      .map((line) => {
        let l = line.split("^|");
        l.pop();
        if (l.length > 2) {
          l.push(batchId);
          l.push(dayjs().format("YYYYMMDDHHmmss"));
          l = l.map((d, i) => (d == "null" ? null : d.trimEnd()));
        }
        return l;
      })
      .filter((line) => line.length > 2);

    const columns = Object.values(META_INFOS[meta].cols).map(
      (d, i) => d.split("|")[0]
    );
    //.join(", ");
    //console.log(columns);

    const maxRows = 1;
    writeLog(`${META_INFOS[meta].filePath} 진행`);
    for (let i = 0; i < rows.length; i++) {
      const chunk = rows.slice(i, i + maxRows);
      await upsertMeta(meta, columns, chunk);
      writeLog(
        `${META_INFOS[meta].tableName} : ${i + 1} / ${rows.length} UPSERT 완료`
      );
    }
  }

  //배치수행 최종완료시간
  await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  // DB 커넥션 해제
  await dbBatch.dbEnd();
})();
