// 내규 자산화 (IEM > IEA)
const fs = require("fs");
const util = require("../util");
const path = require("path");
const dayjs = require("dayjs");
const {
  getSafeBaseDt,
  getBatchId,
  batchStart,
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrMaster,
  updateLdgrSelfPool,
  getFileInfo,
  updateLdgrDupCreateData,
  moveAssetData,
  sync,
  mergeDocument,
  recvMetaFileCheck,
  finFileCreate,
} = require("./common");
const { exec, spawn } = require("child_process");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); // UDA배치기본
const dbMetaMain = require("../sql/TB_UDA_UAI004M"); //내규메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const { updateOriginMaster, updateOriginMasterIea, updateErorVl } = require("../sql/TB_UDA_UAI000M"); // 자산화결과기본(원장)

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  process.exit(1);
}
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------

/*---------------------- 폴더 생성 ----------------------*/
async function makeDir() {
  const dirs = [
    `/data/asset/iem/iea/${basDt}/att`,
    `/data/asset/iem/iea/${basDt}/dp`,
    `/data/asset/iem/iea/${basDt}/json`,
    `/data/asset/iem/iea/${basDt}/origin`,
    `/data/asset/iem/iea/${basDt}/originpdf`,
    `/data/asset/iem/iea/${basDt}/pdf`,
    `/data/asset/iem/iea/${basDt}/txt`,
    `/data/asset/iem/iea/${basDt}/img`,
    `/data/bdpetl/send/gai/gai/iea/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*------------------- 파일 copy ----------------------*/
async function fileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------fileCopy() 시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 메인메타 읽어오기
  let masterPath = `/data/bdpetl/recv/iem/iea/${basDt}/meta/master.DAT`;
  try {
    fs.accessSync(masterPath);
  } catch (err) {
    writeLog(`${masterPath} ${err}`);
    return;
  }

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "IEMIEA");
  let idx = result.rows[0].idsqn;
  let metas = await createMeta(masterPath);
  for (let i = 0; i < metas.length; i++) {
    totalCnt++;
    if (
      metas[i].assz_cfbo_idnt_id == "" ||
      metas[i].assz_cfbo_idnt_id == undefined ||
      metas[i].assz_cfbo_idnt_id == null
    ) {
      writeLog(`메타파일에 원천식별키 없음.`);
      failCnt++;
      continue;
    } else {
      // 비정형데이터자산화시스템최종변경ID
      metas[i].uda_sys_lsmd_id = "UDAIEADASSETR001";

      // 자산화배치수행ID
      metas[i].assz_btch_acmp_id = assz_btch_acmp_id;

      // 자산화처리파일경로명
      metas[i].assz_pcsn_file_path_nm = "";

      // 정상
      metas[i].eror_vl = EROR_CODES.EROR_VL_SUCCESS;
      metas[i].assz_eror_con = EROR_CODES.EROR_VL_SUCCESS_STR;

      // 등록일 경우 자산화통합아이디 채번
      if (metas[i].assz_orgn_pcsn_dcd == "C") {
        metas[i].assz_unfc_id = await getUnfcId("IEMIEA", ++idx);

        // 수정,삭제, 변경없음일 경우 최근원장의 자산화통합아이디 가져오기
      } else if (
        metas[i].assz_orgn_pcsn_dcd == "U" ||
        metas[i].assz_orgn_pcsn_dcd == "D" ||
        metas[i].assz_orgn_pcsn_dcd == "N"
      ) {
        // metas[i].assz_unfc_id = metas[i].assz_unfc_id;
      }

      // 수신폴더 구조로 변경
      const fileName = recvPathChange(metas[i].assz_orcp_file_path_nm);
      const ext = path.extname(metas[i].assz_orcp_file_path_nm);
      metas[i].file_nm = `${metas[i].assz_unfc_id}${ext}`;

      let dirGb = "origin"; // 디렉토리구분
      let chgFullPath = `/data/asset/iem/iea/${basDt}/${dirGb}/${metas[i].file_nm}`;

      // 등록 및 수정일 경우 파일 체크 및 정보 가져오기
      if (
        metas[i].assz_orgn_pcsn_dcd == "C" ||
        metas[i].assz_orgn_pcsn_dcd == "U"
      ) {
        // 파일 복사
        try {
          fs.copyFileSync(fileName, chgFullPath);
          metas[i].assz_pcsn_file_path_nm = chgFullPath;
        } catch (err) {
          metas[i].eror_vl = EROR_CODES.EROR_VL_COPY_FAILED;
          metas[i].assz_eror_con = EROR_CODES.EROR_VL_COPY_FAILED_STR;
          writeLog(
            `${EROR_CODES.EROR_VL_COPY_FAILED_STR}: ${fileName}, ${err}`
          );

          // 메인메타저장 처리
          metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
          await mainMetaDbInsert(metas[i]);

          // 메타로그 저장
          await mainMetaLogDbInsert(metas[i]);

          failCnt++;

          // 파일복사 오류시 프로세스 종료
          process.exit(1);
          // continue;
        }
      }

      // 등록일 경우 자산화결과기본(원장) 추가
      if (metas[i].assz_orgn_pcsn_dcd == "C") {
        // 확장자 체크
        if (!isUseFile(metas[i].file_nm)) {
          metas[i].eror_vl = EROR_CODES.EROR_VL_NON_TARGET;
          metas[i].assz_eror_con = EROR_CODES.EROR_VL_NON_TARGET_STR;
          writeLog(`${EROR_CODES.EROR_VL_NON_TARGET_STR}: ${fileName}`);

          // 메인메타저장 처리
          metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
          await mainMetaDbInsert(metas[i]);

          // 메타로그 저장
          await mainMetaLogDbInsert(metas[i]);

          failCnt++;
          continue;
        }

        // 파일 정보 가져오기
        try {
          let fileInfo = await getFileInfo(fileName);
          metas[i].flsz_vl = fileInfo.size;
          metas[i].assz_orgn_file_encp_rnnm_vl = fileInfo.md5;
        } catch (e) {
          writeLog(e);
          writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${fileName}`);
        }

        // 메인메타 저장 처리
        metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_INIT;
        await mainMetaDbInsert(metas[i]);

        // 메타로그 저장
        await mainMetaLogDbInsert(metas[i]);

        writeLog(`copy 성공 ${fileName}`);
        successCnt++;

        // 수정일 경우 자산화결과기본(원장), 파일정보 변경
      } else if (metas[i].assz_orgn_pcsn_dcd == "U") {
        // 확장자 체크
        if (!isUseFile(metas[i].file_nm)) {
          metas[i].eror_vl = EROR_CODES.EROR_VL_NON_TARGET;
          metas[i].assz_eror_con = EROR_CODES.EROR_VL_NON_TARGET_STR;
          writeLog(`${EROR_CODES.EROR_VL_NON_TARGET_STR}: ${fileName}`);

          // 메인메타수정 처리
          metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
          await mainMetaDbUpdate(metas[i]);

          // 메타로그 저장
          await mainMetaLogDbInsert(metas[i]);

          failCnt++;
          continue;
        }

        // 파일 정보 가져오기
        try {
          let fileInfo = await getFileInfo(fileName);
          metas[i].flsz_vl = fileInfo.size;
          metas[i].assz_orgn_file_encp_rnnm_vl = fileInfo.md5;
        } catch (e) {
          writeLog(e);
          writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${fileName}`);
        }

        // 메인메타 수정 처리
        metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_INIT;
        await mainMetaDbUpdate(metas[i]);

        // 메타로그 저장
        await mainMetaLogDbInsert(metas[i]);
        
        writeLog(`copy 성공 ${fileName}`);
        successCnt++;

        // 삭제일 경우 자산화결과기본(원장) 삭제
      } else if (metas[i].assz_orgn_pcsn_dcd == "D") {
        // 메인메타 삭제 처리
        metas[i].assz_scd = COMMON_CODES.ASSZ_SCD_DELETE;
        await mainMetaDbDelete(metas[i]);

        // 메타로그 저장
        await mainMetaLogDbInsert(metas[i]);
        
        writeLog(`삭제: ${fileName}`);
        successCnt++;

        // 변경 없음일 경우
      } else if (metas[i].assz_orgn_pcsn_dcd == "N") {
        metas[i].eror_vl = EROR_CODES.EROR_VL_NOCHANGE_SUCCESS;
        metas[i].assz_eror_con = EROR_CODES.EROR_VL_NOCHANGE_SUCCESS_STR;

        // 메타파일 데이터와 원장테이블 데이터 비교 시 변경점이 없을 경우 원장 수행정보 변경
        await updateOriginMasterIea(
          metas[i].assz_unfc_id,
          metas[i].assz_btch_acmp_id,
          metas[i].eror_vl,
          metas[i].assz_eror_con
        );

        // 메타로그 저장
        await mainMetaLogDbInsert(metas[i]);

        writeLog(`변경없음: ${fileName}`);
        successCnt++;
      }
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "fileCopy");
  writeLog(
    "----------------------------fileCopy() 종료----------------------------"
  );
}

/*------------------- 메인메타 저장 처리 ----------------------*/
async function mainMetaDbInsert(metas) {
  // 원장마스터 인서트
  await insertLdgrMaster(
    null,
    metas.assz_unfc_id,
    metas.assz_scd,
    metas.assz_cfbo_idnt_id,
    null, // rgsn_ymd
    null, // mdfc_ymd
    metas.assz_orgn_pcsn_dcd,
    metas.eror_vl,
    metas.assz_eror_con,
    "", // assz_pcsn_file_path_nm 초기시 빈값,
    metas.flsz_vl, // 파일 사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    metas.assz_btch_acmp_id,
    metas.uda_sys_lsmd_id
  );

  // 원장메타 저장
  let reveFileName = path.basename(metas.assz_orcp_file_path_nm);
  await dbMetaMain.insertMeta(
    metas.assz_unfc_id,
    metas.assz_cfbo_idnt_id,
    reveFileName,
    metas.assz_orcp_file_path_nm,
    metas.assz_orgn_pcsn_dcd,
    metas.assz_dcmn_clsf_id,
    metas.conn_ttl_nm,
    metas.uda_sys_lsmd_id
  );
}

/*------------------- 메인메타 수정 처리 ----------------------*/
async function mainMetaDbUpdate(metas) {
  // 원장마스터 수정
  await updateOriginMaster(
    metas.assz_unfc_id,
    metas.assz_btch_acmp_id,
    metas.assz_scd,
    metas.flsz_vl, // 파일사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    '', // 자산화처리파일 경로명
    metas.eror_vl,
    metas.assz_eror_con
  );

  // 원장메타 수정
  let reveFileName = path.basename(metas.assz_orcp_file_path_nm);
  await dbMetaMain.updateMeta(
    reveFileName,
    metas.assz_orcp_file_path_nm,
    metas.assz_unfc_id,
    metas.assz_dcmn_clsf_id,
    metas.conn_ttl_nm
  );
}

/*------------------- 메인메타 삭제 처리 ----------------------*/
async function mainMetaDbDelete(metas) {
  // 원장마스터 삭제
  await updateLdgrSelfPool(
    metas.assz_unfc_id,
    metas.assz_btch_acmp_id,
    COMMON_CODES.ASSZ_SCD_DELETE
  );

  // 원장메타 삭제
  await dbMetaMain.deleteMeta(metas.assz_unfc_id);
}

/*------------------- 메타로그 저장  ---------------------- */
async function mainMetaLogDbInsert(metas) {
  await dbMetaMain.insertMetaLog(
    metas.assz_btch_acmp_id,
    metas.assz_cfbo_idnt_id,
    metas.assz_unfc_id,
    metas.file_nm,
    metas.assz_orcp_file_path_nm,
    metas.assz_orgn_pcsn_dcd,
    metas.assz_dcmn_clsf_id,
    metas.conn_ttl_nm,
    metas.assz_pcsn_file_path_nm,
    metas.uda_sys_lsmd_id
  );
}

/*---------------------- 메타 재생성 ----------------------*/
async function createMeta(masterPath) {
  writeLog(
    "----------------------------createMeta()시작----------------------------"
  );
  const masterInfo = fs.readFileSync(masterPath, "utf-8");
  const lines_m = masterInfo.split("\n").filter((line) => line.trim() !== "");

  // 메타 데이터
  const parsedData = lines_m.map((line) => {
    if (line.trim() === "") {
    } else {
      const [
        assz_cfbo_idnt_id,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        assz_orcp_file_path_nm,
        cnt,
      ] = line.split("|");
      return {
        assz_cfbo_idnt_id,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        assz_orcp_file_path_nm,
        cnt,
      };
    }
  });

  // 자산화결과기본(원장) 가장최근 데이터 조회
  const recentOrginData = await dbMetaMain.selectOrginRecent();

  // Map 생성 및 변수 셋팅
  const parsedMap = new Map(
    parsedData.map((item) => [item.assz_cfbo_idnt_id, item])
  );
  const recentMap = new Map(
    recentOrginData.rows.map((item) => [item.assz_cfbo_idnt_id, item])
  );
  const margedData = [];

  // 메타데이터 기준으로 for
  for (const item of parsedData) {
    const recent = recentMap.get(item.assz_cfbo_idnt_id);

    // 메타데이터와 DB데이터가 모두 존재할 경우
    if (recent) {
      // 파일 비교
      let editYn = await compareFiles(
        item.assz_orcp_file_path_nm,
        recent.assz_orgn_file_encp_rnnm_vl
      );

      // 자산화문서분류ID나 콘텐츠제목명이 다를경우
      if (
        item.assz_dcmn_clsf_id != recent.assz_dcmn_clsf_id ||
        item.conn_ttl_nm != recent.conn_ttl_nm
      ) {
        editYn = "Y";
      }

      let assz_orgn_pcsn_dcd = "N";
      if (editYn === "Y") assz_orgn_pcsn_dcd = "U";

      margedData.push({
        ...item,
        assz_unfc_id: recent.assz_unfc_id,
        assz_orgn_file_encp_rnnm_vl: recent.assz_orgn_file_encp_rnnm_vl,
        assz_orgn_pcsn_dcd: assz_orgn_pcsn_dcd,
      });

      // 메타데이터는 있고, DB가 없을 경우
    } else {
      margedData.push({
        ...item,
        assz_orgn_pcsn_dcd: "C",
      });
    }
  }

  // DB데이터 기준으로 for
  for (const item of recentOrginData.rows) {
    // DB데이터는 있고, 메타데이터가 없을 경우
    if (!parsedMap.has(item.assz_cfbo_idnt_id)) {
      margedData.push({
        ...item,
        assz_orgn_pcsn_dcd: "D",
      });
    }
  }

  // 자산화원천실별ID 기준으로 정렬
  margedData.sort((a, b) =>
    a.assz_cfbo_idnt_id.localeCompare(b.assz_cfbo_idnt_id, "en", {
      numeric: true,
    })
  );

  return margedData;
}

/*----------------------compareFiles----------------------*/
async function compareFiles(
  assz_orcp_file_path_nm,
  assz_orgn_file_encp_rnnm_vl
) {
  writeLog(
    "----------------------------compareFiles()시작----------------------------"
  );

  const fileName = recvPathChange(assz_orcp_file_path_nm);
  const drmDir = path.dirname(fileName);

  const command = `sh /app/drm/unpack_auto.sh ${drmDir}`;

  let editYn = "";
  try {
    result = await util.executeCommand(command, "/app/drm");
    writeLog(result);
  } catch (err) {
    writeLog(`drm오류: ${drmDir}`);
  }

  const filePath = path.resolve(fileName);
  let fileInfo = null;

  try {
    fileInfo = await getFileInfo(filePath);
  } catch (e) {
    writeLog(e);
    writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filePath}`);
  }

  try {
    const [hash1, hash2] = await Promise.all([
      fileInfo.md5,
      assz_orgn_file_encp_rnnm_vl,
    ]);
    // 두 파일의 값이 같을 경우
    if (hash1 === hash2) {
      editYn = "N";
      // 두 파일의 값이 다를 경우
    } else {
      editYn = "Y";
    }
  } catch (err) {
    console.error(`파일비교중 오류 발생`, err.message);
  }

  writeLog(
    "----------------------------compareFiles()종료----------------------------"
  );
  return editYn;
}

// 확장자 체크
function isUseFile(fileName) {
  const USE_EXTS = new Set([".hwp", ".hwpx", ".HWP", ".HWPX"]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

// 수신폴더 구조로 변경
function recvPathChange(assz_orcp_file_path_nm) {
  const basePath = "/dat/gens/legas42_ibk/cont/cont_file/";
  const relativePath = assz_orcp_file_path_nm.slice(basePath.length);
  const filePath = `/data/bdpetl/recv/iem/iea/${basDt}/file/${relativePath}`;
  return filePath;
}

/*----------------------DRM해제 작업----------------------*/
async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );

  const dirs = ["origin"]; //DRM해제할 디렉토리 목록
  let result = "";

  for (const dir of dirs) {
    const fullPath = `/data/asset/iem/iea/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`drm오류: ${fullPath}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

/*------------------- 라인그리기 ----------------------*/
async function drawLine(assz_btch_acmp_id) {
  writeLog(
    "---------------------------- drawline() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 메타 성공 조회
  const metaData = await dbMetaMain.selectMetaSuccess(assz_btch_acmp_id);
  for (const meta of metaData.rows) {
    if (
      meta.assz_cfbo_idnt_id == "" ||
      meta.assz_cfbo_idnt_id == undefined ||
      meta.assz_cfbo_idnt_id == null ||
      !(
        path.extname(meta.file_nm).toLowerCase() === ".hwp" ||
        path.extname(meta.file_nm).toLowerCase() === ".hwpx" ||
        path.extname(meta.file_nm).toLowerCase() === ".docx"
      )
    ) {
      continue;
    } else {
      const ext = path.extname(meta.file_nm);
      const name = `${meta.assz_unfc_id}${ext}`;
      let dirGb = "origin"; // 디렉토리구분
      let chgFullPath = `/data/asset/iem/iea/${basDt}/${dirGb}/${name}`;

      if (fs.existsSync(chgFullPath)) {
        fs.copyFileSync(chgFullPath, `${chgFullPath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${chgFullPath}${ext}" "${chgFullPath}" 10`;

      commands.push({
        command: command,
        chgFullPath: chgFullPath,
        ext: ext,
        assz_unfc_id: meta.assz_unfc_id,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => dl(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
      writeLog(`Drawline 성공 ${result.chgFullPath}`);
    } else {
      failCnt++;
      writeLog(`Drawline 실패: ${result.chgFullPath}`);

      let errCd = EROR_CODES.EROR_VL_DRAWLINE_FAILED;
      let errStr = EROR_CODES.EROR_VL_DRAWLINE_FAILED_STR;
      await updateErorVl(result.assz_unfc_id, errCd, errStr);
    }

    const tmpFilename = `${result.chgFullPath}${result.ext}`;

    if (fs.existsSync(tmpFilename)) {
      fs.unlinkSync(tmpFilename);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "drawline");
  writeLog(
    "---------------------------- drawline() 종료 ----------------------------"
  );
}

// 라인그리기
async function dl(data) {
  return await new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          chgFullPath: data.chgFullPath,
          ext: data.ext,
        });
      }
      if (stderr) {
        if (!stderr.includes("Log4j")) {
          resolve({
            success: false,
            chgFullPath: data.chgFullPath,
            ext: data.ext,
          });
        }
      }
      resolve({
        success: true,
        chgFullPath: data.chgFullPath,
        ext: data.ext,
      });
    });
  });
}

/*---------------------- HWP TO PDF ----------------------*/
async function hwptoPdf(assz_btch_acmp_id, folerType = "pdf") {
  writeLog(
    `----------------------------hwptoPdf(${folerType}) 시작----------------------------`
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 메타 성공 조회
  const metaData = await dbMetaMain.selectMetaSuccess(assz_btch_acmp_id);
  for (const rowMetaData of metaData.rows) {
    const { assz_unfc_id, assz_cfbo_idnt_id, assz_orcp_file_path_nm } =
      rowMetaData;

    const ext = path.extname(assz_orcp_file_path_nm);
    const oriFileName = `${assz_unfc_id}${ext}`;

    let chgFileName = "";
    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".HWP" ||
      path.extname(oriFileName).toLowerCase() === ".HWPX"
    ) {
      chgFileName = oriFileName.replace(path.extname(oriFileName), ".pdf");
    } else {
      chgFileName = oriFileName;
    }

    let dirGb = "origin"; //디렉토리구분
    let chgFullPath = `/data/asset/iem/iea/${basDt}/${dirGb}/${oriFileName}`;
    const chgFilePath = `/data/asset/iem/iea/${basDt}/${folerType}/${chgFileName}`;

    // 파일존재 여부 체크
    try {
      fs.accessSync(chgFullPath);
    } catch (err) {
      let errCd = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
      let errStr = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
      writeLog(`파일없음: ${chgFullPath} ${err.message}`);
      await updateErorVl(assz_unfc_id, errCd, errStr);
      failCnt++;
      continue;
    }

    // 테스트일 경우
    let pythonPath = "python";
    if (pcsnClCd.includes("test")) {
      pythonPath = `/app/anaconda3/bin/python3`;
    }

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const command = `${pythonPath} /app/hwp2pdfv2/hwp2pdf.py "${chgFullPath}" "/data/asset/iem/iea/${basDt}/${folerType}"`;

    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      assz_cfbo_idnt_id: assz_cfbo_idnt_id,
      chgFilePath: chgFilePath,
      chgFullPath: chgFullPath,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    totalCnt++;

    if (result.success) {
      try {
        // pdf원본 변환이 아닐 경우
        if (folerType != "originpdf") {
          // 자산화로그 저장
          const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
          await dbAssetLog.insertLog(
            result.assz_btch_acmp_id,
            result.assz_unfc_id,
            result.assz_cfbo_idnt_id,
            null,
            "HW", //HW  HWP PD  PDF ML  HTML
            "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
            "C", //C 신규 U 수정 D삭제
            "N", //이미지처리여부
            null,
            null,
            null,
            "CH", //CH변환 , NO(NONE)
            null,
            null,
            null,
            "SI", // CH 변환 SI 단일문서
            result.staDate, //원본변환시작일시
            endDate, //원본변환종료일시
            result.chgFilePath,
            result.errCd, //에러 0000
            result.errStr,
            "UDAIEADASSETR001"
          );
        }

        successCnt++;
      } catch (err) {
        result.errCd = EROR_CODES.EROR_VL_HTP_FAILED;
        result.errStr = EROR_CODES.EROR_VL_HTP_FAILED_STR;
        await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
        writeLog(`${result.errStr} ${result.chgFilePath} ${err}`);
        failCnt++;
        continue;
      }
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "hwptoPdf");
  writeLog(
    `----------------------------hwptoPdf(${folerType}) 종료----------------------------`
  );
}

// HTML TO PDF
async function htp(data) {
  return await new Promise((resolve, reject) => {
    exec(data.command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.chgFullPath} ${error}`,
          errCd: EROR_CODES.EROR_VL_HTP_FAILED,
          errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
          ...data,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.chgFullPath} ${stderr}`,
          errCd: EROR_CODES.EROR_VL_HTP_FAILED,
          errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
          ...data,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.chgFullPath} ${stdout}`,
          errCd: EROR_CODES.EROR_VL_HTP_FAILED,
          errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
          ...data,
        });
      } else {
        writeLog(`hwptoPdf 결과미확인: ${data.chgFullPath}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*---------------------- 라인그리기 실패한 건만 한번 더 HWP TO PDF ----------------------*/
async function drawLineFailHwptoPdf(assz_btch_acmp_id) {
  writeLog(
    "---------------------------- drawLineFailHwptoPdf()시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 메타 라인그리기 후 PDF변환 실패한 건만 조회
  const metaData = await dbMetaMain.selectDrawLineFailMeta(assz_btch_acmp_id);
  for (const rowMetaData of metaData.rows) {
    const { assz_unfc_id, assz_cfbo_idnt_id, assz_orcp_file_path_nm } =
      rowMetaData;

    // 수신폴더 구조로 변경
    const fileName = recvPathChange(assz_orcp_file_path_nm);
    const ext = path.extname(assz_orcp_file_path_nm);
    const oriFileName = `${assz_unfc_id}${ext}`;

    let chgFileName = "";
    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".HWP" ||
      path.extname(oriFileName).toLowerCase() === ".HWPX"
    ) {
      chgFileName = oriFileName.replace(path.extname(oriFileName), ".pdf");
    } else {
      chgFileName = oriFileName;
    }

    let dirGb = "origin"; //디렉토리구분
    let chgFullPath = `/data/asset/iem/iea/${basDt}/${dirGb}/${oriFileName}`;
    const chgFilePath = `/data/asset/iem/iea/${basDt}/pdf/${chgFileName}`;

    // 파일 복사
    try {
      fs.copyFileSync(fileName, chgFullPath);
      writeLog(`COPY완료 : ${chgFullPath}`);
    } catch (err) {
      writeLog(`Failed to copy ${chgFullPath}, ${err}`);
      failCnt++;
      continue;
    }

    // 테스트일 경우
    let pythonPath = "python";
    if (pcsnClCd.includes("test")) {
      pythonPath = `/app/anaconda3/bin/python3`;
    }

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const command = `${pythonPath} /app/hwp2pdfv2/hwp2pdf.py "${chgFullPath}" "/data/asset/iem/iea/${basDt}/pdf"`;

    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      assz_cfbo_idnt_id: assz_cfbo_idnt_id,
      chgFilePath: chgFilePath,
      chgFullPath: chgFullPath,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    totalCnt++;

    if (result.success) {
      try {
        // 자산화로그 저장
        const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
        await dbAssetLog.insertLog(
          result.assz_btch_acmp_id,
          result.assz_unfc_id,
          result.assz_cfbo_idnt_id,
          null,
          "HW", //HW    HWP PD  PDF ML  HTML
          "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
          "C", //C 신규 U 수정 D삭제
          "N", //이미지처리여부
          null,
          null,
          null,
          "CH", //CH변환 , NO(NONE)
          null,
          null,
          null,
          "SI", // CH   변환 SI 단일문서
          result.staDate, //원본변환시작일시
          endDate, //원본변환종료일시
          result.chgFilePath,
          result.errCd, //에러 0000
          result.errStr,
          "UDAIEADASSETR001"
        );

        // 원장 성공처리로 재변경
        await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);

        successCnt++;
      } catch (err) {
        result.errCd = EROR_CODES.EROR_VL_HTP_FAILED;
        result.errStr = EROR_CODES.EROR_VL_HTP_FAILED_STR;
        await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
        writeLog(`${result.errStr} ${result.chgFilePath} ${err}`);
        failCnt++;
        continue;
      }
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "drawLineFailHwptoPdf"
  );
  writeLog(
    "---------------------------- drawLineFailHwptoPdf()종료 ----------------------------"
  );
}

/*----------------------PDF TO TEXT----------------------*/
async function pdftoText(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );
  const { exec } = require("child_process");
  const outputDir = `/data/asset/iem/iea/${basDt}/txt`;

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 자산화로그 조회
  const logData = await dbAssetLog.selectLog(
    assz_btch_acmp_id,
    "02",
    EROR_CODES.EROR_VL_SUCCESS
  );
  for (const rowLogData of logData.rows) {
    const { assz_btch_acmp_id, assz_unfc_id, assz_orcp_file_path_nm } =
      rowLogData;

    const oriFileName = path.basename(assz_orcp_file_path_nm);
    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const txtFileName = oriFileName.replace(".pdf", ".txt"); //확장자변경
    const txtOutFullPath = `${outputDir}/${txtFileName}`; //확장자변경

    // 테스트일 경우
    let pythonPath = "python";
    if (process.argv[2] == "test") {
      pythonPath = `/app/anaconda3/bin/python3`;
    }
    let command = `${pythonPath} /app/pdftotxt/pdftotxt.py "${assz_orcp_file_path_nm}" "${txtOutFullPath}"`;
    writeLog(`command 실행: ${command}`);
    totalCnt++;
    let errCd = EROR_CODES.EROR_VL_SUCCESS;
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

    try {
      await new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
          if (error) {
            writeLog(`에러:${error.message}`);
            reject(error); //resolve(); //에러나도 넘어가게끔 하려면
            return;
          }
          writeLog(`stdout:${stdout}`);
          if (stdout.includes("[Success]")) {
            writeLog(`변환성공: ${oriFileName}`);
            successCnt++;
            resolve();
          } else if (stdout.includes(`[Fail]`)) {
            errCd = EROR_CODES.EROR_VL_PTT_FAILED;
            errStr = EROR_CODES.EROR_VL_PTT_FAILED_STR;
            updateErorVl(assz_unfc_id, errCd, errStr);
            writeLog(`변환실패 [Fail 출력됨]: ${oriFileName}`);
            failCnt++;
            resolve();
          } else {
            errCd = EROR_CODES.EROR_VL_PTT_FAILED;
            errStr = EROR_CODES.EROR_VL_PTT_FAILED_STR;
            updateErorVl(assz_unfc_id, errCd, errStr);
            writeLog(`결과미확인: ${oriFileName}`);
            reject(new Error(`stdout에서 성공/실패 정보 없음`));
          }
        });
      });
    } catch (err) {
      errCd = EROR_CODES.EROR_VL_PTT_FAILED;
      errStr = EROR_CODES.EROR_VL_PTT_FAILED_STR;
      updateErorVl(assz_unfc_id, errCd, errStr);

      writeLog(`pdftoText 변환 실패: ${oriFileName}`);
      failCnt++;
    }

    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      assz_btch_acmp_id,
      assz_unfc_id,
      "04",
      null,
      null,
      null,
      null,
      null,
      staDate, //변환시작일시
      endDate, //변환종료일시
      txtOutFullPath,
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

/*---------------------- main 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) 자산화 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    // --------- 전처리 작업 ---------
    // fin파일 체크 없음
    // 서버간 수신 파일 동기화
    await sync(`/data/bdpetl/recv/iem/iea/${basDt}/`);

    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IEMIEA",
      "01", //01  수집 02 자산화 03 전송
      "02", //01  대기 02 수행 03 중단 04 오류 05 완료
      "T1", //T1 메타+파일 T2 DB T3 지식샘
      "01" //assz_tgt_sys_cd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/iem/iea/${basDt}/meta/master.DAT`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/iea", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    // --------- 메인 작업 ---------
    // 폴더 생성
    await makeDir();
    // 파일 복사
    await fileCopy(assz_btch_acmp_id);
    // HWP TO PDF(라인그리기 전 원본PDF로 복사)
    await hwptoPdf(assz_btch_acmp_id, "originpdf");
    // DRM 해제
    await drmUnlock();
    // 라인그리기
    await drawLine(assz_btch_acmp_id);
    // HWP TO PDF
    await hwptoPdf(assz_btch_acmp_id);
    // 라인그리기 실패한 건만 한번 더 HWP TO PDF
    await drawLineFailHwptoPdf(assz_btch_acmp_id);
    // PDF TO TEXT
    await pdftoText(assz_btch_acmp_id);
    // Jeff
    await util.runJeff2(assz_btch_acmp_id, "iemiea", basDt);

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/iem/iea", basDt);
    // 원장결과 재생성
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "iemiea",
      basDt,
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 학습데이터 파일복사
    await util.moveToLearn("iemiea", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    // 초기이행용
    // 학습용데이터모음
    await util.moveToLearn("iemiea", null);
  } else if (pcsnClCd == "test") {
    // --------- 전처리 작업 ---------
    // fin파일 체크 없음
    // 서버간 수신 파일 동기화
    await sync(`/data/bdpetl/recv/iem/iea/${basDt}/`);

    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IEMIEA",
      "01", //01  수집 02 자산화 03 전송
      "02", //01  대기 02 수행 03 중단 04 오류 05 완료
      "T1", //T1 메타+파일 T2 DB T3 지식샘
      "01" //assz_tgt_sys_cd
    );
    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/iem/iea/${basDt}/meta/master.DAT`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/iea", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    // --------- 메인 작업 ---------
    // 폴더 생성
    await makeDir();
    // 파일 복사
    await fileCopy(assz_btch_acmp_id);
    // HWP TO PDF(라인그리기 전 원본PDF로 복사)
    await hwptoPdf(assz_btch_acmp_id, "originpdf");
    // DRM 해제
    await drmUnlock();
    // 라인그리기
    await drawLine(assz_btch_acmp_id);
    // HWP TO PDF
    await hwptoPdf(assz_btch_acmp_id);
    // 라인그리기 실패한 건만 한번 더 HWP TO PDF
    await drawLineFailHwptoPdf(assz_btch_acmp_id);
    // PDF TO TEXT
    await pdftoText(assz_btch_acmp_id);
    // Jeff
    await util.runJeff2(assz_btch_acmp_id, "iemiea", basDt);

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/iem/iea", basDt);
    // 원장결과 재생성
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "iemiea",
      basDt,
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 학습데이터 파일복사
    await util.moveToLearn("iemiea", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  }
  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) 자산화 배치 종료 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  return true;
}

main();
