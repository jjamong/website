const fs = require("fs");
const path = require("path");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbMetaMain = require("../sql/TB_UDA_UAI807L");
const dayjs = require("dayjs");
const fromDt = process.argv[4];
const toDt = process.argv[5];

const { finFileCreate, getSafeBaseDt } = require("./common");

//입력값 체크 pcsnClCd=01:날짜처리 , basDt = 날짜
const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------

if (
  pcsnClCd !== "01" &&
  pcsnClCd !== "02" &&
  pcsnClCd !== "99" &&
  pcsnClCd !== "98" &&
  pcsnClCd !== "97"
) {
  writeLog("error node UDAOCHDASSETR001.js clcd(처리구분:01) YYYYMMDD");
}
if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("ERROR UDAOCHDASSETR001.js YYYYMMDD");
  process.exit(1);
}

// 특정 날짜기간으로 전송메타 생성
async function makeJsonRange(basDt, startDt, endDt) {
  writeLog(
    "----------------------------makeJson()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const metaData = await dbMetaMain.selectMetaRange(startDt, endDt);

  let datas = [];

  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_meta_pcsn_sqn,
      assz_cfbo_idnt_id,
      rgsn_ts,
      amnn_ts,
      assz_chb_conn_url_adr,
      assz_pcsn_file_path_nm,
      assz_dcmn_clsf_id,
      hdlr_id,
    } = rowMetaData;

    totalCnt++;
    if (assz_pcsn_file_path_nm) {
      const data = fs.readFileSync(assz_pcsn_file_path_nm, "utf8");

      const [q, a] = data.split("^|").map((s) => s.trim());

      datas.push({
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        q: q,
        a: a,
        assz_dcmn_clsf_id: assz_dcmn_clsf_id,
        assz_chb_conn_url_adr: assz_chb_conn_url_adr,
      });
      successCnt++;
    } else {
      failCnt++;
    }
  }

  if (datas.length > 0) {
    const fileName = `UDA_OCH_GAI_${basDt}.json`;
    const asszPath = `/data/asset/chb/och/${basDt}/json/${fileName}`;
    const sendPath = `/data/bdpetl/send/gai/gai/och/${basDt}/${fileName}`;

    try {
      fs.mkdirSync(`/data/asset/chb/och/${basDt}/json/`, { recursive: true });
    } catch (err) {
      writeLog(
        `디렉터리 생성 실패 : /data/asset/chb/och/${basDt}/json/ , ${err}`
      );
    }

    try {
      fs.mkdirSync(`/data/bdpetl/send/gai/gai/och/${basDt}/`, {
        recursive: true,
      });
    } catch (err) {
      writeLog(
        `디렉터리 생성 실패 : /data/bdpetl/send/gai/gai/och/${basDt}/, ${err}`
      );
    }

    fs.writeFileSync(asszPath, JSON.stringify(datas, null, 2), "utf8");
    writeLog(`자산화파일 저장완료 ${asszPath}`);
    fs.writeFileSync(sendPath, JSON.stringify(datas, null, 2), "utf8");
    writeLog(`전송폴더 저장완료 ${sendPath}`);
  }
  summaryLog(totalCnt, successCnt, failCnt, "", "makeJson");
  writeLog(
    "----------------------------makeJson()종료----------------------------"
  );
}

async function makeDir() {
  const dirs = [
    `/data/asset/chb/och/${basDt}/json`,
    `/data/asset/chb/och/${basDt}/origin`,
    `/data/asset/chb/och/${basDt}/pdf`,
    `/data/asset/chb/och/${basDt}/html`,
    `/data/bdpetl/send/gai/gai/och/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

async function main() {
  writeLog(
    "----------------------------챗봇 batch 시작----------------------------"
  );

  if (pcsnClCd == "01") {
    // 특정 날짜기간으로 전송메타 생성
    await makeJsonRange(basDt, fromDt, toDt);
    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/och", basDt);
  }

  await dbMetaMain.dbEnd();
  writeLog(
    "----------------------------챗봇 batch 종료----------------------------"
  );
  return true;
}
main();
