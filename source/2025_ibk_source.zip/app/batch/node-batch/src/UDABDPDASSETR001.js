const { Client } = require("pg");
const fs = require("fs");
const dayjs = require("dayjs");
const { getBatchId, getSafeBaseDt } = require("./common");

const client = new Client({
  user: "qidp",
  host: "172.18.120.150",
  database: "qidp",
  password: "qidp1234!",
  port: 5432,
});

client.connect();

let META_INFOS = {};

function getMETA_INFOS(basDt) {
  return {
    BDP_QR_CMIB01M_UDA: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/${basDt}/BDP_QR_CMIB01M_UDA_conv.dat`,
      cols: {
        0: "BRCD|CHAR",
        1: "LSMD_YMD|VARCHAR2",
        2: "BZN|CHAR",
        3: "KRN_BRM|VARCHAR2",
        4: "BRNC_FGR6_KRN_NM|CHAR",
        5: "BRNC_FGR4_KRN_NM|CHAR",
        6: "ENSN_BRM|VARCHAR2",
        7: "ZPCD|CHAR",
        8: "BRNC_GU_BSC_ADR|VARCHAR2",
        9: "BRNC_GU_DTL_ADR|VARCHAR2",
        10: "BRNC_TEL_LLN|VARCHAR2",
        11: "BRNC_TPN_TON|VARCHAR2",
        12: "BRNC_TPN_SRN|VARCHAR2",
        13: "RPRS_FAX_LLN|VARCHAR2",
        14: "RPRS_FAX_TON|VARCHAR2",
        15: "RPRS_FAX_SRN|VARCHAR2",
        16: "FAX_LLN|VARCHAR2",
        17: "FXN_TON|VARCHAR2",
        18: "FXN_SRN|VARCHAR2",
        19: "CLCN_TEL_LLN|VARCHAR2",
        20: "CLCN_TEL_TON|VARCHAR2",
        21: "CLCN_TEL_SRN|VARCHAR2",
        22: "BRNC_SCD|CHAR",
        23: "OLD_GICD|CHAR",
        24: "NOEC_CD|CHAR",
        25: "BRNC_DCD|CHAR",
        26: "BRNC_LCTN_CD|CHAR",
        27: "COG_AREA_DCD|CHAR",
        28: "FXBR_DCD|CHAR",
        29: "FREX_BRCD|CHAR",
        30: "FEX_ONBR_YMD|VARCHAR2",
        31: "MNEX_SCBR_YN|CHAR",
        32: "MNEX_SCBR_RGSN_YMD|VARCHAR2",
        33: "FEX_CNTZ_BRCD|CHAR",
        34: "FRFN_CNBR_DCD|CHAR",
        35: "BOK_JRSD_UNCN_BRCD|CHAR",
        36: "PB_BRNC_YN|CHAR",
        37: "PB_BRNC_DCD|CHAR",
        38: "DREAM_ENPR_YN|CHAR",
        39: "RM_BRNC_YN|CHAR",
        40: "INDV_MAGR_CD|CHAR",
        41: "ENPR_MNAP_GRP_CD|CHAR",
        42: "RM_MNAP_GRP_CD|CHAR",
        43: "COH_LMT_AMT|NUMERIC",
        44: "INEL_MTBR_YN|CHAR",
        45: "EXMBR_YN|CHAR",
        46: "EXMBR_BRCD|CHAR",
        47: "IMDE_RCDE_BRNC_YN|CHAR",
        48: "OWN_DCD|CHAR",
        49: "ONL_NO|VARCHAR2",
        50: "ONBR_YMD|VARCHAR2",
        51: "CLSR_PBAN_YMD|VARCHAR2",
        52: "CLOS_YMD|VARCHAR2",
        53: "MBCD|CHAR",
        54: "UNFC_BRCD|CHAR",
        55: "RHDCD|CHAR",
        56: "JRSD_HQCD|CHAR",
        57: "BZSC_CD|CHAR",
        58: "TRSTL_MTHR_BRCD|CHAR",
        59: "RVST_MTBR_BRCD|CHAR",
        60: "BSHD_CD|CHAR",
        61: "RDSC_MTHR_BRCD|CHAR",
        62: "RNSS_MTHR_BRCD|CHAR",
        63: "ACON_BRCD|CHAR",
        64: "BOBM_NM|VARCHAR2",
        65: "BRMG_EMN|CHAR",
        66: "EDPS_CSN|NUMERIC",
        67: "BRNC_BSOP_DCD|CHAR",
        68: "BKIN_GICD|CHAR",
        69: "BNCD|CHAR",
        70: "BOK_JRSD_SVBR_GICD|CHAR",
        71: "NW_ZPCD|CHAR",
        72: "BRNC_NW_BSC_ADR|VARCHAR2",
        73: "BRNC_NW_DTL_ADR|VARCHAR2",
        74: "HUB_EAI_RFLC_YN|CHAR",
        75: "PDF_EAI_RFLC_YN|CHAR",
        76: "BPM_EAI_RFLC_YN|CHAR",
        77: "OGZN_ATTCD|CHAR",
        78: "OGZN_KCD|CHAR",
        79: "ETCL_BASE_YMD|VARCHAR2",
        80: "ETCL_JOB_TS|TIMESTAMP",
        81: "SYS_LSMD_ID|VARCHAR2",
        82: "SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIB01M",
    },
    BDP_QR_CMIE01M_UDA: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/${basDt}/BDP_QR_CMIE01M_UDA_conv.dat`,
      cols: {
        0: "EMN|CHAR",
        1: "EMM|VARCHAR2",
        2: "EMP_ENSN_NM|VARCHAR2",
        3: "GNDR_DCD|CHAR",
        4: "HLOF_YN|CHAR",
        5: "ETBN_DCD|CHAR",
        6: "ETBN_YMD|VARCHAR2",
        7: "BLNG_BRCD|CHAR",
        8: "BETEAM_CD|CHAR",
        9: "EXIG_BLNG_YMD|VARCHAR2",
        10: "TRTH_WORK_BRCD|CHAR",
        11: "RSWR_BRCD|CHAR",
        12: "BRMD_RSN_CON|VARCHAR2",
        13: "DUCD|CHAR",
        14: "DUTY_CD|CHAR",
        15: "DUTY_YMD|VARCHAR2",
        16: "DUTY_GRD|VARCHAR2",
        17: "MNDT_CD|CHAR",
        18: "MNDT_YMD|VARCHAR2",
        19: "JBTT_CD|CHAR",
        20: "JBTT_YMD|VARCHAR2",
        21: "PRAR_JBTT_NO|CHAR",
        22: "PRAR_JTM|VARCHAR2",
        23: "NAME_NM|VARCHAR2",
        24: "EMP_EXT_NAME_NM|VARCHAR2",
        25: "JBCL_CD|CHAR",
        26: "TRTH_BIRT_YMD|VARCHAR2",
        27: "SLCN_UNCG_BIRT_YMD|VARCHAR2",
        28: "LNSL_DCD|CHAR",
        29: "EMP_ROST_SQC|NUMERIC",
        30: "EMAT_RCDE_DCD|CHAR",
        31: "USER_RGSN_BRCD|CHAR",
        32: "USER_RGSN_YMD|VARCHAR2",
        33: "EDPS_CSN|NUMERIC",
        34: "RTRM_YMD|VARCHAR2",
        35: "PRFL_NM|VARCHAR2",
        36: "PRAR_ONL_NO|VARCHAR2",
        37: "EMP_EXTI_NO|VARCHAR2",
        38: "EAD|VARCHAR2",
        39: "LSMD_YMD|VARCHAR2",
        40: "ATHR_MNGM_ID|CHAR",
        41: "WBCS_RLNM_ALTR_NO|VARCHAR2",
        42: "LGL_BIRT_YMD|CHAR",
        43: "ETC_BSWR_CON|VARCHAR",
        44: "RGSF_DCD|CHAR",
        45: "ETCL_BASE_YMD|VARCHAR2",
        46: "ETCL_JOB_TS|TIMESTAMP",
        47: "SYS_LSMD_ID|VARCHAR",
        48: "SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIE01M",
    },
    BDP_QR_CMIE40M_UDA: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/${basDt}/BDP_QR_CMIE40M_UDA_conv.dat`,
      cols: {
        0: "BECD|CHAR",
        1: "HGRN_BECD|CHAR",
        2: "BLNG_NM|VARCHAR2",
        3: "OFOR_SQC|VARCHAR2",
        4: "OGZN_ATTCD|CHAR",
        5: "JRSD_HQCD|CHAR",
        6: "JRSD_BRCD|CHAR",
        7: "BRRM_CD|CHAR",
        8: "BRGR_UT_OGCD|CHAR",
        9: "ACON_BRCD|CHAR",
        10: "BLNG_OPN_YMD|VARCHAR2",
        11: "BLNG_CLSR_YMD|VARCHAR2",
        12: "INRC_TPN|VARCHAR2",
        13: "STRH_TPN|VARCHAR2",
        14: "INBK_TPN|VARCHAR2",
        15: "FXN|VARCHAR2",
        16: "MNAP_GRP_ID|VARCHAR2",
        17: "MAGR_NM|VARCHAR2",
        18: "LSMD_YMD|VARCHAR2",
        19: "ETCL_BASE_YMD|VARCHAR2",
        20: "ETCL_JOB_TS|TIMESTAMP",
        21: "SYS_LSMD_ID|VARCHAR2",
        22: "SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIE40M",
    },
    BDP_QR_CMIE54D_UDA: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/${basDt}/BDP_QR_CMIE54D_UDA_conv.dat`,
      cols: {
        0: "EMN|CHAR",
        1: "DLLZ_CD_VL|CHAR",
        2: "HLTM_DCD|CHAR",
        3: "STTG_YMD|VARCHAR2",
        4: "FNSH_YMD|VARCHAR2",
        5: "STTG_HMS|CHAR",
        6: "FNSH_HMS|CHAR",
        7: "SNCT_ID|VARCHAR2",
        8: "DLLZ_CD_NM|VARCHAR2",
        9: "VCTN_NDD|NUMERIC",
        10: "WRPX_EMN|CHAR",
        11: "SPCM_ADT_YN|CHAR",
        12: "ETCL_BASE_YMD|VARCHAR2",
        13: "ETCL_JOB_TS|TIMESTAMP",
        14: "SYS_LSMD_ID|VARCHAR2",
        15: "SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIE54D",
    },
  };
}

async function upsertMeta(metaName, columns, rows) {
  const tableName = META_INFOS[metaName].tableName;
  const numCols = columns.length;
  const values = [];

  try {
    const tuples = rows
      .map((row, rowIdx) => {
        const offset = rowIdx * numCols;

        row.forEach((val) => values.push(val));

        const placeholders = row
          .map((_, colIdx) => convertColumnType(offset, colIdx, metaName))
          .join(", ");
        return `(${placeholders})`;
      })
      .join(",\n");

    // console.log(tuples);
    let mergeSql = `
      MERGE INTO ${tableName} AS t
      USING (
        VALUES
        ${tuples}
      ) AS s(${columns.join(", ")})
    `;
    if (tableName == "TB_UDA_UAIE54D")
      mergeSql += `ON (t.${columns[0]} = s.${columns[0]} AND t.${columns[1]} = s.${columns[1]} AND t.${columns[2]} = s.${columns[2]} AND t.${columns[3]} = s.${columns[3]} AND t.${columns[4]} = s.${columns[4]} AND t.${columns[5]} = s.${columns[5]} AND t.${columns[6]} = s.${columns[6]} AND t.${columns[7]} = s.${columns[7]})`;
    else mergeSql += `ON (t.${columns[0]} = s.${columns[0]})`;
    mergeSql += `
      WHEN MATCHED THEN
        UPDATE SET
          ${columns
            .slice(1)
            .map((col) => `${col} = s.${col}`)
            .join(",\n      ")}
        WHEN NOT MATCHED THEN
          INSERT (${columns.join(", ")})
          VALUES (${columns.map((col) => `s.${col}`).join(", ")})
    `;
    // console.log(mergeSql);
    //console.log(tuples);
    //console.log(values.length);
    // console.log(values);
    await client.query(mergeSql, values);
  } catch (err) {
    console.log(`❌ ${tableName} => 작업 상태 초기화 실패: ${err.message}`);
    // console.log(err);
  }
}

function convertColumnType(offset, colIdx, metaName) {
  let str = `$${offset + colIdx + 1}`;
  let colType = META_INFOS[metaName].cols[colIdx].split("|")[1];
  let colName = META_INFOS[metaName].cols[colIdx].split("|")[0];

  if (colType) {
    if (colType == "TIMESTAMP")
      str = `TO_TIMESTAMP($${offset + colIdx + 1},'YYYYMMDDHH24MISS')`;
    if (colType == "DATE")
      str = `TO_DATE($${offset + colIdx + 1},'YYYY-MM-DD')`;
    if (colType == "NUMBER") str = `$${offset + colIdx + 1}::integer`;
    if (colType == "NUMERIC") str = `$${offset + colIdx + 1}::NUMERIC`;
  }

  // 20250618 BRCD lpad 처리
  if (colName === "BRCD") {
    str = `LPAD($${offset + colIdx + 1},4,'0')`;
  }

  return str;
}

(async () => {
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[2];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const batchId = getBatchId(process.argv[1]);
  META_INFOS = getMETA_INFOS(basDt);
  //console.log(META_INFOS);
  for (let meta of Object.keys(META_INFOS)) {
    //await parseMeta(meta, META_INFOS[meta].filePath);
    const content = fs.readFileSync(META_INFOS[meta].filePath, "utf8");
    const lines = content.split("\n").filter((line) => line.trim() !== "");
    console.log(lines.length);

    const rows = lines
      .map((line) => {
        let l = line.split("^|");
        l.pop();
        if (l.length > 2) {
          l.push(batchId);
          l.push(dayjs().format("YYYYMMDDHHmmss"));
          l = l.map((d, i) => (d == "null" ? null : d.trimEnd()));
        }
        return l;
      })
      .filter((line) => line.length > 2);

    const columns = Object.values(META_INFOS[meta].cols).map(
      (d, i) => d.split("|")[0]
    );
    //.join(", ");
    //console.log(columns);

    const maxRows = 1;
    for (let i = 0; i < rows.length; i++) {
      const chunk = rows.slice(i, i + maxRows);
      await upsertMeta(meta, columns, chunk);
      console.log(
        `${META_INFOS[meta].tableName} : ${i + 1} / ${rows.length} UPSERT 완료`
      );
    }
  }
  client.end();
})();
