const fs = require("fs");
const dayjs = require("dayjs");
const { getBatchId, batchStart, getSafeBaseDt } = require("./common");
const axios = require("axios");
const { Agent } = require("http");
const { writeLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

// util이 불려진 시점부터 instace 생성하고 30초마다 재생성 keepAlive 처리
let agent = createNewAgent();
let axiosInstance = createAxiosInstance(agent);

//startAgentResetLoop();

function createNewAgent() {
  return new Agent({
    keepAlive: true,
    //keepAliveMsecs: 30000,
    maxSockets: 5000,
    maxFreeSockets: 1000,
  });
}

function createAxiosInstance(agent) {
  return axios.create({
    httpAgent: agent,
    timeout: 0,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });
}

let META_INFOS = {};

function getMETA_INFOS(basDt) {
  return {
    BDP_UDA_CMIE01M: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/BDP_UDA_CMIE01M_${basDt}.dat_NEW`,
      cols: {
        0: "EMN|VARCHAR",
        1: "EMM|VARCHAR",
        2: "EMP_ENSN_NM|VARCHAR",
        3: "GNDR_DCD|VARCHAR",
        4: "HLOF_YN|VARCHAR",
        5: "ETBN_DCD|VARCHAR",
        6: "BLNG_BRCD|VARCHAR",
        7: "BETEAM_CD|VARCHAR",
        8: "TRTH_WORK_BRCD|VARCHAR",
        9: "RSWR_BRCD|VARCHAR",
        10: "BRMD_RSN_CON|VARCHAR",
        11: "DUCD|VARCHAR",
        12: "DUTY_CD|VARCHAR",
        13: "DUTY_GRD|VARCHAR",
        14: "MNDT_CD|VARCHAR",
        15: "JBTT_CD|VARCHAR",
        16: "PRAR_JBTT_NO|VARCHAR",
        17: "PRAR_JTM|VARCHAR",
        18: "NAME_NM|VARCHAR",
        19: "EMP_EXT_NAME_NM|VARCHAR",
        20: "JBCL_CD|VARCHAR",
        21: "LNSL_DCD|VARCHAR",
        22: "EMP_ROST_SQC|NUMERIC",
        23: "EMAT_RCDE_DCD|VARCHAR",
        24: "USER_RGSN_BRCD|VARCHAR",
        25: "EDPS_CSN|NUMERIC",
        26: "PRFL_NM|VARCHAR",
        27: "PRAR_ONL_NO|VARCHAR",
        28: "EMP_EXTI_NO|VARCHAR",
        29: "EAD|VARCHAR",
        30: "ATHR_MNGM_ID|VARCHAR",
        31: "WBCS_RLNM_ALTR_NO|VARCHAR",
        32: "ETC_BSWR_CON|VARCHAR",
        33: "ETBN_YMD|SMALLINT",
        34: "EXIG_BLNG_YMD|VARCHAR",
        35: "DUTY_YMD|VARCHAR",
        36: "MNDT_YMD|VARCHAR",
        37: "JBTT_YMD|VARCHAR",
        38: "TRTH_BIRT_YMD|VARCHAR",
        39: "SLCN_UNCG_BIRT_YMD|VARCHAR",
        40: "USER_RGSN_YMD|VARCHAR",
        41: "RTRM_YMD|VARCHAR",
        42: "LSMD_YMD|VARCHAR",
        43: "LGL_BIRT_YMD|VARCHAR",
        44: "RGSF_DCD|VARCHAR",
        45: "BDP_ETL_BASE_YMD|VARCHAR",
        46: "BDP_ETL_JOB_TS|TIMESTAMP",
        47: "UDA_SYS_LSMD_ID|VARCHAR",
        48: "UDA_SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIE01M",
    },
  };
}

async function upsertMeta(metaName, columns, rows) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();
  const tableName = META_INFOS[metaName].tableName;
  const numCols = columns.length;
  const values = [];

  try {
    const tuples = rows
      .map((row, rowIdx) => {
        const offset = rowIdx * numCols;

        row.forEach((val) => values.push(val));

        const placeholders = row
          .map((_, colIdx) => convertColumnType(offset, colIdx, metaName))
          .join(", ");
        return `(${placeholders})`;
      })
      .join(",\n");

    // console.log(tuples);
    let mergeSql = `
      MERGE INTO ${tableName} AS t
      USING (
        VALUES
        ${tuples}
      ) AS s(${columns.join(", ")})
    `;
    if (tableName == "TB_UDA_UAIE54D")
      mergeSql += `ON (t.${columns[0]} = s.${columns[0]} AND t.${columns[1]} = s.${columns[1]} AND t.${columns[2]} = s.${columns[2]} AND t.${columns[3]} = s.${columns[3]} AND t.${columns[4]} = s.${columns[4]} AND t.${columns[5]} = s.${columns[5]} AND t.${columns[6]} = s.${columns[6]} AND t.${columns[7]} = s.${columns[7]})`;
    else mergeSql += `ON (t.${columns[0]} = s.${columns[0]})`;
    mergeSql += `
      WHEN MATCHED THEN
        UPDATE SET
          ${columns
            .slice(1)
            .map((col) => `${col} = s.${col}`)
            .join(",\n      ")}
        WHEN NOT MATCHED THEN
          INSERT (${columns.join(", ")})
          VALUES (${columns.map((col) => `s.${col}`).join(", ")})
    `;
    // console.log(mergeSql);
    //console.log(tuples);
    //console.log(values.length);
    // console.log(values);
    await client.query(mergeSql, values);
  } catch (err) {
    writeLog(`${tableName} => 작업 상태 초기화 실패: ${err.message}`);
    // console.log(err);
  } finally {
    client.release();
    pool.end();
  }
}

function convertColumnType(offset, colIdx, metaName) {
  let str = `$${offset + colIdx + 1}`;
  let colType = META_INFOS[metaName].cols[colIdx].split("|")[1];
  let colName = META_INFOS[metaName].cols[colIdx].split("|")[0];

  if (colType) {
    if (colType == "TIMESTAMP")
      str = `TO_TIMESTAMP($${offset + colIdx + 1},'YYYYMMDDHH24MISS')`;
    if (colType == "DATE")
      str = `TO_DATE($${offset + colIdx + 1},'YYYY-MM-DD')`;
    if (colType == "NUMBER") str = `$${offset + colIdx + 1}::integer`;
    if (colType == "NUMERIC") str = `$${offset + colIdx + 1}::NUMERIC`;
  }

  // 20250618 BRCD lpad 처리
  if (colName === "BRCD") {
    str = `LPAD($${offset + colIdx + 1},4,'0')`;
  }

  return str;
}

(async () => {
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[2];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const batchId = getBatchId(process.argv[1]);

  const assz_btch_acmp_id = await batchStart(
    basDt,
    batchId,
    "TBE01M",
    "01", //01	수집 02	자산화 03	전송
    "02", //01	대기 02	수행 03	중단 04	오류 05	완료
    "T2", //T1	메타+파일 T2	DB T3	지식샘
    "01" //assz_tgt_sys_cd
  ); //배치수행로그 입력 및 배치ID채번

  META_INFOS = getMETA_INFOS(basDt);
  //console.log(META_INFOS);
  for (let meta of Object.keys(META_INFOS)) {
    //await parseMeta(meta, META_INFOS[meta].filePath);
    let content;
    try {
      content = fs.readFileSync(META_INFOS[meta].filePath, "utf8");
    } catch (e) {
      continue;
    }
    const lines = content.split("\n").filter((line) => line.trim() !== "");
    //console.log(lines.length);

    const rows = lines
      .map((line) => {
        let l = line.split("^|");
        l.pop();
        if (l.length > 2) {
          l.push(batchId);
          l.push(dayjs().format("YYYYMMDDHHmmss"));
          l = l.map((d, i) => (d == "null" ? null : d.trimEnd()));
        }
        return l;
      })
      .filter((line) => line.length > 2);

    const columns = Object.values(META_INFOS[meta].cols).map(
      (d, i) => d.split("|")[0]
    );
    //.join(", ");
    //console.log(columns);

    const maxRows = 1;
    writeLog(`${META_INFOS[meta].filePath} 진행`);
    for (let i = 0; i < rows.length; i++) {
      const chunk = rows.slice(i, i + maxRows);
      await upsertMeta(meta, columns, chunk);
      writeLog(
        `${META_INFOS[meta].tableName} : ${i + 1} / ${rows.length} UPSERT 완료`
      );
    }
    const tableName = META_INFOS[meta].tableName;

    // 직원테이블인 경우 포탈 직원테이블 insert API 호출
    if (tableName == "TB_UDA_UAIE01M") {
      let datas = rows.map((d, i) => {
        return { empNo: d[0], birthDate: d[43] };
      });
      // console.log(datas);
      let API_URL = `http://172.18.120.150:10005/api/mnum/user/create`;

      try {
        const resp = await axiosInstance.post(API_URL, datas);
        writeLog(`${tableName} : ${resp.data.message}`);
      } catch (e) {
        writeLog(`${tableName} : ${e}`);
      }
    }
  }

  //배치수행 최종완료시간
  await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  // DB 커넥션 해제
  await dbBatch.dbEnd();
})();
