// 펀드 음성봇전송 기간데이터모음
const fs = require("fs");
const path = require("path");

const { writeLog, summaryLog } = require("../log");
const { finFileCreate, getSafeBaseDt } = require("./common");

const dbAvtMeta = require("../sql/TB_UDA_AVT_META");

async function avtFileCopyRange(basDt, fromDt, toDt) {
  writeLog(
    "----------------------------avtFileCopyRange()시작----------------------------"
  );

  let totalCnt = 0;
  let fileSuccessCnt = 0;
  let fileFailCnt = 0;
  let jsonSuccessCnt = 0;
  let jsonFailCnt = 0;

  const targetDir = `/data/bdpetl/send/avt/avt/iis/${basDt}`;

  try {
    //자산화된 파일명만 조회.
    const fileNmList = await dbAvtMeta.selectAvtFileIISRange(fromDt, toDt);

    console.log(`총 ${fileNmList.rows.length} 건`);
    for (const fnm of fileNmList.rows) {
      totalCnt++;
      const fileName = fnm.file_nm;
      if (fileName) {
        const fileBaseName = path.basename(fileName);

        if (fs.existsSync(fileName)) {
          try {
            let sendFilePath = path.join(targetDir, fileBaseName);
            fs.copyFileSync(fileName, sendFilePath);
            writeLog(`COPY완료 : ${sendFilePath}`);
            fileSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${fileName}, ${err}`);
            fileFailCnt++;
          }
        } else {
          writeLog(`${fileName} 파일 없음`);
          fileFailCnt++;
        }
      } else {
        writeLog(`${fileName} 파일명 비어있음..`);
        fileFailCnt++;
      }

      const jsonName = fnm.json_nm;
      if (jsonName) {
        const jsonBaseName = path.basename(jsonName);

        if (fs.existsSync(jsonName)) {
          let sendJsonPath = path.join(targetDir, jsonBaseName);
          try {
            let sendJsonPath = path.join(targetDir, jsonBaseName);
            fs.copyFileSync(jsonName, sendJsonPath);
            writeLog(`COPY완료 : ${sendJsonPath}`);
            jsonSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${jsonName}, ${err}`);
            jsonFailCnt++;
          }
        } else {
          writeLog(`${jsonName} 파일 없음`);
          jsonFailCnt++;
        }
      } else {
        writeLog(`${jsonName} 지원하지 않는 문서`);
        jsonFailCnt++;
      }
    }
  } catch (err) {
    writeLog(`Failed to read directory ${err}`);
  }

  console.log(`Total : ${totalCnt} 건`);
  console.log(`fileSuccess : ${fileSuccessCnt} 건`);
  console.log(`fileFail : ${fileFailCnt} 건`);
  console.log(`jsonSuccess : ${jsonSuccessCnt} 건`);
  console.log(`jsonFail : ${jsonFailCnt} 건`);

  summaryLog(
    totalCnt,
    jsonSuccessCnt,
    jsonFailCnt,
    `${fromDt}-${toDt}`,
    "avtFileCopyRange"
  );
  writeLog(
    "----------------------------avtFileCopyRange()종료----------------------------"
  );
}

async function makeMetaRange(basDt, fromDt, toDt) {
  writeLog(
    "----------------------------makeMetaRange()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/avt/avt/iis/${basDt}`;

  try {
    fs.accessSync(targetDir);
    writeLog(`/data/bdpetl/send/avt/avt/iis/${basDt} 경로 존재`);
  } catch (err) {
    writeLog(`/data/bdpetl/send/avt/avt/iis/${basDt} 경로 없음 생성중...`);
    fs.mkdirSync(targetDir, { recursive: true });
  }

  try {
    const res = await dbAvtMeta.selectAvtMetaIISRange(fromDt, toDt);

    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.assz_unfc_id,
          row.file_nm,
          row.assz_cfbo_idnt_id,
          row.flsz_vl,
          row.file_type,
          row.assz_pcsn_tcd,
          row.rgsn_ts,
          row.amnn_ts,
          row.cnvs_grp_cd,
          row.assz_dcmn_clsf_id,
          row.conn_ttl_nm,
          row.assz_fund_dcmn_dcd,
          row.assz_fund_new_abl_yn,
          row.sale_fnsh_ymd,
          row.trth_file_nm,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";

      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  } finally {
  }
  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    `${fromDt}-${toDt}`,
    "makeMetaRange"
  );
  writeLog(
    "----------------------------makeMetaRange()종료----------------------------"
  );
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ IISIIS AVT 전송 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  const pcsnClCd = process.argv[2];
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[3];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const fromDt = process.argv[4];
  const toDt = process.argv[5];

  if (pcsnClCd == "01") {
    await makeMetaRange(basDt, fromDt, toDt);
    await avtFileCopyRange(basDt, fromDt, toDt);
    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/avt/avt/iis", basDt);
  }

  await dbAvtMeta.dbEnd();

  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ IISIIS AVT 전송 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃"
  );
}

main();
