// UDACSMDASSETR002 카드몰 전송스크립트
const fs = require("fs");
const path = require("path");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일

const { selectMetaDocNmCsmRange } = require("../sql/TB_UDA_UAI000M");

const { finFileCreate, getSafeBaseDt } = require("./common");

async function makeMetaRange(basDt, fromDt, toDt) {
  writeLog(
    "----------------------------makeMetaRange()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/csm/${basDt}`;

  try {
    fs.accessSync(targetDir);
    writeLog(`/data/bdpetl/send/gai/gai/csm/${basDt} 경로 존재`);
  } catch (err) {
    writeLog(`/data/bdpetl/send/gai/gai/csm/${basDt} 경로 없음 생성중...`);
    fs.mkdirSync(targetDir, { recursive: true });
  }

  try {
    const res = await dbGaiMeta.selectMakeCsmMetaRange(fromDt, toDt);
    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";

      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  } finally {
  }
  summaryLog(totalCnt, successCnt, failCnt, "", "makeMetaRange");
  writeLog(
    "----------------------------makeMetaRange()종료----------------------------"
  );
}

async function gaiFileCopyRange(basDt, fromDt, toDt) {
  writeLog(
    "----------------------------gaiFileCopyRange()시작----------------------------"
  );

  let totalCnt = 0;
  let fileSuccessCnt = 0;
  let fileFailCnt = 0;
  let jsonSuccessCnt = 0;
  let jsonFailCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/csm/${basDt}`;

  try {
    //자산화된 파일명만 조회.
    const fileNmList = await selectMetaDocNmCsmRange(fromDt, toDt);

    //console.log(`총 ${fileNmList.rows.length} 건`);
    for (const fnm of fileNmList.rows) {
      totalCnt++;
      const fileName = fnm.file_nm;
      if (fileName) {
        const fileBaseName = path.basename(fileName);

        if (fs.existsSync(fileName)) {
          try {
            let sendFilePath = path.join(targetDir, fileBaseName);
            fs.copyFileSync(fileName, sendFilePath);
            writeLog(`COPY완료 : ${sendFilePath}`);
            fileSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${fileName}, ${err}`);
            fileFailCnt++;
          }
        } else {
          writeLog(`${fileName} 파일 없음`);
          fileFailCnt++;
        }
      } else {
        writeLog(`${fileName} 파일명 비어있음..`);
        fileFailCnt++;
      }

      const jsonName = fnm.json_nm;
      if (jsonName) {
        const jsonBaseName = path.basename(jsonName);

        if (fs.existsSync(jsonName)) {
          let sendJsonPath = path.join(targetDir, jsonBaseName);
          try {
            let sendJsonPath = path.join(targetDir, jsonBaseName);
            fs.copyFileSync(jsonName, sendJsonPath);
            writeLog(`COPY완료 : ${sendJsonPath}`);
            jsonSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${jsonName}, ${err}`);
            jsonFailCnt++;
          }
        } else {
          writeLog(`${jsonName} 파일 없음`);
          jsonFailCnt++;
        }
      } else {
        writeLog(`${jsonName} 지원하지 않는 문서`);
        jsonFailCnt++;
      }
    }
  } catch (err) {
    writeLog(`Failed to read directory ${err}`);
  }

  summaryLog(totalCnt, jsonSuccessCnt, jsonFailCnt, "", "gaiFileCopyRange");
  writeLog(
    "----------------------------gaiFileCopyRange()종료----------------------------"
  );
}

/*---------------------- 메인 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ CSMCSM GTP전송 기간데이터모음 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  const pcsnClCd = process.argv[2];
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[3];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const fromDt = process.argv[4];
  const toDt = process.argv[5];

  if (pcsnClCd == "01") {
    await makeMetaRange(basDt, fromDt, toDt);
    await gaiFileCopyRange(basDt, fromDt, toDt);
    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/csm", basDt);
  }

  await dbGaiMeta.dbEnd();

  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ CSMCSM GTP전송 기간데이터모음 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
}

// 메인 실행
main();
