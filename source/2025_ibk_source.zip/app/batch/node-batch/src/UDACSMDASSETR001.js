// UDACSMDASSETR001 카드몰 (CSM > CSM)
const fs = require("fs");
const path = require("path");
const util = require("../util");
const { exec, spawn } = require("child_process");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dayjs = require("dayjs");
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); // 자산화 처리로그
const dbAssetRlt = require("../sql/TB_UDA_UAI910L"); //자산화 처리로그
const dbMetaMain = require("../sql/TB_UDA_UAI872M"); // UDA카드몰메타
const dbImgRlt = require("../sql/TB_UDA_UAI912L");
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

const { pg, cg } = require("../guardComm").initGuard();

const { Pool } = require("pg");
const config = require("../config");

const {
  checkUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  updateBatchId,
  updateErorVl,
  selectMetaDocNmCsm,
  selectOne,
  selectOneForUpdate,
  updateOriginMaster,
  updateOnlyAsszScd,
} = require("../sql/TB_UDA_UAI000M");
const { insertHistory } = require("../sql/TB_UDA_UAI000H");
const {
  EROR_CODES,
  COMMON_CODES,
  batchStart,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  insertLdgrRecvPool,
  updateLdgrSelfPool,
  updateLdgrUpdateSelfPool,
  updateLdgrRecvPool,
  getFileInfo,
  insertLdgrSelfPoolByJsonMerge01,
  sync,
  finFileCheck,
  finFileCreate,
  recvMetaFileCheck,
  getBatchId,
  insertLdgrCsm,
  updateLdgrCsm,
  insertLdgrMaster,
  mergeDocument,
  moveAssetData,
  getSafeBaseDt,
} = require("./common");

const batchId = getBatchId(process.argv[1]);

/*---------------------- 폴더 생성 ----------------------*/
async function makeDir(basDt) {
  const dirs = [
    `/data/asset/csm/csm/${basDt}/att`,
    `/data/asset/csm/csm/${basDt}/dp`,
    `/data/asset/csm/csm/${basDt}/json`,
    `/data/asset/csm/csm/${basDt}/origin`,
    `/data/asset/csm/csm/${basDt}/pdf`,
    `/data/asset/csm/csm/${basDt}/txt`,
    `/data/asset/csm/csm/${basDt}/img`,
    `/data/asset/csm/csm/att`,
    `/data/asset/csm/csm/dp`,
    `/data/asset/csm/csm/json`,
    `/data/asset/csm/csm/origin`,
    `/data/asset/csm/csm/pdf`,
    `/data/asset/csm/csm/txt`,
    `/data/asset/csm/csm/img`,
    `/data/bdpetl/send/gai/gai/csm/${basDt}`, // GPT
    `/data/bdpetl/send/avt/avt/csm/${basDt}`, // 음성봇
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*---------------------- 메인메타 저장 ----------------------*/
async function mainMetaInsert(basDt, assz_btch_acmp_id) {
  writeLog(
    "---------------------------- mainMetaInsert() 시작 ----------------------------"
  );

  const sourceBase = `/data/bdpetl/recv/csm/csm/${basDt}/file`;
  const targetBase = `/data/asset/csm/csm/${basDt}/origin`;
  const pdfBase = `/data/asset/csm/csm/${basDt}/pdf`;
  const attBase = `/data/asset/csm/csm/${basDt}/att`;
  let chgFullBase = "";

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 메인메타 읽어오기
  const masterInfo = fs.readFileSync(
    `/data/asset/csm/csm/${basDt}/meta/master_conv.dat`,
    "utf-8"
  );
  const lines_m = masterInfo.split("\n");

  // info 메타 읽어오기
  const infoMeta = await getInfoMeta(basDt);

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "CSMCSM");
  let idx = result.rows[0].idsqn;

  for (const line of lines_m) {
    if (line.trim() === "") continue;

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      orgn_data_rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_orgn_pcsn_dcd,
      atch_yn,
      atch_sqn,
      assz_dcmn_clsf_id,
      conn_ttl_nm,
    ] = line.split("^|");

    totalCnt++;

    if (file_sqn == "" || file_sqn == null || file_sqn == "null") {
      file_sqn = 0;
    }
    if (atch_sqn == "" || atch_sqn == null || atch_sqn == "null") {
      atch_sqn = 0;
    }

    // 자산화원천별식별ID가 없을 경우
    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`원천키없음 ${assz_cfbo_idnt_id}`);
      continue;
    } else {
      let [
        _, // 원천별식별키
        isnc_tgt_con, // 발급대상내용
        card_kind_con, // 카드종류내용
        isnc_intt_con, // 발급기관내용
        fee_cndt_con, // 수수료조건내용
        cdis_info_con, // 카드발급정보내용
        card_ftpm_trfc_con, // 카드후불교통내용
        anf_con, // 연회비내용
        assz_card_alnc_cd_nm, // 카드제휴코드
      ] = infoMeta.filter((d, i) => d[0] === assz_cfbo_idnt_id)[0];

      let assz_unfc_id = null;
      let errCd = EROR_CODES.EROR_VL_SUCCESS;
      let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      const ext = path.extname(file_nm).toLowerCase();

      let filename = "";

      let sourcePath = path.join(sourceBase, file_nm);
      let pdfPath = "";
      let chgFullPath = "";
      if (atch_yn == "N") {
        chgFullBase = targetBase;
      } else {
        chgFullBase = attBase;
      }

      try {
        fs.accessSync(sourcePath);
      } catch (err) {
        writeLog(`파일없음: ${sourcePath}`);
        assz_unfc_id = await getUnfcId("CSMCSM", ++idx);

        filename = `${assz_unfc_id}${ext}`;
        chgFullPath = path.join(chgFullBase, filename);
        //원장마스터 인서트
        await insertLdgrMaster(
          null,
          assz_unfc_id,
          COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
          assz_cfbo_idnt_id,
          null,
          null,
          assz_orgn_pcsn_dcd,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR,
          chgFullPath, //assz_pcsn_file_path_nm,
          null,
          null,
          assz_btch_acmp_id,
          batchId
        );

        //업무별원장 인서트
        await insertLdgrCsm(
          null,
          assz_unfc_id,
          assz_cfbo_idnt_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          isnc_tgt_con,
          card_kind_con,
          isnc_intt_con,
          fee_cndt_con,
          cdis_info_con,
          card_ftpm_trfc_con,
          anf_con,
          assz_card_alnc_cd_nm,
          batchId
        );
        //히스토리 인서트 없음
        failCnt++;
        continue;
      }

      let isExist = false;

      /**
       * fileinfo 저장, 파일크기, 난수값
       */
      const fileInfo = await getFileInfo(sourcePath);

      // 이미 수행한 건일경우
      const checkItem = await getUnfcIdFromIdntId(
        "CSMCSM",
        assz_cfbo_idnt_id,
        atch_sqn
      );

      if (
        checkItem.rows.filter(
          (d, i) => d.assz_orgn_pcsn_dcd == assz_orgn_pcsn_dcd
        ).length > 0
      ) {
        /**
         *  이미 존재할 때 파일해시값을 비교하여 Update 처리
         */
        if (checkItem.rows[0].assz_orgn_file_encp_rnnm_vl == fileInfo.md5) {
          writeLog(`이미 처리함 ${assz_cfbo_idnt_id} ${assz_btch_acmp_id}`);
          assz_unfc_id = checkItem.rows[0].assz_unfc_id;
          filename = `${assz_unfc_id}${ext}`;
          chgFullPath = path.join(chgFullBase, filename);
          isExist = true;
          /*await updateBatchId(
            checkItem.rows[0].assz_unfc_id,
            assz_btch_acmp_id
          );*/
          successCnt++;
        } else {
          writeLog(`업데이트건 ${assz_cfbo_idnt_id} ${assz_btch_acmp_id}`);

          assz_unfc_id = checkItem.rows[0].assz_unfc_id;
          filename = `${assz_unfc_id}${ext}`;
          chgFullPath = path.join(chgFullBase, filename);
          await updateOriginMaster(
            assz_unfc_id,
            assz_btch_acmp_id,
            COMMON_CODES.ASSZ_SCD_INIT,
            String(fileInfo.size),
            fileInfo.md5,
            chgFullPath,
            "", // 자산화처리파일 경로명
            errCd,
            errStr
          );

          successCnt++;
        }
      } else {
        if (assz_orgn_pcsn_dcd == "D") {
          let result = await getUnfcIdFromIdntId(
            "CSMCSM",
            assz_cfbo_idnt_id,
            atch_sqn
          );

          if (result.rowCount == 0) {
            writeLog(`삭제건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);
            assz_unfc_id = await getUnfcId("CSMCSM", ++idx);

            filename = `${assz_unfc_id}${ext}`;
            chgFullPath = path.join(chgFullBase, filename);

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_UNSUCCESS,
              EROR_CODES.EROR_VL_UNSUCCESS_STR,
              chgFullPath, //assz_pcsn_file_path_nm,
              String(fileInfo.size),
              fileInfo.md5,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrCsm(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              isnc_tgt_con,
              card_kind_con,
              isnc_intt_con,
              fee_cndt_con,
              cdis_info_con,
              card_ftpm_trfc_con,
              anf_con,
              assz_card_alnc_cd_nm,
              batchId
            );

            failCnt++;
            continue;
          } else {
            assz_unfc_id = result.rows[0].assz_unfc_id;
            filename = `${assz_unfc_id}${ext}`;
            chgFullPath = path.join(chgFullBase, filename);
            //'D'  로 변경
            //원장마스터 업데이트
            await updateLdgrSelfPool(
              assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_DELETE
            ); //01 값 확인필요
            //원장은행상품설명서 업데이트
            await updateLdgrCsm(assz_unfc_id, "D");
            successCnt++;
          }
        } else if ("U" === assz_orgn_pcsn_dcd) {
          let result = await getUnfcIdFromIdntId(
            "CSMCSM",
            assz_cfbo_idnt_id,
            atch_sqn
          );

          if (result.rowCount == 0) {
            writeLog(`업데이트건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);
            assz_unfc_id = await getUnfcId("CSMCSM", ++idx);

            filename = `${assz_unfc_id}${ext}`;
            chgFullPath = path.join(chgFullBase, filename);

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_UNSUCCESS2,
              EROR_CODES.EROR_VL_UNSUCCESS2_STR,
              chgFullPath, //assz_pcsn_file_path_nm,
              String(fileInfo.size),
              fileInfo.md5,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrCsm(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              file_nm,
              file_sqn,
              assz_orcp_file_path_nm,
              orgn_data_rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              atch_yn,
              atch_sqn,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              isnc_tgt_con,
              card_kind_con,
              isnc_intt_con,
              fee_cndt_con,
              cdis_info_con,
              card_ftpm_trfc_con,
              anf_con,
              assz_card_alnc_cd_nm,
              batchId
            );

            failCnt++;
            continue;
          } else {
            let cData = await selectOne("CSMCSM", assz_cfbo_idnt_id, atch_sqn);
            assz_unfc_id = cData.rows[0].assz_unfc_id;
            filename = `${assz_unfc_id}${ext}`;
            chgFullPath = path.join(chgFullBase, filename);
            writeLog(`Update! ${assz_unfc_id}`);
            //'U'  로 변경
            //원장마스터 업데이트
            await updateLdgrSelfPool(
              assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_INIT
            ); //01 값 확인필요
            //원장은행상품설명서 업데이트
            await updateLdgrCsm(assz_unfc_id, "U");
            successCnt++;
          }
        } else if ("C" === assz_orgn_pcsn_dcd) {
          assz_unfc_id = await getUnfcId("CSMCSM", ++idx);

          filename = `${assz_unfc_id}${ext}`;
          chgFullPath = path.join(chgFullBase, filename);

          //원장마스터 인서트
          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_INIT, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
            assz_cfbo_idnt_id,
            null,
            null,
            assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_SUCCESS,
            EROR_CODES.EROR_VL_SUCCESS_STR,
            chgFullPath, //assz_pcsn_file_path_nm,
            String(fileInfo.size),
            fileInfo.md5,
            assz_btch_acmp_id,
            batchId
          );

          //업무별원장 인서트
          await insertLdgrCsm(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            file_nm,
            file_sqn,
            assz_orcp_file_path_nm,
            orgn_data_rgsr_id,
            rgsn_ts,
            amnn_ts,
            assz_orgn_pcsn_dcd,
            atch_yn,
            atch_sqn,
            assz_dcmn_clsf_id,
            conn_ttl_nm,
            isnc_tgt_con,
            card_kind_con,
            isnc_intt_con,
            fee_cndt_con,
            cdis_info_con,
            card_ftpm_trfc_con,
            anf_con,
            assz_card_alnc_cd_nm,
            batchId
          );
          successCnt++;
        }
      }

      try {
        chgFullPath = path.join(chgFullBase, filename);
        fs.copyFileSync(sourcePath, chgFullPath);

        if (ext === ".pdf") {
          pdfPath = path.join(pdfBase, filename);
          fs.copyFileSync(sourcePath, pdfPath);
        }
      } catch (err) {
        writeLog(
          `${EROR_CODES.EROR_VL_COPY_FAILED_STR} ${sourcePath}:${chgFullPath}`
        );
        errCd = EROR_CODES.EROR_VL_COPY_FAILED;
        errStr = EROR_CODES.EROR_VL_COPY_FAILED_STR;
        // 배치메타저장
        await dbMetaMain.insertMeta(
          null,
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          conn_ttl_nm,
          chgFullPath,
          batchId
        );

        // 배치 info 메타 저장
        await dbMetaMain.insertInfoMeta(
          null,
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          isnc_tgt_con,
          card_kind_con,
          isnc_intt_con,
          fee_cndt_con,
          cdis_info_con,
          card_ftpm_trfc_con,
          anf_con,
          assz_card_alnc_cd_nm,
          chgFullPath,
          batchId
        );

        failCnt++;

        updateErorVl(assz_unfc_id, errCd, errStr);
        //자산화상태코드 예외로 변경해야함----------------------
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
        continue;
      }

      // 배치메타저장
      await dbMetaMain.insertMeta(
        null,
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        chgFullPath,
        batchId
      );

      // 배치 info 메타 저장
      await dbMetaMain.insertInfoMeta(
        null,
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        isnc_tgt_con,
        card_kind_con,
        isnc_intt_con,
        fee_cndt_con,
        cdis_info_con,
        card_ftpm_trfc_con,
        anf_con,
        assz_card_alnc_cd_nm,
        chgFullPath,
        batchId
      );

      // pdf 만 먼저저장, jpg는 jpgtopdf 에서 저장
      if (ext === ".pdf" && !isExist) {
        const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
        // let astpCd = path.extname(filename).toLowerCase() === ".pdf" ? "PD" : "JG";
        let astpCd = "PD";
        await dbAssetLog.insertLog(
          assz_btch_acmp_id,
          assz_unfc_id,
          assz_cfbo_idnt_id,
          atch_yn,
          astpCd, //HW      HWP PD  PDF ML  HTML
          "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
          "C", //C 신규 U 수정 D삭제
          "N", //이미지처리여부
          null,
          null,
          null,
          "CH", //NO(None),CH(변환)
          null,
          null,
          null,
          "SI", //SI(단일 문서),MU(멀티 통합 문서)
          strDate, //원본변환시작일시
          endDate, //원본변환종료일시
          pdfPath,
          errCd, //에러 0000
          errStr,
          batchId,
          "Y"
        );
      }

      writeLog(`파일복사 성공 ${chgFullPath}`);
    }
  }
  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "mainMetaInsert"
  );
  writeLog(
    "---------------------------- mainMetaInsert() 종료 ----------------------------"
  );
}

function removeTag(text) {
  let match = text.match(/^[^<]+/);
  return match ? match[0].trim() : "";
}

/*---------------------- 메인메타 저장 ----------------------*/
async function getInfoMeta(basDt) {
  // 메인메타 읽어오기
  const masterInfo = fs.readFileSync(
    `/data/asset/csm/csm/${basDt}/meta/add_info_conv.dat`,
    "utf-8"
  );
  const lines_m = masterInfo.split("\n");

  let newMeta = [];

  for (const line of lines_m) {
    if (line.trim() === "") continue;

    let [
      assz_cfbo_idnt_id, // 원천별식별키
      isnc_tgt_con, // 발급대상내용
      card_kind_con, // 카드종류내용
      isnc_intt_con, // 발급기관내용
      fee_cndt_con, // 수수료조건내용
      cdis_info_con, // 카드발급정보내용
      card_ftpm_trfc_con, // 카드후불교통내용
      anf_con, // 연회비내용
      assz_card_alnc_cd_nm, // 카드제휴코드
    ] = line.split("^|");

    // 자산화원천별식별ID가 없을 경우
    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`원천키없음 ${assz_cfbo_idnt_id}`);
      continue;
    } else {
      /**
       *  태그 삭제
       */
      isnc_tgt_con = removeTag(isnc_tgt_con);
      isnc_intt_con = removeTag(isnc_intt_con);

      newMeta.push([
        assz_cfbo_idnt_id == undefined ? "" : assz_cfbo_idnt_id, // 원천별식별키
        isnc_tgt_con == undefined ? "" : isnc_tgt_con, // 발급대상내용
        card_kind_con == undefined ? "" : card_kind_con, // 카드종류내용
        isnc_intt_con == undefined ? "" : isnc_intt_con, // 발급기관내용
        fee_cndt_con == undefined ? "" : fee_cndt_con, // 수수료조건내용
        cdis_info_con == undefined ? "" : cdis_info_con, // 카드발급정보내용
        card_ftpm_trfc_con == undefined ? "" : card_ftpm_trfc_con, // 카드후불교통내용
        anf_con == undefined ? "" : anf_con, // 연회비내용
        assz_card_alnc_cd_nm == undefined ? "" : assz_card_alnc_cd_nm, // 카드제휴코드
      ]);
    }
  }

  return newMeta;
}

async function jtp(data) {
  const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
  return new Promise((resolve, reject) => {
    const command = data.command;
    writeLog(command);
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      //writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        //writeLog(`변환성공: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: true,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
          strDate: strDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`변환실패 [Fail 출력됨]: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0210",
          errStr: `jpgtoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
          strDate: strDate,
        });
      } else {
        writeLog(`결과미확인: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
          strDate: strDate,
        });
      }
    });
  });
}

/*----------------------hwptoPdf----------------------*/
async function jpgtoPdf(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------jpgtoPdf()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(1);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  //조회시 파일 확장자만 필터
  const metaData = await dbMetaMain.selectMeta(null, assz_btch_acmp_id);
  const commands = [];

  //hwp파일변환
  for (const md of metaData.rows) {
    const oriFileName = path.basename(md.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    if (ext != ".jpg") {
      continue;
    }

    let chgFileName = oriFileName.replace(ext, ".pdf");

    const chgFilePath = `/data/asset/csm/csm/${basDt}/pdf/${chgFileName}`;

    totalCnt++;

    let command = `python3 /app/hwp2pdfv2/hwp2pdf.py "${md.assz_pcsn_file_path_nm}" "/data/asset/csm/csm/${basDt}/pdf"`;
    command = command.replace(/`/g, "\\`");

    commands.push({
      assz_btch_acmp_id: assz_btch_acmp_id,
      astpCd: "PD",
      command: command,
      chgFilePath: chgFilePath,
      atch_yn: md.atch_yn,
      assz_pcsn_file_path_nm: md.assz_pcsn_file_path_nm,
      assz_cfbo_idnt_id: md.assz_cfbo_idnt_id,
      assz_unfc_id: md.assz_unfc_id,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => jtp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    await dbAssetLog.insertLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      result.assz_cfbo_idnt_id,
      result.atch_yn,
      result.astpCd, //HW      HWP PD  PDF ML  HTML
      "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
      "C", //C 신규 U 수정 D삭제
      "N", //이미지처리여부
      null,
      null,
      null,
      "CH", //NO(None),CH(변환)
      result.strDate,
      endDate,
      result.chgFilePath,
      "SI", //SI(단일 문서),MU(멀티 통합 문서)
      result.strDate, //원본변환시작일시
      endDate, //원본변환종료일시
      result.chgFilePath,
      result.errCd, //에러 0000
      result.errStr,
      batchId,
      "Y"
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jpgtoPdf");
  writeLog(
    "----------------------------jpgtoPdf()종료----------------------------"
  );
}

/*---------------------- DRM 해제 ----------------------*/
async function drmUnlock(basDt) {
  writeLog(
    "---------------------------- drmUnlock() 시작 ----------------------------"
  );

  const dirs = ["origin", "pdf"]; // DRM 해제 할 디렉토리 목록
  let result = "";

  for (const dir of dirs) {
    const fullPath = `/data/asset/csm/csm/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`DRM 오류: ${fullPath} ${err.message}`);
    }
  }
  writeLog(
    "---------------------------- drmUnlock() 종료 ----------------------------"
  );
}

/*----------------------PDF->IMG 추출----------------------*/
async function pdftoImgPerPage(basDt, assz_btch_acmp_id) {
  writeLog(
    "---------------------------- pdftoImgPerPage() 시작 ----------------------------"
  );

  // 기본 변수 셋팅
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);

  const outFolder = `/data/asset/csm/csm/${basDt}/att`;
  const commands = [];

  // UDA자산화처리로그 조회
  const logData = await dbAssetLog.selectLog06(assz_btch_acmp_id, "02");

  for (const ld of logData.rows) {
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);
    if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      let command = `python3 /app/pdftoimg/pdftoimgpage.py "${ld.assz_orcp_file_path_nm}" "${outFolder}"`;

      commands.push({
        assz_btch_acmp_id: ld.assz_btch_acmp_id,
        assz_unfc_id: ld.assz_unfc_id,
        oriFileName: oriFileName,
        header: ld,
        command: command,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => pti(data)));
  for await (const result of tasks) {
    let errCd = "0000";
    let errStr = "";

    totalCnt++;
    if (result.success) {
      errCd = EROR_CODES.EROR_VL_SUCCESS;
      errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      successCnt++;
    } else {
      errCd = EROR_CODES.EROR_VL_IMG_FAILED2;
      errStr = EROR_CODES.EROR_VL_IMG_FAILED_STR2;
      failCnt++;
    }

    await dbAssetLog.updateLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      "82",
      null, // assz_img_pcsn_yn
      null, // assz_img_pcsn_acmp_sttg_ts
      null, // assz_img_pcsn_acmp_fnsh_ts
      null, // assz_img_pcsn_acmp_rslt_dcd
      null, // assz_conv_pcsn_tcd
      null, //변환시작일시
      null, //변환종료일시
      null, // assz_conv_file_path_nm
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );

    await updateErorVl(result.assz_unfc_id, errCd, errStr);
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "pdftoImgPerPage"
  );
  writeLog(
    "---------------------------- pdftoImgPerPage() 종료 ----------------------------"
  );
}

/*----------------------PDF->IMG 추출----------------------*/
async function pdftoImg(basDt, assz_btch_acmp_id) {
  writeLog(
    "---------------------------- pdftoImg() 시작 ----------------------------"
  );

  // 기본 변수 셋팅
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);

  const imagepdfFolder = `/data/asset/csm/csm/${basDt}/att`;
  const outFolder = `/data/asset/csm/csm/${basDt}/dp`;
  const commands = [];

  // UDA자산화처리로그 조회
  const logData = await dbAssetLog.selectLog06(assz_btch_acmp_id, "82");

  for (const ld of logData.rows) {
    // PDF일 경우
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);
    if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      let command = `python3 /app/pdftoimg/pdftoimg.py "${imagepdfFolder}/${oriFileName}" "${outFolder}" "${ld.assz_btch_acmp_id}" "${ld.assz_unfc_id}" "${ld.uda_sys_lsmd_id}"`;
      commands.push({
        assz_btch_acmp_id: ld.assz_btch_acmp_id,
        assz_unfc_id: ld.assz_unfc_id,
        oriFileName: oriFileName,
        header: ld,
        command: command,
      });
    }
  }

  // PDF->IMG 추출 모듈 실행
  const tasks = commands.map((data, idx) => limit(() => pti(data)));

  for await (const result of tasks) {
    let errCd = "0000";
    let errStr = "";

    totalCnt++;
    if (result.success) {
      errCd = EROR_CODES.EROR_VL_SUCCESS;
      errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      successCnt++;
    } else {
      errCd = EROR_CODES.EROR_VL_IMG_FAILED;
      errStr = EROR_CODES.EROR_VL_IMG_FAILED_STR;
      failCnt++;
    }

    await dbAssetLog.updateLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      "03",
      null, // assz_img_pcsn_yn
      null, // assz_img_pcsn_acmp_sttg_ts
      null, // assz_img_pcsn_acmp_fnsh_ts
      null, // assz_img_pcsn_acmp_rslt_dcd
      null, // assz_conv_pcsn_tcd
      null, //변환시작일시
      null, //변환종료일시
      null, // assz_conv_file_path_nm
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoImg");
  writeLog(
    "---------------------------- pdftoImg() 종료 ----------------------------"
  );
}

/*---------------------- PDF->IMG 추출 모듈 실행 ----------------------*/
async function pti(data) {
  return new Promise((resolve, reject) => {
    const command = data.command;
    writeLog(command);
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr);
        return;
      }
      if (stdout.includes("[Success]")) {
        //writeLog(`추출성공: ${data.oriFileName}`);
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) errMsg = match[1];

        let errStr = `[Fail 출력됨]: ${data.oriFileName} / 사유 : ${errMsg}`;
        resolve({
          success: false,
          errCd: null,
          errStr: errStr,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
        });
      } else {
        writeLog(`pdftoImg 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------jsonMerge----------------------*/
async function jsonMerge(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge01()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const outFolder = `/data/asset/csm/csm/${basDt}/json`;
  const oriJsonFiles = await dbAssetLog.selectLog06(assz_btch_acmp_id, "03");
  const sourcePdfFolder = `/data/asset/csm/csm/${basDt}/pdf`;

  for (const oriJsonFile of oriJsonFiles.rows) {
    if (oriJsonFile.assz_pcsn_tgt_tcd != "PD") {
      writeLog("jsonMerge continue 원본이 PDF가 아닙니다.");
      continue;
    }
    totalCnt++;
    let file_path = oriJsonFile.assz_orcp_file_path_nm;
    writeLog(file_path);
    let fileNameExt = path.basename(file_path);
    let fileName = `${path.parse(fileNameExt).name}.json`;

    fs.writeFileSync(
      `/data/asset/csm/csm/${basDt}/json/${fileName}`,
      JSON.stringify({ data: [] }, null, 2),
      "utf-8"
    );

    const pdfFilePath = path.join(outFolder, fileName);

    const realPdfFileName = `${oriJsonFile.file_nm}.pdf`;
    const realPdfFilePath = path.join(sourcePdfFolder, realPdfFileName);

    const startDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    const imgJsonFiles = await dbImgRlt.selectFilePathNm(
      assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id
    );
    const imgJsonList = imgJsonFiles.rows.map(
      (row) => row.assz_pcsn_file_path_nm
    );

    let errCd = "0000";
    let errStr = "";

    try {
      mergeJsonFiles(pdfFilePath, imgJsonList);
      successCnt++;
      const fileStat = fs.statSync(pdfFilePath);
      const fileSize = Math.floor(fileStat.size / 1024);

      let endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      // 성공 로그 insert
      await dbAssetRlt.insertAst(
        oriJsonFile.assz_btch_acmp_id,
        oriJsonFile.assz_unfc_id,
        "CSMCSM",
        oriJsonFile.assz_cfbo_idnt_id,
        oriJsonFile.dcmn_nm,
        fileName,
        oriJsonFile.assz_pcsn_tgt_tcd,
        oriJsonFile.assz_pcsn_tcd,
        fileSize,
        "PD",
        null,
        null,
        pdfFilePath,
        oriJsonFile.url_adr,
        oriJsonFile.rgsn_ts,
        oriJsonFile.amnn_ts,
        startDate,
        endDate,
        "N",
        null,
        oriJsonFile.uda_sys_lsmd_id,
        errCd,
        errStr,
        "Y"
      );
    } catch (err) {
      //console.log("에러메세지2:::" + err);
      writeLog(`jsonMerge01 변환 실패: ${pdfFilePath}`);
      errCd = "0510";
      errStr = `jsonMerge01 변환 실패: ${pdfFilePath}:::::${err.message}`;
      failCnt++;
    }

    let endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      oriJsonFile.assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id,
      "84",
      null, // assz_img_pcsn_yn
      null, // assz_img_pcsn_acmp_sttg_ts
      null, // assz_img_pcsn_acmp_fnsh_ts
      null, // assz_img_pcsn_acmp_rslt_dcd
      null, // assz_conv_pcsn_tcd
      startDate, //변환시작일시
      endDate, //변환종료일시
      pdfFilePath, // assz_conv_file_path_nm
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jsonMerge01");
  writeLog(
    "----------------------------jsonMerge01()종료----------------------------"
  );
}

async function makeMeta(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeMeta()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/csm/${basDt}`;

  try {
    fs.accessSync(targetDir);
    writeLog(`/data/bdpetl/send/gai/gai/csm/${basDt} 경로 존재`);
  } catch (err) {
    writeLog(`/data/bdpetl/send/gai/gai/csm/${basDt} 경로 없음 생성중...`);
    fs.mkdirSync(targetDir, { recursive: true });
  }

  try {
    const res = await dbGaiMeta.selectMakeCsmMeta(assz_btch_acmp_id);
    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";

      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  } finally {
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeMeta");
  writeLog(
    "----------------------------makeMeta()종료----------------------------"
  );
}

async function gaiFileCopy(basDt, assz_btch_acmp_id) {
  writeLog(
    "----------------------------gaiFileCopy()시작----------------------------"
  );

  let totalCnt = 0;
  let fileSuccessCnt = 0;
  let fileFailCnt = 0;
  let jsonSuccessCnt = 0;
  let jsonFailCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/csm/${basDt}`;

  try {
    //자산화된 파일명만 조회.
    const fileNmList = await selectMetaDocNmCsm(assz_btch_acmp_id, basDt);

    console.log(`총 ${fileNmList.rows.length} 건`);
    for (const fnm of fileNmList.rows) {
      totalCnt++;
      const fileName = fnm.file_nm.replace(".jpg", ".pdf");
      if (fileName) {
        const fileBaseName = path.basename(fileName);

        if (fs.existsSync(fileName)) {
          try {
            let sendFilePath = path.join(targetDir, fileBaseName);
            fs.copyFileSync(fileName, sendFilePath);
            writeLog(`COPY완료 : ${sendFilePath}`);
            fileSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${fileName}, ${err}`);
            fileFailCnt++;
          }
        } else {
          writeLog(`${fileName} 파일 없음`);
          fileFailCnt++;
        }
      } else {
        writeLog(`${fileName} 파일명 비어있음..`);
        fileFailCnt++;
      }

      const jsonName = fnm.json_nm;
      if (jsonName) {
        const jsonBaseName = path.basename(jsonName);

        if (fs.existsSync(jsonName)) {
          let sendJsonPath = path.join(targetDir, jsonBaseName);
          try {
            let sendJsonPath = path.join(targetDir, jsonBaseName);
            fs.copyFileSync(jsonName, sendJsonPath);
            writeLog(`COPY완료 : ${sendJsonPath}`);
            jsonSuccessCnt++;
          } catch (err) {
            writeLog(`Failed to copy ${jsonName}, ${err}`);
            jsonFailCnt++;
          }
        } else {
          writeLog(`${jsonName} 파일 없음`);
          jsonFailCnt++;
        }
      } else {
        writeLog(`${jsonName} 지원하지 않는 문서`);
        jsonFailCnt++;
      }
    }
  } catch (err) {
    writeLog(`Failed to read directory ${err}`);
  }

  console.log(`Total : ${totalCnt} 건`);
  console.log(`fileSuccess : ${fileSuccessCnt} 건`);
  console.log(`fileFail : ${fileFailCnt} 건`);
  console.log(`jsonSuccess : ${jsonSuccessCnt} 건`);
  console.log(`jsonFail : ${jsonFailCnt} 건`);

  summaryLog(
    totalCnt,
    jsonSuccessCnt,
    jsonFailCnt,
    assz_btch_acmp_id,
    "gaiFileCopy"
  );
  writeLog(
    "----------------------------gaiFileCopy()종료----------------------------"
  );
}

/*---------------------- 메인 함수 ----------------------*/
async function main() {
  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃ CSMCSM 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃");

  // 파라미터 셋팅
  const pcsnClCd = process.argv[2];
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[3];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const in_assz_btch_acmp_id = process.argv[4];

  // DB 커넥션
  //const pool = new Pool(config.db);

  if (pcsnClCd == "01") {
    let basePath = `/data/bdpetl/recv/csm/csm/${basDt}/`;
    // 서버간 수신 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    // 배치수행로그 입력 및 배치ID채번
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "CSMCSM",
      "01", //01        수집 02 자산화 03       전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1        메타+파일 T2    DB T3   지식샘
      "01" //assz_tgt_sys_cd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/csm/csm/${basDt}/meta/master.dat`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/csm", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }
    // 폴더 생성
    await makeDir(basDt);
    // 메인 메타 저장
    await mainMetaInsert(basDt, assz_btch_acmp_id);
    //await infoMetaInsert(basDt, assz_btch_acmp_id);
    //await fileCopy(basDt, assz_btch_acmp_id);
    await drmUnlock(basDt);
    await jpgtoPdf(basDt, assz_btch_acmp_id);
    await pdftoImgPerPage(basDt, assz_btch_acmp_id);
    await pdftoImg(basDt, assz_btch_acmp_id);

    await util.imgToDp2(assz_btch_acmp_id, "csmcsm", basDt);
    await util.runImgJeff(assz_btch_acmp_id, "csmcsm", basDt); //DBselect 엔진호출   DBupdate Dbinsert

    await jsonMerge(basDt, assz_btch_acmp_id); //jSON 병합

    // --------- 후처리 작업 ---------
    await moveAssetData("/data/asset/csm/csm", basDt);
    // 원장결과 재생성
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "csmcsm",
      basDt,
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 학습데이터 파일복사
    await util.moveToLearn("csmcsm", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "csmcsm",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "csmcsm",
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
  }

  // DB 커넥션 해제
  //await pool.end();
  await dbBatch.dbEnd();

  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃ CSMCSM 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃");
}

// 메인 실행
main();
