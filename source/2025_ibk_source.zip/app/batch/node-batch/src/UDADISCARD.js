const fs = require("fs");
const path = require("path");

const { EROR_CODES, COMMON_CODES } = require("./common");
const {
  deleteDiscardOriginMaster,
  deleteDiscardOriginMeta,
  selectDiscardMakeMeta,
  selectDiscardOchMakeMeta,
} = require("../sql/TB_UDA_PORTAL");


/*---------------------- 전송메타 생성 ----------------------*/
async function makeMeta(approvalNo, ids) {
  // GAI
  try {
    const res = await selectDiscardMakeMeta(ids, "meta", "gai");

    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");
    if (rows != "") {
      rows = rows + "^|";

      let targetDir = `/data/bdpetl/send/gai/gai/portal/${approvalNo}`;
      fs.mkdirSync(targetDir, { recursive: true });

      let filePath = path.join(targetDir, `${approvalNo}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
    }
  } catch (err) {
    throw new Error(`GAI sam 파일생성 에러발생: ${err}`);
  }

  // AVT
  try {
    const res = await selectDiscardMakeMeta(ids, "meta", "avt");

    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");
    if (rows != "") {
      rows = rows + "^|";

      let targetDir = `/data/bdpetl/send/avt/avt/portal/${approvalNo}`;
      fs.mkdirSync(targetDir, { recursive: true });

      let filePath = path.join(targetDir, `${approvalNo}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
    }
  } catch (err) {
    throw new Error(`AVT sam 파일생성 에러발생: ${err}`);
  }
}

/*---------------------- 챗봇 전송 JSON 생성 ----------------------*/
async function makeJson(approvalNo) {

  try {

    let datas = [];
    const metaData = await selectDiscardOchMakeMeta();
    for (const rowMetaData of metaData.rows) {
      const {
        assz_unfc_id,
        assz_cfbo_idnt_id,
        assz_chb_conn_url_adr,
        assz_pcsn_file_path_nm,
        assz_dcmn_clsf_id,
      } = rowMetaData;
      if (assz_pcsn_file_path_nm) {
        const data = fs.readFileSync(assz_pcsn_file_path_nm, "utf8");

        const [q, a] = data.split("^|").map((s) => s.trim());

        datas.push({
          assz_unfc_id: assz_unfc_id,
          assz_cfbo_idnt_id: assz_cfbo_idnt_id,
          q: q,
          a: a,
          assz_dcmn_clsf_id: assz_dcmn_clsf_id,
          assz_chb_conn_url_adr: assz_chb_conn_url_adr,
        });
      }
    }

    if (datas.length > 0) {
      let targetDir = `/data/bdpetl/send/gai/gai/portal/${approvalNo}`;
      fs.mkdirSync(targetDir, { recursive: true });

      let filePath = path.join(targetDir, `${approvalNo}_OCH.json`);
      fs.writeFileSync(filePath, JSON.stringify(datas, null, 2), "utf8");
    }
  } catch (err) {
    throw new Error(`폐기처리 챗봇 JSON 파일생성 에러발생: ${err}`);
  }
}

/*---------------------- 폐기처리 배치실행 ----------------------*/
async function discardBatchExec(approvalData) {
  try {
    let approvalNo = approvalData.approvalNo;
    let approvalTargets = approvalData.approvalTargets;

    // 원장삭제처리
    for (const app of approvalTargets) {
      let documentId = app.documentId;
      let sysName = documentId.substring(3, 9);

      // 원장마스터 삭제
      await deleteDiscardOriginMaster(documentId, COMMON_CODES.ASSZ_SCD_DELETE);
      // 원장메타 삭제
      await deleteDiscardOriginMeta(documentId, sysName);
    }

    // 전송폴더에 SAM 생성 및 파일 이동
    let ids = approvalTargets.map((t) => t.documentId);
    // 전송메타 생성
    await makeMeta(approvalNo, ids);
    // 챗봇 전송 JSON 생성
    await makeJson(approvalNo);

    return true;
  } catch (err) {
    console.log(err);
    throw err;
  }
}

module.exports = {
  discardBatchExec,
};
