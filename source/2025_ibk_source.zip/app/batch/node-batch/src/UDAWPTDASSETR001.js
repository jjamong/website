// STD MODULE
const fs = require("fs");
const { exec, spawn } = require("child_process");
const path = require("path");
const dayjs = require("dayjs");

// UTILS
const util = require("../util");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

// SQL
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그
const dbMetaLdgr = require("../sql/TB_UDA_UAI001M");
const dbMetaMain = require("../sql/TB_UDA_UAI801L"); //업무포탈 메타
const dbMetaAdd = require("../sql/TB_UDA_UAI802L"); //업무포탈 첨부파일 메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbAssetRlt = require("../sql/TB_UDA_UAI910L"); //자산화 처리로그
const { make_access_101sam } = require("../make_access_101sam");
const { make_access_102sam } = require("../make_access_102sam");
const {
  checkFmtsBaseUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  updateBatchId,
  updateErorVl,
  updateOnlyAsszScd,
  selectMetaDocNm,
  selectMetaDocNmRange,
} = require("../sql/TB_UDA_UAI000M");

//COMMON
const {
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  updateLdgrSelfPool,
  getFileInfo,
  moveAssetData,
  finFileCreate,
  isImageMagick,
  recvMetaFileCheck,
  batchStart,
  getBatchId,
  ///////////////NEW/////////////////
  insertLdgrMaster,
  mergeDocument,
  getSafeBaseDt,
} = require("./common");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const in_assz_btch_acmp_id = process.argv[4];
const programId = "UDAKMSDASSETR001";

if (
  pcsnClCd !== "01" &&
  pcsnClCd !== "02" &&
  pcsnClCd !== "03" &&
  pcsnClCd !== "05" &&
  pcsnClCd !== "06" &&
  pcsnClCd !== "81" &&
  pcsnClCd !== "83" &&
  pcsnClCd !== "98" &&
  pcsnClCd !== "97"
) {
  writeLog("error UDAWPTDASSETR001.js clcd(처리구분:01) YYYYMMDD");
  process.exit(1);
}

if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("error node kmswpt.js YYYYMMDD");
  process.exit(1);
}

/*-------------------권한정보입력----------------------*/
async function access() {
  writeLog(
    "----------------------------access()시작----------------------------"
  );
  const command = `node /app/batch/node-batch/access.js "${basDt}"`;
  try {
    await new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          writeLog(`에러:${error.message}`);
          reject(error); //resolve(); //에러나도 넘어가게끔 하려면
          return;
        }
        if (stderr) {
          writeLog(`stderr:${stderr}`);
          reject(stderr); //resolve(); //에러나도 넘어가게끔 하려면
          return;
        }
        //writeLog(`stdout:${stdout}`);
        writeLog(`권한입력: ${basDt}`);
        resolve();
      });
    });
  } catch (err) {
    writeLog(`권한입력 실패: ${basDt}: ${err.message}`);
  }

  writeLog(
    "----------------------------access()종료----------------------------"
  );
}

function masterMetaSort(fullPath, index) {
  const meta = fs.readFileSync(fullPath, "utf-8");
  let lines = meta.split("\n");

  return lines.sort((a, b) => {
    const aFields = a.split("^|");
    const bFields = b.split("^|");

    const aKey = aFields[index] || "";
    const bKey = bFields[index] || "";

    return aKey.localeCompare(bKey);
  });
}

/*----------------------main meta insert ----------------------*/
async function mainMetaInsert(assz_btch_acmp_id) {
  writeLog(
    "----------------------------mainMetaInsert()시작----------------------------"
  );

  /*const masterInfo = fs.readFileSync(
    `/data/bdpetl/recv/kms/wpt/${basDt}/meta/AC_BOARD.dat`,
    "utf-8"
  );
  const lines_m = masterInfo.split("\n");
  */

  let lines_m = masterMetaSort(
    `/data/bdpetl/recv/kms/wpt/${basDt}/meta/AC_BOARD.dat`,
    3
  );

  for (const line of lines_m) {
    if (line.trim() === "") continue;

    let [
      assz_cfbo_idnt_id,
      rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_orgn_pcsn_dcd,
      assz_dcmn_clsf_id,
      assz_fmts_base_orgn_idnt_id,
      conn_ttl_nm,
      rgsr_dept_id,
      inq_nbi,
      vrsn_no,
      suco_oppb_info_con,
      suco_dcmn_shrn_yn,
    ] = line.split("^|");
    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`원천별식별키없음 ${assz_cfbo_idnt_id}`);
      continue;
    } else {
      // 10. 조회COUNT 없으면 0으로 초기화
      if (inq_nbi == "" || inq_nbi == null) {
        inq_nbi = 0;
      }
      // 11. 버전정보 없으면 0으로 초기화
      if (vrsn_no == "" || vrsn_no == null || vrsn_no == "null") {
        vrsn_no = 0;
      }
      // 12. 자회사 공개 정보
      if (
        suco_oppb_info_con == "" ||
        suco_oppb_info_con == null ||
        suco_oppb_info_con == "null"
      ) {
        suco_oppb_info_con = "";
      }

      conn_ttl_nm = conn_ttl_nm.replace(/\s{2,}/g, " ");

      await dbMetaMain.insertMeta(
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        rgsr_dept_id,
        inq_nbi,
        vrsn_no,
        suco_dcmn_shrn_yn,
        suco_oppb_info_con,
        "",
        programId
      );
    }
  }
  writeLog(
    "----------------------------mainMetaInsert()종료----------------------------"
  );
}

/*----------------------DRM해제 작업----------------------*/

async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );
  const dirs = ["origin", "att"];
  let result = "";

  try {
    fs.mkdirSync(`/data/asset/kms/wpt/${basDt}`, { recursive: true });
  } catch (err) {
    writeLog(`디렉터리 생성 실패 : /data/asset/kms/wpt/${basDt}:${err}`);
  }
  for (const dir of dirs) {
    const fullPath = `/data/asset/kms/wpt/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`drm오류: ${fullPath}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

/*----------------------시행문 파일 copy.----------------------*/
async function fileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------fileCopy()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let sortedMainMeta = masterMetaSort(
    `/data/bdpetl/recv/kms/wpt/${basDt}/meta/AC_BOARD.dat`,
    3
  );

  const keyOrder = sortedMainMeta.map((line) => line.split("^|")[0]);

  const grouped = {};

  const addInfo = fs.readFileSync(
    `/data/bdpetl/recv/kms/wpt/${basDt}/meta/ACTION_DOC_FILE_INFO.dat`,
    "utf-8"
  );

  let lines_m = addInfo.split("\n");

  for (const line of lines_m) {
    const id = line.split("^|")[0];
    if (!grouped[id]) {
      grouped[id] = [];
    }
    grouped[id].push(line);
  }

  let sortedMeta = [];

  for (const id of keyOrder) {
    if (grouped[id]) {
      sortedMeta.push(...grouped[id]);
    }
  }

  lines_m = sortedMeta;

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "KMSWPT");
  let idx = result.rows[0].idsqn;

  for (const line of lines_m) {
    if (line.trim() === "") continue;
    let [
      assz_cfbo_idnt_id,
      file_nm,
      file_sqn,
      assz_orcp_file_path_nm,
      rgsn_ts,
      atch_yn,
      atch_sqn,
      atch_nm,
    ] = line.split("^|");
    totalCnt++;

    if (file_sqn == "" || file_sqn == null || file_sqn == "null") {
      file_sqn = 0;
    }
    if (atch_sqn == "" || atch_sqn == null || atch_sqn == "null") {
      atch_sqn = 0;
    }

    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(`meta 원천키오류 없음 ${assz_cfbo_idnt_id}`);
      //failCnt++;
      continue;
    } else {
      let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분
      const filename = `/data/bdpetl/recv/kms/wpt/${basDt}/file${assz_orcp_file_path_nm}/${file_nm}`;

      const ext = path.extname(file_nm).toLowerCase();

      // 마스터 메타테이블 가져오기
      let metaOne = await dbMetaMain.selectMetaOne(
        assz_btch_acmp_id,
        assz_cfbo_idnt_id
      );

      let mainMeta = null;
      if (metaOne.rowCount > 0) {
        mainMeta = metaOne.rows[0];
      }

      /**
       *   이전식별키로 unfc 조회 (존재한다면 Update 건, 없으면 신규)
       */
      let { rows } = await checkFmtsBaseUnfcId(
        mainMeta.assz_fmts_base_orgn_idnt_id
      );

      let assz_unfc_id = "";

      // 삭제건 먼저처리
      if (mainMeta.assz_orgn_pcsn_dcd == "D") {
        let result = await getUnfcIdFromIdntId(
          "KMSWPT",
          assz_cfbo_idnt_id,
          atch_sqn
        );
        if (result.rowCount == 0) {
          writeLog(`MBY 삭제건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);
          assz_unfc_id = await getUnfcId("KMSWPT", ++idx);

          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_EXCEPTION,
            assz_cfbo_idnt_id,
            null,
            null,
            mainMeta.assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_UNSUCCESS,
            EROR_CODES.EROR_VL_UNSUCCESS_STR,
            `/data/asset/kms/wpt/${basDt}/${dirGb}/${assz_unfc_id}${ext}`, //assz_pcsn_file_path_nm,
            null,
            null,
            assz_btch_acmp_id,
            programId
          );

          await dbMetaLdgr.insertLdgrWPT(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            mainMeta.assz_fmts_base_orgn_idnt_id,
            mainMeta.orgn_data_rgsr_id,
            dayjs(mainMeta.rgsn_ts).format("YYYYMMDDHHmmss"),
            dayjs(mainMeta.amnn_ts).format("YYYYMMDDHHmmss"),
            mainMeta.assz_orgn_pcsn_dcd,
            mainMeta.assz_dcmn_clsf_id,
            mainMeta.conn_ttl_nm,
            mainMeta.rgsr_dept_id,
            mainMeta.inq_nbi,
            mainMeta.vrsn_no,
            mainMeta.suco_dcmn_shrn_yn,
            mainMeta.suco_oppb_info_con,
            assz_orcp_file_path_nm,
            atch_yn,
            atch_nm,
            atch_sqn,
            programId
          );

          // 배치 001 테이블에 통합ID 업데이트
          await dbMetaMain.updateUnfcId(
            assz_unfc_id,
            assz_btch_acmp_id,
            assz_cfbo_idnt_id
          );

          failCnt++;
          continue;
        } else {
          assz_unfc_id = result.rows[0].assz_unfc_id;
          await updateLdgrSelfPool(
            result.rows[0].assz_unfc_id,
            assz_btch_acmp_id,
            COMMON_CODES.ASSZ_SCD_DELETE
          );

          // 배치 001 테이블에 통합ID 업데이트
          await dbMetaMain.updateUnfcId(
            assz_unfc_id,
            assz_btch_acmp_id,
            assz_cfbo_idnt_id
          );
        }
      } else {
        // 재수행건 중복방지
        let result = await getUnfcIdFromIdntId(
          "KMSWPT",
          assz_cfbo_idnt_id,
          atch_sqn
        );
        // 같은 년월일에 배치 재수행 시 원장수행은 PASS, 배치ID는 업데이트
        if (result.rowCount > 0) {
          writeLog(`이미 처리함 ${assz_cfbo_idnt_id}`);
          assz_unfc_id = result.rows[0].assz_unfc_id;
          await updateBatchId(
            result.rows[0].assz_unfc_id,
            assz_btch_acmp_id,
            parseInt(assz_btch_acmp_id.slice(-6), 10)
          );

          // 배치 001 테이블에 통합ID 업데이트
          await dbMetaMain.updateUnfcId(
            assz_unfc_id,
            assz_btch_acmp_id,
            assz_cfbo_idnt_id
          );

          if (
            mainMeta.assz_fmts_base_orgn_idnt_id != mainMeta.assz_cfbo_idnt_id
          ) {
            if (rows.length > 0) {
              writeLog(
                `업데이트 확정건 재처리 ${mainMeta.assz_fmts_base_orgn_idnt_id} -> ${mainMeta.assz_cfbo_idnt_id}`
              );
              await updateLdgrSelfPool(
                rows[0].assz_unfc_id,
                assz_btch_acmp_id,
                COMMON_CODES.ASSZ_SCD_DELETE
              );
            }
          }
        } else {
          assz_unfc_id = await getUnfcId("KMSWPT", ++idx);

          if (
            mainMeta.assz_fmts_base_orgn_idnt_id != mainMeta.assz_cfbo_idnt_id
          ) {
            if (rows.length > 0) {
              writeLog(
                `업데이트 확정건 ${mainMeta.assz_fmts_base_orgn_idnt_id} -> ${mainMeta.assz_cfbo_idnt_id}`
              );
              // 업데이트건 확정
              /**
               *  자산화이전식별키가 원천식별키에 존재하는경우 수정데이터
               *  원장에서 기존아이템 삭제 후 신규 생성
               *  전송메타에 자산화이전식별키 'D', 신규 'C' 두 row가 전송되어야함
               */

              // 1. 원천 데이터 삭제
              await updateLdgrSelfPool(
                rows[0].assz_unfc_id,
                assz_btch_acmp_id,
                COMMON_CODES.ASSZ_SCD_DELETE
              );

              // 3. 'U' 는 'C' 로 처리하기위해 신규아이디채번
              //mainMeta.assz_orgn_pcsn_dcd = "U";
            } else {
              /**
               * 20250825 cbkim
               * 이전식별키가 기존에 적재되지 않은경우 (파일없이 원천식별키가 채번된경우 기존 메타가 없을 수 있음)
               * 이전 원천키가 없으므로 삭제보낼필요없음, 신규건임
               */
              writeLog(
                `이전키없음 신규데이터 ${mainMeta.assz_fmts_base_orgn_idnt_id} -> ${mainMeta.assz_cfbo_idnt_id}`
              );
              mainMeta.assz_orgn_pcsn_dcd = "C";
            }
          }

          await insertLdgrMaster(
            null,
            assz_unfc_id,
            COMMON_CODES.ASSZ_SCD_INIT,
            assz_cfbo_idnt_id,
            null,
            null,
            mainMeta.assz_orgn_pcsn_dcd,
            EROR_CODES.EROR_VL_SUCCESS,
            EROR_CODES.EROR_VL_SUCCESS_STR,
            `/data/asset/kms/wpt/${basDt}/${dirGb}/${assz_unfc_id}${ext}`, //assz_pcsn_file_path_nm,
            null,
            null,
            assz_btch_acmp_id,
            programId
          );

          await dbMetaLdgr.insertLdgrWPT(
            null,
            assz_unfc_id,
            assz_cfbo_idnt_id,
            mainMeta.assz_fmts_base_orgn_idnt_id,
            mainMeta.orgn_data_rgsr_id,
            dayjs(mainMeta.rgsn_ts).format("YYYYMMDDHHmmss"),
            dayjs(mainMeta.amnn_ts).format("YYYYMMDDHHmmss"),
            mainMeta.assz_orgn_pcsn_dcd,
            mainMeta.assz_dcmn_clsf_id,
            mainMeta.conn_ttl_nm,
            mainMeta.rgsr_dept_id,
            mainMeta.inq_nbi,
            mainMeta.vrsn_no,
            mainMeta.suco_dcmn_shrn_yn,
            mainMeta.suco_oppb_info_con,
            assz_orcp_file_path_nm,
            atch_yn,
            atch_nm,
            atch_sqn,
            programId
          );

          // 배치 001 테이블에 통합ID 업데이트
          await dbMetaMain.updateUnfcId(
            assz_unfc_id,
            assz_btch_acmp_id,
            assz_cfbo_idnt_id
          );
        }
      }

      // 통합ID로 파일명
      let chgFullPath = `/data/asset/kms/wpt/${basDt}/${dirGb}/${
        assz_unfc_id + ext
      }`;

      chgFullPath = chgFullPath.replace("PDF", "pdf");

      try {
        fs.accessSync(filename);
      } catch (err) {
        writeLog(`파일없음: ${filename}`);
        await dbMetaAdd.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          rgsn_ts,
          atch_yn,
          atch_sqn,
          atch_nm,
          chgFullPath,
          programId
        );
        failCnt++;

        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
          EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR
        );
        continue;
      }
      const targetPath = `/data/asset/kms/wpt/${basDt}/${dirGb}`;

      if (await isImageMagick(filename)) {
        writeLog(`ImageMagick 건: ${filename}`);
        await dbMetaAdd.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          rgsn_ts,
          atch_yn,
          atch_sqn,
          atch_nm,
          chgFullPath,
          programId
        );
        failCnt++;

        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_NON_TARGET,
          EROR_CODES.EROR_VL_NON_TARGET_STR
        );
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
        continue;
      }

      try {
        fs.mkdirSync(targetPath, { recursive: true });
        fs.copyFileSync(filename, chgFullPath);
      } catch (err) {
        writeLog(
          `${EROR_CODES.EROR_VL_COPY_FAILED_STR}: ${filename}:${chgFullPath}`
        );
        await dbMetaAdd.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          file_nm,
          file_sqn,
          assz_orcp_file_path_nm,
          rgsn_ts,
          atch_yn,
          atch_sqn,
          atch_nm,
          chgFullPath,
          programId
        );
        failCnt++;
        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_COPY_FAILED,
          EROR_CODES.EROR_VL_COPY_FAILED_STR
        );
        try {
          await updateFileInfo(assz_unfc_id, "0", null);
        } catch (e) {
          writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filename}`);
        }
        continue; //파일없으면 skip
      }

      let errCd = EROR_CODES.EROR_VL_SUCCESS;
      let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

      //자산화 대상 파일 아님.
      if (!isUseFile(file_nm)) {
        errCd = EROR_CODES.EROR_VL_NON_TARGET;
        errStr = EROR_CODES.EROR_VL_NON_TARGET_STR;
        await updateErorVl(
          assz_unfc_id,
          EROR_CODES.EROR_VL_NON_TARGET,
          EROR_CODES.EROR_VL_NON_TARGET_STR
        );
        await updateOnlyAsszScd(assz_unfc_id, COMMON_CODES.ASSZ_SCD_EXCEPTION);
      } else {
        await updateErorVl(assz_unfc_id, errCd, errStr);
      }

      successCnt++;

      //writeLog(`COPY 성공 ${filename}`);

      /**
       * fileinfo 저장, 파일크기, 난수값
       */

      try {
        const fileInfo = await getFileInfo(filename);

        await updateFileInfo(assz_unfc_id, String(fileInfo.size), fileInfo.md5);
      } catch (e) {
        writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filename}`);
      }

      await dbMetaAdd.insertMeta(
        assz_btch_acmp_id,
        assz_cfbo_idnt_id,
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        rgsn_ts,
        atch_yn,
        atch_sqn,
        atch_nm,
        chgFullPath,
        programId
      );
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "fileCopy");
  writeLog(
    "----------------------------fileCopy()종료----------------------------"
  );
}

async function dl(data) {
  return await new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          chgFullPath: data.chgFullPath,
          ext: data.ext,
        });
      }
      if (stderr) {
        if (!stderr.includes("Log4j")) {
          resolve({
            success: false,
            chgFullPath: data.chgFullPath,
            filePath: data.filePath,
            ext: data.ext,
          });
        }
      }
      resolve({
        success: true,
        chgFullPath: data.chgFullPath,
        filePath: data.filePath,
        ext: data.ext,
      });
    });
  });
}

async function drawLine(assz_btch_acmp_id) {
  writeLog(
    "----------------------------drawline()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const commands = [];

  const extensions = [".hwp", "hwpx", "docx"];

  const attPath = `/data/asset/kms/wpt/${basDt}/att`;
  const originPath = `/data/asset/kms/wpt/${basDt}/origin`;

  let attFiles = fs.readdirSync(attPath);
  attFiles.forEach((file) => {
    const ext = path.extname(file);
    const filePath = path.join(attPath, file);
    // Drawline 대상파일만 수행
    if (extensions.includes(path.extname(file).toLowerCase())) {
      if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, `${filePath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${filePath}${ext}" "${filePath}" 10`;
      commands.push({
        command: command,
        filePath: filePath,
        ext: ext,
      });
    }
  });

  let originFiles = fs.readdirSync(originPath);
  originFiles.forEach((file) => {
    const ext = path.extname(file);
    const filePath = path.join(originPath, file);
    // Drawline 대상파일만 수행
    if (extensions.includes(path.extname(file).toLowerCase())) {
      if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, `${filePath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${filePath}${ext}" "${filePath}" 10`;
      commands.push({
        command: command,
        filePath: filePath,
        ext: ext,
      });
    }
  });

  const tasks = commands.map((data, idx) => limit(() => dl(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
      writeLog(`Drawline 실패: ${result.filePath}`);
    }

    const tmpFilename = `${result.filePath}${result.ext}`;

    if (fs.existsSync(tmpFilename)) {
      writeLog(`hwp tmp 파일 존재함 unlink`);
      fs.unlinkSync(tmpFilename);
    } else {
      writeLog(`hwp tmp 파일 존재하지않음 ${tmpFilename}`);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "drawline");
  writeLog(
    "----------------------------drawline()종료----------------------------"
  );
}

async function htp(data) {
  const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
  return new Promise((resolve, reject) => {
    const command = data.command;
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      //writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        //writeLog(`변환성공: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: true,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`변환실패 [Fail 출력됨]: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0210",
          errStr: `hwptoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
        });
      } else {
        writeLog(`결과미확인: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
        });
      }
    });
  });
}

/*----------------------hwptoPdf----------------------*/
async function hwptoPdf(assz_btch_acmp_id) {
  writeLog(
    "----------------------------hwptoPdf()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  //조회시 파일 확장자만 필터
  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const md of metaData.rows) {
    const oriFileName = path.basename(md.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (
      ext === ".hwp" ||
      ext === ".hwpx" ||
      ext === ".doc" ||
      ext === ".docx"
    ) {
      chgFileName = oriFileName.replace(ext, ".pdf");
    } else {
      chgFileName = oriFileName;
    }
    const chgFilePath = `/data/asset/kms/wpt/${basDt}/pdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx"
    ) {
      let command = `python3 /app/hwp2pdfv2/hwp2pdf.py "${md.assz_pcsn_file_path_nm}" "/data/asset/kms/wpt/${basDt}/pdf"`;
      command = command.replace(/`/g, "\\`");
      astpCd = "HW";
      //writeLog(`command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: "HW",
        command: command,
        chgFilePath: chgFilePath,
        atch_yn: md.atch_yn,
        assz_pcsn_file_path_nm: md.assz_pcsn_file_path_nm,
        assz_cfbo_idnt_id: md.assz_cfbo_idnt_id,
        assz_unfc_id: md.assz_unfc_id,
      });
    } else if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      successCnt++;
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    await dbAssetLog.insertLog(
      assz_btch_acmp_id,
      result.assz_unfc_id,
      result.assz_cfbo_idnt_id,
      result.atch_yn,
      result.astpCd, //HW      HWP PD  PDF ML  HTML
      "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
      "C", //C 신규 U 수정 D삭제
      "N", //이미지처리여부
      null,
      null,
      null,
      "CH", //NO(None),CH(변환)
      null,
      null,
      null,
      "SI", //SI(단일 문서),MU(멀티 통합 문서)
      result.strDate, //원본변환시작일시
      endDate, //원본변환종료일시
      result.chgFilePath,
      result.errCd, //에러 0000
      result.errStr,
      programId
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "hwptoPdf");
  writeLog(
    "----------------------------hwptoPdf()종료----------------------------"
  );
}

/*----------------------hwptoPdf----------------------*/
async function hwptoPdfOrigin(assz_btch_acmp_id) {
  writeLog(
    "----------------------------hwptoPdfOrigin()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  //조회시 파일 확장자만 필터
  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const md of metaData.rows) {
    const oriFileName = path.basename(md.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (
      ext === ".hwp" ||
      ext === ".hwpx" ||
      ext === ".doc" ||
      ext === ".docx"
    ) {
      chgFileName = oriFileName.replace(ext, ".pdf");
    } else {
      chgFileName = oriFileName;
    }
    const chgFilePath = `/data/asset/kms/wpt/${basDt}/pdf/${chgFileName}`;
    const originPdfPath = `/data/asset/kms/wpt/${basDt}/originpdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx"
    ) {
      let command = `python3 /app/hwp2pdfv2/hwp2pdf.py "${md.assz_pcsn_file_path_nm}" "/data/asset/kms/wpt/${basDt}/originpdf"`;
      command = command.replace(/`/g, "\\`");
      astpCd = "HW";
      //writeLog(`command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: "HW",
        command: command,
        chgFilePath: chgFilePath,
        atch_yn: md.atch_yn,
        assz_pcsn_file_path_nm: md.assz_pcsn_file_path_nm,
        assz_cfbo_idnt_id: md.assz_cfbo_idnt_id,
        assz_unfc_id: md.assz_unfc_id,
      });
    } else if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      astpCd = "PD";
      try {
        fs.copyFileSync(md.assz_pcsn_file_path_nm, chgFilePath);
        fs.copyFileSync(md.assz_pcsn_file_path_nm, originPdfPath);

        //writeLog(`PDF 복사 완료:${chgFilePath} `);
        successCnt++;
      } catch (err) {
        writeLog(`PDF 복사 실패 : ${md.assz_pcsn_file_path_nm}`, err);
        errCd = EROR_VL_HTP_PDF_COPY_FAILED;
        errStr = EROR_VL_HTP_PDF_COPY_FAILED_STR;

        failCnt++;
      }

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      await dbAssetLog.insertLog(
        assz_btch_acmp_id,
        md.assz_unfc_id,
        md.assz_cfbo_idnt_id,
        md.atch_yn,
        astpCd, //HW      HWP PD  PDF ML  HTML
        "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
        "C", //C 신규 U 수정 D삭제
        "N", //이미지처리여부
        null,
        null,
        null,
        "CH", //NO(None),CH(변환)
        null,
        null,
        null,
        "SI", //SI(단일 문서),MU(멀티 통합 문서)
        strDate, //원본변환시작일시
        endDate, //원본변환종료일시
        chgFilePath,
        errCd, //에러 0000
        errStr,
        programId
      );
      await updateErorVl(md.assz_unfc_id, errCd, errStr);
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "hwptoPdfOrigin"
  );
  writeLog(
    "----------------------------hwptoPdfOrigin()종료----------------------------"
  );
}

async function ptt(data) {
  const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

  return new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      let oriFileName = data.oriFileName;
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error);
        return;
      }
      //writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        //writeLog(`변환성공: ${oriFileName}`);
        resolve({
          success: true,
          txtOutFullPath: data.txtOutFullPath,
          errCd: "0000",
          errStr: "",
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) {
          errMsg = match[1];
        }
        writeLog(`변환실패 [Fail 출력됨]: ${oriFileName} / 사유 : ${errMsg}`);
        let errCd = "0410";
        let errStr =
          errMsg == "" ? `변환실패 [Fail 출력됨]: ${oriFileName}` : errMsg;
        resolve({
          success: false,
          errCd: errCd,
          errStr: errStr,
          txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else {
        writeLog(`결과미확인: ${oriFileName}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------pdftoText----------------------*/
async function pdftoText(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  //const outputDir = `/data/asset/kms/wpt/${basDt}/txt`;

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  await dbAssetLog.updateExists(assz_btch_acmp_id);

  const logData = await dbAssetLog.selectLog(assz_btch_acmp_id, "02", "0000");

  const commands = [];

  for (const ld of logData.rows) {
    totalCnt++;
    const outputDir = `/data/asset/kms/wpt/${basDt}/txt`;
    fs.mkdirSync(outputDir, { recursive: true });

    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);
    const txtFileName = oriFileName
      .replace(".pdf", ".txt")
      .replace(".PDF", ".txt");
    const txtOutFullPath = `${outputDir}/${txtFileName}`;
    let command = `python3 /app/pdftotxt/pdftotxt.py "${ld.assz_orcp_file_path_nm}" "${txtOutFullPath}"`;
    command = command.replace(/`/g, "\\`");
    commands.push({
      assz_btch_acmp_id: ld.assz_btch_acmp_id,
      assz_unfc_id: ld.assz_unfc_id,
      oriFileName: oriFileName,
      header: ld,
      command: command,
      txtOutFullPath: txtOutFullPath,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => ptt(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      "04",
      null,
      null,
      null,
      null,
      null,
      result.staDate, //변환시작일시
      endDate, //변환종료일시
      result.txtOutFullPath,
      null,
      null,
      null,
      null,
      result.errCd,
      result.errStr
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

function isUseFile(fileName) {
  const path = require("path");
  const USE_EXTS = new Set([".hwp", ".hwpx", ".pdf", ".docx"]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

async function makeDir() {
  const dirs = [
    `/data/asset/kms/wpt/${basDt}/att`,
    `/data/asset/kms/wpt/${basDt}/dp`,
    `/data/asset/kms/wpt/${basDt}/json`,
    `/data/asset/kms/wpt/${basDt}/origin`,
    `/data/asset/kms/wpt/${basDt}/pdf`,
    `/data/asset/kms/wpt/${basDt}/originpdf`,
    `/data/asset/kms/wpt/${basDt}/txt`,
    `/data/asset/kms/wpt/${basDt}/img`,
    `/data/bdpetl/send/gai/gai/wpt/endn/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

async function sync(targetDir) {
  writeLog(
    "----------------------------sync /data/bdpetl/recv ()시작----------------------------"
  );

  const rsync = spawn("/app/rsync/sync.sh", [targetDir, 2, targetDir]);

  rsync.stdout.on("data", (data) => {
    //writeLog(`[RSYNC STDOUT] ${data}`);
  });

  rsync.stderr.on("data", (data) => {
    //writeLog(`[RSYNC STDERR] ${data}`);
  });

  rsync.on("close", (code) => {
    //writeLog(`[RSYNC EXIT] code :  ${code}`);
  });

  writeLog(
    "---------------------------sync /data/bdpetl/recv 종료----------------------------"
  );
}

async function finFileCheck() {
  writeLog(
    "----------------------------finFileCheck() 시작----------------------------"
  );
  let metaPath = `/data/bdpetl/recv/kms/wpt/${basDt}/meta/${basDt}.fin`;
  let filePath = `/data/bdpetl/recv/kms/wpt/${basDt}/file/${basDt}.fin`;

  try {
    fs.accessSync(metaPath);
  } catch (err) {
    writeLog(`${basDt} fin파일이 없습니다. ${metaPath}`);
    process.exit(1);
  }

  try {
    fs.accessSync(filePath);
  } catch (err) {
    writeLog(`${basDt} fin파일이 없습니다. ${filePath}`);
    process.exit(1);
  }

  writeLog("(#) fin 파일 체크 완료");

  writeLog(
    "---------------------------finFileCheck() 종료----------------------------"
  );
}

async function updateLdgr(assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeMeta()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  try {
    const res = await dbGaiMeta.selectMakeWptMeta(assz_btch_acmp_id);

    for (let row of res.rows) {
    }

    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";

      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  } finally {
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeMeta");
  writeLog(
    "----------------------------makeMeta()종료----------------------------"
  );
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃kmswpt 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃");

  if (pcsnClCd == "01") {
    /*
    // 운영에 올릴때 주석 해제 필요
    // 업무포탈 권한 먼저 처리
    //await access();
    */
    // 서버간 파일 동기화
    await sync(`/data/bdpetl/recv/kms/wpt/${basDt}/`);
    // fin파일 체크
    await finFileCheck();

    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "KMSWPT",
      "01", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB T3 지식샘
      "01" //assz_trms_tgt_sys_dcd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/kms/wpt/${basDt}/meta/AC_BOARD.dat`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/wpt/endn", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    // 폴더 생성
    await makeDir();

    await mainMetaInsert(assz_btch_acmp_id); //메인정보 입력
    await fileCopy(assz_btch_acmp_id); //추가정보입력 + 파일정보

    await drmUnlock(); //DRM해제

    await hwptoPdfOrigin(assz_btch_acmp_id);
    await drawLine(assz_btch_acmp_id);
    await hwptoPdf(assz_btch_acmp_id); //select meta insert 자산화로그

    await pdftoText(assz_btch_acmp_id); //select meta insert 자산화로그
    await util.runJeff2(assz_btch_acmp_id, "kmswpt", basDt);

    await moveAssetData("/data/asset/kms/wpt", basDt);

    await util.resetOriginResult(assz_btch_acmp_id, "kmswpt", basDt, "0000");

    // 학습데이터 파일복사
    await util.moveToLearn("kmswpt", assz_btch_acmp_id);

    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);

    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "kmswpt",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );

    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "kmswpt",
      EROR_CODES.EROR_VL_SUCCESS
    );

    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    //await pdftoText(in_assz_btch_acmp_id);
    //await util.resetOriginResult(in_assz_btch_acmp_id, "kmswpt", basDt, "0000");
    //await access();
    await mergeDocument(null, in_assz_btch_acmp_id);
    // await util.resetOriginResult(in_assz_btch_acmp_id, "kmswpt", basDt, "0000");
    // 학습데이터 파일복사
    //await util.moveToLearn("kmswpt", in_assz_btch_acmp_id);
  }

  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  await dbMetaAdd.dbEnd();
  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  await dbAssetRlt.dbEnd();

  writeLog("＃＃＃＃＃＃＃＃＃＃＃＃kmswpt 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃");
}

main();
