// 문서관리
const fs = require("fs");
const util = require("../util");
const path = require("path");
const dayjs = require("dayjs");
const {
  getSafeBaseDt,
  getBatchId,
  batchStart,
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrMaster,
  updateLdgrSelfPool,
  getFileInfo,
  updateLdgrDupCreateData,
  moveAssetData,
  sync,
  mergeDocument,
  recvMetaFileCheck,
  finFileCreate,
} = require("./common");
const { exec, spawn } = require("child_process");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); // UDA배치기본
const dbMetaMain = require("../sql/TB_UDA_UAI004M"); //내규메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const { updateOriginMaster, updateOriginMasterIea, updateErorVl } = require("../sql/TB_UDA_UAI000M"); // 자산화결과기본(원장)

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  process.exit(1);
}
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------



/*---------------------- main 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) 자산화 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
  } else if (pcsnClCd == "test") {
    console.log(">>>");
    /*
    // --------- 전처리 작업 ---------
    // 서버간 수신 파일 동기화
    await sync(`/data/bdpetl/recv/iem/iea/${basDt}/`);

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/iem/iea/${basDt}/meta/master.DAT`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/iea", basDt);
      process.exit(0);
    }
      */

    // 폴더 생성
    await makeDir();
    /*
    // --------- 메인 작업 ---------
    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IEMIEA",
      "01", //01  수집 02 자산화 03 전송
      "02", //01  대기 02 수행 03 중단 04 오류 05 완료
      "T1", //T1 메타+파일 T2 DB T3 지식샘
      "01" //assz_tgt_sys_cd
    );

    // 파일 복사
    await fileCopy(assz_btch_acmp_id);
    // HWP TO PDF(라인그리기 전 원본PDF로 복사)
    await hwptoPdf(assz_btch_acmp_id, "originpdf");
    // DRM 해제
    await drmUnlock();
    // 라인그리기
    await drawLine(assz_btch_acmp_id);
    // HWP TO PDF
    await hwptoPdf(assz_btch_acmp_id);
    // 라인그리기 실패한 건만 한번 더 HWP TO PDF
    await drawLineFailHwptoPdf(assz_btch_acmp_id);
    // PDF TO TEXT
    await pdftoText(assz_btch_acmp_id);
    // Jeff
    await util.runJeff2(assz_btch_acmp_id, "iemiea", basDt);
    // 원장결과 재생성
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "iemiea",
      basDt,
      EROR_CODES.EROR_VL_SUCCESS
    );

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/iem/iea", basDt);
    // 학습데이터 파일복사
    await util.moveToLearn("iemiea", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );

    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS
    );
    // 배치수행 최종완료시간
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
    let assz_btch_acmp_id = "20250725IEMIEA000001";
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "iemiea",
      EROR_CODES.EROR_VL_SUCCESS
    );
    */
  }
  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) 자산화 배치 종료 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  return true;
}

main();
