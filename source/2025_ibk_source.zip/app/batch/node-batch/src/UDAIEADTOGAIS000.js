// 내규 GTP전송 기간데이터모음 (IEM > IEA)
const fs = require("fs");
const path = require("path");
const { finFileCreate, getSafeBaseDt } = require("./common.js");
const { writeLog, summaryLog } = require("../log.js"); // 로그 모듈
const dbGaiMeta = require("../sql/TB_UDA_GAI_META.js"); //GPT 전송 META파일

//입력값 체크 pcsnClCd=01:날짜처리 , basDt = 날짜
const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const fromDt = process.argv[4];
const toDt = process.argv[5];

if (pcsnClCd !== "01") {
  writeLog("error node iemieb.js clcd(처리구분:01) YYYYMMDD");
}

if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("error node iemieb.js YYYYMMDD");
  process.exit(1);
}

// 특정 날짜기간으로 전송메타 생성
async function makeMetaRange(targetDt, startDt, endDt) {
  writeLog(
    "----------------------------makeMetaRange()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/iea/${targetDt}`;

  try {
    fs.mkdirSync(targetDir, { recursive: true });
  } catch (err) {
    writeLog(`디렉터리 생성 실패 : ${targetDir} , ${err}`);
  }

  try {
    const res = await dbGaiMeta.selectMakeIeaMetaRange("meta", startDt, endDt);

    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";
      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  } finally {
  }
  summaryLog(totalCnt, successCnt, failCnt, "", "makeMetaRange");
  writeLog(
    "----------------------------makeMetaRange()종료----------------------------"
  );
}

// 특정 날짜기간으로 전송파일 이동
async function gaiFileCopyRange(targetDt, startDt, endDt) {
  writeLog(
    "----------------------------gaiFileCopyRange()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/iea/${targetDt}`;

  try {
    fs.mkdirSync(targetDir, { recursive: true });
  } catch (err) {
    writeLog(`디렉터리 생성 실패 : ${targetDir} , ${err}`);
  }

  const metaList = await dbGaiMeta.selectMakeIeaMetaRange(
    "gai",
    startDt,
    endDt
  );
  for (const ml of metaList.rows) {
    // 파일명, 경로 설정
    let name = ml.assz_unfc_id;
    let baseYmd = ml.assz_btch_acmp_id.slice(0, 8);
    let sourcePath = "";
    let targerParh = "";

    // JSON 파일 복사
    try {
      totalCnt++;

      sourcePath = `/data/asset/iem/iea/${baseYmd}/json/${name}.json`;
      targerParh = `${targetDir}/${name}.json`;
      fs.copyFileSync(sourcePath, targerParh);
      writeLog(`COPY완료 : ${targerParh}`);

      successCnt++;
    } catch (err) {
      writeLog(`Failed to copy ${name}.json, ${err}`);
      failCnt++;
      continue;
    }

    // PDF 파일 복사
    try {
      totalCnt++;

      sourcePath = `/data/asset/iem/iea/${baseYmd}/originpdf/${name}.pdf`;
      targerParh = `${targetDir}/${name}.pdf`;
      fs.copyFileSync(sourcePath, targerParh);
      writeLog(`COPY완료 : ${targerParh}`);
      successCnt++;
    } catch (err) {
      writeLog(`Failed to copy ${name}.pdf, ${err}`);
      failCnt++;
      continue;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, "", "gaiFileCopy");
  writeLog(
    "----------------------------gaiFileCopyRange()종료----------------------------"
  );
}

/*---------------------- main 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) GTP전송 기간데이터모음 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    // 특정 날짜기간으로 전송메타 생성
    await makeMetaRange(basDt, fromDt, toDt);
    // 특정 날짜기간으로 전송파일 이동
    await gaiFileCopyRange(basDt, fromDt, toDt);
    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/iea", basDt);
  }
  await dbGaiMeta.dbEnd();

  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 내규(iemiea) GTP전송 기간데이터모음 배치 종료 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  return true;
}

main();
