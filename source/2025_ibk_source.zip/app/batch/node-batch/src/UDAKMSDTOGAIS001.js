// 지식샘 GPT전송 (AIK > KMS)
const fs = require("fs");
const path = require("path");
const {
  getSafeBaseDt,
  getBatchId,
  batchStart,
  finFileCreate,
  sync,
  insertAssetResultSend,
} = require("./common.js");
const { writeLog, summaryLog } = require("../log.js"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M.js");
const dbGaiMeta = require("../sql/TB_UDA_GAI_META.js"); //GPT 전송 META파일

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  process.exit(1);
}
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------

/*---------------------- 폴더 생성 ----------------------*/
async function makeDir() {
  const dirs = [
    `/data/bdpetl/send/gai/gai/kms/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*---------------------- 전송메타 생성 ----------------------*/
async function makeMeta(assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeMeta()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/kms/${basDt}`;

  try {
    const res = await dbGaiMeta.selectMakeKmsMeta(assz_btch_acmp_id, "meta");
    //컬럼간 ^|, 행간 \n 문자열 생성
    let rows = res.rows
      .map((row) => {
        return [
          row.doc_id,
          row.doc_nm,
          row.ori_doc_key,
          row.file_size,
          row.file_type,
          row.url,
          row.pr_gubun,
          row.create_at,
          row.update_at,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          row.suco_oppb_info_con,
          row.suco_dcmn_shrn_yn,
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");
      
    if (rows != "") {
      rows = rows + "^|";
      totalCnt++;
      //sam 저장
      const filePath = path.join(targetDir, `${basDt}_Meta.sam`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료: ${filePath}`);
      successCnt++;
    } else {
      writeLog(`sam 파일생성 실패: 0건`);
    }
  } catch (err) {
    writeLog(`sam 파일생성 에러발생: ${err}`);
    failCnt++;
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeMeta");
  writeLog(
    "----------------------------makeMeta()종료----------------------------"
  );
}

/*---------------------- 전송파일 이동 ----------------------*/
async function gaiFileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------gaiFileCopy()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDir = `/data/bdpetl/send/gai/gai/kms/${basDt}`;
  const metaList = await dbGaiMeta.selectMakeKmsMeta(assz_btch_acmp_id, "gai");
  for (const ml of metaList.rows) {
    // 파일명, 경로 설정
    let sourcePath = "";
    let targerParh = "";

    // JSON 파일 복사
    try {
      totalCnt++;

      sourcePath = `/data/asset/aik/kms/${basDt}/json/${ml.assz_unfc_id}.json`;
      targerParh = `${targetDir}/${ml.assz_unfc_id}.json`;
      
      fs.copyFileSync(sourcePath, targerParh);
      writeLog(`COPY완료 : ${targerParh}`);

      successCnt++;
    } catch (err) {
      writeLog(`Failed to copy ${ml.assz_unfc_id}.json, ${err}`);
      failCnt++;
      continue;
    }

    // PDF 파일 복사
    try {
      totalCnt++;

      sourcePath = `/data/asset/aik/kms/${basDt}/originpdf/${ml.assz_unfc_id}.pdf`;
      targerParh = `${targetDir}/${ml.assz_unfc_id}.pdf`;

      fs.copyFileSync(sourcePath, targerParh);
      writeLog(`COPY완료 : ${targerParh}`);
      successCnt++;
    } catch (err) {
      writeLog(`Failed to copy ${ml.assz_unfc_id}.pdf, ${err}`);
      failCnt++;
      continue;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "gaiFileCopy");
  writeLog(
    "----------------------------gaiFileCopy()종료----------------------------"
  );
}

/*---------------------- main 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 지식샘(aikkms) GTP전송 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "AIKKMS",
      "03", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB
      "02" //assz_tgt_sys_cd
    );

    writeLog(`기준일자 수집배치ID ${assz_btch_acmp_id}`);
    if (assz_btch_acmp_id != null) {
      let error_log;
      try {
        // 폴더 생성
        await makeDir();
        // sam파일 생성
        await makeMeta(assz_btch_acmp_id, basDt);
        // 파일 복사
        await gaiFileCopy(assz_btch_acmp_id, basDt);
      } catch (e) {
        error_log = e;
      }

      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/kms", basDt);
      // 서버간 전송 파일 동기화
      await sync(`/data/bdpetl/send/gai/gai/kms/${basDt}/`);
      // 자산화결과전송 저장
      await insertAssetResultSend(assz_btch_acmp_id, "02", error_log);
      //배치수행 최종완료시간
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "AIKKMS", "03");
    } else {
      writeLog(`기준일자 수집배치ID 존재하지않음 ${basDt}`);
    }
  } else if (pcsnClCd.includes("test")) {
    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "AIKKMS",
      "03", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB
      "02" //assz_tgt_sys_cd
    );

    writeLog(`기준일자 수집배치ID ${assz_btch_acmp_id}`);
    if (assz_btch_acmp_id != null) {
      let error_log;
      try {
        // 폴더 생성
        await makeDir();
        // sam파일 생성
        await makeMeta(assz_btch_acmp_id, basDt);
        // 파일 복사
        await gaiFileCopy(assz_btch_acmp_id, basDt);
      } catch (e) {
        error_log = e;
      }

      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/kms", basDt);
      // 서버간 전송 파일 동기화
      await sync(`/data/bdpetl/send/gai/gai/kms/${basDt}/`);
      // 자산화결과전송 저장
      await insertAssetResultSend(assz_btch_acmp_id, "02", error_log);
      //배치수행 최종완료시간
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "03", "02");
    } else {
      writeLog(`기준일자 수집배치ID 존재하지않음 ${basDt}`);
    }
  }
  await dbBatch.dbEnd();
  await dbGaiMeta.dbEnd();
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 지식샘(aikkms) GTP전송 배치 종료 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  return true;
}

main();
