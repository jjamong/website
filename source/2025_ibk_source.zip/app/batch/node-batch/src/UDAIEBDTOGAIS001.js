const fs = require("fs");
const axios = require("axios");
const { exec } = require("child_process");

const util = require("../util");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그
const dbMetaMain = require("../sql/TB_UDA_UAI003M"); //업무 메뉴얼 메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbAssetRlt = require("../sql/TB_UDA_UAI910L"); //자산화 처리로그
const dbImgRlt = require("../sql/TB_UDA_UAI912L");
const { selectAsszCfboIdntId } = require("../sql/TB_UDA_UAI911L"); // json 목록에서 group_id 추출
const {
  checkUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  updateBatchId,
  updateErorVl,
  chkDupByAsszCfboIdntId,
  chkDupByAsszCfboIdntIdAndStus,
  updateLdgrStusBatId,
  updateLdgrBatId,
} = require("../sql/TB_UDA_UAI000M");
const {
  EROR_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  insertLdgrRecvPool,
  updateLdgrSelfPool,
  updateLdgrRecvPool,
  getFileInfo,
  updateLdgrBatIdStatus,
  updateLdgrDupCreateData,
  insertLdgrForSendData,
  insertLdgrSelfPoolByJsonMerge01,
  moveAssetData,
  updateLdgrByJsonMerge01,
  chkAllDataStatus,
  sync,
  finFileCheck,
  finFileCreate,
  updateLdgrByJsonMerge02,
  ldgrDataByAsszCfboIdntId,
  getldgrDataByBatchId,
  recvMetaFileCheck,
  getAsszUnfcIdByIeb,
  selectUai022mByFileRename,
  fileRename,
  selectByFileRenameBaseYmd,
  updateLdgrUpdateFileNmSelfPool,
  selectByFileRenameByBaseYmd,
  selectByFileRenameByBatchId,
  mergeDocument,
  getBatchId,
  batchStart,
  selectTxtFileCopyToLearn,
  selectTxtFileCopyToLearnByBatchId,
  getSafeBaseDt,
  insertAssetResultSend,
} = require("./common");

const path = require("path");

//입력값 체크 pcsnClCd=01:날짜처리 , basDt = 날짜
const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("error node iemieb.js YYYYMMDD");
  process.exit(1);
}
//외부입력 basDt 값 검증 종료------------------------------------------------------------

if (pcsnClCd !== "01") {
  writeLog("error node iemieb.js clcd(처리구분:01) YYYYMMDD");
}

async function makeMeta(assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeMeta()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const targetDirSam = `/data/bdpetl/send/gai/gai/ieb/${basDt}`;
  const targetPdfDirJaon = `/data/asset/iem/ieb/${basDt}/originpdf`;

  try {
    //let res = await dbGaiMeta.selectMakeIebMetaByBaseYmd(basDt);
    let res = await dbGaiMeta.selectMakeIebMeta(assz_btch_acmp_id);
    //컬럼간 ^|, 행간 \n 문자열 생성

    const rowsFilter = res.rows.filter((row) => {
      totalCnt++;

      // if (fs.existsSync(`${targetPdfDirJaon}/${row.ori_doc_key}.pdf`)) {
      //   const fileStat = fs.statSync(
      //     `${targetPdfDirJaon}/${row.ori_doc_key}.pdf`
      //   );
      if (fs.existsSync(`${targetPdfDirJaon}/${row.doc_id}.pdf`)) {
        const fileStat = fs.statSync(`${targetPdfDirJaon}/${row.doc_id}.pdf`);
        row.fileSize = Math.floor(fileStat.size / 1024);
        //row.url = row.url.replace(/\r/g, "");
        return true;
      } else if (row.pr_gubun == "D") {
        writeLog(`삭제:[${row.doc_id}][${row.ori_doc_key}][${row.doc_nm}]`);
        return true;
        //failCnt++;
        //return false;
      } else {
        failCnt++;
        return false;
      }
    });
    let rows = rowsFilter
      .map((row) => {
        successCnt++;
        return [
          row.doc_id,
          //row.doc_nm,
          row.doc_id, //자산화아이디의 파일명
          row.ori_doc_key,
          row.fileSize,
          row.file_type,
          row.url_adr,
          row.pr_gubun,
          row.rgsn_ts,
          row.amnn_ts,
          row.att_file_yn,
          row.att_file_seq,
          row.link_file_nm,
          "",
          "",
        ]
          .map((val) => val ?? "")
          .join("^|");
      })
      .join("^|\n");

    if (rows != "") {
      rows = rows + "^|";
      //totalCnt++;
      //sam 저장
      const filePath = path.join(targetDirSam, `${basDt}_Meta.sam`);
      writeLog(`sam 파일생성 시작`);
      fs.writeFileSync(filePath, rows, "utf8");
      writeLog(`sam 파일생성 완료:${filePath}`);
      //successCnt++;
    } else {
      writeLog(`sam 파일생성 실패`);
      //failCnt++;
    }
    summaryLog(totalCnt, successCnt, failCnt, basDt, "makeMeta");
  } catch (err) {
    writeLog(`sam 파일생성 에러발생:${err}`);
    summaryLog(totalCnt, successCnt, failCnt, basDt, "makeMeta");
    process.exit(1);
  }
  writeLog(
    "----------------------------makeMeta()종료----------------------------"
  );
}

/*----------------------GAI.----------------------*/
async function gaiFileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------gaiFileCopy()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const sourceDirs = [
    { path: `/data/asset/iem/ieb/${basDt}/json`, ext: "json" },
    //{ path: `/data/asset/iem/ieb/${basDt}/pdf`, ext: "pdf" },
    { path: `/data/asset/iem/ieb/${basDt}/originpdf`, ext: "pdf" },
  ];
  const targetDir = `/data/bdpetl/send/gai/gai/ieb/${basDt}`;

  for (const dirInfo of sourceDirs) {
    const dir = dirInfo.path;
    const ext = dirInfo.ext;
    try {
      //자산화된 파일명만 조회.
      //const fileNmList = await dbAssetRlt.selectMetaDocNmIebByBaseYmd(basDt);
      const fileNmList = await dbAssetRlt.selectMetaDocNmIeb(assz_btch_acmp_id);

      for (const fnm of fileNmList.rows) {
        totalCnt++;
        //const fileName = `${fnm.doc_nm.replace(/\.[^/.]+$/, "")}.${ext}`;
        const fileName = `${fnm.assz_unfc_id.replace(/\.[^/.]+$/, "")}.${ext}`;
        const srcPath = path.join(dir, fileName);
        //const destPath = path.join(targetDir, fileName);
        const destPath = path.join(targetDir, `${fnm.assz_unfc_id}.${ext}`);
        try {
          await fs.copyFileSync(srcPath, destPath);
          writeLog(`COPY완료 : ${fileName}`);
          successCnt++;
        } catch (err) {
          writeLog(`Failed to copy ${fileName} ${srcPath} ${destPath}, ${err}`);
          failCnt++;
        }
      }
    } catch (err) {
      writeLog(`Failed to read directory ${dir}:${err}`);
    }
  }
  await summaryLog(totalCnt, successCnt, failCnt, basDt, "gaiFileCopy");
  writeLog(
    "----------------------------gaiFileCopy()종료----------------------------"
  );
}

/*----------------------mergeFileRename----------------------*/
async function mergeFileRename(assz_btch_acmp_id) {
  writeLog(
    "----------------------------mergeFileRename()시작----------------------------"
  );
  //대상 : originpdf 폴더
  //대상 : json 폴더

  //const resultData = await selectByFileRenameByBaseYmd(null, basDt);
  const resultData = await selectByFileRenameByBatchId(null, assz_btch_acmp_id);

  for (const rd of resultData.rows) {
    if (fs.existsSync(rd.old_pdf_file)) {
      await fileRename(rd.old_pdf_file, rd.new_pdf_file);
      await fileRename(rd.old_json_file, rd.new_json_file);
    }
  }
  writeLog(
    "----------------------------mergeFileRename()종료----------------------------"
  );
}

/*---------------------- 학습데이터 파일복사 ----------------------*/
async function moveToLearn(systemName, assz_btch_acmp_id) {
  writeLog(
    "----------------------------moveToLearn()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const resultData = await selectTxtFileCopyToLearn(
    null,
    systemName,
    assz_btch_acmp_id
  );

  for (const rd of resultData.rows) {
    totalCnt++;
    writeLog(`파일풀path:::${rd.srctxtfile}`);
    if (fs.existsSync(rd.srctxtfile)) {
      writeLog(`파일있음:::${rd.srctxtfile}`);
      try {
        if (!fs.existsSync(rd.tgtdir)) {
          writeLog(`폴더생성하기:::${rd.tgtdir}`);
          await fs.mkdirSync(`${rd.tgtdir}`, { recursive: true });
        }

        await fs.copyFileSync(rd.srctxtfile, rd.tgttxtfile);
        successCnt++;
      } catch (err) {
        failCnt++;
        writeLog(`폴더 생성 실패: ${rd.srctxtfile}:${rd.tgttxtfile}`);
      }
    } else {
      writeLog(`파일없음:::${rd.srctxtfile}`);
      failCnt++;
    }
  }
  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "moveToLearn"
  );
  writeLog(
    "----------------------------moveToLearn()종료----------------------------"
  );
}

/*----------------------moveToLearnByYear----------------------*/
async function moveToLearnByYear(systemName, assz_btch_acmp_id) {
  writeLog(
    "----------------------------moveToLearn()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const resultData = await selectTxtFileCopyToLearnByBatchId(
    null,
    systemName,
    assz_btch_acmp_id
  );

  for (const rd of resultData.rows) {
    totalCnt++;
    writeLog(`파일풀path:::${rd.srctxtfile}`);
    if (fs.existsSync(rd.srctxtfile)) {
      writeLog(`파일있음:::${rd.srctxtfile}`);
      try {
        if (!fs.existsSync(rd.tgtdir)) {
          writeLog(`폴더생성하기:::${rd.tgtdir}`);
          await fs.mkdirSync(`${rd.tgtdir}`, { recursive: true });
        }

        await fs.copyFileSync(rd.srctxtfile, rd.tgttxtfile);
        successCnt++;
      } catch (err) {
        failCnt++;
        writeLog(`폴더 생성 실패: ${rd.srctxtfile}:${rd.tgttxtfile}`);
      }
    } else {
      writeLog(`파일없음:::${rd.srctxtfile}`);
      failCnt++;
    }
  }
  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    systemName,
    "moveToLearnByYear"
  );
  writeLog(
    "----------------------------moveToLearnByYear()종료----------------------------"
  );
}

/*---------------------- 폴더 생성 ----------------------*/
async function makeDir() {
  const dirs = [`/data/bdpetl/send/gai/gai/ieb/${basDt}`];

  for (const dir of dirs) {
    try {
      fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃(전송)UDAIEBDTOGAIS001.js > iemieb 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  if (pcsnClCd == "01") {
    let sendPath = `/data/bdpetl/send/gai/gai/ieb/${basDt}/`;
    //원천메타파일이 없는경우 종료 하기 종료-------------------------------

    //const assz_btch_acmp_id = await dbGaiMeta.getMaxBatchId("IEMIEB");
    /*dbBatch.insertSendBatchJob(
      assz_btch_acmp_id,
      "03", //assz_btch_tcd, "01", // 01 : 수집, 02 : 자산화, 03 : 전송
      "02", //assz_trms_tgt_sys_dcd, 01:UDA,02:GAI....
      basDt, //acmp_ymd
      "UDAIEBDASSETR001", //btch_id
      "IEMIEB", //assz_orgn_sys_cd_con,
      "02", // 01 : 대기, 02 : 수행, 03 : 중단, 04 : 오류, 05 : 완료 assz_btch_pcsn_stg_dcd,
      "T1", // T1 : 메타+파일, T2 : DB, T3 : 지식샘assz_btch_pcsn_tcd,
      EROR_CODES.EROR_VL_SUCCESS, //eror_vl,
      EROR_CODES.EROR_VL_SUCCESS_STR, //assz_eror_con,
      "UDAIEBDASSETR001" //uda_sys_lsmd_id,
    );*/

    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "IEMIEB",
      "03", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB T3 지식샘
      "02" //assz_trms_tgt_sys_dcd
    ); //배치수행로그 입력 및 배치ID채번

    writeLog(`기준일자 수집배치ID ${assz_btch_acmp_id}`);
    if (assz_btch_acmp_id != null) {
      let error_log;
      try {
        await makeDir();
        // sam파일 생성
        await makeMeta(assz_btch_acmp_id);
        // 파일 복사
        await gaiFileCopy(assz_btch_acmp_id);
      } catch (e) {
        error_log = e;
      }
      // 서버간 전송 파일 동기화
      await sync(sendPath);
      // 자산화결과전송 저장
      await insertAssetResultSend(assz_btch_acmp_id, "02", error_log);
    } else {
      writeLog(`기준일자 수집배치ID 존재하지않음 ${basDt}`);
    }

    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/ieb", basDt);
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "03", "02");

    //await mergeFileRename(assz_btch_acmp_id); //머지된 물리적 파일명 리네임  -->다 끝나면 추후 삭제 할것~~

    //연도별로 학습데이터 저장
    //await moveToLearnByYear("iemieb", assz_btch_acmp_id);

    // TB_DOCUMNET 에 머지인서트 시작
    // 자산화쪽으로 이동
    //await mergeDocument(null, assz_btch_acmp_id);
  } else if (pcsnClCd == "02") {
    //초기이행용
    //학습용데이터모음 /data/train_data/rawdata/iemieb/year 연도별로 모으기
    await moveToLearn("iemieb", null);
  }
  await dbAssetRlt.dbEnd();
  await dbGaiMeta.dbEnd();
  await dbAssetLog.dbEnd();
  await dbMetaMain.dbEnd();
  await dbBatch.dbEnd();
  await dbImgRlt.dbEnd();
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃UDAIEBDASSETR002 > iemieb 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃"
  );
}

main();
