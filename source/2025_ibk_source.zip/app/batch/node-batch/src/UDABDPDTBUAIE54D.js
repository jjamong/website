const fs = require("fs");
const dayjs = require("dayjs");
const { getBatchId, batchStart, getSafeBaseDt } = require("./common");
const axios = require("axios");
const { Agent } = require("http");
const { writeLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

// util이 불려진 시점부터 instace 생성하고 30초마다 재생성 keepAlive 처리
let agent = createNewAgent();
let axiosInstance = createAxiosInstance(agent);

//startAgentResetLoop();

function createNewAgent() {
  return new Agent({
    keepAlive: true,
    //keepAliveMsecs: 30000,
    maxSockets: 5000,
    maxFreeSockets: 1000,
  });
}

function createAxiosInstance(agent) {
  return axios.create({
    httpAgent: agent,
    timeout: 0,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });
}

let META_INFOS = {};

function getMETA_INFOS(basDt) {
  return {
    BDP_UDA_CMIE54D: {
      filePath: `/data/bdpetl/recv/bdp/bdp/tbl/BDP_UDA_CMIE54D_${basDt}.dat_NEW`,
      cols: {
        0: "DLLZ_CD_VL|VARCHAR",
        1: "STTG_YMD|VARCHAR",
        2: "FNSH_YMD|VARCHAR",
        3: "WRPX_EMN|VARCHAR",
        4: "STTG_HMS|VARCHAR",
        5: "SPCM_ADT_YN|VARCHAR",
        6: "EMN|VARCHAR",
        7: "FNSH_HMS|VARCHAR",
        8: "HLTM_DCD|VARCHAR",
        9: "DLLZ_CD_NM|VARCHAR",
        10: "VCTN_NDD|NUMERIC",
        11: "SNCT_ID|VARCHAR",
        12: "BDP_ETL_BASE_YMD|VARCHAR",
        13: "BDP_ETL_JOB_TS|TIMESTAMP",
        14: "UDA_SYS_LSMD_ID|VARCHAR",
        15: "UDA_SYS_LSMD_TS|TIMESTAMP",
      },
      tableName: "TB_UDA_UAIE54D",
    },
  };
}

async function upsertMeta(metaName, columns, rows) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();
  const tableName = META_INFOS[metaName].tableName;
  const numCols = columns.length;
  const values = [];

  try {
    const tuples = rows
      .map((row, rowIdx) => {
        const offset = rowIdx * numCols;

        row.forEach((val) => values.push(val));

        const placeholders = row
          .map((_, colIdx) => convertColumnType(offset, colIdx, metaName))
          .join(", ");
        return `(${placeholders})`;
      })
      .join(",\n");

    // console.log(tuples);
    let mergeSql = `
      MERGE INTO ${tableName} AS t
      USING (
        VALUES
        ${tuples}
      ) AS s(${columns.join(", ")})
    `;
    if (tableName == "TB_UDA_UAIE54D")
      mergeSql += `ON (t.${columns[0]} = s.${columns[0]} AND t.${columns[1]} = s.${columns[1]} AND t.${columns[2]} = s.${columns[2]} AND t.${columns[3]} = s.${columns[3]} AND t.${columns[4]} = s.${columns[4]} AND t.${columns[5]} = s.${columns[5]} AND t.${columns[6]} = s.${columns[6]} AND t.${columns[7]} = s.${columns[7]})`;
    else mergeSql += `ON (t.${columns[0]} = s.${columns[0]})`;
    mergeSql += `
      WHEN MATCHED THEN
        UPDATE SET
          ${columns
            .slice(1)
            .map((col) => `${col} = s.${col}`)
            .join(",\n      ")}
        WHEN NOT MATCHED THEN
          INSERT (${columns.join(", ")})
          VALUES (${columns.map((col) => `s.${col}`).join(", ")})
    `;
    // console.log(mergeSql);
    //console.log(tuples);
    //console.log(values.length);
    // console.log(values);
    await client.query(mergeSql, values);
  } catch (err) {
    writeLog(`${tableName} => 작업 상태 초기화 실패: ${err.message}`);
    // console.log(err);
  } finally {
    client.release();
    pool.end();
  }
}

function convertColumnType(offset, colIdx, metaName) {
  let str = `$${offset + colIdx + 1}`;
  let colType = META_INFOS[metaName].cols[colIdx].split("|")[1];
  let colName = META_INFOS[metaName].cols[colIdx].split("|")[0];

  if (colType) {
    if (colType == "TIMESTAMP")
      str = `TO_TIMESTAMP($${offset + colIdx + 1},'YYYYMMDDHH24MISS')`;
    if (colType == "DATE")
      str = `TO_DATE($${offset + colIdx + 1},'YYYY-MM-DD')`;
    if (colType == "NUMBER") str = `$${offset + colIdx + 1}::integer`;
    if (colType == "NUMERIC") str = `$${offset + colIdx + 1}::NUMERIC`;
  }

  // 20250618 BRCD lpad 처리
  if (colName === "BRCD") {
    str = `LPAD($${offset + colIdx + 1},4,'0')`;
  }

  return str;
}

(async () => {
  //외부입력 basDt 값 검증 시작------------------------------------------------------------
  const basDtArg = process.argv[2];
  let safeBasDt = getSafeBaseDt(basDtArg);
  if (safeBasDt == "") {
    writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
    process.exit(1);
  }
  writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
  const basDt = safeBasDt;
  //외부입력 basDt 값 검증 종료------------------------------------------------------------
  const batchId = getBatchId(process.argv[1]);

  const assz_btch_acmp_id = await batchStart(
    basDt,
    batchId,
    "TBE54D",
    "01", //01	수집 02	자산화 03	전송
    "02", //01	대기 02	수행 03	중단 04	오류 05	완료
    "T2", //T1	메타+파일 T2	DB T3	지식샘
    "01" //assz_tgt_sys_cd
  ); //배치수행로그 입력 및 배치ID채번

  META_INFOS = getMETA_INFOS(basDt);
  //console.log(META_INFOS);
  for (let meta of Object.keys(META_INFOS)) {
    //await parseMeta(meta, META_INFOS[meta].filePath);
    let content;
    try {
      content = fs.readFileSync(META_INFOS[meta].filePath, "utf8");
    } catch (e) {
      continue;
    }
    const lines = content.split("\n").filter((line) => line.trim() !== "");
    //console.log(lines.length);

    const rows = lines
      .map((line) => {
        let l = line.split("^|");
        l.pop();
        if (l.length > 2) {
          l.push(batchId);
          l.push(dayjs().format("YYYYMMDDHHmmss"));
          l = l.map((d, i) => (d == "null" ? null : d.trimEnd()));
        }
        return l;
      })
      .filter((line) => line.length > 2);

    const columns = Object.values(META_INFOS[meta].cols).map(
      (d, i) => d.split("|")[0]
    );
    //.join(", ");
    //console.log(columns);

    const maxRows = 1;
    writeLog(`${META_INFOS[meta].filePath} 진행`);
    for (let i = 0; i < rows.length; i++) {
      const chunk = rows.slice(i, i + maxRows);
      await upsertMeta(meta, columns, chunk);
      writeLog(
        `${META_INFOS[meta].tableName} : ${i + 1} / ${rows.length} UPSERT 완료`
      );
    }
  }

  //배치수행 최종완료시간
  await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  // DB 커넥션 해제
  await dbBatch.dbEnd();
})();
