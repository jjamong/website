// 지식샘 자산화 (AIK > KMS)
const fs = require("fs");
const util = require("../util.js");
const path = require("path");
const dayjs = require("dayjs");
const {
  getSafeBaseDt,
  getBatchId,
  batchStart,
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrMaster,
  getFileInfo,
  updateLdgrDupCreateData,
  moveAssetData,
  sync,
  finFileCheck,
  isImageMagick,
  mergeDocument,
  recvMetaFileCheck,
  finFileCreate,
} = require("./common.js");
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const { writeLog, summaryLog } = require("../log.js"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M.js");
const dbMetaMain = require("../sql/TB_UDA_UAI005M.js");
const dbAssetLog = require("../sql/TB_UDA_UAI901L.js"); //자산화 처리로그
const dbAssetRlt = require("../sql/TB_UDA_UAI910L.js");
const dbImgRlt = require("../sql/TB_UDA_UAI912L.js");
const dbGaiMeta = require("../sql/TB_UDA_GAI_META.js"); //GPT 전송 META파일
const {
  chkDupByAsszCfboIdntId,
  updateErorVl,
  updateOriginMaster,
  deleteAddInfoKms,
} = require("../sql/TB_UDA_UAI000M.js"); // 자산화결과기본(원장)

const { exec } = require("child_process");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  process.exit(1);
}
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------

/*---------------------- 폴더 생성 ----------------------*/
async function makeDir() {
  const dirs = [
    `/data/asset/aik/kms/${basDt}/att`,
    `/data/asset/aik/kms/${basDt}/dp`,
    `/data/asset/aik/kms/${basDt}/json`,
    `/data/asset/aik/kms/${basDt}/origin`,
    `/data/asset/aik/kms/${basDt}/originpdf`,
    `/data/asset/aik/kms/${basDt}/pdf`,
    `/data/asset/aik/kms/${basDt}/txt`,
    `/data/asset/aik/kms/${basDt}/img`,
    `/data/bdpetl/send/gai/gai/kms/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*------------------- 메인메타 처리 ----------------------*/
async function mainMetaProcess(assz_btch_acmp_id) {
  writeLog(
    "------------------ mainMetaProcess() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 메인메타 읽어오기
  let masterPath = `/data/bdpetl/recv/aik/kms/${basDt}/meta/master.dat`;
  const masterFileData = fs.readFileSync(masterPath, "utf-8");
  const masterLine = masterFileData.split("<<<ROW>>>");

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "AIKKMS");
  let idx = result.rows[0].idsqn;
  let metas;

  const masterFieldNames = [
    "assz_cfbo_idnt_id", // 자산화원천별식별ID(콘텐츠ID)
    "assz_cnfg_id", // 자산화구성ID(탭ID)
    "assz_sbtl_id", //자산화부제ID(소제목ID)
    "assz_sbtl_con", //자산화부제내용(소제목내용)
    "url_adr", // URL주소
    "qstn_id", //질문ID
    "assz_qstn_con", // 자산화질문내용(질문내용)
    "rply_id", // 답변ID
    "assz_rply_con", // 답변내용
    "orgn_data_rgsr_id", // 등록자
    "rgsn_ts", // 등록일시
    "amnn_ts", // 수정일시
    "assz_orgn_pcsn_dcd", // 자산화원천처리구분코드
    "assz_dcmn_clsf_id", // 자산화문서분류ID
    "conn_ttl_nm", // 콘텐츠제목명
    "tab_nm", // 탭명
    "sb_ttl_nm", // 소제목명
    "file_yn", //파일여부
  ];
  for (const line of masterLine) {
    if (!line.trim()) continue;
    const metaFileData = line.split("^|").map((item) => item.trim());
    metas = Object.fromEntries(
      masterFieldNames.map((k, i) => [k, metaFileData[i]])
    );

    /*
    // 테스트일 경우
    if (process.argv[2] == "test") {
      if (!/^2025010[1-5]/.test(metas.rgsn_ts)) {
      //if (!/^2024010[1]/.test(metas.rgsn_ts)) {
        continue
      }
    }
    */

    totalCnt++;

    // 자산화원천별식별ID가 없을 경우
    if (
      metas.assz_cfbo_idnt_id == "" ||
      metas.assz_cfbo_idnt_id == undefined ||
      metas.assz_cfbo_idnt_id == null
    ) {
      writeLog(`메타파일에 자산화원천별식별ID(콘텐츠ID) 없음`);
      failCnt++;
      continue;

      // 자산화원천별식별ID가 있을 경우
    } else {
      // 비정형데이터자산화시스템최종변경ID
      metas.uda_sys_lsmd_id = "UDAKMSDASSETR001";

      metas.assz_btch_acmp_id = assz_btch_acmp_id;

      // 메인메타 조건체크
      metas = await mainMetaProcessCheck(metas);

      // 원장조회 조회
      let orginIds = await chkDupByAsszCfboIdntId(
        "AIKKMS",
        metas.aikkms_assz_cfbo_idnt_id
      );

      if (metas.assz_orgn_pcsn_dcd == "C") {
        // 원장에 이미 데이터가 존재할 경우
        if (orginIds.rows[0]) {
          // 원장의 자산화통합아이디 가져오기
          metas.assz_unfc_id = orginIds.rows[0].assz_unfc_id;

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 원장에 C로 저장되어 있을 경우 (재수행 건)
          if (orginIds.rows[0].assz_pcsn_tcd == "C") {
            // 메타파일 데이터와 원장테이블 데이터 비교 시 변경점이 없을 경우 원장 수행정보 변경
            await updateLdgrDupCreateData(
              null,
              metas.assz_unfc_id,
              metas.assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_INIT,
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR
            );

            successCnt++;

            // 원장에 C로 저장되어 있지 않을 경우
          } else {
            metas.eror_vl = EROR_CODES.EROR_VL_META_FAILED;
            metas.assz_eror_con = EROR_CODES.EROR_VL_META_FAILED_STR;
            writeLog(
              `${EROR_CODES.EROR_VL_META_FAILED_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : ${orginIds.rows[0].assz_pcsn_tcd}`
            );
            failCnt++;
          }

          // 원장에 데이터가 존재하지 않을 경우
        } else {
          // 자산화통합아이디 채번
          metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 메인메타 원장 처리
          try {
            metas = await mainMetaOrginProcess(metas);

            successCnt++;
          } catch (error) {
            writeLog(error);
            failCnt++;
          }
        }
        // 수정일 경우
      } else if (metas.assz_orgn_pcsn_dcd == "U") {
        // 원장에 이미 데이터가 존재할 경우
        if (orginIds.rows[0]) {
          // 원장의 자산화통합아이디 가져오기
          metas.assz_unfc_id = orginIds.rows[0].assz_unfc_id;

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 원장에 D로 저장되어 있을 경우
          if (orginIds.rows[0].assz_pcsn_tcd == "D") {
            metas.eror_vl = EROR_CODES.EROR_VL_META_FAILED;
            metas.assz_eror_con = EROR_CODES.EROR_VL_META_FAILED_STR;
            writeLog(
              `${EROR_CODES.EROR_VL_META_FAILED_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : ${orginIds.rows[0].assz_pcsn_tcd}`
            );
            failCnt++;

            // 원장에 C, U로 저장되어 있을 경우
          } else if (
            orginIds.rows[0].assz_pcsn_tcd == "C" ||
            orginIds.rows[0].assz_pcsn_tcd == "U"
          ) {
            // 메인메타 원장 처리
            try {
              metas = await mainMetaOrginProcess(metas);

              successCnt++;
            } catch (error) {
              writeLog(error);
              failCnt++;
            }
          }

          // 원장에 데이터가 존재하지 않을 경우
        } else {
          writeLog(
            `${EROR_CODES.EROR_VL_UNSUCCESS2_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : 데이터없음 -> C 신규처리`
          );
          // 원본없는 수정건 케이스
          // 컨텐츠ID 기준으로 하위 탭ID, 소제목ID등이 추가되어도 컨텐츠ID 전체를U로 준다.
          // 최초의 비공개 상태로 만들었다가(C) 나중에 공개여부로 바뀌면 이 때시점에 컨텐츠 ID 전체를 U로 준다.
          metas.assz_orgn_pcsn_dcd = "C"

          // 자산화통합아이디 채번
          metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 메인메타 원장 처리
          try {
            metas = await mainMetaOrginProcess(metas);

            successCnt++;
          } catch (error) {
            writeLog(error);
            failCnt++;
          }
        }

        // 삭제일 경우
      } else if (metas.assz_orgn_pcsn_dcd == "D") {
        // 원장에 이미 데이터가 존재할 경우
        if (orginIds.rows[0]) {
          //원장의 자산화통합아이디 가져오기
          metas.assz_unfc_id = orginIds.rows[0].assz_unfc_id;

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 원장에 D로 저장되어 있을 경우
          if (orginIds.rows[0].assz_pcsn_tcd == "D") {
            metas.eror_vl = EROR_CODES.EROR_VL_META_FAILED;
            metas.assz_eror_con = EROR_CODES.EROR_VL_META_FAILED_STR;
            writeLog(
              `${EROR_CODES.EROR_VL_META_FAILED_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : ${orginIds.rows[0].assz_pcsn_tcd}`
            );
            failCnt++;
            // 원장에 C, U로 저장되어 있을 경우
          } else if (
            orginIds.rows[0].assz_pcsn_tcd == "C" ||
            orginIds.rows[0].assz_pcsn_tcd == "U"
          ) {
            // 메인메타 삭제 처리
            metas.assz_scd = COMMON_CODES.ASSZ_SCD_DELETE;
            await mainMetaDbDelete(metas);

            successCnt++;
          }
          // 원장에 데이터가 존재하지 않을 경우
        } else {
          metas.eror_vl = EROR_CODES.EROR_VL_UNSUCCESS;
          metas.assz_eror_con = EROR_CODES.EROR_VL_UNSUCCESS_STR;
          writeLog(
            `${EROR_CODES.EROR_VL_UNSUCCESS_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : 데이터없음`
          );
          // 자산화통합아이디 채번
          metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);

          // 파일명 변경
          metas.file_nm = `${metas.assz_unfc_id}.html`;
          metas.assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/origin/${metas.file_nm}`;

          // 메인메타 원장 처리
          try {
            metas = await mainMetaOrginProcess(metas);
            failCnt++;
          } catch (error) {
            writeLog(error);
            failCnt++;
          }
        }
      }

      // 메타로그 저장
      await mainMetaLogDbInsert(metas);
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "mainMetaProcess"
  );
  writeLog(
    "------------------ mainMetaProcess() 종료 ----------------------------"
  );
}

/*------------------- 메인메타 조건체크  ----------------------*/
async function mainMetaProcessCheck(metas) {
  // 탭ID, 소제목ID가 존재하고, 질문ID, 답변ID가 없을 경우(소제목 형)
  if (
    metas.assz_cnfg_id &&
    metas.assz_sbtl_id &&
    !metas.qstn_id &&
    !metas.rply_id
  ) {
    metas.eror_vl = EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS;
    metas.assz_eror_con = EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS_STR;

    // 컨텐츠ID + 탭ID + 소제목ID
    metas.aikkms_assz_cfbo_idnt_id = `${metas.assz_cfbo_idnt_id}_${metas.assz_cnfg_id}_${metas.assz_sbtl_id}`;

    // 탭ID, 소제목ID, 질문ID, 답변ID 모든 ID가 있고, 소제목내용이 없는 경우 (질문답변 형)
  } else if (
    metas.assz_cnfg_id &&
    metas.assz_sbtl_id &&
    metas.qstn_id &&
    metas.rply_id &&
    !metas.assz_sbtl_con
  ) {
    metas.eror_vl = EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS;
    metas.assz_eror_con = EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS_STR;

    // 컨텐츠ID + 탭ID + 소제목ID + 질문ID + 답변ID
    metas.aikkms_assz_cfbo_idnt_id = `${metas.assz_cfbo_idnt_id}_${metas.assz_cnfg_id}_${metas.assz_sbtl_id}_${metas.qstn_id}_${metas.rply_id}`;

    // 탭ID, 소제목ID, 질문ID, 답변ID 모든 ID가 없는 경우 (원본)
  } else if (
    !metas.assz_cnfg_id &&
    !metas.assz_sbtl_id &&
    !metas.qstn_id &&
    !metas.rply_id
  ) {
    metas.eror_vl = EROR_CODES.EROR_VL_AIKKMS_ORGIN_SUCESSS;
    metas.assz_eror_con = EROR_CODES.EROR_VL_AIKKMS_ORGIN_SUCESSS_STR;

    // 컨텐츠ID
    metas.aikkms_assz_cfbo_idnt_id = `${metas.assz_cfbo_idnt_id}`;

    // 탭ID가 존재하고, 소제목ID, 질문ID, 답변ID가 없는 경우 (FULL URL)
  } else if (
    metas.assz_cnfg_id &&
    !metas.assz_sbtl_id &&
    !metas.qstn_id &&
    !metas.rply_id
  ) {
    metas.eror_vl = EROR_CODES.EROR_VL_AIKKMS_FULLURL_SUCESSS;
    metas.assz_eror_con = EROR_CODES.EROR_VL_AIKKMS_FULLURL_SUCESSS_STR;

    // 컨텐츠ID + 탭ID
    metas.aikkms_assz_cfbo_idnt_id = `${metas.assz_cfbo_idnt_id}_${metas.assz_cnfg_id}`;
  }

  return metas;
}

/*------------------- 메인메타 원장 처리  ----------------------*/
async function mainMetaOrginProcess(metas) {
  // 지식샘 자산화원천식별ID
  let htmlContent = "";

  // 탭ID, 소제목ID가 존재하고, 질문ID, 답변ID가 없을 경우(소제목 형)
  if (metas.eror_vl == EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS) {
    // 소제목내용
    htmlContent = metas.assz_sbtl_con;

    // HTML 생성
    try {
      fs.writeFileSync(metas.assz_orcp_file_path_nm, htmlContent, "utf8");
      writeLog(`HTML생성성공: ${metas.assz_orcp_file_path_nm}`);
    } catch (err) {
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      metas.eror_vl = EROR_CODES.EROR_VL_HTML_FAILED;
      metas.assz_eror_con = EROR_CODES.EROR_VL_HTML_FAILED_STR;
      writeLog(
        `${metas.assz_eror_con} : ${metas.assz_orcp_file_path_nm}, ${err}`
      );
      throw new Error(
        `${metas.assz_eror_con} : ${metas.assz_orcp_file_path_nm}, ${err}`
      );
    }

    // 파일정보 가져오기
    let fileInfo = null;
    try {
      fileInfo = await getFileInfo(metas.assz_orcp_file_path_nm);
      metas.flsz_vl = fileInfo.size; // 파일 사이즈
      metas.assz_orgn_file_encp_rnnm_vl = fileInfo.md5; // 파일해시
    } catch (e) {
      metas.eror_vl = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
      metas.assz_eror_con = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
      writeLog(`${metas.assz_eror_con} ${metas.assz_orcp_file_path_nm}, ${e}`);
      throw new Error(
        `${metas.assz_eror_con} ${metas.assz_orcp_file_path_nm}, ${e}`
      );
    }

    // 자산화 초기
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_INIT;

    // 탭ID, 소제목ID, 질문ID, 답변ID 모든 ID가 있고, 소제목내용이 없는 경우 (질문답변 형)
  } else if (metas.eror_vl == EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS) {
    // 질문내용 + 답변내용
    htmlContent = metas.assz_qstn_con + metas.assz_rply_con;

    try {
      fs.writeFileSync(metas.assz_orcp_file_path_nm, htmlContent, "utf8");
      writeLog(`HTML생성성공: ${metas.assz_orcp_file_path_nm}`);
    } catch (err) {
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      metas.eror_vl = EROR_CODES.EROR_VL_HTML_FAILED;
      metas.assz_eror_con = EROR_CODES.EROR_VL_HTML_FAILED_STR;
      writeLog(
        `${metas.assz_eror_con} : ${metas.assz_orcp_file_path_nm}, ${err}`
      );
      throw new Error(
        `${metas.assz_eror_con} : ${metas.assz_orcp_file_path_nm}, ${err}`
      );
    }

    // 파일정보 가져오기
    let fileInfo = null;
    try {
      fileInfo = await getFileInfo(metas.assz_orcp_file_path_nm);
      metas.flsz_vl = fileInfo.size; // 파일 사이즈
      metas.assz_orgn_file_encp_rnnm_vl = fileInfo.md5; // 파일해시
    } catch (e) {
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      metas.eror_vl = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
      metas.assz_eror_con = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
      writeLog(`${metas.assz_eror_con} ${metas.assz_orcp_file_path_nm}, ${e}`);
      throw new Error(
        `${metas.assz_eror_con} ${metas.assz_orcp_file_path_nm}, ${e}`
      );
    }

    // 자산화 초기
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_INIT;

    // 탭ID, 소제목ID, 질문ID, 답변ID 모든 ID가 없는 경우 (원본)
  } else if (metas.eror_vl == EROR_CODES.EROR_VL_AIKKMS_ORGIN_SUCESSS) {
    // 자산화 정상
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_SUCCESS;

    // 탭ID가 존재하고, 소제목ID, 질문ID, 답변ID가 없는 경우 (FULL URL)
  } else if (metas.eror_vl == EROR_CODES.EROR_VL_AIKKMS_FULLURL_SUCESSS) {
    // 자산화 정상
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_SUCCESS;
  }

  // 저장일 경우
  if (metas.assz_orgn_pcsn_dcd == "C") {
    // 메인메타 저장 처리
    await mainMetaDbInsert(metas);

    // 수정일 경우
  } else if (metas.assz_orgn_pcsn_dcd == "U") {
    // 메인메타 수정 처리
    await mainMetaDbUpdate(metas);
    
    // 삭제일 경우
  } else if (metas.assz_orgn_pcsn_dcd == "D") {
    // 원본없는 삭제일 경우엔 에러코드로 추가처리
    if (metas.eror_vl == EROR_CODES.EROR_VL_UNSUCCESS) {
      // 메인메타 저장 처리
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      await mainMetaDbInsert(metas);
    }
  }

  return metas;
}

/*------------------- 메인메타 저장 처리   ----------------------*/
async function mainMetaDbInsert(metas) {
  // 원장마스터 인서트
  await insertLdgrMaster(
    null,
    metas.assz_unfc_id,
    metas.assz_scd,
    metas.aikkms_assz_cfbo_idnt_id,
    null, // rgsn_ymd
    null, // mdfc_ymd
    metas.assz_orgn_pcsn_dcd,
    metas.eror_vl,
    metas.assz_eror_con,
    "", // assz_pcsn_file_path_nm 초기시 빈값,
    metas.flsz_vl, // 파일 사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    metas.assz_btch_acmp_id,
    metas.uda_sys_lsmd_id
  );

  // 원장메타 저장
  await dbMetaMain.insertMeta(
    metas.assz_unfc_id, // 자산화통합ID
    metas.assz_cfbo_idnt_id, // 자산화원천식별ID
    metas.assz_cnfg_id, // 자산화구성ID
    metas.assz_sbtl_id, // 자산화부제ID
    metas.assz_sbtl_con, // 자산화부제내용
    metas.url_adr, // URL주소
    metas.qstn_id, // 질문ID
    metas.assz_qstn_con, // 자산화질문내용
    metas.rply_id, // 답변ID
    metas.assz_rply_con, // 자산화답변내용
    metas.orgn_data_rgsr_id, // 원천데이터등록자ID
    metas.rgsn_ts, // 등록일시
    metas.amnn_ts, // 수정일시
    metas.assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
    metas.assz_dcmn_clsf_id, // 자산화문서분류ID
    metas.conn_ttl_nm, // 콘텐츠제목명
    metas.tab_nm, // 탭명
    metas.sb_ttl_nm, // 부제목명
    metas.file_yn, // 파일여부
    "", // 파일명
    "", // 첨부파일KEY값
    COMMON_CODES.DEFAULT_NULL_DATE, // 첨부파일등록일시
    "", // 첨부파일여부
    0, // 첨부파일순번
    "", // 첨부파일명
    metas.assz_orcp_file_path_nm, // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
    metas.uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
  );
}

/*------------------- 메인메타 수정 처리 ----------------------*/
async function mainMetaDbUpdate(metas) {
  // 원장마스터 수정
  await updateOriginMaster(
    metas.assz_unfc_id,
    metas.assz_btch_acmp_id,
    metas.assz_scd,
    metas.flsz_vl, // 파일사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    "", // 자산화처리파일 경로명
    metas.eror_vl,
    metas.assz_eror_con
  );

  // 원장메타 수정
  await dbMetaMain.updateMeta(
    metas.assz_unfc_id,
    metas.assz_sbtl_con, // 자산화부제내용
    metas.url_adr, // URL주소
    metas.assz_qstn_con, // 자산화질문내용
    metas.assz_rply_con, // 자산화답변내용
    metas.orgn_data_rgsr_id, // 원천데이터등록자ID
    metas.rgsn_ts, // 등록일시
    metas.amnn_ts, // 수정일시
    metas.conn_ttl_nm, // 콘텐츠제목명
    metas.tab_nm, // 탭명
    metas.sb_ttl_nm, // 부제목명
    metas.file_yn, // 파일여부
    metas.assz_orcp_file_path_nm // 자산화처리파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
  );

  // 원장 추가정보 삭제 (기존 원장 원장 추가정보 전체 삭제)
  await dbMetaMain.deleteAddInfoMeta(metas.assz_cfbo_idnt_id);
}

/*------------------- 메인메타 삭제 처리 ----------------------*/
async function mainMetaDbDelete(metas) {
  // 원장 마스터 삭제 (기존 원장마스터의 추가정보메타까지 전체 삭제)
  await deleteAddInfoKms(
    metas.assz_cfbo_idnt_id,
    metas.assz_btch_acmp_id,
    COMMON_CODES.ASSZ_SCD_DELETE
  );

  // 원장메타 삭제
  await dbMetaMain.deleteMeta(metas.assz_unfc_id);

  // 원장 추가정보 삭제 (기존 원장 원장 추가정보 전체 삭제)
  await dbMetaMain.deleteAddInfoMeta(metas.assz_cfbo_idnt_id);
}

/*------------------- 메타로그 저장  ---------------------- */
async function mainMetaLogDbInsert(metas) {
  await dbMetaMain.insertMetaLog(
    metas.assz_btch_acmp_id, // 자산화배치수행ID
    metas.assz_cfbo_idnt_id, // 자산화원천식별ID
    metas.assz_unfc_id, // 자산화통합ID
    metas.assz_cnfg_id, // 자산화구성ID
    metas.assz_sbtl_id, // 자산화부제ID
    metas.assz_sbtl_con, // 자산화부제내용
    metas.url_adr, // URL주소
    metas.qstn_id, // 질문ID
    metas.assz_qstn_con, // 자산화질문내용
    metas.rply_id, // 답변ID
    metas.assz_rply_con, // 자산화답변내용
    metas.orgn_data_rgsr_id, // 원천데이터등록자ID
    metas.rgsn_ts, // 등록일시
    metas.amnn_ts, // 수정일시
    metas.assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
    metas.assz_dcmn_clsf_id, // 자산화문서분류ID
    metas.conn_ttl_nm, // 콘텐츠제목명
    metas.tab_nm, // 탭명
    metas.sb_ttl_nm, // 부제목명
    metas.file_yn, // 파일여부
    "", // 파일명
    "", // 첨부파일KEY값
    COMMON_CODES.DEFAULT_NULL_DATE, // 첨부파일등록일시
    "", // 첨부파일여부
    0, // 첨부파일순번
    "", // 첨부파일명
    metas.assz_orcp_file_path_nm, // 자산화처리파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
    metas.uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
  );
}

/*------------------- 추가정보메타 저장 처리 ----------------------*/
async function addInfoMetaProcess(assz_btch_acmp_id) {
  writeLog(
    "------------------ addInfoMetaProcess() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 추가정보메타 읽어오기
  let addinfoPath = `/data/bdpetl/recv/aik/kms/${basDt}/meta/add_info.dat`;

  try {
    fs.accessSync(addinfoPath);
  } catch (err) {
    writeLog(`${addinfoPath} ${err}`);
    return;
  }

  const addInfoFileData = fs.readFileSync(addinfoPath, "utf-8");
  const addInfoLine = addInfoFileData.split("<<<ROW>>>");

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "AIKKMS");
  let idx = result.rows[0].idsqn;
  let metas;

  const addInfoFieldNames = [
    "assz_cfbo_idnt_id", // 자산화원천별식별ID(콘텐츠ID)
    "file_nm", // 파일명
    "atch_key_vl", // 첨부파일Key
    "assz_orcp_file_path_nm", // 자산화원본파일경로명(파일명제외)
    "apnd_file_rgsn_ts", // 첨부파일등록일시
    "atch_yn", // 첨부파일여부
    "atch_sqn", // 첨부파일순번
    "atch_nm", // 첨부파일명
    "assz_pcsn_file_path_nm", // 자산화처리파일경로명
  ];
  for (const line of addInfoLine) {
    if (!line.trim()) continue;
    const metaFileData = line.split("^|").map((item) => item.trim());
    metas = Object.fromEntries(
      addInfoFieldNames.map((k, i) => [k, metaFileData[i]])
    );

    totalCnt++;

    // 자산화원천별식별ID가 없을 경우
    if (
      metas.assz_cfbo_idnt_id == "" ||
      metas.assz_cfbo_idnt_id == undefined ||
      metas.assz_cfbo_idnt_id == null
    ) {
      writeLog(`메타파일에 자산화원천별식별ID(콘텐츠ID) 없음`);
      failCnt++;
      continue;

      // 자산화원천별식별ID가 있을 경우
    } else {
      // 비정형데이터자산화시스템최종변경ID
      metas.uda_sys_lsmd_id = "UDAKMSDASSETR001";

      metas.assz_btch_acmp_id = assz_btch_acmp_id;
      metas.atch_yn = metas.atch_yn;
      metas.atch_sqn = metas.atch_sqn ? metas.atch_sqn : 0; // 첨부파일 여부가 N일경우 순번이 빈값으로 와 디폴트 값 처리
      metas.eror_vl = EROR_CODES.EROR_VL_SUCCESS;
      metas.assz_eror_con = EROR_CODES.EROR_VL_SUCCESS_STR;

      // 파일명, 경로 설정
      let ext = path.extname(metas.file_nm).toLowerCase();
      let dirGb = metas.atch_yn === "N" ? "origin" : "att"; // 디렉토리구분

      const targetPath = `/data/asset/aik/kms/${basDt}/${dirGb}`;
      metas.assz_orgn_file_path_nm = `/data/bdpetl/recv/aik/kms/${basDt}/file/${metas.file_nm}`;

      // 추가정보메타의 원천식별ID로 원장의 처리유형코드 가져오기
      // 추가정보메타의 원천식별ID로 메인메타의 원천식별ID를 검색하면 여러개가 나오나(N:N관계)
      // 모두 같은 처리유형코드(C/U/D)로 되어 있어 하나만 조회해도
      // 메인메타/원장의 원천식별ID의 처리유형코드를 가져올 수 있어 limit1로 구현함
      let orginTcd = await dbMetaMain.selectMetaMasterTcd(
        metas.assz_cfbo_idnt_id
      );

      // 원장이 존재할 경우
      if (orginTcd.rows[0]) {
        metas.assz_orgn_pcsn_dcd = orginTcd.rows[0].assz_pcsn_tcd;

        // 원장첨부파일, 추가정보메타 조회
        let orginData = await dbMetaMain.selectAddInfo(
          metas.assz_cfbo_idnt_id,
          metas.atch_key_vl
        );

        // 등록일 경우
        if (metas.assz_orgn_pcsn_dcd == "C") {
          // 원장첨부파일에 이미 데이터가 존재할 경우
          if (orginData.rows[0]) {
            // 원장첨부파일의 자산화통합아이디 가져오기
            metas.assz_unfc_id = orginData.rows[0].assz_unfc_id;
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;

            // 원장첨부파일에 C로 저장되어 있고, 원장첨부파일의 파일순번이 0이 아닌 경우 (재수행 건)
            // 원장데이터와 원장첨부파일은 파일순번만 다르고 원천식별키가 같음
            if (orginData.rows[0].assz_pcsn_tcd == "C") {
              // 메타파일 데이터와 원장테이블 데이터 비교 시 변경점이 없을 경우 원장 수행정보 변경
              await updateLdgrDupCreateData(
                null,
                metas.assz_unfc_id,
                metas.assz_btch_acmp_id,
                COMMON_CODES.ASSZ_SCD_INIT,
                EROR_CODES.EROR_VL_SUCCESS,
                EROR_CODES.EROR_VL_SUCCESS_STR
              );

              successCnt++;

              // 원장첨부파일에 C로 저장되어 있지 않을 경우
            } else {
              metas.eror_vl = EROR_CODES.EROR_VL_META_FAILED;
              metas.assz_eror_con = EROR_CODES.EROR_VL_META_FAILED_STR;
              writeLog(
                `${EROR_CODES.EROR_VL_META_FAILED_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : ${orginData.rows[0].assz_pcsn_tcd}`
              );
              failCnt++;
            }

            // 원장첨부파일에 데이터가 존재하지 않을 경우
          } else {
            // 자산화통합아이디 채번
            metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;
            // 추가정보메타 원장 처리
            try {
              metas = await addInfoMetaOrginProcess(metas);

              successCnt++;
            } catch (error) {
              writeLog(error);
              failCnt++;
            }
          }

          // 수정일 경우
        } else if (metas.assz_orgn_pcsn_dcd == "U") {
          // 원장첨부파일에 이미 데이터가 존재할 경우
          if (orginData.rows[0]) {
            //원장첨부파일의 자산화통합아이디 가져오기
            metas.assz_unfc_id = orginData.rows[0].assz_unfc_id;
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;

            // 추가정보메타 원장 처리
            try {
              metas = await addInfoMetaOrginProcess(metas);
            } catch (error) {
              writeLog(error);
              failCnt++;
            }

            successCnt++;

            // 원장첨부파일에 데이터가 존재하지 않을 경우
          } else {
            // 원본없는 수정건 케이스
            // 컨텐츠ID 기준으로 하위 탭ID, 소제목ID등이 추가되어도 컨텐츠ID 전체를U로 준다.
            // 최초의 비공개 상태로 만들었다가(C) 나중에 공개여부로 바뀌면 이 때시점에 컨텐츠 ID 전체를 U로 준다.
            writeLog(
              `${EROR_CODES.EROR_VL_UNSUCCESS2_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : 데이터없음 -> C 신규처리`
            );
            metas.assz_orgn_pcsn_dcd = "C";

            // 자산화통합아이디 채번
            metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;
            // 추가정보메타 원장 처리
            try {
              metas = await addInfoMetaOrginProcess(metas);
              failCnt++;
            } catch (error) {
              writeLog(error);
              failCnt++;
            }
          }
          // 삭제일 경우
        } else if (metas.assz_orgn_pcsn_dcd == "D") {
          // 원장첨부파일에 이미 데이터가 존재할 경우
          if (orginData.rows[0]) {
            //원장첨부파일의 자산화통합아이디 가져오기
            metas.assz_unfc_id = orginData.rows[0].assz_unfc_id;
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;

            // 원장첨부파일에 D로 저장되어 있을 경우
            if (orginData.rows[0].assz_pcsn_tcd == "D") {
              // 원장 추가정보메타는 원장마스터 삭제시 한번에 삭제함
              successCnt++;
            }

            // 원장첨부파일에 데이터가 존재하지 않을 경우
          } else {
            metas.eror_vl = EROR_CODES.EROR_VL_UNSUCCESS;
            metas.assz_eror_con = EROR_CODES.EROR_VL_UNSUCCESS_STR;
            writeLog(
              `${EROR_CODES.EROR_VL_UNSUCCESS_STR} / assz_cfbo_idnt_id : ${metas.assz_cfbo_idnt_id}, 메타파일 : ${metas.assz_orgn_pcsn_dcd}, 원장테이블 : 데이터없음`
            );
            // 자산화통합아이디 채번
            metas.assz_unfc_id = await getUnfcId("AIKKMS", ++idx);
            // 파일명 변경
            metas.assz_pcsn_file_path_nm = `${targetPath}/${metas.assz_unfc_id}${ext}`;
            // 추가정보메타 원장 처리
            try {
              metas = await addInfoMetaOrginProcess(metas);
              failCnt++;
            } catch (error) {
              writeLog(error);
              failCnt++;
            }
          }
        }

        // 추가정보메타로그 저장
        await addInfoMetaLogDbInsert(metas);

        // 원장이 존재하지 않을 경우
      } else {
        writeLog(
          `추가정보메타의 원천식별ID가 원장의 원천식별ID와 매칭되지 않음 ${metas.assz_cfbo_idnt_id}`
        );
        failCnt++;
        continue;
      }
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "addInfoMetaProcess"
  );
  writeLog(
    "------------------ addInfoMetaProcess() 종료 ----------------------------"
  );
}

// 확장자 체크
function isUseFile(fileName) {
  const USE_EXTS = new Set([
    ".hwp",
    ".hwpx",
    ".HWP",
    ".HWPX",
    ".doc",
    ".DOC",
    ".docx",
    ".DOCX",
    ".pdf",
    ".PDF",
    ".jpg",
    ".JPG",
    ".jpeg",
    ".JPEG",
    ".png",
    ".PNG",
    ".gif",
    ".GIF",
    ".bmp",
    ".BMP",
    ".tif",
    ".TIF",
    ".tiff",
    ".TIFF",
  ]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

/*------------------- 추가정보메타 원장 처리  ----------------------*/
async function addInfoMetaOrginProcess(metas) {
  // 확장자 체크 (자산화대상 아님 원장에는 저장)
  if (!isUseFile(metas.file_nm)) {
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
    metas.eror_vl = EROR_CODES.EROR_VL_NON_TARGET;
    metas.assz_eror_con = EROR_CODES.EROR_VL_NON_TARGET_STR;
    writeLog(`${metas.assz_eror_con}: ${metas.file_nm}`);
  }

  // 이미지매직 체크 (자산화대상 아님 원장에는 저장)
  if (path.extname(metas.assz_orgn_file_path_nm).toLowerCase() == ".pdf") {
    if (await isImageMagick(metas.assz_orgn_file_path_nm)) {
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      metas.eror_vl = EROR_CODES.EROR_VL_NON_TARGET;
      metas.assz_eror_con = EROR_CODES.EROR_VL_NON_TARGET_STR;
      writeLog(`${metas.assz_eror_con} ImageMagick: ${metas.file_nm}`);
    }
  }

  try {
    fs.accessSync(metas.assz_orgn_file_path_nm);
  } catch (err) {
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
    metas.eror_vl = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
    metas.assz_eror_con = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
    writeLog(
      `${EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR}: ${metas.assz_orgn_file_path_nm} ${err}`
    );
    await updateErorVl(metas.assz_unfc_id, metas.eror_vl, metas.assz_eror_con);
    // 파일복사 오류시 프로세스 종료
    process.exit(1);
    // throw new Error(`${metas.assz_eror_con}: ${metas.assz_orgn_file_path_nm} ${err}`);
  }

  // 파일 복사
  try {
    fs.copyFileSync(metas.assz_orgn_file_path_nm, metas.assz_pcsn_file_path_nm);
  } catch (err) {
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
    metas.eror_vl = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
    metas.assz_eror_con = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
    writeLog(
      `${EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR}: ${metas.file_nm} ${err}`
    );
    await updateErorVl(metas.assz_unfc_id, metas.eror_vl, metas.assz_eror_con);
    // 파일복사 오류시 프로세스 종료
    process.exit(1);
    // throw new Error(`${metas.assz_eror_con}: ${metas.file_nm} ${err}`);
  }

  // 파일정보 가져오기
  let fileInfo = null;
  try {
    fileInfo = await getFileInfo(metas.assz_pcsn_file_path_nm);
    metas.flsz_vl = fileInfo.size; // 파일 사이즈
    metas.assz_orgn_file_encp_rnnm_vl = fileInfo.md5; // 파일해시
  } catch (e) {
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
    metas.eror_vl = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND;
    metas.assz_eror_con = EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR;
    writeLog(`${metas.assz_eror_con} ${metas.assz_pcsn_file_path_nm}, ${e}`);
    await updateErorVl(metas.assz_unfc_id, metas.eror_vl, metas.assz_eror_con);
    throw new Error(
      `${metas.assz_eror_con} ${metas.assz_pcsn_file_path_nm}, ${e}`
    );
  }

  // 저장일 경우
  if (metas.assz_orgn_pcsn_dcd == "C") {
    // 메인메타저장 처리
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_INIT;
    await addInfoMetaDbInsert(metas);

    // 수정일 경우
  } else if (metas.assz_orgn_pcsn_dcd == "U") {
    // 메인메타 수정 처리
    metas.assz_scd = COMMON_CODES.ASSZ_SCD_INIT;
    await addInfoMetaDbUpdate(metas);

    // 삭제일 경우
  } else if (metas.assz_orgn_pcsn_dcd == "D") {
    // 원본없는 삭제일 경우엔 에러코드로 추가처리
    if (metas.eror_vl == EROR_CODES.EROR_VL_UNSUCCESS) {
      // 메인메타 저장 처리
      metas.assz_scd = COMMON_CODES.ASSZ_SCD_EXCEPTION;
      await addInfoMetaDbInsert(metas);
    }
  }

  return metas;
}

/*------------------- 추가정보메타 저장 처리  ----------------------*/
async function addInfoMetaDbInsert(metas) {
  // 원장마스터 인서트
  await insertLdgrMaster(
    null,
    metas.assz_unfc_id,
    metas.assz_scd,
    `${metas.assz_cfbo_idnt_id}_${metas.atch_key_vl}`, // 자산화원천식별ID
    metas.apnd_file_rgsn_ts, // 첨부파일등록일시
    COMMON_CODES.DEFAULT_NULL_DATE, // 수정일시
    metas.assz_orgn_pcsn_dcd,
    metas.eror_vl,
    metas.assz_eror_con,
    "", // assz_pcsn_file_path_nm 초기시 빈값,
    metas.flsz_vl, // 파일 사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    metas.assz_btch_acmp_id,
    metas.uda_sys_lsmd_id
  );

  // 원장메타 저장
  await dbMetaMain.insertMeta(
    metas.assz_unfc_id, // 자산화통합ID
    metas.assz_cfbo_idnt_id, // 자산화원천식별ID
    "", // 자산화구성ID
    "", // 자산화부제ID
    "", // 자산화부제내용
    "", // URL주소
    "", // 질문ID
    "", // 자산화질문내용
    "", // 답변ID
    "", // 자산화답변내용
    "", // 원천데이터등록자ID
    COMMON_CODES.DEFAULT_NULL_DATE, // 등록일시
    COMMON_CODES.DEFAULT_NULL_DATE, // 수정일시
    metas.assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
    "", // 자산화문서분류ID
    "", // 콘텐츠제목명
    "", // 탭명
    "", // 부제목명
    "", // 파일여부
    metas.file_nm, // 파일명
    metas.atch_key_vl, // 첨부파일KEY값
    metas.apnd_file_rgsn_ts, // 첨부파일등록일시
    metas.atch_yn, // 첨부파일여부
    metas.atch_sqn, // 첨부파일순번
    metas.atch_nm, // 첨부파일명
    metas.assz_orcp_file_path_nm, // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
    metas.uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
  );
}

/*------------------- 추가정보메타 수정 처리 ----------------------*/
async function addInfoMetaDbUpdate(metas) {
  // 원장마스터 수정
  await updateOriginMaster(
    metas.assz_unfc_id,
    metas.assz_btch_acmp_id,
    metas.assz_scd,
    metas.flsz_vl, // 파일사이즈
    metas.assz_orgn_file_encp_rnnm_vl, // 파일해시
    "", // 자산화처리파일 경로명
    metas.eror_vl,
    metas.assz_eror_con
  );

  // 원장메타 수정 (추가정보메타의 첨부파일은 수정일자 없음)
  await dbMetaMain.updateAddInfoMeta(
    metas.assz_unfc_id,
    metas.file_nm, // 파일명
    metas.atch_key_vl, // 첨부파일KEY값
    metas.apnd_file_rgsn_ts, // 첨부파일등록일시
    metas.atch_yn, // 첨부파일여부
    metas.atch_sqn, // 첨부파일순번
    metas.atch_nm, // 첨부파일명
    metas.assz_orcp_file_path_nm // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
  );
}

/*------------------- 추가정보메타로그 저장  ----------------------*/
async function addInfoMetaLogDbInsert(metas) {
  await dbMetaMain.insertMetaLog(
    metas.assz_btch_acmp_id, // 자산화배치수행ID
    metas.assz_cfbo_idnt_id, // 자산화원천식별ID
    metas.assz_unfc_id, // 자산화통합ID
    "", // 자산화구성ID
    "", // 자산화부제ID
    "", // 자산화부제내용
    "", // URL주소
    "", // 질문ID
    "", // 자산화질문내용
    "", // 답변ID
    "", // 자산화답변내용
    "", // 원천데이터등록자ID
    COMMON_CODES.DEFAULT_NULL_DATE, // 등록일시
    COMMON_CODES.DEFAULT_NULL_DATE, // 수정일시
    metas.assz_orgn_pcsn_dcd, // 자산화원천처리구분코드
    "", // 자산화문서분류ID
    "", // 콘텐츠제목명
    "", // 탭명
    "", // 부제목명
    "", // 파일여부
    metas.file_nm, // 파일명
    metas.atch_key_vl, // 첨부파일KEY값
    metas.apnd_file_rgsn_ts, // 첨부파일등록일시
    metas.atch_yn, // 첨부파일여부
    metas.atch_sqn, // 첨부파일순번
    metas.atch_nm, // 첨부파일명
    metas.assz_orcp_file_path_nm, // 자산화원본파일경로명 (메타피일에 경로가 없어서 자산화경로 저장)
    metas.uda_sys_lsmd_id // 비정형데이터자산화시스템최종변경ID
  );
}

/*------------------ 이미지 복사 ----------------------------*/
async function imgCopy(assz_btch_acmp_id) {
  writeLog("------------------ imgCopy() 시작 ----------------------------");

  //원본및 대상 디렉토리 경로
  const sourceDir = `/data/bdpetl/recv/aik/kms/${basDt}/img`;
  const destDir = `/data/asset/aik/kms/img`;

  // 파일읽기
  let files;
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  try {
    files = fs.readdirSync(sourceDir);
  } catch (err) {
    writeLog(`파일읽기에러: ${err}`);
    return;
  }

  //파일복사
  for (const file of files) {
    totalCnt++;
    const srcPath = path.join(sourceDir, file);
    const destPath = path.join(destDir, file);
    try {
      fs.copyFileSync(srcPath, destPath);
      writeLog(`이미지 파일 이동 성공: ${file}`);
      successCnt++;
    } catch (err) {
      writeLog(`이미지 파일 이동 실패: ${file} , ${err}`);
      failCnt++;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "imgCopy");
  writeLog("------------------ imgCopy() 종료 ----------------------------");
}

/*------------------- HTML IMG경로 변경 ----------------------*/
async function htmlImgPathChange(assz_btch_acmp_id) {
  writeLog(
    "------------------ htmlImgPathChange() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 메인메타 성공(HTML생성된 것만) 조회
  const metaData = await dbMetaMain.selectMetaSuccess(assz_btch_acmp_id);
  for (const meta of metaData.rows) {
    let htmlContent = "";
    totalCnt++;

    // 파일 읽어오기
    try {
      htmlContent = fs.readFileSync(meta.assz_orcp_file_path_nm, "utf8");
    } catch (err) {
      writeLog(
        `${EROR_CODES.EROR_VL_READ_FILE_FAILED_STR} ${meta.assz_orcp_file_path_nm} ${err}`
      );
      failCnt++;
      continue;
    }

    // 이미지 경로 수정
    try {
      const htmlUpdateContent = htmlContent.replace(
        /<img\s+[^>]*src=["']([^"']+)["'][^>]*>/gi,
        (match, srcPath) => {
          const fileName = path.basename(srcPath);
          const newSrc = `/data/asset/aik/kms/img/${fileName}`;
          return match.replace(srcPath, newSrc);
        }
      );

      fs.writeFileSync(meta.assz_orcp_file_path_nm, htmlUpdateContent, "utf-8");
      writeLog(`${meta.assz_orcp_file_path_nm} 이미지 경로 수정 완료`);
      successCnt++;
    } catch (err) {
      writeLog(
        `${EROR_CODES.EROR_VL_HTML_IMG_FAILED_STR} ${meta.assz_orcp_file_path_nm} ${err}`
      );
      failCnt++;
      continue;
    }
  }

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "htmlImgPathChange"
  );
  writeLog(
    "------------------ htmlImgPathChange() 종료 ----------------------------"
  );
}

/*---------------------- HTML TO PDF (02생성) ----------------------*/
async function htmltoPdf(assz_btch_acmp_id) {
  writeLog(
    "----------------------------htmltoPdf()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 메인메타 성공(HTML생성된 것만) 조회
  const metaData = await dbMetaMain.selectMetaSuccess(assz_btch_acmp_id);
  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_cfbo_idnt_id,
      assz_unfc_id,
      assz_orcp_file_path_nm,
    } = rowMetaData;

    const oriFileName = path.basename(assz_orcp_file_path_nm);
    const chgFileName = oriFileName.replace(".html", ".pdf");
    const chgFilePath = `/data/asset/aik/kms/${basDt}/pdf/${chgFileName}`;
    const chgOriginFilePath = `/data/asset/aik/kms/${basDt}/originpdf/${chgFileName}`;

    // 테스트일 경우
    let pythonPath = "python";
    if (pcsnClCd.includes("test")) {
      pythonPath = `/app/anaconda3/bin/python3`;
    }

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const command = `${pythonPath} /app/htmltopdf/htmltopdf.py "${assz_orcp_file_path_nm}" "/data/asset/aik/kms/${basDt}/pdf/${chgFileName}"`;
    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      assz_cfbo_idnt_id: assz_cfbo_idnt_id,
      chgFilePath: chgFilePath,
      chgOriginFilePath: chgOriginFilePath,
      assz_orcp_file_path_nm: assz_orcp_file_path_nm,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    totalCnt++;

    if (result.success) {
      try {
        // 성공된 파일 복사(라인그리기 전 원본PDF로 복사)
        fs.copyFileSync(result.chgFilePath, result.chgOriginFilePath);

        const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
        await dbAssetLog.insertLog(
          result.assz_btch_acmp_id,
          result.assz_unfc_id,
          result.assz_cfbo_idnt_id,
          "N", // html파일은 자기 자신이 원본
          "ML", // HTML
          "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
          "C", //C 신규 U 수정 D삭제
          "N", //이미지처리여부
          null,
          null,
          null,
          "CH", //CH변환 , NO(NONE)
          null,
          null,
          null,
          "SI", // CH	변환 SI	단일문서
          result.staDate, //원본변환시작일시
          endDate, //원본변환종료일시
          result.chgFilePath,
          result.errCd, //에러 0000
          result.errStr,
          "UDAIEADASSETR001"
        );

        successCnt++;
      } catch (err) {
        result.errCd = EROR_CODES.EROR_VL_COPY_FAILED;
        result.errStr = EROR_CODES.EROR_VL_COPY_FAILED_STR;
        await updateErorVl(
          result.assz_unfc_id,
          result.errCd,
          `${result.errStr} ${result.chgOriginFilePath} ${err}`
        );
        writeLog(`${result.errStr} ${result.chgOriginFilePath} ${err}`);
        failCnt++;
        continue;
      }
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.error);
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "htmltoPdf");
  writeLog(
    "----------------------------htmltoPdf()종료----------------------------"
  );
}

// HTML TO PDF
async function htp(data) {
  return await new Promise((resolve, reject) => {
    exec(data.command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${error}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stderr}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_MLTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stdout}`,
          errCd: EROR_CODES.EROR_VL_MLTP_FAILED,
          errStr: EROR_CODES.EROR_VL_MLTP_FAILED_STR,
          ...data,
        });
      } else {
        writeLog(`htmltoPdf 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*---------------------- DRM 해제 ----------------------*/
async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock() 시작----------------------------"
  );

  const dirs = ["origin", "att"]; // DRM 해제할 디렉토리 목록
  let result = "";

  for (const dir of dirs) {
    const fullPath = `/data/asset/aik/kms/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`DRM 오류 : ${fullPath} ${err}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock() 종료----------------------------"
  );
}

/*------------------- 라인그리기 ----------------------*/
async function drawLine(assz_btch_acmp_id) {
  writeLog(
    "---------------------------- drawline() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 추가정보메타 성공 조회
  const metaData = await dbMetaMain.selectAddInfoMetaSuccess(assz_btch_acmp_id);
  for (const meta of metaData.rows) {
    if (
      meta.atch_sqn == "" ||
      meta.atch_sqn == null ||
      meta.atch_sqn == "null"
    ) {
      meta.atch_sqn = 0;
    }
    if (
      meta.atch_sqn == "" ||
      meta.atch_sqn == null ||
      meta.atch_sqn == "null"
    ) {
      meta.atch_sqn = 0;
    }

    if (
      meta.assz_cfbo_idnt_id == "" ||
      meta.assz_cfbo_idnt_id == undefined ||
      meta.assz_cfbo_idnt_id == null ||
      !(
        path.extname(meta.file_nm).toLowerCase() === ".hwp" ||
        path.extname(meta.file_nm).toLowerCase() === ".hwpx" ||
        // path.extname(meta.file_nm).toLowerCase() === ".doc" || 지원하지 않은 확장자
        path.extname(meta.file_nm).toLowerCase() === ".docx"
      )
    ) {
      writeLog(`Drawline 대상아님: ${meta.file_nm}`);
      continue;
    } else {
      // 파일명, 경로 설정
      const ext = path.extname(meta.file_nm).toLowerCase();
      const dirGb = meta.atch_yn === "N" ? "origin" : "att"; //디렉토리구분
      const chgFullPath = `/data/asset/aik/kms/${basDt}/${dirGb}/${meta.assz_unfc_id}${ext}`;

      if (fs.existsSync(chgFullPath)) {
        fs.copyFileSync(chgFullPath, `${chgFullPath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${chgFullPath}${ext}" "${chgFullPath}" 10`;
      commands.push({
        command: command,
        chgFullPath: chgFullPath,
        ext: ext,
        assz_unfc_id: meta.assz_unfc_id,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => dl(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
      writeLog(`Drawline 성공 ${result.chgFullPath}`);
    } else {
      let errCd = EROR_CODES.EROR_VL_DRAWLINE_FAILED;
      let errStr = EROR_CODES.EROR_VL_DRAWLINE_FAILED_STR;
      await updateErorVl(
        result.assz_unfc_id,
        errCd,
        `${errStr}: ${result.chgFullPath}, ${result.error}`
      );
      writeLog(`${errStr}: ${result.chgFullPath}, ${result.error}`);
      failCnt++;
    }

    const tmpFilename = `${result.chgFullPath}${result.ext}`;

    if (fs.existsSync(tmpFilename)) {
      fs.unlinkSync(tmpFilename);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "drawline");
  writeLog(
    "---------------------------- drawline() 종료 ----------------------------"
  );
}

// 라인그리기
async function dl(data) {
  return await new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          chgFullPath: data.chgFullPath,
          ext: data.ext,
          error: error,
        });
      }
      if (stderr) {
        if (!stderr.includes("Log4j")) {
          resolve({
            success: false,
            chgFullPath: data.chgFullPath,
            ext: data.ext,
            error: stderr,
          });
        }
      }
      resolve({
        success: true,
        chgFullPath: data.chgFullPath,
        ext: data.ext,
      });
    });
  });
}

/*---------------------- FILE TO PDF (02생성) ----------------------*/
async function filetoPdf(assz_btch_acmp_id, folerType = "pdf") {
  writeLog(
    `----------------------------filetoPdf(${folerType}) 시작----------------------------`
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  // 추가정보메타 성공 조회
  const metaData = await dbMetaMain.selectAddInfoMetaSuccess(assz_btch_acmp_id);
  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_cfbo_idnt_id,
      assz_unfc_id,
      file_nm,
      atch_yn,
    } = rowMetaData;

    // 파일명, 경로 설정
    const ext = path.extname(file_nm).toLowerCase();
    const dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분
    const assz_orcp_file_path_nm = `/data/asset/aik/kms/${basDt}/${dirGb}/${assz_unfc_id}${ext}`;
    const oriFileName = path.basename(assz_orcp_file_path_nm);

    let chgFileName = "";

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx" ||
      path.extname(oriFileName).toLowerCase() === ".jpg" ||
      path.extname(oriFileName).toLowerCase() === ".jpeg" ||
      path.extname(oriFileName).toLowerCase() === ".png" ||
      path.extname(oriFileName).toLowerCase() === ".gif" ||
      path.extname(oriFileName).toLowerCase() === ".bmp" ||
      path.extname(oriFileName).toLowerCase() === ".tif" ||
      path.extname(oriFileName).toLowerCase() === ".tiff"
    ) {
      chgFileName = oriFileName.replace(path.extname(oriFileName), ".pdf");
    } else {
      chgFileName = oriFileName;
    }
    const chgFilePath = `/data/asset/aik/kms/${basDt}/${folerType}/${chgFileName}`;

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx"
    ) {
      // 테스트일 경우
      let pythonPath = "python";
      if (pcsnClCd.includes("test")) {
        pythonPath = `/app/anaconda3/bin/python3`;
      }
      const command = `${pythonPath} /app/hwp2pdfv2/hwp2pdf.py "${assz_orcp_file_path_nm}" "/data/asset/aik/kms/${basDt}/${folerType}"`;
      commands.push({
        command: command,
        staDate: staDate,
        astpCd: "HW",
        assz_btch_acmp_id: assz_btch_acmp_id,
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        atch_yn: atch_yn,
        chgFilePath: chgFilePath,
        assz_orcp_file_path_nm: assz_orcp_file_path_nm,
      });
    } else if (
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx"
    ) {
      // 테스트일 경우
      let pythonPath = "python";
      if (pcsnClCd.includes("test")) {
        pythonPath = `/app/anaconda3/bin/python3`;
      }
      const command = `${pythonPath} /app/hwp2pdfv2/hwp2pdf.py "${assz_orcp_file_path_nm}" "/data/asset/aik/kms/${basDt}/${folerType}"`;

      commands.push({
        command: command,
        staDate: staDate,
        astpCd: "DO",
        assz_btch_acmp_id: assz_btch_acmp_id,
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        atch_yn: atch_yn,
        chgFilePath: chgFilePath,
        assz_orcp_file_path_nm: assz_orcp_file_path_nm,
      });
    } else if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      commands.push({
        command: null,
        staDate: staDate,
        astpCd: "PD",
        assz_btch_acmp_id: assz_btch_acmp_id,
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        atch_yn: atch_yn,
        chgFilePath: chgFilePath,
        assz_orcp_file_path_nm: assz_orcp_file_path_nm,
      });
    } else if (
      path.extname(oriFileName).toLowerCase() === ".jpg" ||
      path.extname(oriFileName).toLowerCase() === ".jpeg" ||
      path.extname(oriFileName).toLowerCase() === ".png" ||
      path.extname(oriFileName).toLowerCase() === ".gif" ||
      path.extname(oriFileName).toLowerCase() === ".bmp" ||
      path.extname(oriFileName).toLowerCase() === ".tif" ||
      path.extname(oriFileName).toLowerCase() === ".tiff"
    ) {
      // 테스트일 경우
      let pythonPath = "python";
      if (pcsnClCd.includes("test")) {
        pythonPath = `/app/anaconda3/bin/python3`;
      }
      const command = `${pythonPath} /app/hwp2pdfv2/hwp2pdf.py "${assz_orcp_file_path_nm}" "/data/asset/aik/kms/${basDt}/${folerType}"`;

      commands.push({
        command: command,
        staDate: staDate,
        astpCd: "IM",
        assz_btch_acmp_id: assz_btch_acmp_id,
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        atch_yn: atch_yn,
        chgFilePath: chgFilePath,
        assz_orcp_file_path_nm: assz_orcp_file_path_nm,
      });
    }
  }

  const tasks = commands.map((data, idx) => limit(() => ftp(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      if (folerType == "pdf") {
        const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

        await dbAssetLog.insertLog(
          result.assz_btch_acmp_id,
          result.assz_unfc_id,
          result.assz_cfbo_idnt_id,
          result.atch_yn,
          result.astpCd, // HW : HWP, PD : PDF, DO : DOC, IM : IMAGE
          "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
          "C", //C 신규 U 수정 D삭제
          "N", //이미지처리여부
          null,
          null,
          null,
          "CH", //CH변환 , NO(NONE)
          null,
          null,
          null,
          "SI", // CH	변환 SI	단일문서
          result.staDate, //원본변환시작일시
          endDate, //원본변환종료일시
          result.chgFilePath,
          result.errCd,
          result.errStr,
          "UDAIEADASSETR001"
        );
      }

      successCnt++;
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.error);
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "filetoPdf");
  writeLog(
    `----------------------------filetoPdf(${folerType}) 종료----------------------------`
  );
}

// FILE TO PDF
async function ftp(data) {
  return await new Promise((resolve, reject) => {
    // 한글, 워드, 이미지일 경우
    if (data.astpCd == "HW" || data.astpCd == "DO" || data.astpCd == "IM") {
      exec(data.command, (error, stdout, stderr) => {
        if (error) {
          resolve({
            success: false,
            error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${error}`,
            errCd: EROR_CODES.EROR_VL_HTP_FAILED,
            errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
            ...data,
          });
        }
        if (stderr) {
          resolve({
            success: false,
            error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stderr}`,
            errCd: EROR_CODES.EROR_VL_HTP_FAILED,
            errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
            ...data,
          });
        }
        if (stdout.includes("[Success]")) {
          resolve({
            success: true,
            errCd: EROR_CODES.EROR_VL_SUCCESS,
            errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
            ...data,
          });
        } else if (stdout.includes(`[Fail]`)) {
          resolve({
            success: false,
            error: `${EROR_CODES.EROR_VL_HTP_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stdout}`,
            errCd: EROR_CODES.EROR_VL_HTP_FAILED,
            errStr: EROR_CODES.EROR_VL_HTP_FAILED_STR,
            ...data,
          });
        } else {
          writeLog(`filetoPdf 결과미확인: ${data.assz_orcp_file_path_nm}`);
          reject(new Error(`stdout에서 성공/실패 정보 없음`));
        }
      });

      // PDF일 경우
    } else if (data.astpCd == "PD") {
      try {
        fs.copyFileSync(data.assz_orcp_file_path_nm, data.chgFilePath);

        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } catch (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_COPY_FAILED_STR} ${data.assz_pcsn_file_path_nm} ${error}`,
          errCd: EROR_CODES.EROR_VL_COPY_FAILED,
          errStr: EROR_CODES.EROR_VL_COPY_FAILED_STR,
          ...data,
        });
      }
    }
  });
}

/*---------------------- PDF TO IMG 추출 (02->03변경) ----------------------*/
async function pdftoImg(assz_btch_acmp_id) {
  writeLog(
    "---------------------------- pdftoImg() 시작 ----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  const imagepdfFolder = `/data/asset/aik/kms/${basDt}/pdf`;
  const outFolder = `/data/asset/aik/kms/${basDt}/dp`;

  // UDA자산화처리로그, 추기정보메타 조회
  const logData = await dbAssetLog.selectLogKms(
    assz_btch_acmp_id,
    "02",
    EROR_CODES.EROR_VL_SUCCESS,
    "file"
  );
  for (const ld of logData.rows) {
    try {
      fs.mkdirSync(`${outFolder}/${ld.year}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${outFolder}/${ld.year}`);
    }

    // PDF일 경우
    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);

    if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      // 테스트일 경우
      let pythonPath = "python";
      if (pcsnClCd.includes("test")) {
        pythonPath = `/app/anaconda3/bin/python3`;
      }
      let command = `${pythonPath} /app/pdftoimg/pdftoimg.py "${imagepdfFolder}/${oriFileName}" "${outFolder}/${ld.year}" "${ld.assz_btch_acmp_id}" "${ld.assz_unfc_id}" "${ld.uda_sys_lsmd_id}"`;
      commands.push({
        assz_btch_acmp_id: ld.assz_btch_acmp_id,
        assz_unfc_id: ld.assz_unfc_id,
        fileName: `${imagepdfFolder}/${oriFileName}`,
        header: ld,
        command: command,
        staDate: staDate,
      });
    }
  }

  // PDF->IMG 추출 모듈 실행
  const tasks = commands.map((data, idx) => limit(() => pti(data)));
  for await (const result of tasks) {
    let errCd = EROR_CODES.EROR_VL_SUCCESS;
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

    totalCnt++;

    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    if (result.success) {
      errCd = EROR_CODES.EROR_VL_SUCCESS;
      errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

      await dbAssetLog.updateLog(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "03",
        null,
        null,
        null,
        null,
        null,
        result.staDate, //변환시작일시
        endDate, //변환종료일시
        null,
        null,
        null,
        null,
        null,
        errCd,
        errStr
      );
      successCnt++;
    } else {
      errCd = EROR_CODES.EROR_VL_IMG_FAILED;
      errStr = EROR_CODES.EROR_VL_IMG_FAILED_STR;
      await updateErorVl(
        result.assz_unfc_id,
        errCd,
        `${errStr}: ${result.fileName}, ${result.error}`
      );
      await dbAssetLog.updateLog(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "02",
        null,
        null,
        null,
        null,
        null,
        result.staDate, //변환시작일시
        endDate, //변환종료일시
        result.txtOutFullPath,
        null,
        null,
        null,
        null,
        errCd,
        `${errStr}: ${result.fileName}, ${result.error}`
      );
      writeLog(`${errStr}: ${result.fileName}, ${result.error}`);
      failCnt++;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoImg");
  writeLog(
    "---------------------------- pdftoImg() 종료 ----------------------------"
  );
}

// PDF TO IMG 추출
async function pti(data) {
  return new Promise((resolve, reject) => {
    const command = data.command;
    exec(command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: error,
          fileName: data.fileName,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: stderr,
          fileName: data.fileName,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
          fileName: data.fileName,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
          error: stdout,
          fileName: data.fileName,
        });
      } else {
        writeLog(`pdftoImg 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*---------------------- PDF TO TEXT 추출 (03->04변경) ----------------------*/
async function pdftoText(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  const outputDir = `/data/asset/aik/kms/${basDt}/txt`;

  // UDA자산화처리로그, 추기정보메타 조회
  const logData = await dbAssetLog.selectLogKms(
    assz_btch_acmp_id,
    "03",
    EROR_CODES.EROR_VL_SUCCESS,
    "file"
  );
  for (const rowLogData of logData.rows) {
    const { assz_btch_acmp_id, assz_unfc_id, assz_orcp_file_path_nm, year } =
      rowLogData;

    const oriFileName = path.basename(assz_orcp_file_path_nm);

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    //const pdfFilePath = path.join(targetDir, file);
    const txtFileName = oriFileName.replace(/\.pdf$/i, ".txt"); // 확장자변경 (대소문자 포함)
    const txtOutFullPath = `${outputDir}/${year}/${txtFileName}`; //확장자변경

    try {
      fs.mkdirSync(`${outputDir}/${year}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${outputDir}/${year}`);
    }

    // 테스트일 경우
    let pythonPath = "python";
    if (pcsnClCd.includes("test")) {
      pythonPath = `/app/anaconda3/bin/python3`;
    }
    const command = `${pythonPath} /app/pdftotxt/pdftotxt.py "${assz_orcp_file_path_nm}" "${txtOutFullPath}"`;

    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      txtOutFullPath: txtOutFullPath,
      assz_orcp_file_path_nm: assz_orcp_file_path_nm,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => ptt(data)));

  for await (const result of tasks) {
    totalCnt++;
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    if (result.success) {
      await dbAssetLog.updateLog(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "04",
        null,
        null,
        null,
        null,
        null,
        result.staDate, //변환시작일시
        endDate, //변환종료일시
        result.txtOutFullPath,
        null,
        null,
        null,
        null,
        result.errCd,
        result.errStr
      );
      successCnt++;
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.error);
      await dbAssetLog.updateLog(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "03",
        null,
        null,
        null,
        null,
        null,
        result.staDate, //변환시작일시
        endDate, //변환종료일시
        result.txtOutFullPath,
        null,
        null,
        null,
        null,
        result.errCd,
        result.errStr
      );
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

// PDF TO TEXT 추출
async function ptt(data) {
  return await new Promise((resolve, reject) => {
    exec(data.command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_PTT_FAILED_STR} ${data.assz_orcp_file_path_nm} ${error}`,
          errCd: EROR_CODES.EROR_VL_PTT_FAILED,
          errStr: EROR_CODES.EROR_VL_PTT_FAILED_STR,
          ...data,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_PTT_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stderr}`,
          errCd: EROR_CODES.EROR_VL_PTT_FAILED,
          errStr: EROR_CODES.EROR_VL_PTT_FAILED_STR,
          ...data,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_PTT_FAILED_STR} ${data.assz_orcp_file_path_nm} ${stdout}`,
          errCd: EROR_CODES.EROR_VL_PTT_FAILED,
          errStr: EROR_CODES.EROR_VL_PTT_FAILED_STR,
          ...data,
        });
      } else {
        writeLog(`pdftoText 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*---------------------- HTML TO JSON (02->04변경, 022M 결과생성) ----------------------*/
async function htmltoJson(assz_btch_acmp_id) {
  writeLog(
    "----------------------------htmltoJson()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(50);
  const commands = [];

  const targetDir = `/data/asset/aik/kms/${basDt}/origin`;
  const outputDir = `/data/asset/aik/kms/${basDt}/json`;

  // UDA자산화처리로그, 메인메타 조회
  const logData = await dbAssetLog.selectLogKms(
    assz_btch_acmp_id,
    "02",
    EROR_CODES.EROR_VL_SUCCESS,
    "html"
  );
  for (const rowLogData of logData.rows) {
    const {
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_cfbo_idnt_id, // 자산화원천별식별ID(콘텐츠ID)
      assz_pcsn_tgt_tcd,
      assz_pcsn_tcd,
      assz_orcp_file_path_nm,
      assz_orcp_unfc_id, // 소제목명
      url_adr, // URL주소
      sb_ttl_nm, // 소제목명
      rgsn_ts, // 등록일시
      amnn_ts, // 수정일시
      uda_sys_lsmd_id,
    } = rowLogData;

    const baseName = path.basename(assz_orcp_file_path_nm);
    const oriFileName = `${baseName.replace(/\.[^/.]+$/, "")}.html`;
    const jsonFileName = oriFileName.replace(".html", ".json"); //확장자변경
    const jsonOutFullPath = `${outputDir}/${jsonFileName}`; //확장자변경

    const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    const command = `node /app/htmltojson/htmltojson.js "${targetDir}/${oriFileName}" "${jsonOutFullPath}"`;

    commands.push({
      command: command,
      staDate: staDate,
      assz_btch_acmp_id: assz_btch_acmp_id,
      assz_unfc_id: assz_unfc_id,
      assz_cfbo_idnt_id: assz_cfbo_idnt_id,
      sb_ttl_nm: sb_ttl_nm,
      jsonFileName: jsonFileName,
      assz_pcsn_tgt_tcd: assz_pcsn_tgt_tcd,
      assz_pcsn_tcd: assz_pcsn_tcd,
      assz_orcp_unfc_id: assz_orcp_unfc_id,
      jsonOutFullPath: jsonOutFullPath,
      url_adr: url_adr,
      rgsn_ts: rgsn_ts,
      amnn_ts: amnn_ts,
      uda_sys_lsmd_id: uda_sys_lsmd_id,
      assz_orcp_file_path_nm: assz_orcp_file_path_nm,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => htj(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      await dbAssetLog.updateLog(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "04",
        null,
        null,
        null,
        null,
        null,
        result.startDate, //변환시작일시
        endDate, //변환종료일시
        result.jsonOutFullPath,
        null,
        null,
        null,
        null,
        result.errCd,
        result.errStr
      );

      const fileStat = fs.statSync(result.assz_orcp_file_path_nm);
      const fileSize = Math.floor(fileStat.size / 1024);

      // 성공 로그 insert
      await dbAssetRlt.insertAst(
        result.assz_btch_acmp_id,
        result.assz_unfc_id,
        "AIKKMS",
        result.assz_cfbo_idnt_id,
        result.sb_ttl_nm,
        result.jsonFileName,
        result.assz_pcsn_tgt_tcd,
        result.assz_pcsn_tcd,
        fileSize,
        "ML",
        null,
        null,
        result.jsonOutFullPath,
        result.url_adr,
        result.rgsn_ts,
        result.amnn_ts,
        result.startDate,
        endDate,
        "N",
        null,
        result.uda_sys_lsmd_id,
        result.errCd,
        result.errStr
      );

      successCnt++;
    } else {
      await updateErorVl(result.assz_unfc_id, result.errCd, result.error);
      writeLog(result.error);
      failCnt++;
      continue;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "htmltoJson");
  writeLog(
    "----------------------------htmltoJson()종료----------------------------"
  );
}

// HTML TO JSON 추출
async function htj(data) {
  return await new Promise((resolve, reject) => {
    exec(data.command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_JSON_FAILED_STR} ${data.assz_pcsn_file_path_nm} ${error}`,
          errCd: EROR_CODES.EROR_VL_JSON_FAILED,
          errStr: EROR_CODES.EROR_VL_JSON_FAILED_STR,
          ...data,
        });
      }
      if (stderr) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_JSON_FAILED_STR} ${data.assz_pcsn_file_path_nm} ${stderr}`,
          errCd: EROR_CODES.EROR_VL_JSON_FAILED,
          errStr: EROR_CODES.EROR_VL_JSON_FAILED_STR,
          ...data,
        });
      }
      if (stdout.includes("[Success]")) {
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          ...data,
        });
      } else if (stdout.includes(`[Fail]`)) {
        resolve({
          success: false,
          error: `${EROR_CODES.EROR_VL_JSON_FAILED_STR} ${data.assz_pcsn_file_path_nm} ${stdout}`,
          errCd: EROR_CODES.EROR_VL_JSON_FAILED,
          errStr: EROR_CODES.EROR_VL_JSON_FAILED_STR,
          ...data,
        });
      } else {
        writeLog(`htmltojson 결과미확인: ${data.assz_pcsn_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------  JSON 병합 (FILEJSON, IMGJSON 병합) ----------------------*/
async function jsonMerge(assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const oriJsonFiles = await dbAssetRlt.selectFilePathNm(assz_btch_acmp_id);
  for (const oriJsonFile of oriJsonFiles.rows) {
    const imgJsonFiles = await dbImgRlt.selectFilePathNm(
      assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id
    );
    const imgJsonList = imgJsonFiles.rows.map(
      (row) => row.assz_pcsn_file_path_nm
    );

    totalCnt++;

    let errCd = EROR_CODES.EROR_VL_SUCCESS;
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
    try {
      mergeJsonFiles(oriJsonFile.file_path, imgJsonList);
      writeLog(`jsonMerge 변환 성공!!!: ${oriJsonFile.file_path}`);
      successCnt++;
    } catch (err) {
      errCd = EROR_CODES.EROR_VL_JSON_MERGE_FAILED;
      errStr = `${EROR_CODES.EROR_VL_JSON_MERGE_FAILED_STR} ${oriJsonFile.assz_unfc_id} ${oriJsonFile.file_path} ${err}`;
      updateErorVl(oriJsonFile.assz_unfc_id, errCd, errStr);
      writeLog(errStr);
      await dbAssetLog.updateLogErr04(
        assz_btch_acmp_id,
        oriJsonFile.assz_unfc_id,
        errCd,
        errStr
      );
      failCnt++;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jsonMerge");
  writeLog(
    "----------------------------jsonMerge()종료----------------------------"
  );
}

/*---------------------- main 함수 ----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 지식샘(aikkms) 자산화 배치 시작 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    // --------- 전처리 작업 ---------
    let basePath = `/data/bdpetl/recv/aik/kms/${basDt}/`;
    // 서버간 수신 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "AIKKMS",
      "01", //01  수집 02 자산화 03 전송
      "02", //01  대기 02 수행 03 중단 04 오류 05 완료
      "T1", //T1 메타+파일 T2 DB T3 지식샘
      "01" //assz_tgt_sys_cd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/aik/kms/${basDt}/meta/master.dat`
    );
    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/kms", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    // --------- 메인 작업 ---------
    // 폴더 생성
    await makeDir();
    // 메인메타 처리
    await mainMetaProcess(assz_btch_acmp_id);
    // 추가정보메타 처리
    await addInfoMetaProcess(assz_btch_acmp_id);

    // 메인메타 HTML 처리
    // 이미지 복사
    await imgCopy(assz_btch_acmp_id);
    // HTML IMG경로 변경
    await htmlImgPathChange(assz_btch_acmp_id);
    // HTML TO PDF (02생성)
    await htmltoPdf(assz_btch_acmp_id);

    // 추가정보메타 파일 처리
    // DRM 해제
    await drmUnlock();
    // FILE TO PDF(라인그리기 전 원본PDF로 복사)
    await filetoPdf(assz_btch_acmp_id, "originpdf");
    // 라인그리기
    await drawLine(assz_btch_acmp_id);
    // FILE TO PDF (02생성)
    await filetoPdf(assz_btch_acmp_id);
    // PDF TO IMG 추출 (02->03변경)
    await pdftoImg(assz_btch_acmp_id);
    // PDF TO TEXT 추출 (03->04변경)
    await pdftoText(assz_btch_acmp_id);

    // IMG TO DP
    await util.imgToDp2(assz_btch_acmp_id, "aikkms", basDt);
    // jeff
    await util.runImgJeff(assz_btch_acmp_id, "aikkms", basDt);
    await util.runJeff2(assz_btch_acmp_id, "aikkms", basDt);

    // HTML TO JSON (02->04변경, 022M 결과생성)
    await htmltoJson(assz_btch_acmp_id);
    // JSON 병합(FILEJSON, IMGJSON 병합)
    await jsonMerge(assz_btch_acmp_id);

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/aik/kms", basDt);
    // 원장결과 재생성
    const successCodeIn = `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS},${EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS}`;
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "aikkms",
      basDt,
      successCodeIn
    );
    // 연도별로 학습데이터 파일복사 저장
    await util.moveToLearn("aikkms", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "aikkms",
      successCodeIn,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(assz_btch_acmp_id, "aikkms", successCodeIn);
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    // 초기이행용
    // 학습용데이터모음
    await util.moveToLearn("aikkms", null);
  } else if (pcsnClCd.includes("test")) {
    // --------- 전처리 작업 ---------
    let basePath = `/data/bdpetl/recv/aik/kms/${basDt}/`;
    // 서버간 수신 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "AIKKMS",
      "01", //01  수집 02 자산화 03 전송
      "02", //01  대기 02 수행 03 중단 04 오류 05 완료
      "T1", //T1 메타+파일 T2 DB T3 지식샘
      "01" //assz_tgt_sys_cd
    );
    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/aik/kms/${basDt}/meta/master.dat`
    );
    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/kms", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    // --------- 메인 작업 ---------
    // 폴더 생성
    await makeDir();
    // 메인메타 처리
    await mainMetaProcess(assz_btch_acmp_id);
    // 추가정보메타 처리
    await addInfoMetaProcess(assz_btch_acmp_id);

    // 메인메타 HTML 처리
    // 이미지 복사
    // await imgCopy(assz_btch_acmp_id);
    // HTML IMG경로 변경
    await htmlImgPathChange(assz_btch_acmp_id);
    // HTML TO PDF (02생성)
    await htmltoPdf(assz_btch_acmp_id);

    // 추가정보메타 파일 처리
    // DRM 해제
    await drmUnlock();
    // FILE TO PDF(라인그리기 전 원본PDF로 복사)
    await filetoPdf(assz_btch_acmp_id, "originpdf");
    // 라인그리기
    await drawLine(assz_btch_acmp_id);
    // FILE TO PDF (02생성)
    await filetoPdf(assz_btch_acmp_id);
    // PDF TO IMG 추출 (02->03변경)
    await pdftoImg(assz_btch_acmp_id);
    // PDF TO TEXT 추출 (03->04변경)
    await pdftoText(assz_btch_acmp_id);

    // IMG TO DP
    await util.imgToDp2(assz_btch_acmp_id, "aikkms", basDt);
    // jeff
    await util.runImgJeff(assz_btch_acmp_id, "aikkms", basDt);
    await util.runJeff2(assz_btch_acmp_id, "aikkms", basDt);

    // HTML TO JSON (02->04변경, 022M 결과생성)
    await htmltoJson(assz_btch_acmp_id);
    // JSON 병합(FILEJSON, IMGJSON 병합)
    await jsonMerge(assz_btch_acmp_id);

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/aik/kms", basDt);
    // 원장결과 재생성
    const successCodeIn = `${EROR_CODES.EROR_VL_SUCCESS},${EROR_CODES.EROR_VL_AIKKMS_SBTL_SUCESSS},${EROR_CODES.EROR_VL_AIKKMS_QNA_SUCESSS}`;
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "aikkms",
      basDt,
      successCodeIn
    );
    // 연도별로 학습데이터 파일복사 저장
    await util.moveToLearn("aikkms", assz_btch_acmp_id);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "aikkms",
      successCodeIn,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(assz_btch_acmp_id, "aikkms", successCodeIn);
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  }
  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  await dbAssetRlt.dbEnd();

  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃ 지식샘(aikkms) 자산화 배치 종료 ＃＃＃＃＃＃＃＃＃＃＃＃"
  );
  return true;
}

main();
