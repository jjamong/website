const fs = require("fs");
const path = require("path");
const dayjs = require("dayjs");

const util = require("../util");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈

const dbBatch = require("../sql/TB_UDA_UAI900M");
const dbMetaLdgr = require("../sql/TB_UDA_UAI007M");
const dbMetaMain = require("../sql/TB_UDA_UAI807L");
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일

const {
  updateFileInfo,
  updateBatchId,
  selectOneOch,
  updateErorVl,
  updateOriginMaster,
} = require("../sql/TB_UDA_UAI000M");

const {
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  getFileInfo,
  updateLdgrBatIdStatus,
  sync,
  finFileCheck,
  recvMetaFileCheck,
  moveAssetData,
  finFileCreate,
  ///////////////NEW/////////////////
  insertLdgrMaster,
  batchStart,
  getBatchId,
  mergeDocument,
  getSafeBaseDt,
} = require("./common");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const in_assz_btch_acmp_id = process.argv[4];
const { exec } = require("child_process");

const batchId = getBatchId(process.argv[1]);

if (pcsnClCd !== "01" && pcsnClCd !== "02") {
  writeLog("error node UDAOCHDASSETR001.js clcd(처리구분:01) YYYYMMDD");
}

async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );

  const dirs = ["origin"];
  let result = "";

  for (const dir of dirs) {
    const fullPath = `/data/asset/chb/och/${basDt}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
    } catch (err) {
      writeLog(`drm오류: ${fullPath}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

/*-------------------파일 copy.----------------------*/
async function fileCopy(assz_btch_acmp_id) {
  writeLog("------------------fileCopy()시작----------------------------");
  const masterInfo = fs.readFileSync(
    `/data/bdpetl/recv/chb/och/${basDt}/meta/MetaFile${basDt}.dat`,
    "utf-8"
  );
  const lines_m = masterInfo.split("\n");

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  // 자산화통합ID 마지막 seq 가져오기
  let result = await selectUnfcSeq(null, "CHBOCH");
  let idx = result.rows[0].idsqn;

  for (const line of lines_m) {
    if (line.trim() === "") continue;
    let [
      assz_cfbo_idnt_id,
      rgsr_id,
      rgsn_ts,
      amnn_ts,
      assz_dcmn_clsf_id,
      assz_chb_conn_url_adr,
    ] = line.split("^|");
    totalCnt++;

    if (
      assz_cfbo_idnt_id == "" ||
      assz_cfbo_idnt_id == undefined ||
      assz_cfbo_idnt_id == null
    ) {
      writeLog(
        `continue assz_cfbo_idnt_id == "" || assz_cfbo_idnt_id == undefined || assz_cfbo_idnt_id == null ${fileNm}`
      );
      failCnt++;
      continue;
    } else {
      let dirGb = "origin"; //디렉토리구분
      const filename = `/data/bdpetl/recv/chb/och/${basDt}/file/${assz_cfbo_idnt_id}.dat`;

      let assz_unfc_id = "";
      let fileInfo = "";

      // 원장등록시작
      let selectOne = await selectOneOch(assz_cfbo_idnt_id);

      if (selectOne.rowCount == 0) {
        // C 데이터
        assz_unfc_id = await getUnfcId("CHBOCH", ++idx);
        writeLog(`신규데이터 : ${assz_cfbo_idnt_id}`);

        await insertLdgrMaster(
          null,
          assz_unfc_id,
          COMMON_CODES.ASSZ_SCD_INIT,
          assz_cfbo_idnt_id,
          null,
          null,
          "C",
          EROR_CODES.EROR_VL_SUCCESS,
          EROR_CODES.EROR_VL_SUCCESS_STR,
          `/data/asset/chb/och/${basDt}/${dirGb}/${assz_unfc_id}.dat`, //assz_pcsn_file_path_nm,
          null,
          null,
          assz_btch_acmp_id,
          batchId
        );

        await dbMetaLdgr.insertLdgr(
          assz_unfc_id,
          assz_cfbo_idnt_id,
          rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_dcmn_clsf_id,
          assz_chb_conn_url_adr,
          "",
          "",
          "",
          "",
          batchId
        );
      } else {
        assz_unfc_id = selectOne.rows[0].assz_unfc_id;

        try {
          // 파일정보 가져오기
          const fileInfo = await getFileInfo(filename);

          if (fileInfo.md5 == selectOne.rows[0].assz_orgn_file_encp_rnnm_vl) {
            // 같은파일도 배치아이디는 업데이트
            await updateBatchId(assz_unfc_id, assz_btch_acmp_id);
          } else {
            // 원장마스터 수정
            await updateOriginMaster(
              assz_unfc_id,
              assz_btch_acmp_id,
              COMMON_CODES.ASSZ_SCD_SUCCESS,
              fileInfo.size, // 파일사이즈
              fileInfo.md5, // 파일해시
              "", // 자산화처리파일 경로명
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR
            );
            // 원장메타 수정
            await dbMetaLdgr.updateMeta(
              assz_unfc_id,
              assz_cfbo_idnt_id,
              rgsr_id,
              rgsn_ts,
              amnn_ts,
              assz_dcmn_clsf_id,
              assz_chb_conn_url_adr,
              batchId
            );
          }
        } catch (e) {
          failCnt++;
          writeLog(
            `${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filename}, ${e}`
          );
        }
      }

      try {
        fs.accessSync(filename);
      } catch (err) {
        writeLog(`파일없음: ${filename}`);
        process.exit(1);
      }

      try {
        fileInfo = await getFileInfo(filename);

        await updateFileInfo(assz_unfc_id, String(fileInfo.size), fileInfo.md5);
      } catch (e) {
        failCnt++;
        writeLog(
          `${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filename} , ${e}`
        );
      }

      const targetPath = `/data/asset/chb/och/${basDt}/${dirGb}`;
      const outfilename = `${targetPath}/${assz_unfc_id}.dat`;
      let assz_qstn_con = "";
      let assz_rply_con = "";

      try {
        fs.copyFileSync(filename, outfilename);
        const datFile = fs.readFileSync(outfilename, "utf-8").split("^|");
        assz_qstn_con = datFile[0];
        assz_rply_con = datFile[1];

        successCnt++;
      } catch (err) {
        failCnt++;
        writeLog(`파일copy실패: ${outfilename}`);
        process.exit(1);
      }

      await dbMetaMain.insertMeta(
        assz_btch_acmp_id,
        assz_unfc_id,
        assz_cfbo_idnt_id,
        rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_dcmn_clsf_id,
        assz_chb_conn_url_adr,
        "", //assz_chb_frtm_conn_url_adr
        "", //assz_chb_sctm_conn_url_adr
        "", //assz_chb_thtm_conn_url_adr
        "", //assz_chb_fotm_conn_url_adr
        outfilename, //assz_pcsn_file_path_nm
        batchId //hdlr_id
      );
      //writeLog(`copy 성공 ${outfilename}`);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "fileCopy");
  writeLog("------------------fileCopy()종료----------------------------");
}

async function makeJson(assz_btch_acmp_id) {
  writeLog(
    "----------------------------makeJson()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const metaData = await dbMetaMain.selectMeta(assz_btch_acmp_id);

  let datas = [];

  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_meta_pcsn_sqn,
      assz_cfbo_idnt_id,
      rgsn_ts,
      amnn_ts,
      assz_chb_conn_url_adr,
      assz_pcsn_file_path_nm,
      assz_dcmn_clsf_id,
      hdlr_id,
    } = rowMetaData;

    totalCnt++;

    writeLog(assz_pcsn_file_path_nm);

    if (assz_pcsn_file_path_nm) {
      const data = fs.readFileSync(assz_pcsn_file_path_nm, "utf8");

      const [q, a] = data.split("^|").map((s) => s.trim());

      datas.push({
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        q: q,
        a: a,
        assz_dcmn_clsf_id: assz_dcmn_clsf_id,
        assz_chb_conn_url_adr: assz_chb_conn_url_adr,
      });
      successCnt++;
    } else {
      failCnt++;
    }
  }

  if (datas.length > 0) {
    // const fileName = `UDA_OCH_GAI_${basDt}.json`;
    // const asszPath = `/data/asset/chb/och/${basDt}/json/${fileName}`;
    // const sendPath = `/data/bdpetl/send/gai/gai/och/${basDt}/${fileName}`;
    // fs.writeFileSync(asszPath, JSON.stringify(datas, null, 2), "utf8");
    // writeLog(`자산화파일 저장완료 ${asszPath}`);
    // fs.writeFileSync(sendPath, JSON.stringify(datas, null, 2), "utf8");
    // writeLog(`전송폴더 저장완료 ${sendPath}`);
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "makeJson");
  writeLog(
    "----------------------------makeJson()종료----------------------------"
  );
}

async function makeDir() {
  const dirs = [
    `/data/asset/chb/och/${basDt}/json`,
    `/data/asset/chb/och/${basDt}/origin`,
    `/data/asset/chb/och/${basDt}/pdf`,
    `/data/asset/chb/och/${basDt}/html`,
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

async function main() {
  writeLog(
    "----------------------------챗봇 batch 시작----------------------------"
  );

  if (pcsnClCd == "01") {
    let basePath = `/data/bdpetl/recv/chb/och/${basDt}/`;
    // 서버간 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath);

    //배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "CHBOCH",
      "01", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB T3 지식샘
      "01" //assz_trms_tgt_sys_dcd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/chb/och/${basDt}/meta/MetaFile${basDt}.dat`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/och", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }
    await makeDir();

    await fileCopy(assz_btch_acmp_id); //파일 원본 경로로 옮기고 DB INSERT
    await drmUnlock(); //DRM해제
    await makeJson(assz_btch_acmp_id);

    // --------- 후처리 작업 ---------
    // 원장 파일 동기화
    await moveAssetData("/data/asset/chb/och", basDt);
    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    await makeJson(in_assz_btch_acmp_id);

    // await pdfCreate(in_assz_btch_acmp_id); //파일 원본 경로로 옮기고 DB INSERT
    // await makeMeta(in_assz_btch_acmp_id);
    // await gaiFileCopy(in_assz_btch_acmp_id);
  }
  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  //await dbAssetRlt.dbEnd();
  writeLog(
    "----------------------------챗봇 batch 종료----------------------------"
  );
  return true;
}
main();
