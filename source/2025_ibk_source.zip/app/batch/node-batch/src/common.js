const { Pool } = require("pg");
const config = require("../config");
const dayjs = require("dayjs");
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { spawn, spawnSync } = require("child_process");

/**
 *  EROR_VL, ASSZ_EROR_CON 정의
 */
const EROR_CODES = {
  EROR_VL_SUCCESS: "0000",
  EROR_VL_SUCCESS_STR: "정상",
  EROR_VL_UNSUCCESS: "0001",
  EROR_VL_UNSUCCESS_STR: "원본 없는 삭제건",
  EROR_VL_UNSUCCESS2: "0002",
  EROR_VL_UNSUCCESS2_STR: "원본 없는 업데이트건",
  EROR_VL_MSUCCESS: "0003",
  EROR_VL_MSUCCESS_STR: "병합정상",
  EROR_VL_NOCHANGE_SUCCESS: "0004",
  EROR_VL_NOCHANGE_SUCCESS_STR: "변경없음정상",

  EROR_VL_AIKKMS_SBTL_SUCESSS: "0011",
  EROR_VL_AIKKMS_SBTL_SUCESSS_STR: "지식샘-소제목형",
  EROR_VL_AIKKMS_QNA_SUCESSS: "0012",
  EROR_VL_AIKKMS_QNA_SUCESSS_STR: "지식샘-질문답변형",
  EROR_VL_AIKKMS_ORGIN_SUCESSS: "0013",
  EROR_VL_AIKKMS_ORGIN_SUCESSS_STR: "지식샘-원본형",
  EROR_VL_AIKKMS_FULLURL_SUCESSS: "0014",
  EROR_VL_AIKKMS_FULLURL_SUCESSS_STR: "지식샘-FULLURL형",

  EROR_VL_NON_TARGET: "9999",
  EROR_VL_NON_TARGET_STR: "자산화대상아님",
  EROR_VL_META_FAILED: "9910",
  EROR_VL_META_FAILED_STR: "메타파일내용오류",

  EROR_VL_COPY_FILE_NOT_FOUND: "0110",
  EROR_VL_COPY_FILE_NOT_FOUND_STR: "파일없음",
  EROR_VL_COPY_FAILED: "0111",
  EROR_VL_COPY_FAILED_STR: "파일복사실패",
  EROR_VL_READ_FILE_FAILED: "0112",
  EROR_VL_READ_FILE_FAILED_STR: "파일읽기실패",
  EROR_VL_HTML_FAILED: "0120",
  EROR_VL_HTML_FAILED_STR: "HTML생성실패",
  EROR_VL_HTML_IMG_FAILED: "0121",
  EROR_VL_HTML_IMG_FAILED_STR: "HTML이미지변경생성실패",

  EROR_VL_FILEINFO_FAILED_STR: "파일정보읽기실패",

  // DRAWLINE
  EROR_VL_DRAWLINE_FAILED: "0150",
  EROR_VL_DRAWLINE_FAILED_STR: "라인그리기실패",

  // HWPTOPDF
  EROR_VL_HTP_FAILED: "0210",
  EROR_VL_HTP_FAILED_STR: "PDF변환실패",
  EROR_VL_HTP_PDF_COPY_FAILED: "0220",
  EROR_VL_HTP_PDF_COPY_FAILED_STR: "PDF복사실패",
  // HTMLTOPDF
  EROR_VL_MLTP_FAILED: "0230",
  EROR_VL_MLTP_FAILED_STR: "HTMLTOPDF변환실패",
  // FILETOPDF
  EROR_VL_FITP_FAILED: "0240",
  EROR_VL_FITP_FAILED_STR: "FILETOPDF변환실패",

  // DP ...
  EROR_VL_IMG_FAILED: "0310",
  EROR_VL_IMG_FAILED_STR: "이미지추출실패",
  EROR_VL_IMG_FAILED2: "0320",
  EROR_VL_IMG_FAILED_STR2: "PDF페이지이미지추출실패",
  EROR_VL_DP_FAILED: "0330",
  EROR_VL_DP_FAILED_STR: "DP처리오류",
  EROR_VL_DP_CLEAN_FAILED: "0340",
  EROR_VL_DP_CLEAN_FAILED_STR: "DP TXT CLEAN오류",

  // PDFTOTEXT
  EROR_VL_PTT_FAILED: "0410",
  EROR_VL_PTT_FAILED_STR: "TEXT변환실패",

  //PDFMerge
  EROR_VL_PTM_FAILED: "0430",
  EROR_VL_PTM_FAILED_STR: "pdfMerge 변환 실패",

  //PDFTOIMG
  EROR_VL_PTI_FAILED: "0440",
  EROR_VL_PTI_FAILED_STR: "pdftoImg 변환 실패",

  // JEFF
  EROR_VL_JEFF_YEAR: "0511",
  EROR_VL_JEFF_YEAR_STR: "지원하지 않는 년도입니다.",
  EROR_VL_JEFF_DCMN_CLSF_ID: "0512",
  EROR_VL_JEFF_DCMN_CLSF_ID_STR: "지원하지 않는 업무구분입니다.",

  // JSON
  EROR_VL_JSON_FAILED: "0610",
  EROR_VL_JSON_FAILED_STR: "JSON변환실패",
  EROR_VL_JSON_MERGE_FAILED: "0620",
  EROR_VL_JSON_MERGE_FAILED_STR: "JSON병합실패",

  //JSONMERGE
  EROR_VL_JSONM_FAILED: "0804",
  EROR_VL_JSONM_FAILED_STR: "jsonMerge02 파일생성 오류",
};

/**
 *  공통 정의
 */
const COMMON_CODES = {
  // 자산화상태코드
  ASSZ_SCD_INIT: "00", // 초기
  ASSZ_SCD_SUCCESS: "10", // 정상
  ASSZ_SCD_EXCEPTION: "20", // 예외
  ASSZ_SCD_DELETE: "30", // 삭제

  // 날짜 빈값
  DEFAULT_NULL_DATE: "99991231",
};

/**
 * 20250710 CBKIM
 * @param {*} basDt
 * @param {*} btch_id
 * @param {*} assz_orgn_sys_cd_con
 * @param {*} assz_btch_tcd
 * @param {*} assz_btch_pcsn_stg_dcd
 * @param {*} assz_btch_pcsn_tcd
 * @returns
 */
/*-------------------배치수행로그 입력 및 배치ID채번----------------------*/
async function batchStart(
  basDt,
  btch_id,
  assz_orgn_sys_cd_con,
  assz_btch_tcd,
  assz_btch_pcsn_stg_dcd,
  assz_btch_pcsn_tcd,
  assz_trms_tgt_sys_dcd
) {
  //배치수행로그 입력 및 배치ID채번
  let assz_btch_acmp_id = "";
  if (assz_btch_tcd == "01" || assz_btch_tcd == "02") {
    assz_btch_acmp_id = await dbBatch.insertBatchJob(
      assz_btch_tcd, //assz_btch_tcd, "01", // 01 : 수집, 02 : 자산화, 03 : 전송
      assz_trms_tgt_sys_dcd, //assz_trms_tgt_sys_dcd, 01:UDA,02:GAI....
      basDt, //acmp_ymd
      btch_id, //btch_id
      assz_orgn_sys_cd_con, //assz_orgn_sys_cd_con,
      assz_btch_pcsn_stg_dcd, // 01 : 대기, 02 : 수행, 03 : 중단, 04 : 오류, 05 : 완료 assz_btch_pcsn_stg_dcd,
      assz_btch_pcsn_tcd, // T1 : 메타+파일, T2 : DB, T3 : 지식샘assz_btch_pcsn_tcd,
      EROR_CODES.EROR_VL_SUCCESS, //eror_vl,
      EROR_CODES.EROR_VL_SUCCESS_STR, //assz_eror_con,
      btch_id //uda_sys_lsmd_id,
    );
    writeLog(`ok : ${assz_btch_acmp_id}`);
  } else if (assz_btch_tcd == "03") {
    assz_btch_acmp_id = await selectLastBatchId(assz_orgn_sys_cd_con, basDt);
    if (assz_btch_acmp_id != "") {
      await dbBatch.insertSendBatchJob(
        assz_btch_acmp_id,
        assz_btch_tcd, //assz_btch_tcd, "01", // 01 : 수집, 02 : 자산화, 03 : 전송
        assz_trms_tgt_sys_dcd, //assz_trms_tgt_sys_dcd, 01:UDA,02:GAI....
        basDt, //acmp_ymd
        btch_id, //btch_id
        assz_orgn_sys_cd_con, //assz_orgn_sys_cd_con,
        assz_btch_pcsn_stg_dcd, // 01 : 대기, 02 : 수행, 03 : 중단, 04 : 오류, 05 : 완료 assz_btch_pcsn_stg_dcd,
        assz_btch_pcsn_tcd, // T1 : 메타+파일, T2 : DB, T3 : 지식샘assz_btch_pcsn_tcd,
        EROR_CODES.EROR_VL_SUCCESS, //eror_vl,
        EROR_CODES.EROR_VL_SUCCESS_STR, //assz_eror_con,
        btch_id //uda_sys_lsmd_id,
      );
    }
  }

  return assz_btch_acmp_id;
}

/**
 * 20250806 BYMUN
 * @param {*} batchPath
 * @returns
 */
/*-------------------배치수행로그 입력 및 배치ID채번----------------------*/
function getBatchId(batchPath) {
  const batchFileExt = path.extname(batchPath);
  const batchId = path.basename(batchPath, batchFileExt);

  return batchId;
}

/**
 * 20250710 cbkim
 * 자산화통합ID 채번 함수 - SEQ 는 직접 구해서 매개변수로 전달해야함 (보통 for문 안에서 호출)
 * @param {*} systemName
 * @param {*} idx
 * @returns
 */
async function getUnfcId(systemName, idx) {
  let id = `UDA${systemName}${String(idx).padStart(10, "0")}`;
  return id;
}

/**
 * 원천별 자산화통합ID 마지막 seq 가져오기
 * @param {*} pool
 * @param {*} basDt
 * @param {*} tableName
 * @returns
 */
async function selectUnfcSeq(pool, assz_orgn_sys_cd_con) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        select
        max(idSqn) as idSqn
        from
        (
          select
            idSqn
          from
          (
            select
              ltrim(SUBSTRING(assz_unfc_id, 10), '0') as idSqn
            from tb_uda_uai000m
            where assz_unfc_id like 'UDA' || $1 || '%'
            order by assz_unfc_id desc
            limit 1
          )

          union

          select
          '0' as idSqn
        )
      `,
      [assz_orgn_sys_cd_con]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

//원장테이블 인서트 (자체 DB풀생성)
async function insertLdgrSelfPool(
  assz_unfc_id,
  base_ymd,
  sqn,
  assz_btch_acmp_id,
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  atch_yn,
  atch_sqn,
  assz_orcp_unfc_id,
  dcmn_nm,
  file_nm,
  assz_pcsn_tgt_tcd,
  assz_pcsn_tcd,
  url_adr,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  rgsn_ts,
  amnn_ts,
  sys_lsmd_id,
  eror_vl,
  assz_eror_con
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI000M(assz_unfc_id, base_ymd, sqn, assz_btch_acmp_id, assz_orgn_sys_cd_con, assz_cfbo_idnt_id, atch_yn, assz_orcp_unfc_id, dcmn_nm, file_nm, assz_pcsn_tgt_tcd, assz_pcsn_tcd, url_adr, flsz_vl, assz_orgn_file_encp_rnnm_vl, rgsn_ts, amnn_ts, del_yn, del_ymd, sys_lsmd_id, sys_lsmd_ts, atch_sqn, eror_vl, assz_eror_con)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, TO_TIMESTAMP($16,'YYYYMMDDHH24MISS'), TO_TIMESTAMP($17,'YYYYMMDDHH24MISS'), 'N', null, $18, Current_timestamp, $19, $20, $21)
    `,
      [
        assz_unfc_id,
        base_ymd,
        sqn,
        assz_btch_acmp_id,
        assz_orgn_sys_cd_con,
        assz_cfbo_idnt_id,
        atch_yn,
        assz_orcp_unfc_id,
        dcmn_nm,
        file_nm,
        assz_pcsn_tgt_tcd,
        assz_pcsn_tcd,
        url_adr,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        rgsn_ts,
        amnn_ts,
        sys_lsmd_id,
        atch_sqn,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

//원장테이블 인서트 (pool 받아서 처리)
async function insertLdgrRecvPool(
  pool,
  assz_unfc_id,
  base_ymd,
  sqn,
  assz_btch_acmp_id,
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  atch_yn,
  atch_sqn,
  assz_orcp_unfc_id,
  dcmn_nm,
  file_nm,
  assz_pcsn_tgt_tcd,
  assz_pcsn_tcd,
  url_adr,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  rgsn_ts,
  amnn_ts,
  sys_lsmd_id,
  eror_vl,
  assz_eror_con
) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI000M(assz_unfc_id, base_ymd, sqn, assz_btch_acmp_id, assz_orgn_sys_cd_con, assz_cfbo_idnt_id, atch_yn, assz_orcp_unfc_id, dcmn_nm, file_nm, assz_pcsn_tgt_tcd, assz_pcsn_tcd, url_adr, flsz_vl, assz_orgn_file_encp_rnnm_vl, rgsn_ts, amnn_ts, del_yn, del_ymd, sys_lsmd_id, sys_lsmd_ts, atch_sqn, eror_vl, assz_eror_con)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, TO_TIMESTAMP($16,'YYYYMMDDHH24MISS'), TO_TIMESTAMP($17,'YYYYMMDDHH24MISS'), 'N', null, $18, Current_timestamp, $19, $20, $21)
    `,
      [
        assz_unfc_id,
        base_ymd,
        sqn,
        assz_btch_acmp_id,
        assz_orgn_sys_cd_con,
        assz_cfbo_idnt_id,
        atch_yn,
        atch_sqn,
        assz_orcp_unfc_id,
        dcmn_nm,
        file_nm,
        assz_pcsn_tgt_tcd,
        assz_pcsn_tcd,
        url_adr,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        rgsn_ts,
        amnn_ts,
        sys_lsmd_id,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result;
  } finally {
    client.release();
  }
}

//원장테이블 인서트 (자체 DB풀생성)
async function insertLdgrSelfPoolByJsonMerge01(
  assz_unfc_id,
  base_ymd,
  sqn,
  assz_btch_acmp_id,
  assz_orgn_sys_cd_con,
  assz_cfbo_idnt_id,
  atch_yn,
  atch_sqn,
  assz_orcp_unfc_id,
  dcmn_nm,
  file_nm,
  assz_pcsn_tgt_tcd,
  assz_pcsn_tcd,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  rgsn_ts,
  amnn_ts,
  sys_lsmd_id,
  eror_vl,
  assz_eror_con,
  url_adr
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
    INSERT INTO TB_UDA_UAI000M(assz_unfc_id, base_ymd, sqn, assz_btch_acmp_id, assz_orgn_sys_cd_con, assz_cfbo_idnt_id, atch_yn, assz_orcp_unfc_id, dcmn_nm, file_nm, assz_pcsn_tgt_tcd, assz_pcsn_tcd, flsz_vl, assz_orgn_file_encp_rnnm_vl, rgsn_ts, amnn_ts, del_yn, del_ymd, sys_lsmd_id, sys_lsmd_ts, atch_sqn, eror_vl, assz_eror_con, url_adr)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, 'N', null, $17, Current_timestamp, $18, $19, $20, $21)
    `,
      [
        assz_unfc_id,
        base_ymd,
        sqn,
        assz_btch_acmp_id,
        assz_orgn_sys_cd_con,
        assz_cfbo_idnt_id,
        atch_yn,
        assz_orcp_unfc_id,
        dcmn_nm,
        file_nm,
        assz_pcsn_tgt_tcd,
        assz_pcsn_tcd,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        rgsn_ts,
        amnn_ts,
        sys_lsmd_id,
        atch_sqn,
        eror_vl,
        assz_eror_con,
        url_adr,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

// 원장테이블 'U' 업데이트
async function updateLdgrUpdateSelfPool(
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_scd
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
              set 
                  assz_scd = $3  
                  , assz_pcsn_tcd = 'U'
                  , assz_btch_acmp_id = $2
                  , UDA_SYS_LSMD_TS = Current_timestamp
                  , MDFC_YMD = to_char(now(),'YYYYMMDD')
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_btch_acmp_id, assz_scd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

//원장테이블 'D' 업데이트
async function updateLdgrSelfPool(assz_unfc_id, assz_btch_acmp_id, assz_scd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
              set 
                  assz_scd = $3  
                  , assz_pcsn_tcd = 'D'
                  , assz_btch_acmp_id = $2
                  , UDA_SYS_LSMD_TS = Current_timestamp
                  , MDFC_YMD = to_char(now(),'YYYYMMDD')
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_btch_acmp_id, assz_scd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateAllLdgrSelfPool(
  assz_unfc_ids,
  assz_btch_acmp_id,
  assz_scd
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    if (assz_unfc_ids && assz_unfc_ids.length < 1) return null;

    let auiStr = `('${assz_unfc_ids.join("', '")}')`;
    const result = await client.query(
      `
      update tb_uda_uai000m
              set 
                  assz_scd = $2  
                  , assz_pcsn_tcd = 'D'
                  , assz_btch_acmp_id = $1
                  , UDA_SYS_LSMD_TS = Current_timestamp
                  , MDFC_YMD = to_char(now(),'YYYYMMDD')
      where assz_unfc_id in ${auiStr}
    `,
      [assz_btch_acmp_id, assz_scd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateAllLdgrEpnPlz(assz_unfc_ids) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    if (assz_unfc_ids && assz_unfc_ids.length < 1) return null;

    let auiStr = `('${assz_unfc_ids.join("', '")}')`;
    const result = await client.query(
      `
      update tb_uda_uai071m
              set 
                  assz_orgn_pcsn_dcd = 'D'
                  , uda_sys_lsmd_ts = current_timestamp
      where assz_unfc_id in ${auiStr}
    `,
      []
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

//원장테이블 업데이트
async function updateLdgrRecvPool(pool, assz_unfc_id) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
                                set   del_yn = 'Y'
                          , del_ymd = Current_date
                  , sys_lsmd_ts = Current_timestamp
                  , assz_btch_acmp_id = $2
                  , assz_pcsn_tcd = 'D'
      where assz_unfc_id = $1                       
    `,
      [assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
  }
}

async function getFileInfo(filePath) {
  return new Promise((resolve, reject) => {
    fs.stat(filePath, (err, stats) => {
      if (err) return reject(new Error(`파일 정보 확인 실패: ${err.message}`));
      if (!stats.isFile())
        return reject(new Error("해당 경로는 파일이 아닙니다."));

      const hash = crypto.createHash("md5");
      const stream = fs.createReadStream(filePath);

      stream.on("data", (chunk) => hash.update(chunk));
      stream.on("end", () => {
        resolve({
          size: stats.size,
          md5: hash.digest("hex"),
        });
      });
      stream.on("error", (err) =>
        reject(new Error(`파일 읽기 실패: ${err.message}`))
      );
    });
  });
}

/**
 * 메타파일 데이터와 원장테이블 데이터 비교 시 변경점이 없을 경우 수행정보 변경
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @param {*} assz_btch_acmp_id
 * assz_scd
 * @returns
 */
async function updateLdgrDupCreateData(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_scd,
  eror_vl,
  assz_eror_con
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set   uda_sys_lsmd_ts = Current_timestamp
          , assz_btch_acmp_id = $2
          , assz_scd = $3
          , MDFC_YMD = to_char(now(),'YYYYMMDD')     
          , eror_vl = $4
          , assz_eror_con = $5
      where assz_unfc_id = $1  
      `,
      [assz_unfc_id, assz_btch_acmp_id, assz_scd, eror_vl, assz_eror_con]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 원천별 자산화통합ID 마지막 seq 가져오기
 * @param {*} pool
 * @param {*} basDt
 * @param {*} tableName
 * @returns
 */
async function updateLdgrBatIdStatus(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  file_name,
  amnn_ts
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  const fileInfo = await getFileInfo(file_name);
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);
  const modfileSize = String(fileInfo.size);
  const modencpRnnmVl = fileInfo.md5;

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set   uda_sys_lsmd_ts = Current_timestamp
          , amnn_ts = TO_TIMESTAMP($7,'YYYYMMDDHH24MISS')
          , assz_btch_acmp_id = $2
          , assz_pcsn_tcd = 'U'
          , base_ymd = $3
          , sqn = $4
          , flsz_vl = $5
          , assz_orgn_file_encp_rnnm_vl = $6
      where assz_unfc_id = $1  
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        modBaseYmd,
        modSqn,
        modfileSize,
        modencpRnnmVl,
        amnn_ts,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * updateLdgrByJsonMerge01
 * @param {*} pool
 * @param {*} assz_unfc_id,
 * @param {*} assz_btch_acmp_id,
 * @param {*} assz_cfbo_idnt_id
 * @param {*} modfileSize,
 * @param {*} modencpRnnmVl,
 * @returns
 */
async function updateLdgrByJsonMerge01(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  modfileSize,
  modencpRnnmVl
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set   uda_sys_lsmd_ts = Current_timestamp
          , assz_btch_acmp_id = $2
          , assz_pcsn_tcd = 'U'
          , flsz_vl = $3
          , assz_orgn_file_encp_rnnm_vl = $4
      where assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_btch_acmp_id, modfileSize, modencpRnnmVl]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * updateLdgrByJsonMerge01
 * @param {*} pool
 * @param {*} assz_unfc_id,
 * @param {*} assz_btch_acmp_id,
 * @param {*} assz_mnl_id
 * @returns
 */
async function updateLdgrByJsonMerge01_01(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_mnl_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai003m
      set
      	amnn_ts = to_timestamp((select to_char(max(z.amnn_ts),'YYYYMMDDHH24MISS') from  tb_uda_uai803l Z where z.assz_mnl_id = $2 and Z.assz_btch_acmp_id = $3),'YYYYMMDDHH24MISS')
      where assz_unfc_id = $1
      `,
      [assz_unfc_id, assz_mnl_id, assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * tb_uda_uai000m 테이블에 자산화처리유형코드0003으로 데이터를 넣느다
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @returns
 */
async function insertLdgrForSendData(pool, assz_unfc_id, new_assz_unfc_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
          insert into tb_uda_uai000m      
      select 
        $2
        , base_ymd
        , sqn, assz_btch_acmp_id
        , assz_orgn_sys_cd_con
        , assz_cfbo_idnt_id
        , atch_yn
        , atch_sqn
        , assz_orcp_unfc_id
        , dcmn_nm
        , file_nm
        , assz_pcsn_tgt_tcd
        , assz_pcsn_tcd
        , flsz_vl
        , assz_orgn_file_encp_rnnm_vl
        , rgsn_ts
        , amnn_ts
        , '0003'
        , assz_eror_con
        , del_yn
        , del_ymd
        , sys_lsmd_id
        , sys_lsmd_ts
        , url_adr
      from tb_uda_uai000m
      where assz_unfc_id = $1
      `,
      [assz_unfc_id, new_assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

// 원장 수정
async function updateOrgin(
  assz_unfc_id,
  assz_btch_acmp_id,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  amnn_ts
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  const base_ymd = assz_btch_acmp_id.slice(0, 8);
  const sqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set   sys_lsmd_ts = Current_timestamp
          , assz_pcsn_tcd = 'U'
          , assz_btch_acmp_id = $2
          , base_ymd = $3
          , sqn = $4
          , flsz_vl = $5
          , assz_orgn_file_encp_rnnm_vl = $6
          , amnn_ts = TO_TIMESTAMP($7,'YYYYMMDDHH24MISS')
      where assz_unfc_id = $1 
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        base_ymd,
        sqn,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        amnn_ts,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

function masterMetaSort(fullPath, index) {
  const meta = fs.readFileSync(fullPath, "utf-8");
  let lines = meta.split("\n");

  return lines.sort((a, b) => {
    const aFields = a.split("^|");
    const bFields = b.split("^|");

    const aKey = aFields[index] || "";
    const bKey = bFields[index] || "";

    return aKey.localeCompare(bKey);
  });
}

/**
 *  basePath 예시 : /data/asset/kms/wpt
 */
async function moveAssetData(basePath, basDt) {
  writeLog(
    "----------------------------moveAssetData()시작----------------------------"
  );

  const result = spawnSync("rsync", [
    "-av",
    "--info=progress2",
    `${basePath}/${basDt}/`,
    `${basePath}/`,
  ]);

  if (result.error) {
    writeLog(`[RSYNC STDERR] ${result.error}`);
  } else {
    writeLog(`[RSYNC EXIT][${basePath}][${result.status}]`);
  }

  writeLog(
    "----------------------------moveAssetData()종료----------------------------"
  );
}

/**
 * 업무매뉴얼 > 원천식별키로 전체 건이 D인지 확인
 * @param {*} pool
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function chkAllDataStatus(pool, assz_cfbo_idnt_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        (case when not exists (select 1 from tb_uda_uai000m where assz_unfc_id like 'UDAIEMIEB'||'%' and assz_cfbo_idnt_id like cast($1 as text)||'_'||'%' and assz_pcsn_tcd <> 'D') 
        then 'Y'
        else 'N' end) as statusYn;
      `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

async function sync(targetDir) {
  writeLog(
    "----------------------------sync /data/bdpetl/recv ()시작----------------------------"
  );

  const result = spawnSync("/app/rsync/sync.sh", [targetDir, 2, targetDir]);

  if (result.error) {
    writeLog(`[RSYNC STDERR] ${data}`);
  } else {
    writeLog(`[RSYNC EXIT][${targetDir}][${result.status}]`);
  }

  // const rsync = spawn("/app/rsync/sync.sh", [targetDir, 2, targetDir]);

  // rsync.stdout.on("data", (data) => {
  //   //writeLog(`[RSYNC STDOUT] ${data}`);
  // });

  // rsync.stderr.on("data", (data) => {
  //   writeLog(`[RSYNC STDERR] ${data}`);
  // });

  // rsync.on("close", (code) => {
  //   writeLog(`[RSYNC EXIT] code :  ${code}`);
  // });

  writeLog(
    "---------------------------sync /data/bdpetl/recv 종료----------------------------"
  );
}

async function finFileCheck(basDt, basPath, sysName) {
  writeLog(
    "----------------------------finFileCheck() 시작----------------------------"
  );
  let metaPath = `${basPath}/meta/${basDt}.fin`;
  let filePath = `${basPath}/file/${basDt}.fin`;

  if (sysName && sysName == "KMSEPN") {
    metaPath = `${basPath}/meta_productManual/${basDt}.fin`;
    filePath = `${basPath}/file_productManual/${basDt}.fin`;
  } else if (sysName && sysName == "KMSPLZ") {
    metaPath = `${basPath}/meta_plaza/${basDt}.fin`;
    filePath = `${basPath}/file_plaza/${basDt}.fin`;
  }

  try {
    fs.accessSync(metaPath);
  } catch (err) {
    writeLog(`${basDt} fin파일이 없습니다. ${metaPath}`);
    process.exit(1);
  }

  try {
    fs.accessSync(filePath);
  } catch (err) {
    writeLog(`${basDt} fin파일이 없습니다. ${filePath}`);
    process.exit(1);
  }

  writeLog("(#) fin 파일 체크 완료");

  writeLog(
    "---------------------------finFileCheck() 종료----------------------------"
  );
}

async function finFileCreate(sendPath, basDt) {
  writeLog(
    "----------------------------finFileCreate() 시작----------------------------"
  );
  try {
    fs.mkdirSync(`${sendPath}/${basDt}`, { recursive: true });
    fs.writeFileSync(`${sendPath}/${basDt}/${basDt}.fin`, basDt, "utf8");
  } catch (err) {
    writeLog(`${basDt} fin파일 생성 오류. ${sendPath}/${basDt}/${basDt}.fin`);
    process.exit(1);
  }

  writeLog("(#) fin 파일 생성 완료");
  writeLog(
    "---------------------------finFileCreate() 종료----------------------------"
  );
}

/**
 * updateLdgrByJsonMerge02
 * @param {*} pool
 * @param {*} assz_unfc_id,
 * @param {*} assz_btch_acmp_id,
 * @param {*} assz_cfbo_idnt_id
 * @param {*} modfileSize,
 * @param {*} modencpRnnmVl,
 * @param {*} assz_pcsn_tcd
 * @returns
 */
async function updateLdgrByJsonMerge02(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  assz_cfbo_idnt_id,
  modfileSize,
  modencpRnnmVl,
  assz_pcsn_tcd
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set   uda_sys_lsmd_ts = Current_timestamp
          , assz_btch_acmp_id = $2
          , assz_pcsn_tcd = $3
          , flsz_vl = $4
          , assz_orgn_file_encp_rnnm_vl = $5
      where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        assz_pcsn_tcd,
        modfileSize,
        modencpRnnmVl,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 원천식별아이디로 머지된 파일의 자산화아이디 가져오기
 * @param {*} pool
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function ldgrDataByAsszCfboIdntId(pool, assz_cfbo_idnt_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select assz_unfc_id as assz_unfc_id 
      from  tb_uda_uai000m  
      where assz_unfc_id like 'UDAIEMIEB'||'%'
      and assz_cfbo_idnt_id = $1
      `,
      [assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 배치아이디로 머지된 원천식별아이디 가져오기
 * @param {*} pool
 * @param {*} batchId
 * @returns
 */
async function getldgrDataByBatchId(pool, batchId) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      // `
      // select
      //   substr(file_nm,1,19) assz_cfbo_idnt_id
      // from tb_uda_uai000m a
      // where 1=1
      // and assz_orgn_sys_cd_con = 'IEMIEB'
      // and a.assz_btch_acmp_id = $1
      // and a.assz_pcsn_tcd ='D'
      // group by substr(file_nm,1,19)
      // `,
      `
      select 
      	substr(b.file_nm,1,19) assz_cfbo_idnt_id
      from tb_uda_uai000m a
      inner join tb_uda_uai003m b on (a.assz_unfc_id = b.assz_unfc_id)
      where a.assz_btch_acmp_id = $1
      and a.assz_pcsn_tcd ='D'      
      group by substr(b.file_nm,1,19)      
      `,
      [batchId]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

async function recvMetaFileCheck(metaFileFull) {
  writeLog(
    "----------------------------recvMetaFileCheck() 시작----------------------------"
  );
  let rtnVal = true;

  try {
    fs.accessSync(metaFileFull);
  } catch (err) {
    writeLog(`recv meta 파일이 없습니다. ${metaFileFull}`);
    rtnVal = false;
  }

  writeLog("(#) recv meta 파일 유무 확인 완료");
  writeLog(
    "---------------------------recvMetaFileCheck() 종료----------------------------"
  );
  return rtnVal;
}

/**
 * 배치아이디로 머지된 원천식별아이디 가져오기
 * @param {*} pool
 * @param {*} batchId
 * @param {*} assz_cfbo_idnt_id
 * @returns
 */
async function getAsszUnfcIdByIeb(pool, batchId, assz_cfbo_idnt_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select max(assz_unfc_id) as assz_unfc_id 
      from TB_UDA_UAI910L
      where 1=1
      and assz_btch_acmp_id = $1
      and assz_cfbo_idnt_id = $2
      `,
      [batchId, assz_cfbo_idnt_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 배치아이디로 머지된 json 파일정보 가져오기
 * @param {*} pool
 * @param {*} batchId
 * @returns
 */
async function selectUai022mByFileRename(pool, batchId) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        assz_unfc_id
        ,assz_cfbo_idnt_id
        ,file_nm
        ,assz_pcsn_file_path_nm
      from TB_UDA_UAI910L
      where 1=1
      and assz_btch_acmp_id = $1
      and assz_pcsn_tgt_tcd = 'PD'
      `,
      [batchId]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

async function fileRename(oldFileInfo, newFileInfo) {
  writeLog(
    "----------------------------fileRename() 시작----------------------------"
  );

  try {
    fs.renameSync(oldFileInfo, newFileInfo);
  } catch (err) {
    writeLog(`파일이름 변경실패::::::: ${oldFileInfo}::::${newFileInfo}`);
  }

  writeLog(`(#) 파일이름 변경성공:::::${oldFileInfo}::::${newFileInfo}`);

  writeLog(
    "---------------------------fileRename() 종료----------------------------"
  );
}

/**
 * 머지된 파일 리네임을 위한 날자별로 실행하는 기능
 * @param {*} pool
 * @param {*} base_ymd
 * @returns
 */
async function selectByFileRenameBaseYmd(pool, base_ymd) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        M.base_ymd
        ,M.assz_cfbo_idnt_id
        ,M.file_nm
        ,'/data/asset/iem/ieb/'||$1||'/originpdf/'||M.assz_cfbo_idnt_id||'.pdf' as old_pdf_file
        ,'/data/asset/iem/ieb/'||$1||'/originpdf/'||file_nm as new_pdf_file
        ,'/data/asset/iem/ieb/'||$1||'/json/'||M.assz_cfbo_idnt_id||'.json' as old_json_file
        ,'/data/asset/iem/ieb/'||$1||'/json/'||replace(file_nm,'.pdf','.json') as new_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||$1||'/'||M.assz_cfbo_idnt_id||'.pdf' as old_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||$1||'/'||file_nm as new_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||$1||'/'||M.assz_cfbo_idnt_id||'.json' as old_send_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||$1||'/'||replace(file_nm,'.pdf','.json') as new_send_json_file
      from (
        select
          base_ymd
          ,assz_cfbo_idnt_id
          ,file_nm
        from tb_uda_uai000m--여기는 바꿨어
        where 1=1
        and assz_orgn_sys_cd_con = 'IEMIEB'
        and eror_vl = '0003'
      ) M
      `,
      [base_ymd]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

// 원장테이블 파일명 업데이트
async function updateLdgrUpdateFileNmSelfPool(assz_orgn_sys_cd_con) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set
        file_nm = assz_unfc_id||'.pdf'
      where assz_orgn_sys_cd_con = $1
      and eror_vl = '0003'
    `,
      [assz_orgn_sys_cd_con]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 머지된 파일 리네임을 위한 날자별로 실행하는 기능
 * @param {*} pool
 * @param {*} base_ymd
 * @returns
 */
async function selectByFileRenameByBaseYmd(pool, base_ymd) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        M.base_ymd
        ,M.assz_cfbo_idnt_id
        ,M.file_nm
        ,'/data/asset/iem/ieb/'||M.base_ymd||'/originpdf/'||M.assz_cfbo_idnt_id||'.pdf' as old_pdf_file
        ,'/data/asset/iem/ieb/'||M.base_ymd||'/originpdf/'||file_nm as new_pdf_file
        ,'/data/asset/iem/ieb/'||M.base_ymd||'/json/'||M.assz_cfbo_idnt_id||'.json' as old_json_file
        ,'/data/asset/iem/ieb/'||M.base_ymd||'/json/'||replace(M.file_nm,'.pdf','.json') as new_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||M.base_ymd||'/'||M.assz_cfbo_idnt_id||'.pdf' as old_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||M.base_ymd||'/'||M.file_nm as new_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||M.base_ymd||'/'||M.assz_cfbo_idnt_id||'.json' as old_send_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||M.base_ymd||'/'||replace(file_nm,'.pdf','.json') as new_send_json_file
      from (
        select
          base_ymd
          ,assz_cfbo_idnt_id
          ,file_nm
        from tb_uda_uai000m
        where 1=1
        and assz_orgn_sys_cd_con = 'IEMIEB'
        and eror_vl = '0003'
        and base_ymd = $1
      ) M
      `,
      [base_ymd]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

// 원장테이블 파일명 업데이트
async function updateLdgrUpdateFileNmSelfPool(assz_orgn_sys_cd_con) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();
  const modBaseYmd = assz_btch_acmp_id.slice(0, 8);
  const modSqn = parseInt(assz_btch_acmp_id.slice(-6), 10);

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set
        file_nm = assz_unfc_id||'.pdf'
      where assz_orgn_sys_cd_con = $1
      and eror_vl = '0003'
    `,
      [assz_orgn_sys_cd_con]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 20250818 cbkim
 * PDF 파일 중 ImageMagick으로 변조 된 PDF는 fitz로 읽히지않음, 예외로 처리 (errCd:9999)
 * @param {*} pdfFilePath
 * @returns
 */
async function isImageMagick(pdfFilePath) {
  const target = Buffer.from("ImageMagick", "utf-8");
  const chunkSize = 4096;
  try {
    const fd = fs.openSync(pdfFilePath, "r");
    const buffer = Buffer.alloc(chunkSize);

    let bytesRead;
    while ((bytesRead = fs.readSync(fd, buffer, 0, chunkSize, null)) > 0) {
      if (buffer.slice(0, bytesRead).includes(target)) {
        fs.closeSync(fd);
        return true;
      }
    }
    fs.closeSync(fd);
    return false;
  } catch (err) {
    writeLog(`에러 발생: ${err.message}`);
    return false;
  }
}

/**
 * 20250818 bymun
 * 원장에서 원천시스템 코드를 기준으로 최신 배치ID 반환
 * @param {*} assz_orgn_sys_cd_con
 * @returns
 */
async function selectLastBatchId(assz_orgn_sys_cd_con, baseDt) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        select
			    coalesce(max(assz_btch_acmp_id), '') as assz_btch_acmp_id
        from tb_uda_uai900m
        where
        assz_btch_tcd = '01'
        and assz_trms_tgt_sys_dcd = '01'
        and assz_btch_pcsn_stg_dcd = '05'
        and assz_orgn_sys_cd_con = $1
        and acmp_ymd = $2
    `,
      [assz_orgn_sys_cd_con, baseDt]
    );
    return result.rows[0].assz_btch_acmp_id;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 머지된 파일 리네임을 위한 날자별로 실행하는 기능
 * @param {*} pool
 * @param {*} assz_btch_acmp_id
 * @returns
 */
async function selectByFileRenameByBatchId(pool, assz_btch_acmp_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      select 
        substr(trim(M.assz_btch_acmp_id),1,8)
        ,M.assz_cfbo_idnt_id
        ,M.file_nm
        ,'/data/asset/iem/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/originpdf/'||M.assz_cfbo_idnt_id||'.pdf' as old_pdf_file
        ,'/data/asset/iem/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/originpdf/'||M.assz_unfc_id||'.pdf' as new_pdf_file
        ,'/data/asset/iem/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/json/'||M.assz_cfbo_idnt_id||'.json' as old_json_file
        ,'/data/asset/iem/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/json/'||M.assz_unfc_id||'.json' as new_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/'||M.assz_cfbo_idnt_id||'.pdf' as old_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/'||M.assz_unfc_id||'.pdf' as new_send_pdf_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/'||M.assz_cfbo_idnt_id||'.json' as old_send_json_file
        ,'/data/bdpetl/send/gai/gai/ieb/'||substr(trim(M.assz_btch_acmp_id),1,8)||'/'||M.assz_unfc_id||'.json' as new_send_json_file
      from (
        select
          a.assz_cfbo_idnt_id
          ,b.file_nm
          , a.assz_btch_acmp_id
          , a.assz_unfc_id
        from tb_uda_uai000m a
        inner join tb_uda_uai003m b on (a.assz_unfc_id = b.assz_unfc_id)
        where 1=1
        and a.eror_vl = '0003'
        and a.assz_btch_acmp_id = $1
      ) M
      `,
      [assz_btch_acmp_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * TB_DOCUMNET 에 머지하는 쿼리
 * @param {*} pool
 * @param {*} assz_btch_acmp_id
 * @returns
 */
async function mergeDocument(pool, assz_btch_acmp_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      	WITH upsert AS(
          INSERT INTO tb_document (
            document_id
            , document_name
            , original_doc_type
            , source_system
            , classification
            , registration_type
            , registered_by
            , registered_branch
            , registered_at
            , assetization_status
            , assetized_at
            , updated_at
            , assz_cfbo_idnt_id
            , chunked_file_path
          )
        SELECT doc.assz_unfc_id	AS document_id
          , doc.document_name
          , doc.original_doc_type
          , doc.assz_orgn_sys_cd_con AS source_system
          , doc.assz_dcmn_clsf_id AS classification
          , doc.registration_type AS registration_type
          , CASE WHEN doc.orgn_data_rgsr_id IS NULL OR doc.orgn_data_rgsr_id = '' THEN NULL
        ELSE LPAD(doc.orgn_data_rgsr_id, 6, '0')
        END													AS registered_by
          , registered_branch
          , doc.amnn_ts::timestamp(0)                            AS registered_at
          , assetization_status
          , doc.uda_sys_lsmd_ts::timestamp(0)                    AS assetized_at
          , null													AS updated_at
          , assz_cfbo_idnt_id
          , chunked_file_path
        FROM (
          -- 업무포탈(시행문)
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSWPT'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd							AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , b.assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
            JOIN tb_uda_uai001m b /* UDA시행문메타기본 */
              ON a.assz_unfc_id = b.assz_unfc_id
            LEFT OUTER JOIN tb_uda_uai101m c
              ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1
                
          UNION ALL

          -- 상품플라자
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSPLZ'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd							AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , '' 								AS assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/epnt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
          JOIN tb_uda_uai071m b /* UDA업무포탈상품설명서메타기본 */ 
            ON a.assz_unfc_id = b.assz_unfc_id /* PLZ EPN 구분값 조건 추가 */
            AND a.assz_unfc_id LIKE '%KMSPLZ%' /* 임시 */
          LEFT OUTER JOIN tb_uda_uai101m c
            ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 상품설명서
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'KMSEPN'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.brcd							AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , '' 								AS assz_cfbo_idnt_id
            , '/data/asset/kms/wpt/epnt/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
            JOIN tb_uda_uai071m b /* UDA업무포탈상품설명서메타기본 */ 
              ON a.assz_unfc_id = b.assz_unfc_id /* PLZ EPN 구분값 조건 추가 */
              AND a.assz_unfc_id LIKE '%KMSEPN%' /* 임시 */
            LEFT OUTER JOIN tb_uda_uai101m c
              ON b.rgsr_dept_id = c.wpt_athr_grp_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1
          
          UNION ALL

          -- FAQ
          SELECT a.assz_unfc_id
              , a.assz_cfbo_idnt_id	            AS document_name
              , 'ETC'                            AS original_doc_type
              , 'CHBOCH'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , b.orgn_data_rgsr_id
              , c.trth_work_brcd					AS registered_branch
              , b.amnn_ts
              , a.uda_sys_lsmd_ts
              , '' 								AS assz_cfbo_idnt_id
              , '' as chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai007m b /* UDA챗봇FAQ메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
                LEFT OUTER JOIN tb_uda_uaie01m c
                  ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1
          
          UNION ALL

          -- 카드몰
          SELECT a.assz_unfc_id
              , b.conn_ttl_nm                    AS document_name
              , CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                      WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                      ELSE 'ETC'
                  END                             AS original_doc_type
              , 'CSMCSM'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , b.orgn_data_rgsr_id
              , c.trth_work_brcd					AS registered_branch
              , b.amnn_ts
              , a.uda_sys_lsmd_ts
              , '' 								AS assz_cfbo_idnt_id
              , '/data/asset/csm/csm/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai072m b /* UDA카드상품설명서메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
                LEFT OUTER JOIN tb_uda_uaie01m c
                  ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1

          UNION ALL
    
          -- 지식샘
          SELECT a.assz_unfc_id
            , CASE WHEN b.atch_key_vl != '' THEN SUBSTRING(b.atch_nm from '^(.*)\.[^\.]+$')
                    ELSE b.conn_ttl_nm 
                END                             AS document_name
            , CASE WHEN b.file_nm IS NULL OR b.file_nm = '' THEN 'HTML'
                  ELSE CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                            WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                            ELSE 'ETC'
                        END 
              END                             AS original_doc_type
            , 'AIKKMS'                         AS assz_orgn_sys_cd_con
            , (REGEXP_SPLIT_TO_ARRAY(b.assz_dcmn_clsf_id, '/'))[
                ARRAY_LENGTH(REGEXP_SPLIT_TO_ARRAY(b.assz_dcmn_clsf_id, '/'), 1)
            ]                                AS assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd					AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , '' 								AS assz_cfbo_idnt_id
            , '/data/asset/aik/kms/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai005m b /* UDA지식샘메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002', '0013', '0014')
          and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 펀드
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm		            AS document_name
            , CASE WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.atch_nm, POSITION('.' IN REVERSE(b.atch_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'IISIIS'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd					AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , '' 								AS assz_cfbo_idnt_id
            , '/data/asset/iis/iis/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai074m b /* UDA펀드투자설명서메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1

          UNION ALL
          
          -- 내규
          SELECT a.assz_unfc_id
              , b.conn_ttl_nm                    AS document_name
              , 'HWP'                            AS original_doc_type
              , 'IEMIEA'                         AS assz_orgn_sys_cd_con
              , b.assz_dcmn_clsf_id
              , 'BATCH'                          AS registration_type
              , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
              , ''                               AS orgn_data_rgsr_id
              , ''								AS registered_branch
              , NULL                             AS amnn_ts
              , a.uda_sys_lsmd_ts
              , '' 								AS assz_cfbo_idnt_id
              , '/data/asset/iem/iea/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
            FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
                JOIN tb_uda_uai004m b /* UDA내규메타기본 */
                  ON a.assz_unfc_id = b.assz_unfc_id
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1

          UNION ALL

          -- 업무메뉴얼
          SELECT a.assz_unfc_id
            , b.conn_ttl_nm                    AS document_name
            , CASE WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('HWP', 'HWPX') THEN 'HWP'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('JPG', 'JPEG', 'PNG', 'TIF', 'TIFF') THEN 'IMG'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) IN ('DOC', 'DOCX') THEN 'DOC'
                    WHEN UPPER(RIGHT(b.file_nm, POSITION('.' IN REVERSE(b.file_nm)) - 1)) = 'PDF' THEN 'PDF'
                    ELSE 'ETC'
                END                             AS original_doc_type
            , 'IEMIEB'                         AS assz_orgn_sys_cd_con
            , b.assz_dcmn_clsf_id
            , 'BATCH'                          AS registration_type
            , (case when substr(eror_vl,1,2) = '00' then 'SUCCESS' else 'FAIL' end) as assetization_status
            , b.orgn_data_rgsr_id
            , c.trth_work_brcd					AS registered_branch
            , b.amnn_ts
            , a.uda_sys_lsmd_ts
            , '' 								AS assz_cfbo_idnt_id
            , '/data/asset/iem/ieb/json/' || a.assz_unfc_id || '.json' AS chunked_file_path
          FROM tb_uda_uai000m      a /* UDA자산화메타통합기본 */
              JOIN tb_uda_uai003m b /* UDA업무매뉴얼메타기본 */
                ON a.assz_unfc_id = b.assz_unfc_id
              LEFT OUTER JOIN tb_uda_uaie01m c
                ON LPAD(b.orgn_data_rgsr_id, 6, '0') = c.emn
          where 1=1
          and eror_vl not in ('0001', '0002')
          and a.assz_btch_acmp_id = $1

        ) AS doc
        LEFT OUTER JOIN tb_uda_uaie01m emp 
            ON LPAD(doc.orgn_data_rgsr_id, 6, '0') = emp.emn
        ON CONFLICT (document_id, source_system)
        DO UPDATE 
        SET 
            document_name = EXCLUDED.document_name
          , original_doc_type = EXCLUDED.original_doc_type
          , classification = EXCLUDED.classification
          , registration_type =	EXCLUDED.registration_type
          , registered_by =	EXCLUDED.registered_by
          , registered_branch =	EXCLUDED.registered_branch
          , registered_at =	EXCLUDED.registered_at
          , assetization_status	=	EXCLUDED.assetization_status
          , assetized_at	=	EXCLUDED.assetized_at
          , assz_cfbo_idnt_id = EXCLUDED.assz_cfbo_idnt_id
          , chunked_file_path = EXCLUDED.chunked_file_path
          , del_yn = EXCLUDED.del_yn
              RETURNING xmin
      )
      select count(*) FILTER (where xmin = 0) AS inserted_count,
            count(*) FILTER (where xmin <> 0) AS updated_count
      from upsert; 
      `,
      [assz_btch_acmp_id]
    );

    const { inserted_count, updated_count } = result.rows[0];
    writeLog(
      `(#)UPSERT RESULT---------${assz_btch_acmp_id}-------------------------`
    );
    writeLog(`(#)INSERT COUNT : ${inserted_count}`);
    writeLog(`(#)UPDATE COUNT : ${updated_count}`);
    writeLog(`(#)---------------------------------------------------------`);
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 원장마스터 인서트
 * @param {*} pool
 * @param {*} assz_unfc_id,
 * @param {*} assz_scd,
 * @param {*} assz_cfbo_idnt_id,
 * @param {*} rgsn_ymd,
 * @param {*} mdfc_ymd,
 * @param {*} assz_pcsn_tcd,
 * @param {*} eror_vl,
 * @param {*} assz_eror_con,
 * @param {*} assz_pcsn_file_path_nm,
 * @param {*} flsz_vl,
 * @param {*} assz_orgn_file_encp_rnnm_vl,
 * @param {*} assz_btch_acmp_id,
 * @param {*} uda_sys_lsmd_id
 * @returns
 */
async function insertLdgrMaster(
  pool,
  assz_unfc_id,
  assz_scd,
  assz_cfbo_idnt_id,
  rgsn_ymd,
  mdfc_ymd,
  assz_pcsn_tcd,
  eror_vl,
  assz_eror_con,
  assz_pcsn_file_path_nm,
  flsz_vl,
  assz_orgn_file_encp_rnnm_vl,
  assz_btch_acmp_id,
  uda_sys_lsmd_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const nowDate = dayjs().format("YYYYMMDD");
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai000m(
        assz_unfc_id
        , assz_scd
        , assz_cfbo_idnt_id
        , rgsn_ymd
        , mdfc_ymd
        , assz_pcsn_tcd
        , eror_vl
        , assz_eror_con
        , assz_pcsn_file_path_nm
        , flsz_vl
        , assz_orgn_file_encp_rnnm_vl
        , assz_btch_acmp_id
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts)
      VALUES(
        $1 --assz_unfc_id
        ,$2 --assz_scd
        ,$3 --assz_cfbo_idnt_id
        ,$4 --rgsn_ymd
        ,$5 --mdfc_ymd
        ,$6 --assz_pcsn_tcd
        ,$7 --eror_vl
        ,$8 --assz_eror_con
        ,$9 --assz_pcsn_file_path_nm
        ,$10 --flsz_vl
        ,$11 --assz_orgn_file_encp_rnnm_vl
        ,$12 --assz_btch_acmp_id
        ,$13 --uda_sys_lsmd_id
        ,Current_timestamp --uda_sys_lsmd_ts
      );      
      `,
      [
        assz_unfc_id,
        assz_scd,
        assz_cfbo_idnt_id,
        nowDate,
        nowDate,
        assz_pcsn_tcd,
        eror_vl,
        assz_eror_con,
        assz_pcsn_file_path_nm,
        flsz_vl,
        assz_orgn_file_encp_rnnm_vl,
        assz_btch_acmp_id,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 업무매뉴얼원장 인서트
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @param {*} assz_cfbo_idnt_id
 * @param {*} file_nm
 * @param {*} file_sqn
 * @param {*} assz_orcp_file_path_nm
 * @param {*} orgn_data_rgsr_id
 * @param {*} rgsn_ts
 * @param {*} amnn_ts
 * @param {*} assz_orgn_pcsn_dcd
 * @param {*} atch_yn
 * @param {*} atch_sqn
 * @param {*} assz_dcmn_clsf_id
 * @param {*} conn_ttl_nm
 * @param {*} url_adr
 * @param {*} uda_sys_lsmd_id
 * @param {*} sub_ttl_nm
 * @returns
 */
async function insertLdgrManual(
  pool,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  url_adr,
  uda_sys_lsmd_id,
  sub_ttl_nm
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  console.log(`rgsn_ts::::amnn_ts====>>>${rgsn_ts}::::${amnn_ts}`);
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai003m(
        assz_unfc_id
        , assz_cfbo_idnt_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , url_adr
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts
        , sub_ttl_nm
        )
      VALUES(
        $1 --assz_unfc_id
        , $2 --assz_cfbo_idnt_id
        , $3 --file_nm
        , $4 --file_sqn
        , $5 --assz_orcp_file_path_nm
        , $6 --orgn_data_rgsr_id
        , TO_TIMESTAMP($7,'YYYYMMDDHH24MISS') --rgsn_ts
        , TO_TIMESTAMP($8,'YYYYMMDDHH24MISS') --amnn_ts
        , $9 --assz_orgn_pcsn_dcd
        , $10 --atch_yn
        , $11 --atch_sqn
        , $12 --assz_dcmn_clsf_id
        , $13 --conn_ttl_nm
        , $14 --url_adr
        , $15 --uda_sys_lsmd_id
        , Current_timestamp
        , $16
      );
      `,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        url_adr,
        uda_sys_lsmd_id,
        sub_ttl_nm,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 은행상품설명서 메타 원장 insert
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @param {*} assz_cfbo_idnt_id
 * @param {*} assz_fmts_base_orgn_idnt_id
 * @param {*} orgn_data_rgsr_id
 * @param {*} rgsn_ts
 * @param {*} amnn_ts
 * @param {*} assz_orgn_pcsn_dcd
 * @param {*} assz_dcmn_clsf_id
 * @param {*} conn_ttl_nm
 * @param {*} rgsr_dept_id
 * @param {*} assz_orcp_file_path_nm
 * @param {*} atch_yn
 * @param {*} atch_sqn
 * @param {*} atch_nm
 * @param {*} use_sttg_ymd
 * @param {*} use_fnsh_ymd
 * @param {*} sale_info_con
 * @param {*} assz_dcmn_clsf_con
 * @param {*} uda_sys_lsmd_id
 */
async function insertLdgrEpnPlz(
  pool,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  assz_fmts_base_orgn_idnt_id,
  orgn_data_rgsr_id,
  file_nm,
  file_sqn,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  rgsr_dept_id,
  assz_orcp_file_path_nm,
  atch_yn,
  atch_sqn,
  atch_nm,
  use_sttg_ymd,
  use_fnsh_ymd,
  sale_info_con,
  assz_dcmn_clsf_con,
  uda_sys_lsmd_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai071m(
        assz_unfc_id
        , assz_cfbo_idnt_id
        , assz_fmts_base_orgn_idnt_id
        , orgn_data_rgsr_id
        , file_nm
        , file_sqn
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , rgsr_dept_id
        , assz_orcp_file_path_nm
        , atch_yn
        , atch_sqn
        , atch_nm
        , use_sttg_ymd
        , use_fnsh_ymd
        , sale_info_con
        , assz_dcmn_clsf_con
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts)
      VALUES(
        $1 -- assz_unfc_id,
        , $2 -- assz_cfbo_idnt_id,
        , $3 -- assz_fmts_base_orgn_idnt_id,
        , $4 -- orgn_data_rgsr_id,
        , $5 -- file_nm,
        , $6 -- file_sqn,
        , $7 -- rgsn_ts,
        , $8 -- amnn_ts,
        , $9 -- assz_orgn_pcsn_dcd,
        , $10 -- assz_dcmn_clsf_id,
        , $11 -- conn_ttl_nm,
        , $12 -- rgsr_dept_id,
        , $13 -- assz_orcp_file_path_nm,
        , $14 -- atch_yn,
        , $15 -- atch_sqn,
        , $16 -- atch_nm,
        , coalesce(to_char(to_date($17, 'YYYY-MM-DD'), 'YYYYMMDD'), null) -- use_sttg_ymd,
        , coalesce(to_char(to_date($18, 'YYYY-MM-DD'), 'YYYYMMDD'), null) -- use_fnsh_ymd,
        , $19 -- sale_info_con,
        , $20 -- assz_dcmn_clsf_con,
        , $21 -- uda_sys_lsmd_id
        , Current_timestamp
      );
      `,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        assz_fmts_base_orgn_idnt_id,
        orgn_data_rgsr_id,
        file_nm,
        file_sqn,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        rgsr_dept_id,
        assz_orcp_file_path_nm,
        atch_yn,
        atch_sqn,
        atch_nm,
        use_sttg_ymd,
        use_fnsh_ymd,
        sale_info_con,
        assz_dcmn_clsf_con,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 카드몰 메타 원장 insert
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @param {*} assz_cfbo_idnt_id
 * @param {*} file_nm
 * @param {*} file_sqn
 * @param {*} assz_orcp_file_path_nm
 * @param {*} orgn_data_rgsr_id
 * @param {*} rgsn_ts
 * @param {*} amnn_ts
 * @param {*} assz_orgn_pcsn_dcd
 * @param {*} atch_yn
 * @param {*} atch_sqn
 * @param {*} assz_dcmn_clsf_id
 * @param {*} conn_ttl_nm
 * @param {*} isnc_tgt_con
 * @param {*} card_kind_con
 * @param {*} isnc_intt_con
 * @param {*} fee_cndt_con
 * @param {*} cdis_info_con
 * @param {*} card_ftpm_trfc_con
 * @param {*} anf_con
 * @param {*} assz_card_alnc_cd_nm
 * @param {*} uda_sys_lsmd_id
 */
async function insertLdgrCsm(
  pool,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  isnc_tgt_con,
  card_kind_con,
  isnc_intt_con,
  fee_cndt_con,
  cdis_info_con,
  card_ftpm_trfc_con,
  anf_con,
  assz_card_alnc_cd_nm,
  uda_sys_lsmd_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai072m(
        assz_unfc_id
        , assz_cfbo_idnt_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , isnc_tgt_con
        , card_kind_con
        , isnc_intt_con
        , fee_cndt_con
        , cdis_info_con
        , card_ftpm_trfc_con
        , anf_con
        , assz_card_alnc_cd_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts)
      VALUES(
        $1 -- assz_unfc_id
        , $2 -- assz_cfbo_idnt_id
        , $3 -- file_nm
        , $4 -- file_sqn
        , $5 -- assz_orcp_file_path_nm
        , $6 -- orgn_data_rgsr_id
        , coalesce(to_timestamp($7, 'YYYYMMDDHH24MISS'), null) -- rgsn_ts,
        , coalesce(to_timestamp($8, 'YYYYMMDDHH24MISS'), null) -- amnn_ts,
        , $9 -- assz_orgn_pcsn_dcd
        , $10 -- atch_yn
        , $11 -- atch_sqn
        , $12 -- assz_dcmn_clsf_id
        , $13 -- conn_ttl_nm
        , $14 -- isnc_tgt_con
        , $15 -- card_kind_con
        , $16 -- isnc_intt_con
        , $17 -- fee_cndt_con
        , $18 -- cdis_info_con
        , $19 -- card_ftpm_trfc_con
        , $20 -- anf_con
        , $21 -- assz_card_alnc_cd_nm
        , $22 -- uda_sys_lsmd_id
        , Current_timestamp -- uda_sys_lsmd_ts
      );
      `,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        isnc_tgt_con,
        card_kind_con,
        isnc_intt_con,
        fee_cndt_con,
        cdis_info_con,
        card_ftpm_trfc_con,
        anf_con,
        assz_card_alnc_cd_nm,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 카드몰 메타 원장 insert
 * @param {*} pool
 * @param {*} assz_unfc_id
 * @param {*} assz_cfbo_idnt_id
 * @param {*} file_nm
 * @param {*} file_sqn
 * @param {*} assz_orcp_file_path_nm
 * @param {*} orgn_data_rgsr_id
 * @param {*} rgsn_ts
 * @param {*} amnn_ts
 * @param {*} assz_orgn_pcsn_dcd
 * @param {*} atch_yn
 * @param {*} atch_sqn
 * @param {*} assz_dcmn_clsf_id
 * @param {*} conn_ttl_nm
 * @param {*} cnvs_grp_cd
 * @param {*} assz_fund_dcmn_dcd
 * @param {*} assz_fund_new_abl_yn
 * @param {*} sale_fnsh_ymd
 * @param {*} atch_nm
 * @param {*} uda_sys_lsmd_id
 */
async function insertLdgrIis(
  pool,
  assz_unfc_id,
  assz_cfbo_idnt_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  atch_yn,
  atch_sqn,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  cnvs_grp_cd,
  assz_fund_dcmn_dcd,
  assz_fund_new_abl_yn,
  sale_fnsh_ymd,
  atch_nm,
  uda_sys_lsmd_id
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();
  try {
    const result = await client.query(
      `
      INSERT INTO tb_uda_uai074m(
        assz_unfc_id
        , assz_cfbo_idnt_id
        , file_nm
        , file_sqn
        , assz_orcp_file_path_nm
        , orgn_data_rgsr_id
        , rgsn_ts
        , amnn_ts
        , assz_orgn_pcsn_dcd
        , atch_yn
        , atch_sqn
        , assz_dcmn_clsf_id
        , conn_ttl_nm
        , cnvs_grp_cd
        , assz_fund_dcmn_dcd
        , assz_fund_new_abl_yn
        , sale_fnsh_ymd
        , atch_nm
        , uda_sys_lsmd_id
        , uda_sys_lsmd_ts
      )
      VALUES(
        $1 -- assz_unfc_id
        , $2 -- assz_cfbo_idnt_id
        , $3 -- file_nm
        , $4 -- file_sqn
        , $5 -- assz_orcp_file_path_nm
        , $6 -- orgn_data_rgsr_id
        , coalesce(to_timestamp($7, 'YYYYMMDDHH24MISS'), null) -- rgsn_ts,
        , coalesce(to_timestamp($8, 'YYYYMMDDHH24MISS'), null) -- amnn_ts,
        , $9 -- assz_orgn_pcsn_dcd
        , $10 -- atch_yn
        , $11 -- atch_sqn
        , $12 -- assz_dcmn_clsf_id
        , $13 -- conn_ttl_nm
        , $14 -- cnvs_grp_cd
        , $15 -- assz_fund_dcmn_dcd
        , $16 -- assz_fund_new_abl_yn
        , $17 -- sale_fnsh_ymd
        , $18 -- atch_nm
        , $19 -- uda_sys_lsmd_id
        , Current_timestamp -- uda_sys_lsmd_ts
      );
      `,
      [
        assz_unfc_id,
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        cnvs_grp_cd,
        assz_fund_dcmn_dcd,
        assz_fund_new_abl_yn,
        sale_fnsh_ymd,
        atch_nm,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

//원장업무매뉴얼 업데이트(D상태일때 식별키있는경우)
async function updateLdgrMnl(assz_unfc_id, assz_orgn_pcsn_dcd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai003m
              set 
                  assz_orgn_pcsn_dcd = $2  
                  , UDA_SYS_LSMD_TS = Current_timestamp
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_orgn_pcsn_dcd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

//원장 은행상품설명서 업데이트(D상태일때 식별키있는경우)
async function updateLdgrEpnPlz(assz_unfc_id, assz_orgn_pcsn_dcd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai071m
              set 
                  assz_orgn_pcsn_dcd = $2  
                  , UDA_SYS_LSMD_TS = Current_timestamp
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_orgn_pcsn_dcd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

//원장 카드몰 업데이트(D상태일때 식별키있는경우)
async function updateLdgrCsm(assz_unfc_id, assz_orgn_pcsn_dcd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai072m
              set 
                  assz_orgn_pcsn_dcd = $2  
                  , UDA_SYS_LSMD_TS = Current_timestamp
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_orgn_pcsn_dcd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

async function updateLdgrIis(assz_unfc_id, assz_orgn_pcsn_dcd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai074m
              set 
                  assz_orgn_pcsn_dcd = $2  
                  , UDA_SYS_LSMD_TS = Current_timestamp
      where assz_unfc_id = $1
    `,
      [assz_unfc_id, assz_orgn_pcsn_dcd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 원장마스터 업데이트(U일때 식별키가 존재할때)
 * @param {*} pool
 * @param {*} basDt
 * @param {*} tableName
 * @returns
 */
async function updateLdgrMaster01(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  file_name,
  assz_scd,
  eror_vl,
  assz_eror_con
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  const fileInfo = await getFileInfo(file_name);
  const modfileSize = String(fileInfo.size);
  const modencpRnnmVl = fileInfo.md5;

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set 
        uda_sys_lsmd_ts = Current_timestamp
        , assz_btch_acmp_id = $2
        , assz_pcsn_tcd = 'U'
        , flsz_vl = $3 
        , assz_orgn_file_encp_rnnm_vl = $4
        , MDFC_YMD = to_char(now(),'YYYYMMDD')
        , assz_scd = $5
        , eror_vl = $6
        , assz_eror_con = $7
      where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        modfileSize,
        modencpRnnmVl,
        assz_scd,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 원장마스터 업데이트(U일때 식별키가 존재할때)
 * @param {*} pool
 * @param {*} basDt
 * @param {*} tableName
 * @returns
 */
async function updateLdgrMnlMaster01(
  pool,
  assz_unfc_id,
  file_nm,
  file_sqn,
  assz_orcp_file_path_nm,
  orgn_data_rgsr_id,
  rgsn_ts,
  amnn_ts,
  assz_orgn_pcsn_dcd,
  assz_dcmn_clsf_id,
  conn_ttl_nm,
  url_adr,
  sub_ttl_nm
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai003m
      set 
        uda_sys_lsmd_ts = Current_timestamp
        , file_nm = $2
        , file_sqn = $3
        , assz_orcp_file_path_nm = $4
        , orgn_data_rgsr_id = $5
        , rgsn_ts = TO_TIMESTAMP($6,'YYYYMMDDHH24MISS')
        , amnn_ts = TO_TIMESTAMP($7,'YYYYMMDDHH24MISS')
        , assz_orgn_pcsn_dcd = $8
        , assz_dcmn_clsf_id = $9
        , conn_ttl_nm = $10
        , url_adr = $11
        , sub_ttl_nm = $12
      where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm, //원천메타 recv 에서 들어온 경로
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        assz_dcmn_clsf_id,
        conn_ttl_nm,
        url_adr,
        sub_ttl_nm,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

//jsonMerge01 에서 마지막에 자산화상태코드를 정상으로 바꾸는 쿼리
async function updateLdgrMnlForNormalcy(assz_btch_acmp_id, assz_scd) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);

  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set
        assz_scd = $2
      where eror_vl = '0003'
      and assz_btch_acmp_id = $1
    `,
      [assz_btch_acmp_id, assz_scd]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 학습용 txt 파일 ==> /data/train_data/rawdata/iemieb/year(2025)/ 로 카피하는 기능
 */
async function selectTxtFileCopyToLearn(pool, sysName, assz_btch_acmp_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }

  const depth1 = sysName.substring(0, 3);
  let depth2 = sysName.substring(3, 6);
  if (depth2.toLowerCase() == "wpt") {
    //depth2 = "wpt/endn";
  } else if (depth2.toLowerCase() == "epn" || depth2.toLowerCase() == "plz") {
    depth2 = "wpt/epnt";
  }
  const sysNameUpper = sysName.toUpperCase();
  writeLog(`${depth1}::::${depth2}::::::${sysNameUpper}`);

  const client = await pool.connect();
  try {
    let column_sql = "";
    if (sysNameUpper == "AIKKMS") {
      column_sql = `
        , b.apnd_file_rgsn_ts
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.apnd_file_rgsn_ts,'YYYY') as tgtDir
        , '/data/asset/'||$1||'/'||$2||'/txt/'||to_char(b.apnd_file_rgsn_ts,'YYYY')||'/'||a.assz_unfc_id||'.txt' as srcTxtFile
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.apnd_file_rgsn_ts,'YYYY')||'/'||a.assz_unfc_id||'.txt' as tgtTxtFile
      `;
    } else if (sysNameUpper == "IEMIEA") {
      column_sql = `
        , '/data/train_data/rawdata/'||$3 as tgtDir
        , '/data/asset/'||$1||'/'||$2||'/txt/'||a.assz_unfc_id||'.txt' as srcTxtFile
        , '/data/train_data/rawdata/'||$3||'/'||a.assz_unfc_id||'.txt' as tgtTxtFile
      `;
    } else if (sysNameUpper == "IEMIEB") {
      column_sql = `
        , b.amnn_ts as amnn_ts      
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY') as tgtDir        
        , '/data/asset/'||$1||'/'||$2||'/txt/'||a.assz_cfbo_idnt_id||'.txt' as srcTxtFile
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY')||'/'||A.assz_cfbo_idnt_id||'.txt' as tgtTxtFile  
      `;
    } else if (sysNameUpper == "IISIIS") {
      column_sql = `
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY') as tgtDir        
        , '/data/asset/'||$1||'/'||$2||'/txt/'||b.file_nm||'.txt' as srcTxtFile
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY')||'/'||b.file_nm||'.txt' as tgtTxtFile  
      `;
    } else {
      column_sql = `
        , a.assz_cfbo_idnt_id
        , b.amnn_ts as amnn_ts      
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY') as tgtDir        
        , '/data/asset/'||$1||'/'||$2||'/txt/'||a.assz_unfc_id||'.txt' as srcTxtFile
        , '/data/train_data/rawdata/'||$3||'/'||to_char(b.amnn_ts,'YYYY')||'/'||A.assz_unfc_id||'.txt' as tgtTxtFile  
      `;
    }

    let sql = `
      select 
        a.assz_unfc_id as doc_id
        ${column_sql}     
      from tb_uda_uai000m a
    `;
    if (sysNameUpper == "KMSWPT") {
      sql += `
        join tb_uda_uai001m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    } else if (sysNameUpper == "KMSEPN" || sysNameUpper == "KMSPLZ") {
      sql += `
        join tb_uda_uai071m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    } else if (sysNameUpper == "CSMCSM") {
      sql += `
        join tb_uda_uai072m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    } else if (sysNameUpper == "IEMIEB") {
      sql += `
      join tb_uda_uai003m b on (a.assz_unfc_id = b.assz_unfc_id )
      `;
    } else if (sysNameUpper == "IISIIS") {
      sql += `
        join tb_uda_uai074m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    } else if (sysNameUpper == "AIKKMS") {
      sql += `
        join tb_uda_uai005m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    } else if (sysNameUpper == "IEMIEA") {
      sql += `
        join tb_uda_uai004m b on a.assz_unfc_id = b.assz_unfc_id
      `;
    }

    let where_sql = "";
    if (sysNameUpper == "AIKKMS") {
      where_sql = `
        and a.eror_vl = '0000' -- 추가정보메타건만, HTML은 text변환 없음
        and b.apnd_file_rgsn_ts >= current_date - interval '4years'
      `;
    } else if (sysNameUpper == "IEMIEA") {
      where_sql = `
        and a.eror_vl = '0000'
      `;
    } else {
      where_sql = `
        and a.eror_vl = '0000'
        and b.amnn_ts >= current_date - interval '4years'
      `;
    }

    sql += `
      where 1=1
      ${where_sql}
      and a.assz_pcsn_tcd in ('C', 'U')
      ${
        assz_btch_acmp_id
          ? "and a.assz_btch_acmp_id = '" + assz_btch_acmp_id + "'"
          : ""
      }
      order by a.assz_unfc_id 
    `;

    //console.log(">>>", sql);
    const result = await client.query(sql, [depth1, depth2, sysName]);
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

function getSafeBaseDt(baseDt) {
  let year = baseDt.substring(0, 4);
  let month = baseDt.substring(4, 6);
  let day = baseDt.substring(6, 8);

  let rtnYear = 0;
  let rtnMonth = 0;
  let rtnDay = 0;

  for (let i = 1900; i <= 3000; i++) {
    if (i == Number(year)) {
      rtnYear = String(i);
    }
  }

  for (let i = 1; i <= 12; i++) {
    if (i == Number(month)) {
      rtnMonth = String(i);
    }
  }

  for (let i = 1; i <= 31; i++) {
    if (i == Number(day)) {
      rtnDay = String(i);
    }
  }

  let baseDtJoin = [
    rtnYear,
    rtnMonth.padStart(2, "0"),
    rtnDay.padStart(2, "0"),
  ].join("");

  const baseDtConvJobVal = baseDtJoin
    .substring(0, 8)
    .replace(/\.[^/.]+$/, "")
    .replace(/\.\./g, "");

  console.log("baseDtConvJobVal======>>>>" + baseDtConvJobVal);
  const regex1 = /^\d{8}$/;
  if (!regex1.test(baseDtConvJobVal)) {
    return "";
  } else {
    return baseDtConvJobVal;
  }
}

/**
 * 비식별화 마스터 추가
 */
async function insertAnonymizedData(pool, assz_unfc_id, targetPath, batchId) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }

  const client = await pool.connect();
  try {
    //console.log(">>>", sql);
    const result = await client.query(
      `
            INSERT INTO tb_anonymized_data
            (anonymized_data_id, document_id, approval_no, executed_at, target, file_path, registered_branch, registered_by, registered_at, updated_by, updated_at, del_yn)
            SELECT
              qidp.get_next_seq('anonymized_data_id', 8) as anonymized_data_id
            ,  $1::varchar AS document_id
            , null AS approval_no
            , null AS executed_at
            , 'Y' AS target
            , $2 AS file_path
            , registered_branch as registered_branch
            , registered_by as registered_by
            , registered_at as registered_at
            , $3 as updated_by
            , current_timestamp as updated_at
            , 'N' as del_yn
            from tb_document
            where document_id = $1::varchar
            RETURNING anonymized_data_id;
            `,
      [assz_unfc_id, targetPath, batchId]
    );
    return result.rows[0].anonymized_data_id;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 비식별화 상세 추가
 */
async function insertAnonymizedDataDetail(
  pool,
  anonymized_data_id,
  deid_data_id,
  normalized_data,
  batchId
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }

  const client = await pool.connect();
  try {
    //console.log(">>>", sql);
    const result = await client.query(
      `
            INSERT INTO tb_anonymized_data_detail
            (anonymized_data_id, seq, deid_data_id, normalized_data, registered_branch, registered_by, registered_at, updated_by, updated_at, del_yn)
            SELECT
              $1 AS anonymized_data_id
              , (select coalesce(max(seq)+1,1)
                      from tb_anonymized_data_detail
                      where anonymized_data_id = $1::VARCHAR) AS seq
              , $2 AS deid_data_id
              , $3 AS normalized_data
              , null AS registered_branch
              , $4 AS registered_by
              , current_timestamp AS registered_at
              , $4 AS updated_by
              , current_timestamp AS updated_at
              , 'N' AS del_yn
            `,
      [anonymized_data_id, deid_data_id, normalized_data, batchId]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 비식별화 상세 추가
 */
async function deleteAnonymizedData(pool, assz_unfc_id) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }

  const client = await pool.connect();
  try {
    //console.log(">>>", sql);
    let result = await client.query(
      `
        delete from tb_anonymized_data_detail
        where anonymized_data_id in (select anonymized_data_id from tb_anonymized_data where document_id = $1);
      `,
      [assz_unfc_id]
    );

    result = await client.query(
      `
        delete from tb_anonymized_data
        where document_id = $1;
      `,
      [assz_unfc_id]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 원장마스터 업데이트(파일없음일때)
 * @param {*}   pool
 * @param {*}   assz_unfc_id,
 * @param {*}   assz_btch_acmp_id,
 * @param {*}   file_name,
 * @param {*}   assz_scd,
 * @param {*}   eror_vl,
 * @param {*}   assz_eror_con
 * @returns
 */
async function updateLdgrMaster02(
  pool,
  assz_unfc_id,
  assz_btch_acmp_id,
  file_name,
  assz_scd,
  eror_vl,
  assz_eror_con
) {
  let isCreatePool = false;
  if (pool == null) {
    isCreatePool = true;
    pool = new Pool(config.db);
  }
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      update tb_uda_uai000m
      set 
        uda_sys_lsmd_ts = Current_timestamp
        , assz_btch_acmp_id = $2
        , assz_pcsn_tcd = 'U'
        , flsz_vl = $3 
        , assz_orgn_file_encp_rnnm_vl = $4
        , MDFC_YMD = to_char(now(),'YYYYMMDD')
        , assz_scd = $5
        , eror_vl = $6
        , assz_eror_con = $7
      where assz_unfc_id = $1
      `,
      [
        assz_unfc_id,
        assz_btch_acmp_id,
        0,
        null,
        assz_scd,
        eror_vl,
        assz_eror_con,
      ]
    );
    return result;
  } finally {
    client.release();
    if (isCreatePool) {
      pool.end();
    }
  }
}

/**
 * 수명주기 문서조회
 */
async function selectCountLifecycle(document_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        SELECT COUNT(*) FROM tb_lifecycle_target
        WHERE document_id = $1
      `,
      [document_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 수명주기 저장
 */
async function insertLifecycle(
  assz_unfc_id,
  orgn_data_rgsr_id,
  rgsr_dept_id,
  rgsn_ts,
  uda_sys_lsmd_id
) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      INSERT INTO tb_lifecycle_target (
        lifecycle_id,
        document_id,
        approval_no,
        lifecycle_target_yn,
        renewal_cycle_code,
        expiration_at,
        registered_branch,
        registered_by,
        registered_at,
        updated_by,
        updated_at,
        del_yn
      ) VALUES (
        (SELECT get_next_seq('lifecycle_id', 8)), -- lifecycle_id
        $1, -- document_id
        '', -- approval_no
        'N', -- lifecycle_target_yn
        '', -- renewal_cycle_code
        '2999-12-31 23:59:59', -- expiration_at
        $2, -- registered_branch
        $3, -- registered_by
        $4, -- registered_at
        $5, -- updated_by
        current_timestamp, -- updated_at
        'N' -- del_yn
      )
      `,
      [assz_unfc_id, orgn_data_rgsr_id, rgsr_dept_id, rgsn_ts, uda_sys_lsmd_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 문서 폐기처리
 */
async function discardDocument(document_id) {
  const { Pool } = require("pg");
  const config = require("../config");
  const pool = new Pool(config.db);
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
        update tb_document set
          assetization_status = 'DISCARD'
        WHERE document_id = $1
      `,
      [document_id]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 자산화결과전송 저장
 */
async function insertAssetResultSend(
  assz_btch_acmp_id,
  assz_trms_tgt_sys_dcd,
  error_log
) {
  let pool = new Pool(config.db);

  const client = await pool.connect();
  try {
    let transmitted_at = dayjs().format("YYYY-MM-DD HH:mm:ss");
    let transmission_status = "SUCCESS";
    if (error_log) {
      transmission_status = "FAIL";
    }
    const result = await client.query(
      `
        INSERT INTO tb_assetization_transmission (
          transmission_id,
          batch_integrated_id,
          mapping_system_id,
          source_system,
          integration_task_code,
          transmitted_at,
          transmission_status,
          error_log,
          registered_branch,
          registered_by,
          registered_at,
          updated_by,
          updated_at,
          del_yn
        )
        SELECT
          get_next_seq('transmission_id', 8) as transmission_id,
          assz_btch_acmp_id as  batch_integrated_id,
          case 
            when assz_trms_tgt_sys_dcd = '02' then (select interface_id from tb_interface_system where target_system = 'GAIGAI' limit 1)
            when assz_trms_tgt_sys_dcd = '03' then (select interface_id from tb_interface_system where target_system = 'AVTAVT' limit 1)
          end as mapping_system_id,
          substring(assz_btch_acmp_id, 9, 6) as source_system,
          'BAT' as integration_task_code,
          $3 as transmitted_at,
          $4 as transmission_status,
          $5 as error_log,
          '' as registered_branch,
          uda_sys_lsmd_id as registered_by,
          uda_sys_lsmd_ts as registered_at,
          uda_sys_lsmd_id as updated_by,
          uda_sys_lsmd_ts as updated_at,
          'N' as del_yn
        from tb_uda_uai900m 
        where assz_btch_acmp_id = $1
        and assz_trms_tgt_sys_dcd = $2
        and assz_btch_tcd = '03'
      `,
      [
        assz_btch_acmp_id,
        assz_trms_tgt_sys_dcd,
        transmitted_at,
        transmission_status,
        error_log,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

/**
 * 자산화품질관리 저장
 */
async function insertQualityMng(
  assz_unfc_id,
  trans_file_name,
  doc_type,
  dup_char_rate,
  dup_word_rate,
  lcs_rouge,
  meteor,
  bert,
  uda_sys_lsmd_id
) {
  let pool = new Pool(config.db);

  const client = await pool.connect();
  try {
    const result = await client.query(
      `
        INSERT INTO tb_quality_management (
          quality_mgmt_id,
          document_id,
          trans_file_name,
          doc_type,
          dup_char_rate,
          dup_word_rate,
          lcs_rouge,
          meteor,
          bert,
          registered_branch,
          registered_by,
          registered_at,
          updated_by,
          updated_at,
          del_yn
        )
        VALUES (
          get_next_seq('quality_mgmt_id', 8),
          $1,
          $2,
          $3,
          $4,
          $5,
          $6,
          $7,
          $8,
          '',
          $9,
          current_timestamp,
          $9,
          current_timestamp,
          'N'
        )
      `,
      [
        assz_unfc_id,
        trans_file_name,
        doc_type,
        dup_char_rate,
        dup_word_rate,
        lcs_rouge,
        meteor,
        bert,
        uda_sys_lsmd_id,
      ]
    );
    return result;
  } finally {
    client.release();
    pool.end();
  }
}

module.exports = {
  getBatchId,
  batchStart,
  EROR_CODES,
  COMMON_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  insertLdgrRecvPool,
  updateLdgrSelfPool,
  updateLdgrRecvPool,
  getFileInfo,
  updateLdgrBatIdStatus,
  updateLdgrDupCreateData,
  insertLdgrForSendData,
  insertLdgrSelfPoolByJsonMerge01,
  updateOrgin,
  masterMetaSort,
  updateLdgrUpdateSelfPool,
  moveAssetData,
  updateLdgrByJsonMerge01,
  chkAllDataStatus,
  sync,
  finFileCheck,
  finFileCreate,
  updateLdgrByJsonMerge02,
  ldgrDataByAsszCfboIdntId,
  getldgrDataByBatchId,
  recvMetaFileCheck,
  getAsszUnfcIdByIeb,
  fileRename,
  selectUai022mByFileRename,
  selectByFileRenameBaseYmd,
  updateLdgrUpdateFileNmSelfPool,
  selectByFileRenameByBaseYmd,
  isImageMagick,
  selectLastBatchId,
  selectByFileRenameByBatchId,
  mergeDocument,
  insertLdgrMaster,
  insertLdgrManual,
  insertLdgrEpnPlz,
  insertLdgrCsm,
  insertLdgrIis,
  updateLdgrMnl,
  updateLdgrEpnPlz,
  updateLdgrCsm,
  updateLdgrIis,
  updateLdgrMaster01,
  updateLdgrMnlMaster01,
  updateLdgrByJsonMerge01_01,
  updateLdgrMnlForNormalcy,
  selectTxtFileCopyToLearn,
  getSafeBaseDt,
  updateAllLdgrSelfPool,
  updateAllLdgrEpnPlz,
  insertAnonymizedData,
  insertAnonymizedDataDetail,
  deleteAnonymizedData,
  updateLdgrMaster02,
  selectCountLifecycle,
  insertLifecycle,
  discardDocument,
  insertAssetResultSend,
  insertQualityMng,
};
