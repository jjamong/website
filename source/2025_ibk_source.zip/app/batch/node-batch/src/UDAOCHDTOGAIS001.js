const fs = require("fs");
const path = require("path");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const dbBatch = require("../sql/TB_UDA_UAI900M");
const dbMetaMain = require("../sql/TB_UDA_UAI807L");
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dayjs = require("dayjs");
const in_assz_btch_acmp_id = process.argv[4];
const { exec } = require("child_process");

const {
  updateFileInfo,
  updateBatchId,
  selectOneOch,
  updateErorVl,
} = require("../sql/TB_UDA_UAI000M");
const { insertHistory } = require("../sql/TB_UDA_UAI000H");
const {
  getBatchId,
  batchStart,
  EROR_CODES,
  getUnfcId,
  selectUnfcSeq,
  insertLdgrSelfPool,
  getFileInfo,
  updateLdgrBatIdStatus,
  sync,
  finFileCheck,
  recvMetaFileCheck,
  moveAssetData,
  finFileCreate,
  getSafeBaseDt,
  insertAssetResultSend
} = require("./common");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------

if (
  pcsnClCd !== "01" &&
  pcsnClCd !== "02" &&
  pcsnClCd !== "99" &&
  pcsnClCd !== "98" &&
  pcsnClCd !== "97"
) {
  writeLog("error node UDAOCHDASSETR001.js clcd(처리구분:01) YYYYMMDD");
}
if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("ERROR UDAOCHDASSETR001.js YYYYMMDD");
  process.exit(1);
}

async function makeJson(btchAcmpId) {
  writeLog(
    "----------------------------makeJson()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const metaData = await dbMetaMain.selectMeta(btchAcmpId);

  let datas = [];

  for (const rowMetaData of metaData.rows) {
    const {
      assz_btch_acmp_id,
      assz_unfc_id,
      assz_meta_pcsn_sqn,
      assz_cfbo_idnt_id,
      rgsn_ts,
      amnn_ts,
      assz_chb_conn_url_adr,
      assz_pcsn_file_path_nm,
      assz_dcmn_clsf_id,
      hdlr_id,
    } = rowMetaData;

    totalCnt++;

    if (assz_pcsn_file_path_nm) {
      const data = fs.readFileSync(assz_pcsn_file_path_nm, "utf8");

      const [q, a] = data.split("^|").map((s) => s.trim());

      datas.push({
        assz_unfc_id: assz_unfc_id,
        assz_cfbo_idnt_id: assz_cfbo_idnt_id,
        q: q,
        a: a,
        assz_dcmn_clsf_id: assz_dcmn_clsf_id,
        assz_chb_conn_url_adr: assz_chb_conn_url_adr,
      });
      successCnt++;
    } else {
      failCnt++;
    }
  }

  if (datas.length > 0) {
    const fileName = `UDA_OCH_GAI_${basDt}.json`;
    const asszPath = `/data/asset/chb/och/${basDt}/json/${fileName}`;
    const sendPath = `/data/bdpetl/send/gai/gai/och/${basDt}/${fileName}`;

    fs.writeFileSync(asszPath, JSON.stringify(datas, null, 2), "utf8");
    writeLog(`자산화파일 저장완료 ${asszPath}`);
    fs.writeFileSync(sendPath, JSON.stringify(datas, null, 2), "utf8");
    writeLog(`전송폴더 저장완료 ${sendPath}`);
  }
  summaryLog(totalCnt, successCnt, failCnt, btchAcmpId, "makeJson");
  writeLog(
    "----------------------------makeJson()종료----------------------------"
  );
}

async function makeDir() {
  const dirs = [
    `/data/asset/chb/och/${basDt}/json`,
    `/data/asset/chb/och/${basDt}/origin`,
    `/data/asset/chb/och/${basDt}/pdf`,
    `/data/asset/chb/och/${basDt}/html`,
    `/data/bdpetl/send/gai/gai/och/${basDt}`,
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

async function main() {
  writeLog(
    "----------------------------챗봇 batch 시작----------------------------"
  );

  if (pcsnClCd == "01") {
    // 배치수행로그 입력 및 배치ID채번
    const batchId = getBatchId(process.argv[1]);
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "CHBOCH",
      "03", //01  수집 02 자산화 03  전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1 메타+파일 T2  DB T3 지식샘
      "02" //assz_tgt_sys_cd
    );

    writeLog(`기준일자 수집배치ID ${assz_btch_acmp_id}`);
    if (assz_btch_acmp_id != null) {
      let error_log;
      try {
        // 폴더 생성
        await makeDir();
        // sam파일 생성
        await makeJson(assz_btch_acmp_id);
      } catch (e) {
        error_log = e;
      }
      // 서버간 전송 파일 동기화
      await sync(`/data/bdpetl/send/gai/gai/och/${basDt}/`);
      // 자산화결과전송 저장
      await insertAssetResultSend(assz_btch_acmp_id, "02", error_log);
    } else {
      writeLog(`기준일자 수집배치ID 존재하지않음 ${basDt}`);
    }

    // fin파일 생성
    await finFileCreate("/data/bdpetl/send/gai/gai/och", basDt);
    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "03", "02");
  } else if (pcsnClCd == "02") {
    await makeJson(in_assz_btch_acmp_id);

    // await pdfCreate(in_assz_btch_acmp_id); //파일 원본 경로로 옮기고 DB INSERT
    // await makeMeta(in_assz_btch_acmp_id);
    // await gaiFileCopy(in_assz_btch_acmp_id);
  }
  await dbBatch.dbEnd();
  await dbMetaMain.dbEnd();
  writeLog(
    "----------------------------챗봇 batch 종료----------------------------"
  );
  return true;
}
main();
