// STD MODULE
const fs = require("fs");
const { writeLog } = require("../log"); // 로그 모듈

const { make_access_101sam } = require("../make_access_101sam");
const { make_access_102sam } = require("../make_access_102sam");
const { getSafeBaseDt } = require("./common");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  writeLog("error node iemieb.js YYYYMMDD:::::" + safeBasDt);
  process.exit(1);
}
writeLog("node iemieb.js YYYYMMDD:::::" + safeBasDt);
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const in_assz_btch_acmp_id = process.argv[4];

if (pcsnClCd !== "01") {
  writeLog("error UDAWPTDTOGAIS002.js clcd(처리구분:01) YYYYMMDD");
  process.exit(1);
}

async function makeDir() {
  const dirs = [`/data/bdpetl/send/gai/gai/auth/${basDt}`];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃kmswpt AUTH 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    await makeDir();

    await make_access_101sam(basDt);
    await make_access_102sam(basDt);
  }

  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃kmswpt AUTH 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃"
  );
}

main();
