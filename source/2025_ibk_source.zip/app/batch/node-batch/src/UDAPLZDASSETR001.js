﻿const fs = require("fs");
const path = require("path");
const dayjs = require("dayjs");
const { exec } = require("child_process");

const util = require("../util");
const { writeLog, summaryLog } = require("../log"); // 로그 모듈
const { mergeJsonFiles } = require("/app/jsonmerge/jsonmerge");
const dbMetaProd = require("../sql/TB_UDA_UAI871M"); //업무포탈 메타
const dbAssetLog = require("../sql/TB_UDA_UAI901L"); //자산화 처리로그
const dbGaiMeta = require("../sql/TB_UDA_GAI_META"); //GPT 전송 META파일
const dbAssetRlt = require("../sql/TB_UDA_UAI910L"); //자산화 처리로그
const dbImgRlt = require("../sql/TB_UDA_UAI912L");
const dbBatch = require("../sql/TB_UDA_UAI900M"); //배치로그

const {
  checkUnfcId,
  updateFileInfo,
  getUnfcIdFromIdntId,
  getUnfcIdFromTodayCheckId,
  updateBatchId,
  updateErorVl,
  selectMetaDocNmEpn,
  updateOnlyAsszScd,
  checkFmtsBaseUnfcIdEpn,
} = require("../sql/TB_UDA_UAI000M");

const {
  EROR_CODES,
  COMMON_CODES,
  batchStart,
  getBatchId,
  getUnfcId,
  selectUnfcSeq,
  updateLdgrSelfPool,
  getFileInfo,
  updateLdgrDupCreateData,
  moveAssetData,
  sync,
  finFileCheck,
  insertLdgrMaster,
  insertLdgrEpnPlz,
  updateLdgrEpnPlz,
  mergeDocument,
  getSafeBaseDt,
  updateAllLdgrSelfPool,
  updateAllLdgrEpnPlz,
  recvMetaFileCheck,
  finFileCreate,
} = require("./common");

const pcsnClCd = process.argv[2];
//외부입력 basDt 값 검증 시작------------------------------------------------------------
const basDtArg = process.argv[3];
let safeBasDt = getSafeBaseDt(basDtArg);
if (safeBasDt == "") {
  process.exit(1);
}
const basDt = safeBasDt;
//외부입력 basDt 값 검증 종료------------------------------------------------------------
const in_assz_btch_acmp_id = process.argv[4];
const batchId = getBatchId(process.argv[1]);

const baseAssetPath = `/data/asset/kms/wpt/epnt/${basDt}`;

const includeObj = {
  안내문: "PLZEPN001",
  간이: "PLZEPN002",
  투자설명서: "PLZEPN002",
  약관: "PLZEPN003",
  특약: "PLZEPN003",
  상품설명서: "PLZEPN004",
};

const includeList = Object.keys(includeObj);

if (
  pcsnClCd !== "01" &&
  pcsnClCd !== "02" &&
  pcsnClCd !== "03" &&
  pcsnClCd !== "04" &&
  pcsnClCd !== "99" &&
  pcsnClCd !== "98" &&
  pcsnClCd !== "97"
) {
  writeLog("error UDAPLZDASSETR001.js clcd(처리구분:01) YYYYMMDD");
  process.exit(1);
}

if (!basDt || !/^\d{8}$/.test(basDt)) {
  writeLog("error node kmsepn.js YYYYMMDD");
  process.exit(1);
}

/*----------------------DRM해제 작업----------------------*/

async function drmUnlock() {
  writeLog(
    "----------------------------drmUnlock()시작----------------------------"
  );
  const dirs = ["origin", "att"];
  let result = "";

  try {
    fs.mkdirSync(baseAssetPath, { recursive: true });
  } catch (err) {
    writeLog(`디렉터리 생성 실패 : ${baseAssetPath}:${err}`);
  }
  for (const dir of dirs) {
    const fullPath = `${baseAssetPath}/${dir}/`;
    const command = `sh /app/drm/unpack_auto.sh ${fullPath}`;
    try {
      result = await util.executeCommand(command, "/app/drm");
      writeLog(result);
    } catch (err) {
      writeLog(`drm오류: ${fullPath}`);
    }
  }
  writeLog(
    "----------------------------drmUnlock()종료----------------------------"
  );
}

async function dl(data) {
  return await new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      if (error) {
        resolve({
          success: false,
          chgFullPath: data.chgFullPath,
          ext: data.ext,
        });
      }
      if (stderr) {
        if (!stderr.includes("Log4j")) {
          resolve({
            success: false,
            chgFullPath: data.chgFullPath,
            ext: data.ext,
          });
        }
      }
      resolve({
        success: true,
        chgFullPath: data.chgFullPath,
        ext: data.ext,
      });
    });
  });
}

async function drawLine(assz_btch_acmp_id) {
  writeLog(
    "----------------------------drawline()시작----------------------------"
  );
  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const commands = [];

  const extensions = [".hwp", "hwpx", "docx"];

  const attPath = `${baseAssetPath}/att`;
  const originPath = `${baseAssetPath}/origin`;

  let attFiles = fs.readdirSync(attPath);
  attFiles.forEach((file) => {
    const ext = path.extname(file);
    const filePath = path.join(attPath, file);
    // Drawline 대상파일만 수행
    if (extensions.includes(path.extname(file).toLowerCase())) {
      if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, `${filePath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${filePath}${ext}" "${filePath}" 10`;
      commands.push({
        command: command,
        filePath: filePath,
        ext: ext,
      });
    }
  });

  let originFiles = fs.readdirSync(originPath);
  originFiles.forEach((file) => {
    const ext = path.extname(file);
    const filePath = path.join(originPath, file);
    // Drawline 대상파일만 수행
    if (extensions.includes(path.extname(file).toLowerCase())) {
      if (fs.existsSync(filePath)) {
        fs.copyFileSync(filePath, `${filePath}${ext}`);
      }

      let command = `java -jar /app/hwpline/qt-document-fixer-fat-1.2.2.jar file_timeout "${filePath}${ext}" "${filePath}" 10`;
      commands.push({
        command: command,
        filePath: filePath,
        ext: ext,
      });
    }
  });

  const tasks = commands.map((data, idx) => limit(() => dl(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
      writeLog(`Drawline 실패: ${result.filePath}`);
    }

    const tmpFilename = `${result.filePath}${result.ext}`;

    if (fs.existsSync(tmpFilename)) {
      fs.unlinkSync(tmpFilename);
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "drawline");
  writeLog(
    "----------------------------drawline()종료----------------------------"
  );
}

function masterMetaSort(fullPath, index) {
  const meta = fs.readFileSync(fullPath, "utf-8");
  let lines = meta.split("\n");

  return lines.sort((a, b) => {
    const aFields = a.split("^|");
    const bFields = b.split("^|");

    const aKey = aFields[index] || "";
    const bKey = bFields[index] || "";

    return aKey.localeCompare(bKey);
  });
}

/*---------------------- 파일 copy ----------------------*/
async function prodFileCopy(assz_btch_acmp_id) {
  writeLog(
    "----------------------------prodFileCopy()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  if (
    fs.existsSync(
      `/data/bdpetl/recv/kms/wpt/${basDt}/meta_plaza/PRODUCT_PLAZA.dat`
    )
  ) {
    let lines_m = masterMetaSort(
      `/data/bdpetl/recv/kms/wpt/${basDt}/meta_plaza/PRODUCT_PLAZA.dat`,
      6
    );

    // 자산화통합ID 마지막 seq 가져오기
    let result = await selectUnfcSeq(null, "KMSPLZ");
    let idx = result.rows[0].idsqn;

    for (const line of lines_m) {
      if (line.trim() === "") continue;
      let [
        assz_cfbo_idnt_id,
        file_nm,
        file_sqn,
        assz_orcp_file_path_nm,
        orgn_data_rgsr_id,
        rgsn_ts,
        amnn_ts,
        assz_orgn_pcsn_dcd,
        atch_yn,
        atch_sqn,
        assz_dcmn_clsf_id,
        assz_fmts_base_orgn_idnt_id,
        conn_ttl_nm,
        rgsr_dept_id,
        use_sttg_ymd,
        use_fnsh_ymd,
        sale_info_con,
        assz_dcmn_clsf_con,
        atch_nm,
      ] = line.split("^|");
      totalCnt++;

      if (file_sqn == "" || file_sqn == null || file_sqn == "null") {
        file_sqn = 0;
      }
      if (atch_sqn == "" || atch_sqn == null || atch_sqn == "null") {
        atch_sqn = 0;
      }
      if (atch_yn == "" || atch_yn == null || atch_yn == "null") {
        atch_yn = "";
      }

      if (
        use_sttg_ymd == "" ||
        use_sttg_ymd == null ||
        use_sttg_ymd == "null"
      ) {
        use_sttg_ymd = null;
      }
      if (
        use_fnsh_ymd == "" ||
        use_fnsh_ymd == null ||
        use_fnsh_ymd == "null"
      ) {
        use_fnsh_ymd = null;
      }
      if (
        sale_info_con == "" ||
        sale_info_con == null ||
        sale_info_con == "null"
      ) {
        sale_info_con = null;
      }
      if (
        assz_dcmn_clsf_con == "" ||
        assz_dcmn_clsf_con == null ||
        assz_dcmn_clsf_con == "null"
      ) {
        assz_dcmn_clsf_con = null;
      }

      if (
        assz_cfbo_idnt_id == "" ||
        assz_cfbo_idnt_id == undefined ||
        assz_cfbo_idnt_id == null
      ) {
        //writeLog(`원천별식별키없음 ${assz_cfbo_idnt_id}`);
        //failCnt++;
        continue;
      } else {
        /**
         *   이전식별키로 unfc 조회 (존재한다면 Update 건, 없으면 신규)
         */
        let { rows } = await checkFmtsBaseUnfcIdEpn(
          assz_fmts_base_orgn_idnt_id,
          assz_cfbo_idnt_id
        );

        let assz_unfc_id = "";
        const ext = path.extname(file_nm).toLowerCase();
        let targetFileName = "";
        let chgFullPath;

        let filename = `/data/bdpetl/recv/kms/wpt/${basDt}/file_plaza`;

        if (assz_orcp_file_path_nm.endsWith("/")) {
          filename = filename + `${assz_orcp_file_path_nm}${file_nm}`;
        } else {
          filename = filename + `${assz_orcp_file_path_nm}/${file_nm}`;
        }

        let todayRow = await getUnfcIdFromTodayCheckId(
          "KMSPLZ",
          assz_cfbo_idnt_id,
          assz_fmts_base_orgn_idnt_id,
          file_sqn,
          atch_sqn,
          basDt
        );

        try {
          fs.accessSync(filename);
        } catch (err) {
          writeLog(`파일없음: ${filename}`);
          assz_unfc_id = await getUnfcId("KMSPLZ", ++idx);

          targetFileName = `${assz_unfc_id}${ext}`;
          
          // 재수행이 아닐 경우
          if (todayRow.rowCount == 0) {
            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND,
              EROR_CODES.EROR_VL_COPY_FILE_NOT_FOUND_STR,
              `${baseAssetPath}/originpdf/${targetFileName}`, //assz_pcsn_file_path_nm,
              null,
              null,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrEpnPlz(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              assz_fmts_base_orgn_idnt_id,
              orgn_data_rgsr_id,
              targetFileName,
              file_sqn,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              rgsr_dept_id,
              assz_orcp_file_path_nm,
              atch_yn,
              atch_sqn,
              atch_nm,
              use_sttg_ymd,
              use_fnsh_ymd,
              sale_info_con,
              assz_dcmn_clsf_con,
              batchId
            );
          }

          //히스토리 인서트 없음
          failCnt++;
          continue;
        }

        /**
         * fileinfo 저장, 파일크기, 난수값
         */
        const fileInfo = await getFileInfo(filename);

        // 같은 년월일에 배치 재수행 시 원장수행은 PASS, 배치ID는 업데이트
        if (todayRow.rowCount > 0) {
          writeLog(`이미 처리함 ${assz_cfbo_idnt_id}`);
          assz_unfc_id = todayRow.rows[0].assz_unfc_id;
          targetFileName = `${assz_unfc_id}${ext}`;
          await updateBatchId(todayRow.rows[0].assz_unfc_id, assz_btch_acmp_id);
          
          let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분
          const targetPath = `${baseAssetPath}/${dirGb}`;
          chgFullPath = path.join(targetPath, targetFileName);

          if (assz_fmts_base_orgn_idnt_id != assz_cfbo_idnt_id) {
            if (rows.length > 0) {
              writeLog(
                `업데이트 확정건 재처리 ${assz_fmts_base_orgn_idnt_id} -> ${assz_cfbo_idnt_id}`
              );
              // 메타파일 데이터와 원장테이블 데이터 비교 시 변경점이 없을 경우 원장 수행정보 변경
              await updateLdgrDupCreateData(
                null,
                assz_unfc_id,
                assz_btch_acmp_id,
                COMMON_CODES.ASSZ_SCD_INIT,
                EROR_CODES.EROR_VL_SUCCESS,
                EROR_CODES.EROR_VL_SUCCESS_STR
              );
            }
          }
          
        // 재수행이 아닐경우
        } else {
          // 삭제일 경우
          if (assz_orgn_pcsn_dcd == "D") {
            let result = await getUnfcIdFromIdntId(
              "KMSPLZ",
              assz_cfbo_idnt_id,
              atch_sqn
            );

            if (result.rowCount == 0) {
              writeLog(`MBY 삭제건 식별키 찾을 수 없음 ${assz_cfbo_idnt_id}`);
              assz_unfc_id = await getUnfcId("KMSPLZ", ++idx);

              targetFileName = `${assz_unfc_id}${ext}`;

              //원장마스터 인서트
              await insertLdgrMaster(
                null,
                assz_unfc_id,
                COMMON_CODES.ASSZ_SCD_EXCEPTION, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
                assz_cfbo_idnt_id,
                null,
                null,
                assz_orgn_pcsn_dcd,
                EROR_CODES.EROR_VL_UNSUCCESS,
                EROR_CODES.EROR_VL_UNSUCCESS_STR,
                `${baseAssetPath}/originpdf/${targetFileName}`, //assz_pcsn_file_path_nm,
                String(fileInfo.size),
                fileInfo.md5,
                assz_btch_acmp_id,
                batchId
              );

              //업무별원장 인서트
              await insertLdgrEpnPlz(
                null,
                assz_unfc_id,
                assz_cfbo_idnt_id,
                assz_fmts_base_orgn_idnt_id,
                orgn_data_rgsr_id,
                targetFileName,
                file_sqn,
                rgsn_ts,
                amnn_ts,
                assz_orgn_pcsn_dcd,
                assz_dcmn_clsf_id,
                conn_ttl_nm,
                rgsr_dept_id,
                assz_orcp_file_path_nm,
                atch_yn,
                atch_sqn,
                atch_nm,
                use_sttg_ymd,
                use_fnsh_ymd,
                sale_info_con,
                assz_dcmn_clsf_con,
                batchId
              );

              failCnt++;
              continue;
            } else {
              //해당건을 찾았을때 원장테이블에 삭제로 변경
              assz_unfc_id = result.rows[0].assz_unfc_id;
              targetFileName = `${assz_unfc_id}${ext}`;
              //'D'  로 변경
              //원장마스터 업데이트
              await updateLdgrSelfPool(
                assz_unfc_id,
                assz_btch_acmp_id,
                COMMON_CODES.ASSZ_SCD_DELETE
              ); //01 값 확인필요

              //원장은행상품설명서 업데이트
              await updateLdgrEpnPlz(assz_unfc_id, "D");
            }

            let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분
            const targetPath = `${baseAssetPath}/${dirGb}`;
            chgFullPath = path.join(targetPath, targetFileName);

          // 등록, 수정일 경우
          } else {
            assz_unfc_id = await getUnfcId("KMSPLZ", ++idx);
            
            // 수정일 경우
            if (assz_fmts_base_orgn_idnt_id != assz_cfbo_idnt_id) {
              if (rows.length > 0) {
                writeLog(
                  `업데이트 확정건 ${assz_fmts_base_orgn_idnt_id} -> ${assz_cfbo_idnt_id}`
                );
                // 업데이트건 확정
                /**
                 *  자산화이전식별키가 원천식별키에 존재하는경우 수정데이터
                 *  원장에서 기존아이템 삭제 후 신규 생성
                 *  전송메타에 자산화이전식별키 'D', 신규 'C' 두 row가 전송되어야함
                 */

                // 원천 데이터의 이전키 삭제처리
                await updateAllLdgrSelfPool(
                  rows.map((d, i) => d.assz_unfc_id),
                  assz_btch_acmp_id,
                  COMMON_CODES.ASSZ_SCD_DELETE
                );

                // 원장메타 데이터의 이전키 삭제처리
                await updateAllLdgrEpnPlz(rows.map((d, i) => d.assz_unfc_id));
              } else {
                /**
                 * 20250825 cbkim
                 * 이전식별키가 기존에 적재되지 않은경우 (파일없이 원천식별키가 채번된경우 기존 메타가 없을 수 있음)
                 * 이전 원천키가 없으므로 삭제보낼필요없음, 신규건임
                 */
                writeLog(
                  `이전키없음 신규데이터 ${assz_fmts_base_orgn_idnt_id} -> ${assz_cfbo_idnt_id}`
                );
              }
            }

            targetFileName = `${assz_unfc_id}${ext}`;

            //원장마스터 인서트
            await insertLdgrMaster(
              null,
              assz_unfc_id,
              COMMON_CODES.ASSZ_SCD_INIT, //assz_scd, 00 : 초기, 10 : 정상, 20 : 예외, 30 : 삭제
              assz_cfbo_idnt_id,
              null,
              null,
              assz_orgn_pcsn_dcd,
              EROR_CODES.EROR_VL_SUCCESS,
              EROR_CODES.EROR_VL_SUCCESS_STR,
              `${baseAssetPath}/originpdf/${targetFileName}`, //assz_pcsn_file_path_nm,
              String(fileInfo.size),
              fileInfo.md5,
              assz_btch_acmp_id,
              batchId
            );

            //업무별원장 인서트
            await insertLdgrEpnPlz(
              null,
              assz_unfc_id,
              assz_cfbo_idnt_id,
              assz_fmts_base_orgn_idnt_id,
              orgn_data_rgsr_id,
              targetFileName,
              file_sqn,
              rgsn_ts,
              amnn_ts,
              assz_orgn_pcsn_dcd,
              assz_dcmn_clsf_id,
              conn_ttl_nm,
              rgsr_dept_id,
              assz_orcp_file_path_nm,
              atch_yn,
              atch_sqn,
              atch_nm,
              use_sttg_ymd,
              use_fnsh_ymd,
              sale_info_con,
              assz_dcmn_clsf_con,
              batchId
            );

            let dirGb = atch_yn === "N" ? "origin" : "att"; //디렉토리구분

            const targetPath = `${baseAssetPath}/${dirGb}`;
            chgFullPath = path.join(targetPath, targetFileName);

            try {
              fs.mkdirSync(targetPath, { recursive: true });
              fs.copyFileSync(filename, chgFullPath);
            } catch (err) {
              writeLog(
                `${EROR_CODES.EROR_VL_COPY_FAILED_STR}: ${filename}:${chgFullPath}`
              );
              await dbMetaProd.insertMeta(
                assz_btch_acmp_id,
                assz_cfbo_idnt_id,
                assz_unfc_id,
                targetFileName,
                file_sqn,
                assz_orcp_file_path_nm,
                orgn_data_rgsr_id,
                rgsn_ts,
                amnn_ts,
                assz_orgn_pcsn_dcd,
                atch_yn,
                atch_sqn,
                assz_dcmn_clsf_id,
                assz_fmts_base_orgn_idnt_id,
                conn_ttl_nm,
                rgsr_dept_id,
                use_sttg_ymd,
                use_fnsh_ymd,
                sale_info_con,
                assz_dcmn_clsf_con,
                atch_nm,
                chgFullPath,
                batchId
              );
              failCnt++;
              await updateErorVl(
                assz_unfc_id,
                EROR_CODES.EROR_VL_COPY_FAILED,
                EROR_CODES.EROR_VL_COPY_FAILED_STR
              );
              //자산화상태코드 예외로 변경해야함----------------------
              await updateOnlyAsszScd(
                assz_unfc_id,
                COMMON_CODES.ASSZ_SCD_EXCEPTION
              );
              //---------------------------------------------------
              try {
                await updateFileInfo(assz_unfc_id, "0", null);
              } catch (e) {
                writeLog(`${EROR_CODES.EROR_VL_FILEINFO_FAILED_STR} ${filename}`);
              }
              continue; //파일없으면 skip
            }

            let errCd = EROR_CODES.EROR_VL_SUCCESS;
            let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;

            if (
              atch_sqn == 0 &&
              atch_yn == "" &&
              assz_orcp_file_path_nm.includes("/ikep4jfile/images")
            ) {
              errCd = EROR_CODES.EROR_VL_NON_TARGET;
              errStr = EROR_CODES.EROR_VL_NON_TARGET_STR;
              await updateErorVl(
                assz_unfc_id,
                EROR_CODES.EROR_VL_NON_TARGET,
                EROR_CODES.EROR_VL_NON_TARGET_STR
              );
              //자산화상태코드 예외로 변경해야함----------------------
              await updateOnlyAsszScd(
                assz_unfc_id,
                COMMON_CODES.ASSZ_SCD_EXCEPTION
              );
              //---------------------------------------------------
            }
            
            //자산화 대상 파일 아님.
            if (!isUseFile(file_nm)) {
              errCd = EROR_CODES.EROR_VL_NON_TARGET;
              errStr = EROR_CODES.EROR_VL_NON_TARGET_STR;
              await updateErorVl(
                assz_unfc_id,
                EROR_CODES.EROR_VL_NON_TARGET,
                EROR_CODES.EROR_VL_NON_TARGET_STR
              );
              //자산화상태코드 예외로 변경해야함----------------------
              await updateOnlyAsszScd(
                assz_unfc_id,
                COMMON_CODES.ASSZ_SCD_EXCEPTION
              );
              //---------------------------------------------------
            }
          }
        }

        successCnt++;

        writeLog(`COPY 성공 ${filename}`);
        await dbMetaProd.insertMeta(
          assz_btch_acmp_id,
          assz_cfbo_idnt_id,
          assz_unfc_id,
          targetFileName,
          file_sqn,
          assz_orcp_file_path_nm,
          orgn_data_rgsr_id,
          rgsn_ts,
          amnn_ts,
          assz_orgn_pcsn_dcd,
          atch_yn,
          atch_sqn,
          assz_dcmn_clsf_id,
          assz_fmts_base_orgn_idnt_id,
          conn_ttl_nm,
          rgsr_dept_id,
          use_sttg_ymd,
          use_fnsh_ymd,
          sale_info_con,
          assz_dcmn_clsf_con,
          atch_nm,
          chgFullPath,
          batchId
        );
      }
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "prodFileCopy");
  writeLog(
    "----------------------------prodFileCopy()종료----------------------------"
  );
}

async function htp(data) {
  const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
  return new Promise((resolve, reject) => {
    const command = data.command;
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr); //resolve(); //에러나도 넘어가게끔 하려면
        return;
      }
      writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        writeLog(`변환성공: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: true,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
        });
      } else if (stdout.includes(`[Fail]`)) {
        writeLog(`변환실패 [Fail 출력됨]: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0210",
          errStr: `hwptoPdf 변환실패 [Fail 출력됨]${data.assz_pcsn_file_path_nm}`,
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
        });
      } else {
        writeLog(`결과미확인: ${data.assz_pcsn_file_path_nm}`);
        resolve({
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_cfbo_idnt_id: data.assz_cfbo_idnt_id,
          atch_yn: data.atch_yn,
          assz_unfc_id: data.assz_unfc_id,
          success: false,
          errCd: "0000",
          errStr: "",
          chgFilePath: data.chgFilePath,
          astpCd: data.astpCd,
          strDate: strDate,
          assz_pcsn_file_path_nm: data.assz_pcsn_file_path_nm,
        });
      }
    });
  });
}

/*----------------------hwptoPdf----------------------*/
async function prodHwptoPdf(assz_btch_acmp_id) {
  writeLog(
    "----------------------------prodHwptoPdf()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  //조회시 파일 확장자만 필터
  const metaData = await dbMetaProd.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const md of metaData.rows) {
    const oriFileName = path.basename(md.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (
      ext === ".hwp" ||
      ext === ".hwpx" ||
      ext === ".doc" ||
      ext === ".docx"
    ) {
      chgFileName = oriFileName.replace(ext, ".pdf");
    } else {
      chgFileName = oriFileName;
    }
    const chgFilePath = `${baseAssetPath}/pdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx"
    ) {
      let command = `python3 /app/hwp2pdfv2/hwp2pdf.py "${md.assz_pcsn_file_path_nm}" "/data/asset/kms/wpt/epnt/${basDt}/pdf"`;
      command = command.replace(/`/g, "\\`");
      astpCd = "HW";
      writeLog(`command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: "HW",
        command: command,
        chgFilePath: chgFilePath,
        atch_yn: md.atch_yn,
        assz_pcsn_file_path_nm: md.assz_pcsn_file_path_nm,
        assz_cfbo_idnt_id: md.assz_cfbo_idnt_id,
        assz_unfc_id: md.assz_unfc_id,
        strDate: strDate,
      });
    } else if (
      path.extname(oriFileName).toLowerCase() === ".pdf" ||
      path.extname(oriFileName).toLowerCase() === ".PDF"
    ) {
      successCnt++;
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    await dbAssetLog.insertLog(
      assz_btch_acmp_id,
      result.assz_unfc_id,
      result.assz_cfbo_idnt_id,
      result.atch_yn,
      result.astpCd, //HW      HWP PD  PDF ML  HTML
      "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
      "C", //C 신규 U 수정 D삭제
      "N", //이미지처리여부
      null,
      null,
      null,
      "CH", //NO(None),CH(변환)
      null,
      null,
      null,
      "SI", //SI(단일 문서),MU(멀티 통합 문서)
      result.strDate, //원본변환시작일시
      endDate, //원본변환종료일시
      result.chgFilePath,
      result.errCd, //에러 0000
      result.errStr,
      batchId,
      "Y"
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "prodHwptoPdf");
  writeLog(
    "----------------------------prodHwptoPdf()종료----------------------------"
  );
}

/*----------------------hwptoPdf----------------------*/
async function hwptoPdfOrigin(assz_btch_acmp_id) {
  writeLog(
    "----------------------------hwptoPdfOrigin()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(50);

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  //조회시 파일 확장자만 필터
  const metaData = await dbMetaProd.selectMeta(assz_btch_acmp_id);

  const commands = [];

  //hwp파일변환
  for (const md of metaData.rows) {
    const oriFileName = path.basename(md.assz_pcsn_file_path_nm);
    const ext = path.extname(oriFileName).toLowerCase();

    let chgFileName = "";

    if (
      ext === ".hwp" ||
      ext === ".hwpx" ||
      ext === ".doc" ||
      ext === ".docx"
    ) {
      chgFileName = oriFileName.replace(ext, ".pdf");
    } else {
      chgFileName = oriFileName;
    }
    const chgFilePath = `${baseAssetPath}/pdf/${chgFileName}`;
    const chgOriginFilePath = `${baseAssetPath}/originpdf/${chgFileName}`;

    totalCnt++;

    let errCd = "0000";
    let errStr = "";
    let astpCd = "";

    const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

    if (
      path.extname(oriFileName).toLowerCase() === ".hwp" ||
      path.extname(oriFileName).toLowerCase() === ".hwpx" ||
      path.extname(oriFileName).toLowerCase() === ".doc" ||
      path.extname(oriFileName).toLowerCase() === ".docx"
    ) {
      let command = `python3 /app/hwp2pdfv2/hwp2pdf.py "${md.assz_pcsn_file_path_nm}" "/data/asset/kms/wpt/epnt/${basDt}/originpdf"`;
      command = command.replace(/`/g, "\\`");
      astpCd = "HW";
      writeLog(`command 실행: ${command}`);

      commands.push({
        assz_btch_acmp_id: assz_btch_acmp_id,
        astpCd: "HW",
        command: command,
        chgFilePath: chgFilePath,
        atch_yn: md.atch_yn,
        assz_pcsn_file_path_nm: md.assz_pcsn_file_path_nm,
        assz_cfbo_idnt_id: md.assz_cfbo_idnt_id,
        assz_unfc_id: md.assz_unfc_id,
      });
    } else if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      const strDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      astpCd = "PD";
      try {
        fs.copyFileSync(md.assz_pcsn_file_path_nm, chgFilePath);
        fs.copyFileSync(md.assz_pcsn_file_path_nm, chgOriginFilePath);
        writeLog(`PDF 복사 완료:${chgFilePath} `);
        successCnt++;
      } catch (err) {
        writeLog(`PDF 복사 실패 : ${md.assz_pcsn_file_path_nm}`, err);
        errCd = EROR_CODES.EROR_VL_HTP_PDF_COPY_FAILED;
        errStr = EROR_CODES.EROR_VL_HTP_PDF_COPY_FAILED_STR;

        await updateErorVl(md.assz_unfc_id, errCd, errStr);
        failCnt++;
      }

      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      await dbAssetLog.insertLog(
        assz_btch_acmp_id,
        md.assz_unfc_id,
        md.assz_cfbo_idnt_id,
        md.atch_yn,
        astpCd, //HW      HWP PD  PDF ML  HTML
        "02", //00(DRM해제)/01(전처리)/02(원본문서생성)/03(이미지처리)/04(text변환)
        "C", //C 신규 U 수정 D삭제
        "N", //이미지처리여부
        null,
        null,
        null,
        "CH", //NO(None),CH(변환)
        null,
        null,
        null,
        "SI", //SI(단일 문서),MU(멀티 통합 문서)
        strDate, //원본변환시작일시
        endDate, //원본변환종료일시
        chgFilePath,
        errCd, //에러 0000
        errStr,
        batchId,
        "Y"
      );
    }
  }

  const tasks = commands.map((data, idx) => limit(() => htp(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
  }
  //통합ID에 대한 원본통합ID 업데이트

  summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "hwptoPdfOrigin"
  );
  writeLog(
    "----------------------------hwptoPdfOrigin()종료----------------------------"
  );
}

async function ptt(data) {
  const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

  return new Promise((resolve, reject) => {
    const command = data.command;

    exec(command, (error, stdout, stderr) => {
      let oriFileName = data.oriFileName;
      if (error) {
        writeLog(`에러:${error.message}`);
        reject(error);
        return;
      }
      writeLog(`stdout:${stdout}`);
      if (stdout.includes("[Success]")) {
        writeLog(`변환성공: ${oriFileName}`);
        resolve({
          success: true,
          txtOutFullPath: data.txtOutFullPath,
          errCd: "0000",
          errStr: "",
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) {
          errMsg = match[1];
        }
        writeLog(`변환실패 [Fail 출력됨]: ${oriFileName} / 사유 : ${errMsg}`);
        let errCd = "0410";
        let errStr =
          errMsg == "" ? `변환실패 [Fail 출력됨]: ${oriFileName}` : errMsg;
        resolve({
          success: false,
          errCd: errCd,
          errStr: errStr,
          txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          staDate: staDate,
        });
      } else {
        writeLog(`결과미확인: ${oriFileName}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------pdftoText----------------------*/
async function pdftoText(assz_btch_acmp_id) {
  writeLog(
    "----------------------------pdftoText()시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;

  const limit = pLimit(80);

  let outputDir = `${baseAssetPath}/txt`;
  fs.mkdirSync(outputDir, { recursive: true });

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  //.pdf 파일만 필터링
  //  const pdfFiles = files.filter(
  //    (file) => path.extname(file).toLowerCase() === ".pdf"
  //  );        const ext = path.extname(file_nm);

  let commands = [];

  const logData = await dbAssetLog.selectLog07(assz_btch_acmp_id, "02", "0000");
  //pdftotxt 변환
  for (const ld of logData.rows) {
    totalCnt++;
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);

    const txtFileName = oriFileName
      .replace(".pdf", ".txt")
      .replace(".PDF", ".txt"); //확장자변경
    const txtOutFullPath = `${outputDir}/${txtFileName}`;
    let command = `python3 /app/pdftotxt/pdftotxt.py "${ld.assz_orcp_file_path_nm}" "${txtOutFullPath}"`;
    command = command.replace(/`/g, "\\`");
    commands.push({
      assz_btch_acmp_id: ld.assz_btch_acmp_id,
      assz_unfc_id: ld.assz_unfc_id,
      oriFileName: oriFileName,
      header: ld,
      command: command,
      txtOutFullPath: txtOutFullPath,
    });
  }

  const tasks = commands.map((data, idx) => limit(() => ptt(data)));

  for await (const result of tasks) {
    if (result.success) {
      successCnt++;
    } else {
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      result.assz_btch_acmp_id,
      result.assz_unfc_id,
      "82",
      null,
      null,
      null,
      null,
      null,
      result.staDate, //변환시작일시
      endDate, //변환종료일시
      result.txtOutFullPath,
      null,
      null,
      null,
      null,
      result.errCd,
      result.errStr
    );

    await updateErorVl(result.assz_unfc_id, result.errCd, result.errStr);
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoText");
  writeLog(
    "----------------------------pdftoText()종료----------------------------"
  );
}

/*----------------------pdftoImg----------------------*/
async function pdftoImg(assz_btch_acmp_id) {
  writeLog(
    "---------------------------- pdftoImg() 시작 ----------------------------"
  );

  // 기본 변수 셋팅
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(100);

  const imagepdfFolder = `/data/asset/kms/wpt/epnt/${basDt}/pdf`;
  const outFolder = `/data/asset/kms/wpt/epnt/${basDt}/dp`;
  const commands = [];

  // UDA자산화처리로그 조회
  const logData = await dbAssetLog.selectLog06(assz_btch_acmp_id, "82");

  for (const ld of logData.rows) {
    // PDF일 경우
    const oriFileName = path.basename(ld.assz_orcp_file_path_nm);
    if (path.extname(oriFileName).toLowerCase() === ".pdf") {
      let command = `python3 /app/pdftoimg/pdftoimg.py "${imagepdfFolder}/${oriFileName}" "${outFolder}" "${ld.assz_btch_acmp_id}" "${ld.assz_unfc_id}" "${ld.uda_sys_lsmd_id}"`;
      commands.push({
        assz_btch_acmp_id: ld.assz_btch_acmp_id,
        assz_unfc_id: ld.assz_unfc_id,
        oriFileName: oriFileName,
        header: ld,
        command: command,
      });
    }
  }

  // PDF->IMG 추출 모듈 실행
  const tasks = commands.map((data, idx) => limit(() => pti(data)));
  for await (const result of tasks) {
    let errCd = "0000";
    let errStr = "";

    totalCnt++;
    if (result.success) {
      errCd = EROR_CODES.EROR_VL_SUCCESS;
      errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
      successCnt++;
    } else {
      errCd = EROR_CODES.EROR_VL_IMG_FAILED;
      errStr = EROR_CODES.EROR_VL_IMG_FAILED_STR;
      failCnt++;
    }
    const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    await dbAssetLog.updateLog(
      assz_btch_acmp_id,
      result.header.assz_unfc_id,
      "04",
      null,
      null,
      null,
      null,
      null,
      result.staDate, //변환시작일시
      endDate, //변환종료일시
      null,
      null,
      null,
      null,
      null,
      errCd,
      errStr
    );
    await updateErorVl(result.assz_unfc_id, errCd, errStr);
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "pdftoImg");
  writeLog(
    "---------------------------- pdftoImg() 종료 ----------------------------"
  );
}

/*---------------------- PDF->IMG 추출 모듈 실행 ----------------------*/
async function pti(data) {
  const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

  return new Promise((resolve, reject) => {
    const command = data.command;
    exec(command, (error, stdout, stderr) => {
      if (error) {
        writeLog(`에러: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        writeLog(`stderr:${stderr}`);
        reject(stderr);
        return;
      }
      if (stdout.includes("[Success]")) {
        //writeLog(`추출성공: ${data.oriFileName}`);
        resolve({
          success: true,
          errCd: EROR_CODES.EROR_VL_SUCCESS,
          errStr: EROR_CODES.EROR_VL_SUCCESS_STR,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
          staDate: staDate,
        });
      } else if (stdout.includes(`[Fail]`)) {
        const match = stdout.trim().match(/\[Fail\]\[(.*?)\]/);
        let errMsg = "";
        if (match) errMsg = match[1];
        let errStr = `[Fail 출력됨]: ${data.oriFileName} / 사유 : ${errMsg}`;
        writeLog(errStr);
        resolve({
          success: false,
          errCd: null,
          errStr: errStr,
          // txtOutFullPath: data.txtOutFullPath,
          assz_btch_acmp_id: data.assz_btch_acmp_id,
          assz_unfc_id: data.assz_unfc_id,
          header: data.header,
          staDate: staDate,
        });
      } else {
        writeLog(`pdftoImg 결과미확인: ${data.assz_orcp_file_path_nm}`);
        reject(new Error(`stdout에서 성공/실패 정보 없음`));
      }
    });
  });
}

/*----------------------  JSON 병합 (FILEJSON, IMGJSON 병합) ----------------------*/
async function jsonMerge(assz_btch_acmp_id) {
  writeLog(
    "----------------------------jsonMerge()시작----------------------------"
  );

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  const oriJsonFiles = await dbAssetRlt.selectFilePathNm(assz_btch_acmp_id);
  for (const oriJsonFile of oriJsonFiles.rows) {
    const imgJsonFiles = await dbImgRlt.selectFilePathNm(
      assz_btch_acmp_id,
      oriJsonFile.assz_unfc_id
    );
    const imgJsonList = imgJsonFiles.rows.map(
      (row) => row.assz_pcsn_file_path_nm
    );

    totalCnt++;

    let errCd = EROR_CODES.EROR_VL_SUCCESS;
    let errStr = EROR_CODES.EROR_VL_SUCCESS_STR;
    try {
      mergeJsonFiles(oriJsonFile.file_path, imgJsonList);
      writeLog(`jsonMerge 변환 성공!!!: ${oriJsonFile.file_path}`);
      successCnt++;
    } catch (err) {
      errCd = EROR_CODES.EROR_VL_JSON_MERGE_FAILED;
      errStr = `${EROR_CODES.EROR_VL_JSON_MERGE_FAILED_STR} ${oriJsonFile.assz_unfc_id} ${oriJsonFile.file_path} ${err}`;
      updateErorVl(oriJsonFile.assz_unfc_id, errCd, errStr);
      writeLog(errStr);
      await dbAssetLog.updateLogErr04(
        assz_btch_acmp_id,
        oriJsonFile.assz_unfc_id,
        errCd,
        errStr
      );
      failCnt++;
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "jsonMerge");
  writeLog(
    "----------------------------jsonMerge()종료----------------------------"
  );
}

async function makeDir() {
  const dirs = [
    `${baseAssetPath}/att`,
    `${baseAssetPath}/dp`,
    `${baseAssetPath}/json`,
    `${baseAssetPath}/origin`,
    `${baseAssetPath}/originpdf`,
    `${baseAssetPath}/pdf`,
    `${baseAssetPath}/txt`,
    `${baseAssetPath}/img`,
    `/data/bdpetl/send/gai/gai/wpt/epnt/${basDt}`,
    `/data/bdpetl/send/avt/avt/wpt/${basDt}`, // 음성봇
  ];

  for (const dir of dirs) {
    try {
      await fs.mkdirSync(`${dir}`, { recursive: true });
    } catch (err) {
      writeLog(`디렉터리 생성 실패 : ${dir}`);
    }
    writeLog(`디렉터리 생성 성공 : ${dir}`);
  }
}
function isUseFile(fileName) {
  const USE_EXTS = new Set([
    ".hwp",
    ".hwpx",
    ".HWP",
    ".HWPX",
    ".pdf",
    ".PDF",
    ".doc",
    ".docx",
    ".DOC",
    ".DOCX",
  ]);
  return USE_EXTS.has(path.extname(fileName).toLowerCase());
}

/*----------------------main 함수----------------------*/
async function main() {
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃kmsplzepnt 상품약관/설명서 배치 시작＃＃＃＃＃＃＃＃＃＃＃＃"
  );

  if (pcsnClCd == "01") {
    let basePath = `/data/bdpetl/recv/kms/wpt/${basDt}/`;
    // 서버간 파일 동기화
    await sync(basePath);
    // fin파일 체크
    await finFileCheck(basDt, basePath, "KMSPLZ");

    //배치수행로그 입력 및 배치ID채번
    const assz_btch_acmp_id = await batchStart(
      basDt,
      batchId,
      "KMSPLZ",
      "01", //01	수집 02	자산화 03	전송
      "01", //01 초기 02 성공 03 실패
      "T1", //T1	메타+파일 T2	DB T3	지식샘
      "01" //assz_tgt_sys_cd
    );

    //원천메타파일이 없는경우 fin파일만 생성후 종료 하기 시작-------------------------------
    let recvMetaRtnVal = await recvMetaFileCheck(
      `/data/bdpetl/recv/kms/wpt/${basDt}/meta_plaza/PRODUCT_PLAZA.dat`
    );

    if (!recvMetaRtnVal) {
      // fin파일 생성
      await finFileCreate("/data/bdpetl/send/gai/gai/wpt/epnt", basDt);
      // 배치수행 최종완료 처리
      await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
      process.exit(0);
    }

    await makeDir();
    await prodFileCopy(assz_btch_acmp_id); // 메타 입력 및 파일 통합
    await drmUnlock(); //DRM해제

    await hwptoPdfOrigin(assz_btch_acmp_id); //단건으로 처리
    await drawLine();
    await prodHwptoPdf(assz_btch_acmp_id); //단건으로 처리
    await pdftoText(assz_btch_acmp_id); //단건으로 처리
    await pdftoImg(assz_btch_acmp_id); //머지된 pdf로 처리 20 82 --> 이미지처리 결과 업데이트

    await util.imgToDp2(assz_btch_acmp_id, "kms/wpt/plz", basDt); //전체 (첨부,부속이미지)이미지를 텍스트로
    //-----------------------------------------------머지
    await util.runImgJeff(assz_btch_acmp_id, "kms/wpt/plz", basDt, includeObj); //DBselect 엔진호출   DBupdate Dbinsert
    await util.runJeff2(assz_btch_acmp_id, "kms/wpt/plz", basDt, includeObj);
    //-----------------------------------------------변경대상
    await jsonMerge(assz_btch_acmp_id); //pdf jSON  img JSON 병합   20 84 -> 22

    // 원장 파일 동기화
    await moveAssetData("/data/asset/kms/wpt/epnt", basDt);
    // 원장결과 재생성
    await util.resetOriginResult(
      assz_btch_acmp_id,
      "kms/wpt/plz",
      basDt,
      EROR_CODES.EROR_VL_SUCCESS
    );

    // 학습데이터 파일복사
    await util.moveToLearn("kmsplz", assz_btch_acmp_id);

    // TB_DOCUMNET 에 머지인서트 시작
    await mergeDocument(null, assz_btch_acmp_id);

    // 비식별화 데이터 생성
    await util.insertMaskingData(
      assz_btch_acmp_id,
      "kms/wpt/plz",
      EROR_CODES.EROR_VL_SUCCESS,
      batchId
    );
    // 수명주기 저장
    await util.lifecycleInsert(
      assz_btch_acmp_id,
      "kms/wpt/plz",
      EROR_CODES.EROR_VL_SUCCESS
    );

    // 배치수행 최종완료 처리
    await dbBatch.updateBatchFinishTime(assz_btch_acmp_id, "01", "01");
  } else if (pcsnClCd == "02") {
    // 초기이행용
    // 학습용데이터모음 /data/train_data/rawdata/iemieb/year 연도별로 모으기
    // await moveToLearn("iemiea");
  } else if (pcsnClCd == "03") {
  } else if (pcsnClCd == "04") {
  } else if (pcsnClCd == "81") {
  } else if (pcsnClCd == "82") {
  } else if (pcsnClCd == "83") {
  } else if (pcsnClCd == "97") {
  } else if (pcsnClCd == "98") {
  } else if (pcsnClCd == "99") {
  }

  await dbAssetLog.dbEnd();
  await dbGaiMeta.dbEnd();
  await dbAssetRlt.dbEnd();
  await dbMetaProd.dbEnd();
  await dbImgRlt.dbEnd();
  await dbBatch.dbEnd();
  writeLog(
    "＃＃＃＃＃＃＃＃＃＃＃＃kmsplzepnt 배치 종료＃＃＃＃＃＃＃＃＃＃＃＃"
  );
}

main();
