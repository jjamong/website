const { execFile, execFileSync } = require("child_process");
const { promisify } = require("util");
const path = require("path");

const execFileAsync = promisify(execFile);

class CommandGuard {
  constructor(whitelistCmds) {
    this.whiltelist = Object.freeze({
      ...(whitelistCmds || {}),
    });
  }

  _resolveBinary(cmdKey) {
    const bin = this.whiltelist[cmdKey];
    if (!bin) throw new Error(`command not allowed: ${cmdKey}`);
    if (!path.isAbsolute(bin))
      throw new Error("whitelisted command must be absolute path");
    return bin;
  }

  static validateStringArgs(args) {
    const SAFE = /^[\w@%+=:,./-]{1,256}$/;
    for (const a of args || []) {
      if (typeof a !== "string") throw new Error("arg must be string");
      if (a.includes("\0")) throw new Error("Nul not allowed");
      if (![...a].every((ch) => ch >= " "))
        throw new Error("control char not allowed");
      if (!SAFE.test(a)) throw new Error(`arg contains unsafe char: ${a}`);
    }
  }

  static async buildPathArgsAsync(spec, pathGuard) {
    const list = [];
    const rootIndex = spec?.rootIndex ?? 0;
    if (spec?.abs) {
      for (const p of spec.abs) {
        const real = await pathGuard.allowAbsolute(p);
        list.push(real);
      }
    }
    if (spec?.rel) {
      for (const p of spec.rel) {
        const abs = pathGuard.resolveUnder(p, rootIndex);
        list.push(abs);
      }
    }

    return list;
  }

  static buildPathArgsSync(spec, pathGuard) {
    const list = [];
    const rootIndex = spec?.rootIndex ?? 0;
    if (spec?.abs) {
      for (const p of spec.abs) {
        const real = pathGuard.allowAbsoluteSync(p);
        list.push(real);
      }
    }
    if (spec?.rel) {
      for (const p of spec.rel) {
        const abs = pathGuard.resolveUnder(p, rootIndex);
        list.push(abs);
      }
    }
    return list;
  }

  async run(cmdKey, stringArgs = [], opts = []) {
    const bin = this._resolveBinary(cmdKey);
    CommandGuard.validateStringArgs(stringArgs);

    const timeout = opts.timeoutMs ?? 60_000;
    const maxBuffer = opts.maxBuffer ?? 10 * 1024 * 1024;
    const cwd = opts.cwd ? path.resolve(opts.cwd) : process.cwd();

    return execFileAsync(bin, stringArgs, {
      cwd,
      timeout,
      maxBuffer,
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
    });
  }

  async runScript(interpreterKey, script, args, pathGuard, opts = {}) {
    const interp = this._resolveBinary(interpreterKey);

    let scriptAbs;
    if (script?.abs) scriptAbs = await pathGuard.allowAbsolute(script.abs);
    else if (script?.rel)
      scriptAbs = pathGuard.resolveUnder(script.rel, script.rootIndex ?? 0);
    else throw new Error("script path (abs or rel) required");

    const { PathGuard } = require("./pathGuard");
    await PathGuard.assertRegularFile(scriptAbs);

    const stringArgs = args?.strings ?? [];
    CommandGuard.validateStringArgs(stringArgs);

    const pathArgs = [
      ...(await CommandGuard.buildPathArgsAsync(
        { abs: args?.absPaths, rootIndex: args?.rootIndex },
        pathGuard
      )),
      ...(await CommandGuard.buildPathArgsAsync(
        { rel: args?.relPaths, rootIndex: args?.rootIndex },
        pathGuard
      )),
    ];

    const finalArgs = [scriptAbs, ...stringArgs, ...pathArgs];

    const timeout = opts.timeoutMs ?? 5 * 60_000;
    const maxBuffer = opts.maxBuffer ?? 20 * 1024 * 1024;
    const cwd = opts.cwd ? path.resolve(opts.cwd1) : process.cwd();

    return execFileAsync(interp, finalArgs, {
      cwd,
      timeout,
      maxBuffer,
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
    });
  }

  runScriptSync(interpreterKey, script, args, pathGuard, opts = {}) {
    const interp = this._resolveBinary(interpreterKey);

    let scriptAbs;
    if (script?.abs) scriptAbs = pathGuard.allowAbsoluteSync(script.abs);
    else if (script?.rel)
      scriptAbs = pathGuard.resolveUnder(script.rel, script.rootIndex ?? 0);
    else throw new Error("script path (abs or rel) required");

    const { PathGuard } = require("./pathGuard");
    PathGuard.assertRegularFileSync(scriptAbs);

    const stringArgs = args?.strings ?? [];
    CommandGuard.validateStringArgs(stringArgs);

    const pathArgs = [
      ...CommandGuard.buildPathArgsSync(
        { abs: args?.absPaths, rootIndex: args?.rootIndex },
        pathGuard
      ),
      ...CommandGuard.buildPathArgsSync(
        { rel: args?.relPaths, rootIndex: args?.rootIndex },
        pathGuard
      ),
    ];

    const finalArgs = [scriptAbs, ...stringArgs, ...pathArgs];

    return execFileSync(this._resolveBinary(interpreterKey), finalArgs, {
      cwd: opts.cwd ? path.resolve(opts.cwd) : process.cwd(),
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
      maxBuffer: opts.maxBuffer ?? 20 * 1024 * 1024,
    });
  }
}

module.exports = { CommandGuard };
