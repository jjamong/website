const { spawn } = require("child_process");
const axios = require("axios");
const { Agent } = require("http");
const { writeLog, summaryLog } = require("./log"); // 로그 모듈
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const FormData = require("form-data");
const dayjs = require("dayjs");
const { lock_timeout } = require("pg/lib/defaults");
const {
  updateErorVl,
  updateAsszScd,
  selectMetaSuccess,
  selectMetaSuccessReGen,
  selectMetaSuccessLifecycle,
  selectMetaSuccessMaskingAll,
} = require("./sql/TB_UDA_UAI000M");
const {
  deleteAssDtl,
  insertAssDtl,
  getAssDtlSeq,
} = require("./sql/TB_UDA_UAI000D");
const TB_UDA_UAI001M = require("./sql/TB_UDA_UAI001M"); //업무포탈
const TB_UDA_UAI003M = require("./sql/TB_UDA_UAI003M"); //업무매뉴얼
const TB_UDA_UAI004M = require("./sql/TB_UDA_UAI004M"); //내규
const TB_UDA_UAI005M = require("./sql/TB_UDA_UAI005M"); // 지식샘
const TB_UDA_UAI872M = require("./sql/TB_UDA_UAI872M");
const TB_UDA_UAI871M = require("./sql/TB_UDA_UAI871M"); // 은행상품설명서
const TB_UDA_UAI874M = require("./sql/TB_UDA_UAI874M");
const TB_UDA_UAI901L = require("./sql/TB_UDA_UAI901L");
const TB_UDA_UAI902L = require("./sql/TB_UDA_UAI902L");
const TB_UDA_UAI910L = require("./sql/TB_UDA_UAI910L");
const TB_UDA_UAI911L = require("./sql/TB_UDA_UAI911L");
const TB_UDA_UAI912L = require("./sql/TB_UDA_UAI912L");
const TB_UDA_UAI803L = require("./sql/TB_UDA_UAI803L");

const {
  EROR_CODES,
  COMMON_CODES,
  selectTxtFileCopyToLearn,
  insertAnonymizedData,
  insertAnonymizedDataDetail,
  deleteAnonymizedData,
  selectCountLifecycle,
  insertLifecycle,
  discardDocument,
  insertQualityMng,
} = require("./src/common");

const jeffUrls = [
  "http://172.18.120.150:10090",
  "http://172.18.120.150:10091",
  "http://172.18.120.150:10092",
  "http://172.18.120.150:10093",
];

const maskingUrls = jeffUrls;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// util이 불려진 시점부터 instace 생성하고 30초마다 재생성 keepAlive 처리
let agent = createNewAgent();
let axiosInstance = createAxiosInstance(agent);

//startAgentResetLoop();

function createNewAgent() {
  return new Agent({
    keepAlive: true,
    //keepAliveMsecs: 30000,
    maxSockets: 5000,
    maxFreeSockets: 1000,
  });
}

function createAxiosInstance(agent) {
  return axios.create({
    httpAgent: agent,
    timeout: 0,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });
}

function startAgentResetLoop() {
  setInterval(() => {
    agent.destroy();
    agent = createNewAgent();
    axiosInstance = createAxiosInstance(agent);
  }, 60000);
}

function isImageFile(fileName) {
  const IMAGE_EXTS = new Set([
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".bmp",
    ".tif",
    ".tiff",
  ]);
  return IMAGE_EXTS.has(path.extname(fileName).toLowerCase());
}

async function callDpApi(imgFilePath) {
  const DP_API_URL = "http://dgaiapl02:32218/inference";
  const DP_MODEL = "document-parse"; // 모델이 바뀌는 경우는..???

  const form = new FormData();
  form.append("document", fs.createReadStream(imgFilePath));
  form.append("model", DP_MODEL);

  // const resp = await axios.post(DP_API_URL, form, {
  //   header: form.getHeaders(),
  //   maxContentLength: Infinity,
  //   maxBodyLength: Infinity,
  //   timeout: 0,
  // });

  const resp = await axiosInstance.post(DP_API_URL, form);

  if (resp.error) {
    const { message, type, code } = resp.error;
    const errorMessage = `[${type || "UnknownType"}:${code || "UnknownCode"}] ${
      message || "Error Occured"
    }`;
    throw new Error(errorMessage);
  }

  return resp.data;
}

async function callJeffApi(url, txtFilePath, sysName, assz_dcmn_clsf_id, year) {
  try {
    let JEFF_API_URL = `${url}/cbc/inference`;

    const form = new FormData();
    form.append("file", fs.createReadStream(txtFilePath));
    JEFF_API_URL = `${JEFF_API_URL}?system_name=${sysName}&code=${assz_dcmn_clsf_id}&year=${year}`;

    writeLog(`callJeffApi "${JEFF_API_URL}" "${txtFilePath}"`);

    const resp = await axiosInstance.post(JEFF_API_URL, form);

    // const resp = await axios.post(JEFF_API_URL, form, {
    //   header: form.getHeaders(),
    //   maxContentLength: Infinity,
    //   maxBodyLength: Infinity,
    //   timeout: 0,
    // });

    return {
      resp: resp,
      jeffApiUrl: JEFF_API_URL,
    };
  } catch (e) {
    writeLog(`callJeffApi() ${url} ERROR ${e}`);
    return null;
  }
}

async function callMaskingApi(url, txtFilePath) {
  try {
    let MASKING_API_URL = `${url}/cbc/masking`;

    let f = fs.readFileSync(txtFilePath, "utf-8");

    const resp = await axiosInstance.post(MASKING_API_URL, f);

    return {
      resp: resp,
      maskingApiUrl: MASKING_API_URL,
    };
  } catch (e) {
    writeLog(`callMaskingApi() ERROR ${e}`);
    return null;
  }
}

function writeTxt(outputPath, fileName, dpData) {
  try {
    fs.mkdirSync(outputPath, { recursive: true });
    const fullPath = path.join(outputPath, fileName);
    //fs.writeFileSync(fullPath, JSON.stringify(dpData));
    fs.writeFileSync(fullPath, JSON.stringify(dpData, null, 2), "utf8");
    //writeLog(`IMAGE DP 생성 완료 : ${fullPath}`);
  } catch (err) {
    writeLog(err);
  }
}

// 병렬처리 jeff
async function rj(data) {
  while (true) {
    for (let url of jeffUrls) {
      // port 별로
      let res = {};
      const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      sleep(100);
      const jeffData = await callJeffApi(
        url,
        data.conv_flpt_vl,
        data.sysName,
        data.assz_dcmn_clsf_id != "" ? data.assz_dcmn_clsf_id : data.code,
        data.year
      );

      if (!jeffData || !jeffData.resp) continue;

      if (jeffData.resp.data?.is_processing) continue;

      writeLog(`callJeffApi "${jeffData.jeffApiUrl}" "${data.conv_flpt_vl}"`);

      try {
        res.jeffData = jeffData.resp;
        res.success = jeffData.resp.data.is_success == 1 ? true : false;
        res.metaData = data.metaData;
        res.ad = data.ad;
        res.outputPath = data.outputPath;
        res.fileName = data.fileName;
        res.perOutputPath = data.perOutputPath;
        res.dcmn_nm = data.dcmn_nm;
        res.sysName = data.sysName;
        res.startDate = staDate;
        res.oriFileName = data.oriFileName;
        res.conv_flpt_vl = data.conv_flpt_vl;
      } catch (err) {
        writeLog(err);
      }

      return res;
    }
  }
}

async function runJeff2(assz_btch_acmp_id, sysName, basDt, includeObj) {
  writeLog("------------------runJeff2()시작----------------------------");

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(jeffUrls.length);
  const limitParams = [];

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  //let outputPath = `/data/bdpetl/send/gai/gai/${sysDir.split('/')[1]}/${basDt}`; //권한 설정 후 진행
  let outputPath = `/data/asset/${sysDir}/${basDt}/json`;
  let perOutputPath = `/data/asset/${sysDir}/${basDt}/perfor`;

  fs.mkdirSync(outputPath, { recursive: true });
  fs.mkdirSync(perOutputPath, { recursive: true });

  const assetData = await TB_UDA_UAI901L.selectLog(
    assz_btch_acmp_id,
    "04",
    EROR_CODES.EROR_VL_SUCCESS
  );
  writeLog(`runJeff2() > assetData > length ::${assetData.rows.length}`);

  for (const ad of assetData.rows) {
    // writeLog(
    //   `runJeff2() > assetData > for() > assz_cfbo_idnt_id ::${ad.assz_cfbo_idnt_id}`
    // );
    const conv_flpt_vl = ad.assz_conv_file_path_nm;
    if (!conv_flpt_vl) {
      continue;
    }
    const oriFileName = path.basename(conv_flpt_vl);
    let metaData = null;

    if (path.extname(oriFileName).toLowerCase() === ".txt") {
      let fileName = `${path.parse(oriFileName).name}.json`;
      let dcmn_nm = "";
      let assz_dcmn_clsf_id = "";
      let year = "";
      let code = "";

      if (sysName == "kmswpt") {
        checkData = await TB_UDA_UAI910L.selectExists(
          assz_btch_acmp_id,
          ad.assz_unfc_id
        );

        if (checkData.rowCount > 0) {
          //writeLog(`${assz_btch_acmp_id} 이미 수행했음 PASS`);
          continue;
        } else {
          //writeLog(`존재할리가없어 `);
        }
        metaData = await TB_UDA_UAI001M.selectMeta02(
          assz_btch_acmp_id,
          ad.assz_unfc_id
        );

        if (
          !metaData.rows ||
          metaData.rows.length === 0 ||
          metaData.rows[0] == undefined
        ) {
          writeLog(`결과 없음`);
        } else {
          dcmn_nm = metaData.rows[0].dcmn_nm;
          assz_dcmn_clsf_id = metaData.rows[0].assz_dcmn_clsf_id;
          year = String(metaData.rows[0].amnn_ts).split(" ")[3];

          // 2014 이전 년도 처리
          if (year < 2014) {
            // 원장 Update
            await updateErorVl(
              ad.assz_unfc_id,
              EROR_CODES.EROR_VL_JEFF_YEAR,
              EROR_CODES.EROR_VL_JEFF_YEAR_STR
            );
            await TB_UDA_UAI901L.updateLog(
              assz_btch_acmp_id,
              ad.assz_unfc_id,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              EROR_CODES.EROR_VL_JEFF_YEAR,
              EROR_CODES.EROR_VL_JEFF_YEAR_STR
            );
            continue;
          }

          // 이전 시행문 처리
          if (assz_dcmn_clsf_id == "120004856838") {
            // 원장 Update
            await updateErorVl(
              ad.assz_unfc_id,
              EROR_CODES.EROR_VL_JEFF_DCMN_CLSF_ID,
              EROR_CODES.EROR_VL_JEFF_DCMN_CLSF_ID_STR
            );
            await TB_UDA_UAI901L.updateLog(
              assz_btch_acmp_id,
              ad.assz_unfc_id,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              EROR_CODES.EROR_VL_JEFF_DCMN_CLSF_ID,
              EROR_CODES.EROR_VL_JEFF_DCMN_CLSF_ID_STR
            );
            continue;
          }
        }
      } else if (sysName == "aikkms") {
        metaData = await TB_UDA_UAI005M.selectAddInfoMetaSuccessOne(
          assz_btch_acmp_id,
          ad.assz_unfc_id
        );
        dcmn_nm = metaData.rows[0].dcmn_nm;
        year = String(metaData.rows[0].apnd_file_rgsn_ts).split(" ")[3];
      } else if (sysName == "iemieb") {
        writeLog(
          `runJeff2() > assetData > iemieb system > selectMeta02::${ad.assz_cfbo_idnt_id}`
        );
        metaData = await TB_UDA_UAI803L.selectMeta02(
          assz_btch_acmp_id,
          ad.assz_cfbo_idnt_id
        );

        dcmn_nm = metaData.rows[0].dcmn_nm;
        year = String(metaData.rows[0].amnn_ts).split(" ")[3];
      } else if (sysName == "iemiea") {
      } else if (sysName == "kmsepn" || sysName == "kmsplz") {
        metaData = await TB_UDA_UAI871M.selectMetaOne(
          null,
          assz_btch_acmp_id,
          ad.assz_unfc_id
        );

        year = String(metaData.rows[0].amnn_ts).split(" ")[3];
        let includeList = Object.keys(includeObj);
        code =
          includeObj[
            sysName === "kmsepn"
              ? includeList.filter((d, i) =>
                  metaData.rows[0].atch_nm.includes(d)
                )[0]
              : "상품설명서"
          ];
      } else if (sysName == "iisiis") {
        metaData = await TB_UDA_UAI874M.selectMetaOne(
          null,
          assz_btch_acmp_id,
          ad.assz_unfc_id
        );
      }

      limitParams.push({
        conv_flpt_vl: conv_flpt_vl,
        sysName: sysName,
        assz_dcmn_clsf_id: assz_dcmn_clsf_id,
        year: year,
        metaData: metaData,
        ad: ad,
        outputPath: outputPath,
        fileName: fileName,
        perOutputPath: perOutputPath,
        dcmn_nm: dcmn_nm,
        oriFileName: oriFileName,
        code: code,
      });
    }
  }

  const tasks = limitParams.map((data, idx) => limit(() => rj(data)));

  for await (const result of tasks) {
    totalCnt++;
    if (result.success) {
      let rgsn_ts = null;
      let amnn_ts = null;
      let url_adr = null;
      if (sysName == "iemiea") {
      } else {
        rgsn_ts = result.metaData.rows[0].rgsn_ts
          ? result.metaData.rows[0].rgsn_ts
          : null;
        amnn_ts = result.metaData.rows[0].amnn_ts
          ? result.metaData.rows[0].amnn_ts
          : null;
        url_adr = result.metaData.rows[0].url_adr
          ? result.metaData.rows[0].url_adr
          : null;
      }
      // console.log(
      //   "result.ad.assz_orcp_file_path_nm=====>>>" +
      //     result.ad.assz_orcp_file_path_nm
      // );
      const fileStat = fs.statSync(result.ad.assz_orcp_file_path_nm);
      const fileSize = Math.floor(fileStat.size / 1024);

      let chunkedData = result.jeffData.data.chunked;
      // {
      //   "metric1":{
      //     "dup_rate":{
      //       "dup_char_rate":0,
      //       "dup_word_rate":0,
      //       "dup_chunk_rate":0
      //     }
      //   },
      //   "metric2":{
      //     "rouge":{
      //       "rouge1":1,
      //       "rouge2":1,
      //       "rougeL":1
      //     },
      //     "error_rate":{
      //       "wer":0,
      //       "cer":0.0008,
      //       "filter_cer":0
      //     }
      //   },
      //   "metric3":{
      //     "meteor":0.1033,
      //     "lcs":0.0871,
      //     "ti_cos_sim":0.0966
      //   },
      //   "metric4":{
      //     "bert":0.1033,
      //     "em_cos_sim":0.0871
      //   }
      // }
      let perforMetrics = result.jeffData.data.perfor_metrics;

      writeLog(result.ad.assz_unfc_id);
      writeLog(JSON.stringify(perforMetrics));
      writeLog(Object.keys(perforMetrics).length);

      // data 결과
      const outFullPath = `${result.outputPath}/${result.fileName}`;
      let outJsonStr = JSON.parse(
        `{"data":${
          Object.keys(chunkedData).length != 0
            ? JSON.stringify(chunkedData.data)
            : "{}"
        }${
          typeof chunkedData.maxPage != "undefined"
            ? ', "maxPage" : ' + chunkedData.maxPage
            : ""
        }}`
      );

      // console.log("chunkedData====>>>" + JSON.stringify(chunkedData.data));
      fs.writeFileSync(
        outFullPath,
        JSON.stringify(outJsonStr, null, 2),
        "utf-8"
      );

      // performce 결과
      const perforOutFullPath = `${result.perOutputPath}/${result.fileName}`;
      let perforOutJsonStr = JSON.parse(
        `{"result":${
          Object.keys(chunkedData).length != 0
            ? JSON.stringify(chunkedData.result)
            : "{}"
        }}`
      );
      fs.writeFileSync(
        perforOutFullPath,
        JSON.stringify(perforOutJsonStr, null, 2),
        "utf-8"
      );

      if (Object.keys(perforMetrics).length > 0) {
        const dup_char_rate = perforMetrics.metric1.dup_rate.dup_char_rate;
        const dup_word_rate = perforMetrics.metric1.dup_rate.dup_word_rate;
        const lcs_rouge = perforMetrics.metric2.rouge.rougeL;
        const meteor = perforMetrics.metric3.meteor;
        const bert = perforMetrics.metric4.bert;

        await insertQualityMng(
          result.ad.assz_unfc_id,
          result.oriFileName,
          "PDF",
          dup_char_rate,
          dup_word_rate,
          lcs_rouge,
          meteor,
          bert,
          result.ad.uda_sys_lsmd_id
        );
      }
      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

      // 성공 로그 insert
      await TB_UDA_UAI910L.insertAst(
        result.ad.assz_btch_acmp_id,
        result.ad.assz_unfc_id,
        result.sysName.toUpperCase(),
        result.ad.assz_cfbo_idnt_id,
        result.dcmn_nm,
        result.fileName,
        result.ad.assz_pcsn_tgt_tcd,
        result.ad.assz_pcsn_tcd,
        fileSize,
        result.ad.assz_pcsn_tgt_tcd,
        null,
        null,
        outFullPath,
        url_adr,
        rgsn_ts,
        amnn_ts,
        result.startDate,
        endDate,
        "N",
        null,
        result.ad.uda_sys_lsmd_id
      );

      try {
        //JSON 읽기
        console.log(`outFullPath:!!!!${outFullPath}`);
        const rawData = fs.readFileSync(outFullPath, "utf8");
        const jsonData = JSON.parse(rawData);

        // Jeff 결과가 {} 인 경우는 원본 txt가 빈텍스트인 경우
        // 20250613 cbkim
        if (
          Object.keys(jsonData).length === 0 ||
          Object.keys(jsonData.data).length === 0
        ) {
          // 자산화결과 상세 저장
          await TB_UDA_UAI911L.insertAstDtl(
            result.ad.assz_btch_acmp_id,
            result.ad.assz_unfc_id,
            "CK",
            "",
            0,
            0,
            outFullPath,
            result.startDate,
            endDate,
            result.ad.uda_sys_lsmd_id
          );
        } else {
          for (const ck of jsonData.data) {
            let { page, chunk_seq, chunk } = ck;

            const chunkChg = chunk.replace(/\u0000/g, "");

            // 자산화결과 상세 저장
            await TB_UDA_UAI911L.insertAstDtl(
              result.ad.assz_btch_acmp_id,
              result.ad.assz_unfc_id,
              "CK",
              chunkChg,
              page,
              chunk_seq,
              outFullPath,
              result.startDate,
              endDate,
              result.ad.uda_sys_lsmd_id
            );
          }
        }
      } catch (err) {
        writeLog(`자산화 결과 ERROR  : ${err.message}`);
      }

      writeLog(
        `[Jeff][${path.dirname(result.conv_flpt_vl)}][${result.oriFileName}][${
          result.outputPath
        }][${result.fileName}][Success]`
      );
      successCnt++;
    } else {
      writeLog(
        `[Jeff][${path.dirname(result.conv_flpt_vl)}][${
          result.oriFileName
        }][][][Fail]`
      );
      writeLog(`ERROR  : ${result.jeffData.data.error_msg}`);

      let errCdLog = "0510";
      let errStrLog = `ERROR  : ${result.jeffData.data.error_msg}`;

      if (result.sysName == "iemieb") {
        await TB_UDA_UAI901L.updateLogErr02(
          result.ad.assz_btch_acmp_id,
          result.ad.assz_unfc_id,
          errCdLog,
          errStrLog
        );
      } else {
        await TB_UDA_UAI901L.updateLog(
          result.ad.assz_btch_acmp_id,
          result.ad.assz_unfc_id,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          null,
          errCdLog,
          errStrLog
        );
      }

      updateErorVl(result.ad.assz_unfc_id, errCdLog, errStrLog);
      failCnt++;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "runJeff");
  writeLog("------------------runJeff2()종료----------------------------");
}

// 병렬처리 img jeff
async function rij(data) {
  while (true) {
    for (let url of jeffUrls) {
      // port 별로
      let res = {};
      const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      sleep(20);
      const jeffData = await callJeffApi(
        url,
        data.conv_flpt_vl,
        data.sysName,
        data.code != "" ? data.code : data.assz_dcmn_clsf_id,
        data.year
      );

      if (!jeffData || !jeffData.resp) continue;

      if (jeffData.resp.data.is_processing) continue;
      writeLog(`callJeffApi "${jeffData.jeffApiUrl}" "${data.conv_flpt_vl}"`);

      res.jeffData = jeffData.resp;
      res.success = jeffData.resp.data.is_success == 1 ? true : false;
      res.metaData = data.metaData;
      res.outputPath = data.outputPath;
      res.perOutputPath = data.perOutputPath;
      res.il = data.il;
      res.startDate = staDate;
      res.conv_flpt_vl = data.conv_flpt_vl;
      res.fileName = data.fileName;
      res.sysName = data.sysName;
      res.oriFileName = data.oriFileName;

      return res;
    }
  }
}

async function runImgJeff(assz_btch_acmp_id, sysName, basDt, includeObj) {
  writeLog("------------------runImgJeff()시작----------------------------");
  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(jeffUrls.length);
  const limitParams = [];

  let year = "";
  let metaData = null;
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  let outputPath = `/data/asset/${sysDir}/${basDt}/json`;
  let perOutputPath = `/data/asset/${sysDir}/${basDt}/perfor`;

  writeLog(`------------------${outputPath}---------------------------`);

  fs.mkdirSync(outputPath, { recursive: true });
  fs.mkdirSync(perOutputPath, { recursive: true });

  const imgLog = await TB_UDA_UAI902L.selectImgLog(assz_btch_acmp_id, "0000");
  writeLog(`runImgJeff > imgLog > length::${imgLog.rows.length}`);
  for (const il of imgLog.rows) {
    const conv_flpt_vl = il.assz_img_file_path_nm;
    if (!conv_flpt_vl) {
      continue;
    }
    const oriFileName = path.basename(conv_flpt_vl);

    if (path.extname(oriFileName).toLowerCase() === ".txt") {
      let fileName = `${path.parse(oriFileName).name}.json`;

      const startDate = dayjs().format("YYYY-MM-DD HH:mm:ss");

      let code = "";
      let dcmn_nm = "";

      // 업무매뉴얼일 경우
      if (sysName == "iemieb") {
        metaData = await TB_UDA_UAI803L.selectMeta02(
          assz_btch_acmp_id,
          il.assz_cfbo_idnt_id
        );
        dcmn_nm = metaData.rows[0].dcmn_nm;
        year = String(metaData.rows[0].amnn_ts).split(" ")[3];
      } else if (sysName == "csmcsm") {
        metaData = await TB_UDA_UAI872M.selectMetaOne(
          null,
          assz_btch_acmp_id,
          il.assz_cfbo_idnt_id
        );
        year = String(metaData.rows[0].amnn_ts).split(" ")[3];
        // 지식샘일 경우
      } else if (sysName == "aikkms") {
        year = il.assz_img_file_path_nm.split("/")[7];
        outputPath = `/data/asset/${sysDir}/${basDt}/txt/${year}`;
      } else if (sysName == "kmsepn" || sysName == "kmsplz") {
        metaData = await TB_UDA_UAI871M.selectMetaOne(
          null,
          assz_btch_acmp_id,
          il.assz_unfc_id
        );

        year = String(metaData.rows[0].amnn_ts).split(" ")[3];
        let includeList = Object.keys(includeObj);
        code =
          includeObj[
            sysName === "kmsepn"
              ? includeList.filter((d, i) =>
                  metaData.rows[0].atch_nm.includes(d)
                )[0]
              : "상품설명서"
          ];
      }

      limitParams.push({
        conv_flpt_vl: conv_flpt_vl,
        sysName: sysName,
        assz_dcmn_clsf_id: "",
        year: year,
        metaData: metaData,
        outputPath: outputPath,
        perOutputPath: perOutputPath,
        il: il,
        fileName: fileName,
        //dcmn_nm: dcmn_nm,
        oriFileName: oriFileName,
        code: code,
      });
    }
  }

  const tasks = limitParams.map((data, idx) => limit(() => rij(data)));

  for await (const result of tasks) {
    totalCnt++;

    if (result.success) {
      let chunkedData = result.jeffData.data.chunked;

      let perforMetrics = result.jeffData.data.perfor_metrics;

      writeLog(result.il.assz_unfc_id);
      writeLog(JSON.stringify(perforMetrics));
      writeLog(Object.keys(perforMetrics).length);

      // data 결과
      const outFullPath = `${result.outputPath}/${result.fileName}`;
      let outJsonStr = JSON.parse(
        `{"data":${
          Object.keys(chunkedData).length != 0
            ? JSON.stringify(chunkedData.data)
            : "{}"
        }}`
      );
      fs.writeFileSync(
        outFullPath,
        JSON.stringify(outJsonStr, null, 2),
        "utf-8"
      );

      // performce 결과
      const perforOutFullPath = `${result.perOutputPath}/${result.fileName}`;
      let perforOutJsonStr = JSON.parse(
        `{"result":${
          Object.keys(chunkedData).length != 0
            ? JSON.stringify(chunkedData.result)
            : "{}"
        }}`
      );
      fs.writeFileSync(
        perforOutFullPath,
        JSON.stringify(perforOutJsonStr, null, 2),
        "utf-8"
      );

      if (Object.keys(perforMetrics).length > 0) {
        const dup_char_rate = perforMetrics.metric1.dup_rate.dup_char_rate;
        const dup_word_rate = perforMetrics.metric1.dup_rate.dup_word_rate;
        const lcs_rouge = perforMetrics.metric2.rouge.rougeL;
        const meteor = perforMetrics.metric3.meteor;
        const bert = perforMetrics.metric4.bert;

        await insertQualityMng(
          result.il.assz_unfc_id,
          result.oriFileName,
          "IMG",
          dup_char_rate,
          dup_word_rate,
          lcs_rouge,
          meteor,
          bert,
          result.il.uda_sys_lsmd_id
        );
      }

      // 성공 로그 insert
      const endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      await TB_UDA_UAI912L.insertImgAst(
        result.il.assz_btch_acmp_id,
        result.il.assz_unfc_id,
        result.il.img_sqn,
        result.il.assz_page_no,
        result.il.assz_img_no,
        result.il.assz_img_tppo_xcr_vl,
        result.il.assz_img_tppo_ycr_vl,
        result.il.assz_img_lwen_xcr_vl,
        result.il.assz_img_lwen_ycr_vl,
        result.oriFileName,
        JSON.stringify(outJsonStr),
        "IG",
        outFullPath,
        result.startDate,
        endDate,
        result.il.uda_sys_lsmd_id
      );

      writeLog(
        `[Jeff][${path.dirname(result.conv_flpt_vl)}][${result.oriFileName}][${
          result.outputPath
        }][${result.fileName}][Success]`
      );
      successCnt++;
    } else {
      writeLog(
        `[Jeff][${path.dirname(result.conv_flpt_vl)}][${
          result.oriFileName
        }][][][Fail]`
      );
      writeLog(`ERROR : ${result.jeffData.data.error_msg}`);

      const endDate2 = dayjs().format("YYYY-MM-DD HH:mm:ss");
      errCd = "0510";
      errStr = `ERROR  : ${result.jeffData.data.error_msg}`;
      await TB_UDA_UAI902L.updateImgLog(
        result.il.assz_btch_acmp_id,
        result.il.assz_unfc_id,
        result.il.img_sqn,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        errCd,
        errStr,
        null,
        endDate2,
        null,
        null
      );
      failCnt++;
      continue;
    }
  }

  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "runImgJeff");
  writeLog("------------------runImgJeff()종료----------------------------");
}

function executeCommand(commandStr, cwd) {
  return new Promise((resolve, reject) => {
    const parts = commandStr.split(" ");
    const cmd = parts[0];
    const args = parts.slice(1);

    let options = {
      shell: true,
    };
    if (typeof cwd != "undefined") {
      options.cwd = cwd;
    }

    const child = spawn(cmd, args, options);

    let output = "";
    let errorOutput = "";

    child.stdout.on("data", (data) => {
      output += data.toString();
    });

    child.stderr.on("data", (data) => {
      errorOutput += data.toString();
    });

    child.on("close", (code) => {
      if (code === 0) {
        resolve(output.trim());
      } else {
        reject(errorOutput || `명령어 실패 (종료코드: ${code})`);
      }
    });

    child.on("error", (err) => {
      reject(`명령어 실행 오류: ${err.message}`);
    });
  });
}

async function imgToDp2(assz_btch_acmp_id, sysName, basDt) {
  //***21번 read 21번 업데이트
  writeLog("------------------imgToDp2()시작----------------------------");
  //let sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  const imgData = await TB_UDA_UAI902L.selectImgLog02(
    assz_btch_acmp_id,
    "0000"
  );
  const { exec } = require("child_process");

  let inputPath = `/data/asset/${sysDir}/${basDt}/dp`;
  //let outputPath = `/data/bdpetl/send/gai/gai/${sysDir.split('/')[1]}/${basDt}`;
  let outputPath = `/data/asset/${sysDir}/${basDt}/txt`;
  /*if (isAtt == "Y") {
    inputPath = `/data/asset/${sysDir}/${basDt}/att`;
  } else {
    inputPath = `/data/asset/${sysDir}/${basDt}/dp`;
  }*/

  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  let metaData = null;
  let year = "";

  writeLog(`start`);
  //  for (let inputPath of inputPaths) {
  //    let entries = fs.readdirSync(inputPath, { withFileTypes: true });
  for (const imd of imgData.rows) {
    writeLog(`start${imd.assz_img_file_path_nm}`);

    let startDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    let endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
    //for (let ent of entries) {
    //if (!imd.isFile()) continue;
    //      const fn = ent.name;
    //const src = path.join(inputPath, fn);
    const src = imd.assz_img_file_path_nm;
    const ext = path.extname(src);
    const name = path.basename(src, ext);
    const fileName = `${name}.txt`;

    // 지식샘일 경우
    if (sysName == "aikkms") {
      year = src.split("/")[7];
      outputPath = `/data/asset/${sysDir}/${basDt}/txt/${year}`;
    }

    // 이미지인지 체크
    if (isImageFile(src)) {
      totalCnt++;
      try {
        // DP API 호출
        //writeLog(`***************Src : ${src}`);
        const dpData = await callDpApi(src);
        //writeLog(`***************dpData : ${dpData}`);
        //writeLog(`[DP][${inputPath}][${fn}][Success]`);
        //          let fileName = `${path.parse(src).name}.txt`;
        // DP결과 생성
        writeTxt(outputPath, fileName, dpData); //DP준대로저장
        //await fsp.unlink(src);
      } catch (err) {
        writeLog(`[DP][${inputPath}][${name}][][][Fail]`);
        writeLog(`ERROR : ${err.message}`);
        endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
        failCnt++;
        await TB_UDA_UAI902L.updateDpLog(
          imd.assz_btch_acmp_id,
          imd.assz_unfc_id,
          imd.img_sqn,
          "02",
          EROR_CODES.EROR_VL_DP_FAILED,
          EROR_CODES.EROR_VL_DP_FAILED_STR,
          startDate,
          endDate,
          `${outputPath}/${fileName}`,
          `UDA${sysName.slice(-3).toUpperCase()}DASSETR001`
        );
        await TB_UDA_UAI901L.updateLog(
          imd.assz_btch_acmp_id,
          imd.assz_unfc_id,
          "02",
          null,
          null,
          null,
          null,
          null,
          startDate, //변환시작일시
          endDate, //변환종료일시
          `${outputPath}/${fileName}`,
          null,
          null,
          null,
          null,
          EROR_CODES.EROR_VL_DP_FAILED,
          EROR_CODES.EROR_VL_DP_FAILED_STR
        );

        // 지식샘일 경우
        if (sysName == "aikkms") {
          updateErorVl(
            imd.assz_unfc_id,
            EROR_CODES.EROR_VL_DP_FAILED,
            `${EROR_CODES.EROR_VL_DP_FAILED_STR} ${err.message}`
          );
        }
        continue;
      }
      try {
        // 운영
        // const command = `python /app/dp/DP_cleaned_result2.py "${outputPath}/${fileName}"`;
        // 개발
        const command = `/app/anaconda3/bin/python3 /app/dp/DP_cleaned_result2.py "${outputPath}/${fileName}"`;
        await new Promise((resolve, reject) => {
          exec(command, (error, stdout, stderr) => {
            if (error) {
              //writeLog(`DP TXT CLEAN 에러:${error.message}`);
              reject(new Error(`DP TXT CLEAN 에러`));
              //resolve(); //에러나도 넘어가게끔 하려면
            }
            //writeLog(`stdout:${stdout}`);
            if (stdout.includes("[Success]")) {
              writeLog(`DP TXT CLEAN 성공: ${outputPath}/${fileName}`);
              //reject(new Error(`DP TXT CLEAN 성공`));
              resolve();
            } else if (stdout.includes(`[Fail]`)) {
              //writeLog(`DP TXT CLEAN 실패 [Fail 출력됨]: ${outputPath}/${fileName}`);
              reject(new Error(`DP TXT CLEAN 실패 [Fail 출력됨]`));
              //resolve();
            } else {
              //writeLog(`결과미확인 성공/실패 정보 없음: ${outputPath}/${fileName}`);
              reject(new Error(`결과미확인 성공/실패 정보 없음`));
              //resolve(); //에러나도 넘어가게끔 하려면
            }
          });
        });
      } catch (err) {
        writeLog(`[DP][${inputPath}][${name}][][][Fail]`);
        writeLog(`ERROR : ${err.message}`);
        endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
        failCnt++;
        await TB_UDA_UAI902L.updateDpLog(
          imd.assz_btch_acmp_id,
          imd.assz_unfc_id,
          imd.img_sqn,
          "02",
          EROR_CODES.EROR_VL_DP_CLEAN_FAILED,
          EROR_CODES.EROR_VL_DP_CLEAN_FAILED_STR,
          startDate,
          endDate,
          `${outputPath}/${fileName}`,
          `UDA${sysName.slice(-3).toUpperCase()}DASSETR001`
        );
        await TB_UDA_UAI901L.updateLog(
          imd.assz_btch_acmp_id,
          imd.assz_unfc_id,
          "02",
          null,
          null,
          null,
          null,
          null,
          startDate, //변환시작일시
          endDate, //변환종료일시
          `${outputPath}/${fileName}`,
          null,
          null,
          null,
          null,
          EROR_CODES.EROR_VL_DP_CLEAN_FAILED,
          EROR_CODES.EROR_VL_DP_CLEAN_FAILED_STR
        );

        // 지식샘일 경우
        if (sysName == "aikkms") {
          updateErorVl(
            imd.assz_unfc_id,
            EROR_CODES.EROR_VL_DP_CLEAN_FAILED,
            `${EROR_CODES.EROR_VL_DP_CLEAN_FAILED_STR} ${err.message}`
          );
        }

        continue;
      }
      writeLog(
        `[DP][${inputPath}][${name}][${outputPath}][${fileName}][Success]`
      );
      endDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      successCnt++;
      await TB_UDA_UAI902L.updateDpLog(
        imd.assz_btch_acmp_id,
        imd.assz_unfc_id,
        imd.img_sqn,
        "01",
        "0000",
        "DP처리정상",
        startDate,
        endDate,
        `${outputPath}/${fileName}`,
        `UDA${sysName.slice(-3).toUpperCase()}DASSETR001`
      );
    }
  }
  summaryLog(totalCnt, successCnt, failCnt, assz_btch_acmp_id, "imgToDp2");
  writeLog("------------------imgToDp2()종료----------------------------");
}

// 원장결과 재생성
async function resetOriginResult(assz_btch_acmp_id, sysName, basDt, eror_vl) {
  writeLog(
    "----------------------------resetOriginResult() 시작----------------------------"
  );

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  //const outputDir = `/data/asset/${sysDir}/${basDt}/json`;
  const outputDir = `/data/asset/${sysDir}/json`;

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccess(
    assz_btch_acmp_id,
    sysName.toUpperCase(),
    eror_vl
  );

  for (const rowMetaData of metaData.rows) {
    try {
      let outFullPath = `${outputDir}/${rowMetaData.assz_unfc_id}.json`;
      let erorVl = COMMON_CODES.ASSZ_SCD_SUCCESS;
      if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
        outFullPath = `${outputDir}/${rowMetaData.assz_cfbo_idnt_id}.json`;
        erorVl = COMMON_CODES.ASSZ_SCD_INIT;
      }
      let outOriginPdfFullPath = outFullPath
        .replaceAll("/json", "/originpdf")
        .replaceAll(".json", ".pdf");
      // 원장 자산화 상태코드 변경
      await updateAsszScd(
        rowMetaData.assz_unfc_id,
        erorVl,
        outOriginPdfFullPath
      ); // 000m originpdf 경로가 되어야한다
      const rawData = fs.readFileSync(outFullPath, "utf8");
      const jsonData = JSON.parse(rawData);

      // 원장 결과 삭제 후 저장
      await deleteAssDtl(rowMetaData.assz_unfc_id);

      let getAssDtlSeqData = await getAssDtlSeq(rowMetaData.assz_unfc_id);
      let assz_rslt_dtl_sqn = getAssDtlSeqData.rows[0].idx;

      if (
        Object.keys(jsonData).length === 0 ||
        Object.keys(jsonData.data).length === 0
      ) {
        // 원장 결과 저장
        await insertAssDtl(
          rowMetaData.assz_unfc_id,
          ++assz_rslt_dtl_sqn,
          "CK",
          0,
          0,
          outFullPath,
          "",
          0,
          0,
          0,
          0,
          rowMetaData.uda_sys_lsmd_id
        );
      } else {
        for (const ck of jsonData.data) {
          let { page, chunk_seq, chunk } = ck;
          const chunkChg = chunk.replace(/\u0000/g, "");
          // 원장 결과 저장
          await insertAssDtl(
            rowMetaData.assz_unfc_id,
            ++assz_rslt_dtl_sqn,
            "CK",
            page,
            chunk_seq,
            outFullPath,
            chunkChg,
            0,
            0,
            0,
            0,
            rowMetaData.uda_sys_lsmd_id
          );
        }
      }
    } catch (err) {
      writeLog(
        `자산화 원장 결과 ERROR  ${rowMetaData.assz_unfc_id}: ${err.message}`
      );
    }
  }

  writeLog(
    "---------------------------resetOriginResult() 종료----------------------------"
  );
}

/*---------------------- 학습데이터 파일복사 ----------------------*/
async function moveToLearn(systemName, assz_btch_acmp_id) {
  writeLog(
    "----------------------------moveToLearn()시작----------------------------"
  );
  let totalCnt = 0;
  let successCnt = 0;
  let failCnt = 0;
  const resultData = await selectTxtFileCopyToLearn(
    null,
    systemName,
    assz_btch_acmp_id
  );

  for (const rd of resultData.rows) {
    totalCnt++;
    writeLog(`파일풀path:::${rd.srctxtfile}`);
    if (fs.existsSync(rd.srctxtfile)) {
      writeLog(`파일있음:::${rd.srctxtfile}`);
      try {
        if (!fs.existsSync(rd.tgtdir)) {
          writeLog(`폴더생성하기:::${rd.tgtdir}`);
          await fs.mkdirSync(`${rd.tgtdir}`, { recursive: true });
        }

        await fs.copyFileSync(rd.srctxtfile, rd.tgttxtfile);
        successCnt++;
      } catch (err) {
        failCnt++;
        writeLog(`폴더 생성 실패: ${rd.srctxtfile}:${rd.tgttxtfile}`);
      }
    } else {
      writeLog(`파일없음:::${rd.srctxtfile}`);
      failCnt++;
    }
  }
  await summaryLog(
    totalCnt,
    successCnt,
    failCnt,
    assz_btch_acmp_id,
    "moveToLearn"
  );
  writeLog(
    "----------------------------moveToLearn()종료----------------------------"
  );
}

// 병렬처리 masking
async function rm(data) {
  while (true) {
    for (let url of maskingUrls) {
      // port 별로
      let res = {};
      const staDate = dayjs().format("YYYY-MM-DD HH:mm:ss");
      sleep(100);
      const maskingData = await callMaskingApi(url, data.targetFullPath);

      if (!maskingData || !maskingData.resp) continue;

      if (maskingData.resp.data?.is_processing) continue;

      // console.log(maskingData);
      //maskingData.resp.data.data.forEach((d, i) => console.log(d.be));
      //let deid = maskingData.resp.data.data.filter((d, i) => d.be.length > 0);

      writeLog(
        `callMaskingApi "${maskingData.maskingApiUrl}" "${data.targetFullPath}"`
      );

      res.maskingData = maskingData.resp;
      //res.success = maskingData.resp.data.is_success == 1 ? true : false;
      res.targetFullPath = data.targetFullPath;
      res.maskDir = data.maskDir;
      res.startDate = staDate;
      res.assz_unfc_id = data.assz_unfc_id;
      return res;
    }
  }
}

// 비식별화 데이터 생성
async function insertMaskingData(assz_btch_acmp_id, sysName, eror_vl, batchId) {
  writeLog(
    "----------------------------insertMaskingData() 시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(maskingUrls.length);
  const limitParams = [];

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  const targetDir = `/data/asset/${sysDir}/json`;
  const maskDir = `/data/asset/${sysDir}/mask`;

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccess(
    assz_btch_acmp_id,
    sysName.toUpperCase(),
    eror_vl
  );

  for (const rowMetaData of metaData.rows) {
    let targetFullPath = "";
    if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
      targetFullPath = `${targetDir}/${rowMetaData.assz_cfbo_idnt_id}.json`;
    } else {
      targetFullPath = `${targetDir}/${rowMetaData.assz_unfc_id}.json`;
    }

    limitParams.push({
      targetFullPath: targetFullPath,
      maskDir: maskDir,
      assz_unfc_id: rowMetaData.assz_unfc_id,
    });
  }

  const tasks = limitParams.map((data, idx) => limit(() => rm(data)));

  for await (const result of tasks) {
    let deids = Array.isArray(result.maskingData.data.data)
      ? result.maskingData.data.data.filter((d, i) => d.be.length > 0)
      : [];
    if (deids.length > 0) {
      //unfcId = path.basename(result.targetFullPath, ".json");
      unfcId = result.assz_unfc_id;
      let maskginPath = result.targetFullPath.replace("/json/", "/mask/");

      writeTxt(result.maskDir, `${unfcId}.json`, result.maskingData.data);

      await deleteAnonymizedData(null, unfcId);

      let anonymized_data_id = await insertAnonymizedData(
        null,
        unfcId,
        maskginPath,
        batchId
      );

      for (let deid of deids) {
        let details = deid.be.map((d, i) => {
          return {
            seq: deid.chunk_seq,
            type: d.type,
            text: deid.chunk.substring(d.start, d.end),
          };
        });

        for (let d of details) {
          await insertAnonymizedDataDetail(
            null,
            anonymized_data_id,
            d.type,
            d.text,
            batchId
          );
        }
        //console.log(aa);
      }
    }
  }

  writeLog(
    "---------------------------insertMaskingData() 종료----------------------------"
  );
}

// 수명주기 저장
async function lifecycleInsert(assz_btch_acmp_id, sysName, eror_vl) {
  writeLog(
    "----------------------------lifecycleInsert() 시작----------------------------"
  );

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccessLifecycle(
    assz_btch_acmp_id,
    sysName.toUpperCase(),
    eror_vl
  );

  for (const rowMetaData of metaData.rows) {
    try {
      // console.log(">>> rowMetaData", rowMetaData);
      // 수명주기 조회
      let result = await selectCountLifecycle(rowMetaData.assz_unfc_id);

      // 수명주기가 존재하지 않을 경우
      if (result.rows[0].count == 0) {
        if (rowMetaData.assz_pcsn_tcd == "C") {
          // 수명주기 저장
          await insertLifecycle(
            rowMetaData.assz_unfc_id,
            rowMetaData.orgn_data_rgsr_id,
            rowMetaData.rgsr_dept_id,
            rowMetaData.rgsn_ts
              ? rowMetaData.rgsn_ts
              : COMMON_CODES.DEFAULT_NULL_DATE,
            rowMetaData.uda_sys_lsmd_id
          );
        }
        // 수명주기가 존재할 경우
      } else {
        // 문서 폐기처리
        if (rowMetaData.assz_pcsn_tcd == "D") {
          await discardDocument(rowMetaData.assz_unfc_id);
        }
      }
    } catch (err) {
      writeLog(`생명주기 저장 ERROR  : ${err.message}`);
    }
  }

  writeLog(
    "---------------------------lifecycleInsert() 종료----------------------------"
  );
}

// 원장결과 재생성
async function resetOriginResultReGen(sysName, eror_vl) {
  writeLog(
    "----------------------------resetOriginResultReGen() 시작----------------------------"
  );

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccessReGen(sysName.toUpperCase(), eror_vl);
  writeLog(`metaData total::::${metaData.rowCount}`);
  for (const rowMetaData of metaData.rows) {
    try {
      //const outputDir = `/data/asset/${sysDir}/${rowMetaData.basdt}/json`;
      const outputDir = `/data/asset/${sysDir}/json`;
      writeLog(`outputDir::::${outputDir}`);
      // 원장 자산화 상태코드 변경
      let orginPdfPath = outputDir.replace("json", "originpdf");
      let originPdfFullPath = `${orginPdfPath}/${rowMetaData.assz_unfc_id}.pdf`;

      let erorVl = COMMON_CODES.ASSZ_SCD_SUCCESS;
      if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
        originPdfFullPath = `${orginPdfPath}/${rowMetaData.assz_cfbo_idnt_id}.pdf`;
        erorVl = COMMON_CODES.ASSZ_SCD_INIT;
      }

      await updateAsszScd(rowMetaData.assz_unfc_id, erorVl, originPdfFullPath);

      let outFullPath = `${outputDir}/${rowMetaData.assz_unfc_id}.json`;

      if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
        outFullPath = `${outputDir}/${rowMetaData.assz_cfbo_idnt_id}.json`;
      }

      const rawData = fs.readFileSync(outFullPath, "utf8");
      const jsonData = JSON.parse(rawData);

      // 원장 결과 삭제 후 저장
      await deleteAssDtl(rowMetaData.assz_unfc_id);

      let getAssDtlSeqData = await getAssDtlSeq(rowMetaData.assz_unfc_id);
      writeLog(`getAssDtlSeqData idx::::${getAssDtlSeqData.rows[0].idx}`);
      let assz_rslt_dtl_sqn = getAssDtlSeqData.rows[0].idx;

      if (
        Object.keys(jsonData).length === 0 ||
        Object.keys(jsonData.data).length === 0
      ) {
        writeLog(`jsonData length 0 case::::${rowMetaData.assz_unfc_id}`);
        // 원장 결과 저장
        await insertAssDtl(
          rowMetaData.assz_unfc_id,
          ++assz_rslt_dtl_sqn,
          "CK",
          0,
          0,
          outFullPath,
          "",
          0,
          0,
          0,
          0,
          rowMetaData.uda_sys_lsmd_id
        );
      } else {
        writeLog(`jsonData length not 0 case::::${rowMetaData.assz_unfc_id}`);
        for (const ck of jsonData.data) {
          let { page, chunk_seq, chunk } = ck;
          const chunkChg = chunk.replace(/\u0000/g, "");
          writeLog(`jsonData length not 0 >  case::::${page}::${chunk_seq}`);
          // 원장 결과 저장
          await insertAssDtl(
            rowMetaData.assz_unfc_id,
            ++assz_rslt_dtl_sqn,
            "CK",
            page,
            chunk_seq,
            outFullPath,
            chunkChg,
            0,
            0,
            0,
            0,
            rowMetaData.uda_sys_lsmd_id
          );
        }
      }
    } catch (err) {
      writeLog(
        `자산화 원장 결과 ERROR  ${rowMetaData.assz_unfc_id}: ${err.message}`
      );
    }
  }

  writeLog(
    "---------------------------resetOriginResultReGen() 종료----------------------------"
  );
}

// 비식별화 데이터 생성 (업무매뉴얼의 경우 eror_vl: 0000,0003 을 할경우 0003은 되어있고 0000만 돌려야할경우)
async function insertMaskingDataMaskingAll(sysName, batchId) {
  writeLog(
    "----------------------------insertMaskingData() 시작----------------------------"
  );

  const pLimit = (await import("p-limit")).default;
  const limit = pLimit(maskingUrls.length);
  const limitParams = [];

  let sysDir = "";
  if (sysName.length == 6) {
    sysDir = `${sysName.slice(0, 3)}/${sysName.slice(3)}`;
  } else {
    sysDir = sysName.replace("epn", "epnt").replace("plz", "epnt");
    let sp = sysName.split("/");
    if (sp.length > 2) {
      if (sp[2] == "epn") {
        sysName = "kmsepn";
      } else if (sp[2] == "plz") {
        sysName = "kmsplz";
      } else {
        sysName = sp[0] + sp[1];
      }
    }
  }

  const targetDir = `/data/asset/${sysDir}/json`;
  const maskDir = `/data/asset/${sysDir}/mask`;

  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  // 원장 마스터, 메타 조회 (각 시스템별로 성공한 건만)
  let metaData = await selectMetaSuccessMaskingAll(sysName.toUpperCase());

  for (const rowMetaData of metaData.rows) {
    let targetFullPath = "";
    if (sysName == "iemieb" && rowMetaData.eror_vl == "0000") {
      targetFullPath = `${targetDir}/${rowMetaData.assz_cfbo_idnt_id}.json`;
    } else {
      targetFullPath = `${targetDir}/${rowMetaData.assz_unfc_id}.json`;
    }

    limitParams.push({
      targetFullPath: targetFullPath,
      maskDir: maskDir,
    });
  }

  const tasks = limitParams.map((data, idx) => limit(() => rm(data)));

  for await (const result of tasks) {
    let deids = Array.isArray(result.maskingData.data.data)
      ? result.maskingData.data.data.filter((d, i) => d.be.length > 0)
      : [];
    if (deids.length > 0) {
      unfcId = path.basename(result.targetFullPath, ".json");
      let maskginPath = result.targetFullPath.replace("/json/", "/mask/");

      writeTxt(result.maskDir, `${unfcId}.json`, result.maskingData.data);

      await deleteAnonymizedData(null, unfcId);

      let anonymized_data_id = await insertAnonymizedData(
        null,
        unfcId,
        maskginPath,
        batchId
      );

      for (let deid of deids) {
        let details = deid.be.map((d, i) => {
          return {
            seq: deid.chunk_seq,
            type: d.type,
            text: deid.chunk.substring(d.start, d.end),
          };
        });

        for (let d of details) {
          await insertAnonymizedDataDetail(
            null,
            anonymized_data_id,
            d.type,
            d.text,
            batchId
          );
        }
        //console.log(aa);
      }
    }
  }

  writeLog(
    "---------------------------insertMaskingData() 종료----------------------------"
  );
}

module.exports = {
  imgToDp2,
  runJeff2,
  runImgJeff,
  executeCommand,
  sleep,
  callDpApi,
  resetOriginResult,
  moveToLearn,
  insertMaskingData,
  lifecycleInsert,
  resetOriginResultReGen,
  insertMaskingDataMaskingAll,
};
