const { Pool } = require("pg");
const config = require("./config");
const pool = new Pool(config.db);
const fs = require("fs");

//const basDt = process.argv[2];

const make_access_102sam = async (basDt) => {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `
      select coalesce(wpt_enfr_dcmn_id::text, '') 
      || '^|' 
      || coalesce(wpt_rtpl_grp_id::text, '') 
      || '^|' 
      || coalesce(wpt_rtpl_grp_nm::text, '') 
      || '^|' 
      || coalesce(wpt_rgsr_id::text, '') 
      || '^|' 
      || coalesce(rgsn_ts::text, '') 
      || '^|' 
      || coalesce(wpt_rtpl_grp_dsnc_vl::text, '') 
      || '^|' 
      || coalesce(uda_sys_lsmd_id::text, '') 
      || '^|' 
      || coalesce(uda_sys_lsmd_ts::text, '') as meta 
      from tb_uda_uai102m
      where sys_lsmd_ts = (select max(sys_lsmd_ts) from tb_uda_uai102m)
    `
    );
    let datas = res.rows;

    let metas = datas.map((d, i) => d.meta).join("\n");

    const dirPath = `/data/bdpetl/send/gai/gai/auth/${basDt}/`;
    const fileName = `tb_uda_uai102m_${basDt}.sam`;
    const fullPath = `${dirPath}${fileName}`;

    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
      console.log(`[폴더생성][${dirPath}]`);
    }

    fs.writeFileSync(fullPath, metas, "utf-8");
    console.log(`[권한SAM생성완료][102][${fullPath}][${res.rowCount}]`);
  } catch (e) {
    console.log(e);
  } finally {
    client.release();
  }
};

//run();

module.exports = { make_access_102sam };
