const { execFile, execFileSync } = require("child_process");
const { promisify } = require("util");
const path = require("path");
const fs = require("fs");

const execFileAsync = promisify(execFile);

/* =========================
 *   Option token validator
 * ========================= */
function buildOptionValidator(allowList = [], allowPatterns = []) {
  const exact = new Set(allowList);
  const regexps = allowPatterns.map((p) => new RegExp(p));
  return function validate(tokens = []) {
    for (const t of tokens) {
      if (typeof t !== "string" || t.length === 0 || t.length > 256) {
        throw new Error("invalid option token length/type");
      }
      // 공백/메타문자 차단 (쉘은 안 쓰지만 보수적으로 막음)
      if (/[ \t\r\n`"'\\;&|<>]/.test(t) || t.includes("\0")) {
        throw new Error(`unsafe chars in option: ${t}`);
      }
      if (exact.has(t)) continue;
      if (regexps.some((r) => r.test(t))) continue;
      throw new Error(`disallowed option: ${t}`);
    }
    return tokens;
  };
}

/**
 * Command Injection 방어 (CWE-78)
 * - execFile/execFileSync만 사용, shell:false 고정
 * - 인터프리터/바이너리 절대경로 화이트리스트
 * - 옵션 토큰 화이트리스트/패턴 + 경로 인자 PathGuard 정화
 * - 최종 argv는 새 배열로 재조립 후 freeze (Fortify 친화)
 */
class CommandGuard {
  /**
   * @param {Object} opts
   * @param {Record<string, string>} opts.whitelistCmds { python3:"/usr/bin/python3", node: "/usr/bin/node" }
   * @param {string[]} [opts.allowedScriptRoots] 스크립트 허용 디렉터리(절대경로)
   * @param {Record<string, {allowList?:string[], allowPaterns?:string[]}>} [opts.optionPolicies]
   */

  constructor({
    whitelistCmds = {},
    allowedScriptRoots = [],
    optionPolicies = {},
  } = {}) {
    this.whitelist = Object.freeze({ ...whitelistCmds });
    this.allowedScriptRoots = Object.freeze([...allowedScriptRoots]);
    this.optionValidators = Object.freeze(
      Object.fromEntries(
        Object.entries(optionPolicies).map(([k, v]) => [
          k,
          buildOptionValidator(v.allowList || [], v.allowPaterns || []),
        ])
      )
    );
  }

  _resolveBinary(key) {
    const bin = this.whitelist[key];
    if (!bin) throw new Error(`command not allowed: ${key}`);
    if (!path.isAbsolute(bin))
      throw new Error(`whitelisted command must be absolute path`);
    return bin;
  }

  static _inside(baseAbs, targetAbs) {
    const rel = path.relative(baseAbs, targetAbs);
    return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
  }

  /**
   * ----------------------------------------
   * 공용: 스크립트 경로 정화 + 허용 디렉터리 검사
   * ----------------------------------------*/

  _sanitizeScriptPathSync(script, pathGuard) {
    const { PathGuard } = require("./pathGuard"); // 순환 의존 방지
    let scriptAbs;
    if (script?.abs) scriptAbs = pathGuard.allowAbsoluteSync(script.abs);
    else if (script?.rel)
      scriptAbs = pathGuard.resolveUnder(script.rel, script.rootIndex ?? 0);
    else throw new Error("script path (abs or rel) required");

    // 정규파일 확인
    PathGuard.assertRegularFileSync(scriptAbs);

    // 스크립트 허용 루트 내부만 허용 (선택, 있으면 강하게 막음)
    if (this.allowedScriptRoots.length > 0) {
      const realRoots = this.allowedScriptRoots.map((r) => {
        try {
          return fs.realpathSync.native(r);
        } catch {
          return path.resolve(r);
        }
      });
      const ok = realRoots.some((root) =>
        CommandGuard._inside(root, scriptAbs)
      );
      if (!ok) throw new Error("script outside allowed script roots");
    }
    return scriptAbs;
  }

  /**
   * 공용: 토큰/경로 인자 정화 -> argv 생성
   */
  _buildArgvSync(interpreterKey, scriptAbs, args, pathGuard) {
    const validator =
      this.optionValidators[interpreterKey] ||
      ((tokens = []) => {
        // 기본 SAFE 정규식 (공백/메타문자 배제)
        const SAFE = /^[\w@%+=:,./-]{1,256}$/;
        for (const t of tokens) {
          if (typeof t !== "string" || !SAFE.test(t))
            throw new Error(`unsafe option: ${t}`);
        }
        return tokens;
      });

    const tokens = validator(
      Array.isArray(args?.strings) ? [...args.strings] : []
    );

    const rootIndex = args?.rootIndex ?? 0;

    const absArgs = [];
    for (const p of args?.absPaths || []) {
      absArgs.push(pathGuard.allowAbsoluteSync(p));
    }

    const relArgs = [];
    for (const p of args?.relPaths || []) {
      relArgs.push(pathGuard.resolveUnder(p, rootIndex));
    }

    // Fortify 친화 : 검증된 값만 새 배열에 담고 freeze
    return Object.freeze([scriptAbs, ...tokens, ...absArgs, ...relArgs]);
  }

  /* ===============================
   * 비동기 실행 (execFile)
   * =============================== */
  async run(cmdKey, stringArgs = [], opts = {}) {
    const bin = this._resolveBinary(cmdKey);

    // 기본 토큰 검증
    const SAFE = /^[\w@%+=:,./-]{1,256}$/;
    for (const t of stringArgs) {
      if (typeof t !== "string" || !SAFE.test(t))
        throw new Error(`unsafe option: ${t}`);
    }
    const argv = Object.freeze([...stringArgs]);

    const timeout = opts.timeoutMs ?? 60_000;
    const maxBuffer = opts.maxBuffer ?? 10 * 1024 * 1024;
    const cwd = opts.cwd ? path.resolve(opts.cwd) : process.cwd();

    return execFileAsync(bin, argv, {
      cwd,
      timeout,
      maxBuffer,
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
    });
    // Fortify note:
    // - bin from absolute whitelist
    // - argv rebuilt & frozen from validated tokens (no shell)
  }

  /* ===============================
   * 인터프리터 + 스크립트 실행 (SYNC)
   * =============================== */
  runScriptSync(interpreterKey, script, args, pathGuard, opts = {}) {
    const interpreter = this._resolveBinary(interpreterKey);

    // 1) 스크립트 경로 정화(실경로 + 허용루트 + 정규파일)
    const scriptAbs = this._sanitizeScriptPathSync(script, pathGuard);

    // 2) 옵션/경로 인자 정화 -> argv 재조립(freeze)
    const argv = this._buildArgvSync(
      interpreterKey,
      scriptAbs,
      args,
      pathGuard
    );

    // 3) execFileSync(shell:false) - Fortify가 보는 싱크
    return execFileSync(interpreter, argv, {
      cwd: opts.cwd ? path.resolve(opts.cwd) : process.cwd(),
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
      maxBuffer: opts.maxBuffer ?? 20 * 1024 * 1024,
    });
    // Fortify review points (요약):
    // - interpreter: absolute-path whitelist
    // - scriptAbs: realpath + allowed roots + isRegularFile
    // - tokens: allow-list/regex validated; no whitespace/meta chars
    // - ptah args: sanitized viz PathGuard (abs/rel)
    // - argv: locally rebuilt & frozen; shell=false (no shell injection vector)
  }

  /* ===========================
   * 인터프리터 + 스크립트 실행 (ASYNC)
   * =========================== */
  async runScript(interpreterKey, script, args, pathGuard, opts = {}) {
    const interpreter = this._resolveBinary(interpreterKey);

    // 스크립트 경로 정화(동기 로직 재사용)
    const scriptAbs = this._sanitizeScriptPathSync(script, pathGuard);

    // 옵션/경로 인자 정화(동기 로직 재사용)
    const argv = this._buildArgvSync(
      interpreterKey,
      scriptAbs,
      args,
      pathGuard
    );

    const timeout = opts.timeoutMs ?? 300_000;
    const maxBuffer = opts.maxBuffer ?? 20 * 1024 * 1024;
    const cwd = opts.cwd ? path.resolve(opts.cwd) : process.cwd();

    return execFileAsync(interpreter, argv, {
      cwd,
      timeout,
      maxBuffer,
      windowsHide: true,
      shell: false,
      env: opts.env ? { ...opts.env } : process.env,
    });
  }
}

module.exports = { CommandGuard };
