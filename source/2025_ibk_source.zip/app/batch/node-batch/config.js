const fs = require("fs");
const path = require("path");

function loadSecurityConfig(opts = {}) {
  const envRoots = process.env.ALLOWED_ROOTS || "";
  const allowedRoots = (opts.allowedRoots ?? envRoots)
    .toString()
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  let cmdWhitelist = {};
  const file = opts.cmdWhitelistFile || process.env.CMD_WHITELIST_FILE;
  if (file) {
    const p = path.resolve(file);
    const raw = fs.readFileSync(p, "utf8");
    cmdWhitelist = JSON.parse(raw);
  } else if (opts.cmdWhitelist) {
    cmdWhitelist = { ...opts.cmdWhitelist };
  }

  if (allowedRoots.length === 0) {
    throw new Error(
      "ALLOWED_ROOTS is required (comma separated absolute paths)"
    );
  }
  return { allowedRoots, cmdWhitelist };
}

module.exports = {
  db: {
    user: "qidp",
    host: "172.18.120.150",
    database: "qidp",
    password: "qidp1234!",
    port: 5432,
    max: "50",
    options: "-c search_path=qidp_er",
    ssl: {
      rejectUnauthorized: false,
    },
  },
  loadSecurityConfig,
};
