const { loadSecurityConfig } = require("./config");
const { PathGuard } = require("./pathGuard");
const { CommandGuard } = require("./cmdGuard");

function initGuard(opts = {}) {
  const pg = new PathGuard(["/data/asset/", "/log/uda/", "/app/"]);
  const cg = new CommandGuard({
    whitelistCmds: {
      python3: "/app/anaconda3/bin/python3",
      python: "/app/anaconda3/bin/python",
      node: "/usr/bin/node",
    },
    // 스크립트는 이 디렉터리 내부만 허용 (선택이지만 권장)
    allowedScriptRoots: ["/app"],
    optionPolices: {
      python3: {
        allowList: [],
        allowPatterns: [],
      },
      node: {
        allowList: [],
        allowPatterns: [],
      },
    },
  });

  return { pg, cg };
}

module.exports = { initGuard };
