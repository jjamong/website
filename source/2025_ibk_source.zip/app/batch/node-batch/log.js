const dbBatch = require("./sql/TB_UDA_UAI900M"); //배치로그

// log.js
const fs = require("fs");
const path = require("path");
const dayjs = require("dayjs");

function writeLog(message) {
  const now = dayjs();
  const date = now.format("YYYYMMDD");
  const time = now.format("HH:mm:ss");

  const logDir = path.join("/log/uda/asset", "logs");
  const logFile = path.join(logDir, `qidp-batch-log-${date}.log`);

  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }

  const logMessage = `[${date}][${time}] ${message}\n`;
  fs.appendFileSync(logFile, logMessage, "utf8");
  console.log(logMessage.trim());
}

async function summaryLog(
  totalCnt,
  successCnt,
  failCnt,
  assz_btch_acmp_id,
  clNm
) {
  writeLog(
    `(#)------------------ 단계 : ${clNm} : ${assz_btch_acmp_id} ------------------`
  );
  writeLog(`(#)- Total File Count : ${totalCnt}`);
  writeLog(`(#)- Success File Count : ${successCnt}`);
  writeLog(`(#)- Fail File Count : ${failCnt}`);

  let errStr = `단계:${clNm} Total : ${totalCnt} Success :${successCnt} Fail: ${failCnt}`;

  await dbBatch.updateBatchRst(assz_btch_acmp_id, null, errStr);
}

module.exports = {
  writeLog,
  summaryLog,
};
