const { Client } = require("pg");
const fs = require("fs");
const dayjs = require("dayjs");
const config = require("./config");

const client = new Client(config.db);

client.connect();

let META_INFOS = {};

function getMETA_INFOS(basDt) {
  return {
    RECEVEIVER_META: {
      filePath: `/data/bdpetl/recv/kms/wpt/${basDt}/meta/IKEP4_AC_RECEIVER_INFO.dat`,
      cols: {
        0: "WPT_ENFR_DCMN_ID|VARCHAR2",
        1: "WPT_RTPL_GRP_ID|VARCHAR2",
        2: "WPT_RTPL_GRP_NM|VARCHAR2",
        3: "WPT_RGSR_ID|VARCHAR2",
        4: "RGSN_TS|TIMESTAMP",
        5: "WPT_RTPL_GRP_DSNC_VL|VARCHAR2",
        6: "uda_sys_lsmd_id|VARCHAR2",
        7: "uda_sys_lsmd_ts|DATE",
      },
      tableName: "TB_UDA_UAI102M",
    },
    GROUP_META: {
      filePath: `/data/bdpetl/recv/kms/wpt/${basDt}/meta/IKEP4_EV_GROUP.dat`,
      cols: {
        0: "WPT_ATHR_GRP_ID|VARCHAR2",
        1: "WPT_ATHR_GRP_NM|VARCHAR2",
        2: "WPT_HGRN_ATHR_GRP_ID|VARCHAR2",
        3: "WPT_ATHR_GRP_TYPE_NM|VARCHAR2",
        4: "WPT_ATHR_GRP_ENSN_NM|VARCHAR2",
        5: "WPT_LRRN_ATHR_NBI|NUMBER",
        //6: "WPT_ORD_VL|VARCHAR2",
        6: "wpt_lnp_sqc_vl|VARCHAR2",
        //7: "WPT_ID|VARCHAR2",
        7: "wpt_rgsr_id|VARCHAR2",
        8: "WPT_RGSR_NM|VARCHAR2",
        9: "WPT_MDFR_ID|VARCHAR2",
        10: "WPT_MDFR_NM|VARCHAR2",
        11: "RGSN_TS|DATE",
        12: "MDFC_TS|DATE",
        13: "SCRE_OTPT_OPT_VL|NUMBER",
        14: "WPT_ALL_ATHR_GRP_PATH_VL|VARCHAR2",
        15: "OGZN_ATTCD|CHAR",
        16: "TEAM_KCD|CHAR",
        17: "BRCD|CHAR",
        18: "uda_sys_lsmd_id|VARCHAR2",
        19: "uda_sys_lsmd_ts|DATE",
      },
      tableName: "TB_UDA_UAI101M",
    },
  };
}

async function parseMeta(metaName, metaPath) {
  console.log(metaName, metaPath);
  let fsMeta = await fs.readFileSync(metaPath, "utf-8");
  // console.log(fsMeta);

  let metaRows = fsMeta.split("\n");
  for (let metaRow of metaRows) {
    let metaCols = metaRow.split("^|");
    metaCols.pop();

    // console.log(metaCols);
    if (metaCols.length < 2) continue;

    metaCols.push("test");
    metaCols.push(new Date().toISOString().split("T")[0]);

    metaCols = metaCols.map((d, i) => (d == "null" ? null : d));
    //console.log(metaCols);

    let tableName = META_INFOS[metaName].tableName;

    let insert_query = `insert into ${tableName}(${Object.values(
      META_INFOS[metaName].cols
    )
      .map((d, i) => d.split("|")[0])
      .join(", ")}) VALUES (${Object.keys(META_INFOS[metaName].cols)
      .map((d, i) => convertColumnType(i, metaName))
      .join(", ")})`;

    // console.log(insert_query);
    try {
      await client.query(insert_query, metaCols);
      // console.log(`${metaName} insert!!`);
    } catch (err) {
      // 중복 키인 경우는 무시
      console.log(`❌ ${metaCols[0]} => 작업 상태 초기화 실패: ${err.message}`);
      // process.exit(1);
    }
  }
}

async function upsertMeta(metaName, columns, rows) {
  const tableName = META_INFOS[metaName].tableName;
  const numCols = columns.length;
  const values = [];

  try {
    const tuples = rows
      .map((row, rowIdx) => {
        const offset = rowIdx * numCols;

        row.forEach((val) => values.push(val));

        const placeholders = row
          .map((_, colIdx) => convertColumnType(offset, colIdx, metaName))
          .join(", ");
        return `(${placeholders})`;
      })
      .join(",\n");

    //console.log(tuples);
    let mergeSql = `
      MERGE INTO ${tableName} AS t
      USING (
        VALUES
        ${tuples}
      ) AS s(${columns.join(", ")})
    `;
    if (tableName == "TB_UDA_UAI102M")
      mergeSql += `ON (t.${columns[0]} = s.${columns[0]} AND t.${columns[1]} = s.${columns[1]})`;
    else mergeSql += `ON (t.${columns[0]} = s.${columns[0]})`;
    mergeSql += `
      WHEN MATCHED THEN
        UPDATE SET
          ${columns
            .slice(1)
            .map((col) => `${col} = s.${col}`)
            .join(",\n      ")}
        WHEN NOT MATCHED THEN
          INSERT (${columns.join(", ")})
          VALUES (${columns.map((col) => `s.${col}`).join(", ")})
    `;
    //console.log(mergeSql);
    //console.log(tuples);
    //console.log(values.length);
    //console.log(values);
    await client.query(mergeSql, values);
  } catch (err) {
    console.log(`❌ ${tableName} => 작업 상태 초기화 실패: ${err.message}`);
    // console.log(err);
  }
}

function convertColumnType(offset, colIdx, metaName) {
  let str = `$${offset + colIdx + 1}`;
  let colType = META_INFOS[metaName].cols[colIdx].split("|")[1];
  let colName = META_INFOS[metaName].cols[colIdx].split("|")[0];

  if (colType) {
    if (colType == "TIMESTAMP")
      str = `TO_TIMESTAMP($${offset + colIdx + 1},'YYYYMMDDHH24MISS')`;
    if (colType == "DATE")
      str = `TO_DATE($${offset + colIdx + 1},'YYYY-MM-DD')`;
    if (colType == "NUMBER") str = `$${offset + colIdx + 1}::integer`;
  }

  // 20250618 BRCD lpad 처리
  if (colName === "BRCD") {
    str = `LPAD($${offset + colIdx + 1},4,'0')`;
  }

  return str;
}

(async () => {
  const basDt = process.argv[2];
  META_INFOS = getMETA_INFOS(basDt);
  //console.log(META_INFOS);
  for (let meta of Object.keys(META_INFOS)) {
    //await parseMeta(meta, META_INFOS[meta].filePath);
    let content;
    try {
      content = fs.readFileSync(META_INFOS[meta].filePath, "utf8");
    } catch (e) {
      continue;
    }
    const lines = content.split("\n").filter((line) => line.trim() !== "");
    console.log(lines.length);

    const rows = lines
      .map((line) => {
        let l = line.split("^|");
        l.pop();
        if (l.length > 2) {
          l.push("admin");
          l.push(dayjs(basDt).format("YYYY-MM-DD"));
          l = l.map((d, i) => (d == "null" ? "" : d));
        }
        return l;
      })
      .filter((line) => line.length > 2);

    const columns = Object.values(META_INFOS[meta].cols).map(
      (d, i) => d.split("|")[0]
    );
    //.join(", ");
    //console.log(columns);

    const maxRows = 1;
    for (let i = 0; i < rows.length; i++) {
      const chunk = rows.slice(i, i + maxRows);
      await upsertMeta(meta, columns, chunk);
      //console.log(        `${META_INFOS[meta].tableName} : ${i + 1} / ${rows.length} UPSERT 완료`      );
    }
  }
  client.end();
})();
