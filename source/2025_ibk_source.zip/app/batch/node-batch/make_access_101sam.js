const { Pool } = require("pg");
const config = require("./config.js");
const pool = new Pool(config.db);
const fs = require("fs");

//const basDt = process.argv[2];

const make_access_101sam = async (basDt) => {
  const client = await pool.connect();
  try {
    const res = await client.query(
      `
    select 
    coalesce(WPT_ATHR_GRP_ID::text, '') 
    || '^|' 
    || coalesce(WPT_ATHR_GRP_NM::text, '') 
    || '^|' 
    || coalesce(WPT_HGRN_ATHR_GRP_ID::text, '') 
    || '^|' 
    || coalesce(WPT_ATHR_GRP_TYPE_NM::text, '') 
    || '^|' 
    || coalesce(WPT_ATHR_GRP_ENSN_NM::text, '') 
    || '^|' 
    || coalesce(WPT_LRRN_ATHR_NBI::text, '') 
    || '^|' 
    || coalesce(WPT_LNP_SQC_VL::text, '') 
    || '^|' 
    || coalesce(WPT_RGSR_ID::text, '') 
    || '^|' 
    || coalesce(WPT_RGSR_NM::text, '') 
    || '^|' 
    || coalesce(WPT_MDFR_ID::text, '') 
    || '^|' 
    || coalesce(WPT_MDFR_NM::text, '') 
    || '^|' 
    || coalesce(RGSN_TS::text, '') 
    || '^|' 
    || coalesce(MDFC_TS::text, '') 
    || '^|' 
    || coalesce(SCRE_OTPT_OPT_VL::text, '') 
    || '^|' 
    || coalesce(WPT_ALL_ATHR_GRP_PATH_VL::text, '') 
    || '^|' 
    || coalesce(OGZN_ATTCD::text, '') 
    || '^|' 
    || coalesce(TEAM_KCD::text, '') 
    || '^|' 
    || coalesce(BRCD::text, '') 
    || '^|' 
    || coalesce(UDA_SYS_LSMD_ID::text, '') 
    || '^|' 
    || coalesce(UDA_SYS_LSMD_TS::text, '') as meta
    from TB_UDA_UAI101M
    `
    );
    let datas = res.rows;
    let metas = datas.map((d, i) => d.meta).join("\n");

    const dirPath = `/data/bdpetl/send/gai/gai/auth/${basDt}/`;
    const fileName = `tb_uda_uai101m_${basDt}.sam`;
    const fullPath = `${dirPath}${fileName}`;

    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
      console.log(`[폴더생성][${dirPath}]`);
    }

    fs.writeFileSync(fullPath, metas, "utf-8");
    console.log(`[권한SAM생성완료][101][${fullPath}][${res.rowCount}]`);
  } catch (e) {
    console.log(e);
  } finally {
    client.release();
    pool.end();
  }
};

//run();

module.exports = { make_access_101sam };
