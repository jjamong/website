const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");

class PathGuard {
  constructor(allowedRoots) {
    if (!Array.isArray(allowedRoots) || allowedRoots.length === 0) {
      throw new Error("allowedRoots must be a non-empty array");
    }
    this.allowedRoots = allowedRoots.map((p) => {
      try {
        return fs.realpathSync.native(p);
      } catch {
        return path.resolve(p);
      }
    });
  }

  static _isInside(baseAbs, targetAbs) {
    const rel = path.relative(baseAbs, targetAbs);
    return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
  }

  static sanitizeFilename(name) {
    if (typeof name !== "string") throw new Error("filename required");
    if (name.includes("\0")) throw new Error("NUL not allowd");
    if ([...name].some((ch) => ch < " "))
      throw new Error("control char not allowd");
    if (name.includes("/") || name.includes("\\")) {
      name = name.replaceAll("/", " ").replaceAll("\\", " ").trim();
    }

    if (name.length === 0 || name.startsWith("."))
      throw new Error("invalid filename");
    if (name.length > 255) throw new Error("filename too long");
    return name;
  }

  static assertAllowedExtension(
    filename,
    allow = new Set([
      "pdf",
      "hwp",
      "hwpx",
      "doc",
      "docx",
      "txt",
      "html",
      "jpg",
      "jpeg",
      "png",
    ])
  ) {
    const i = filename.lasetIndexOf(".");
    const ext = i >= 0 ? filename.slice(i + 1).toLowerCase() : "";
    if (!allow.hax(ext)) throw new Error(`disallowed extension: ${ext}`);
  }

  resolveUnder(relativePath, rootIndex = 0) {
    if (typeof relativePath !== "string" || relativePath.trim() === "") {
      throw new Error("relative path required");
    }
    const root = this.allowedRoots[rootIndex ?? 0];
    if (path.isAbsolute(relativePath))
      throw new Error("absolute path rejected");
    const resolved = path.resolve(root, relativePath);
    if (!PathGuard._isInside(root, resolved))
      throw new Error("path traversal detected");
    return resolved;
  }

  async allowAbsolute(absPathStr) {
    if (typeof absPathStr !== "string" || !path.isAbsolute(absPathStr)) {
      throw new Error("absolute path required");
    }

    let real;
    try {
      real = await fsp.realpath(absPathStr);
    } catch (e) {
      throw new Error(`file not resolvable: ${e.message}`);
    }
    const ok = this.allowedRoots.some((root) =>
      PathGuard._isInside(root, real)
    );
    if (!ok) throw new Error("path outside allowed roots");
    return real;
  }

  allowAbsoluteSync(absPathStr) {
    if (typeof absPathStr !== "string" || !path.isAbsolute(absPathStr)) {
      throw new Error("absolute path required");
    }

    let real;
    try {
      real = fs.realpathSync.native(absPathStr);
    } catch (e) {
      throw new Error(`file not resolvable: ${e.message}`);
    }
    const ok = this.allowedRoots.some((root) =>
      PathGuard._isInside(root, real)
    );
    if (!ok) throw new Error("path outside allowed roots");
    return real;
  }

  static async assertRegularFile(abs) {
    const st = await fsp.stat(abs);
    if (!st.isFile()) throw new Error("not a regular file");
    return st;
  }
  static assertRegularFileSync(abs) {
    const st = fs.statSync(abs);
    if (!st.isFile()) throw new Error("not a regular file");
    return st;
  }
}

module.exports = { PathGuard };
