import torch
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
print(torch.cuda.is_available())  # True여야 정상 사용 가능
print(torch.cuda.current_device())  # 0이 출력되면 0번 GPU
import re
import json
from jiwer import wer, cer
import difflib
from rouge_score import rouge_scorer, tokenizers
import math
TOKEN_RE = re.compile(r"[\uAC00-\uD7A3]+|[A-Za-z0-9]+|[^\s]")

class KoreanFriendlyTokenizer(tokenizers.Tokenizer):
    def tokenize(self, text):
        if not text:
            return []
        return TOKEN_RE.findall(text)


# rouge_scorer 객체 생성 (평가할 ROUGE 타입 지정)
# rouge_scorer_ = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=False)
rouge_scorer_ = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=False, tokenizer=KoreanFriendlyTokenizer())
rouge_scorer_1 = rouge_scorer.RougeScorer(['rouge1'], use_stemmer=False, tokenizer=KoreanFriendlyTokenizer())

from bert_score import BERTScorer
# from transformers import AutoTokenizer
# auto_tokenizer = AutoTokenizer.from_pretrained("bert_score_model/models--bert-base-multilingual-cased/snapshots/3f076fdb1ab68d5b2880cb87a0886f315b8146f8")

bert_model_path = "bert_score_model/models--bert-base-multilingual-cased/snapshots/3f076fdb1ab68d5b2880cb87a0886f315b8146f8"
bert_scorer = BERTScorer(
    model_type=bert_model_path,
    num_layers=12,
    # lang="ko",
    rescale_with_baseline=False,
    idf=False,
    # batch_size=4,
    # use_fast_tokenizer=True
)

# 로컬 모델
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
snt_tf_model = SentenceTransformer('embedding_model') 
# 훈련 데이터 세트 -> 행정 문서 대상, 뉴스 기사, 도서 자료, 숫자 연산, 금융 법률 문서

import os
import nltk
from nltk.tokenize import word_tokenize
from nltk.translate.meteor_score import meteor_score
nltk.data.path.append('nltk_data')

import math
from collections import Counter

##################################
# 전처리
##################################

def clean_text(raw_text):
    # 1. \\r\\n → \n 처리
    cleaned = raw_text.replace("\\n", "\n").replace("\\r", "\r").replace("\\r\\n", "\r\n")
    # 3. \' → ' 로 변경
    cleaned = cleaned.replace("\\'", "'").replace("'", "'")
    # # 4. \\ → \ 또는 제거 (원하는 처리 방식에 따라 조절 가능)
    # cleaned = cleaned.replace("\\\\", "\\")
    return cleaned

def preprocessing_test_text(txt):
    cleaned_text = clean_text(txt)
    if re.findall(r"\n\n\</page\>\n\n|<page\s+num='\d+'>\n\n|\n\n\</page\>",cleaned_text):
        cleaned_text = cleaned_text.replace('\n\n','\r\n').strip()
        cleaned_text = cleaned_text.replace("\r\r\n\n", "\r\n\r\n")
        
    lines = []
    for text_split in cleaned_text.split('\r\n'):
        n_split = [li for li in text_split.split('\n') if li.strip()]
        lines.extend(n_split)

    new_lines = list()
    for line in lines:
        page_start_pattern = re.compile(r"<page\s+num='(\d+)'>")
        num_pattern = re.compile(r'\d+')
        page_end_pattern = re.compile(r"\</page\>")   
        if page_end_pattern.match(line):
            pass
        elif page_start_pattern.match(line):
            pass
        else:
            new_lines.append(line)
    
    new_text = '\n'.join(new_lines).strip().replace(' \n ','\n')
    return new_text

# def clamp(text, max_len=256):
#     ids = auto_tokenizer(text, truncation=True, max_length=max_len)["input_ids"]
#     return auto_tokenizer.decode(ids, skip_special_tokens=True)

##################################
# 청크간 중복률
##################################

# char based
def find_max_char_overlab(a, b):
    # 앞, 뒤 텍스트의 최대 중복구간을 찾아 위치를 반환
    max_len = 0
    min_len = min(len(a), len(b))
    for i in range(1, min_len+1):
        # print('a :', repr(a[-i:]))
        # print('b :', repr(b[:i]))
        if a[-i:] == b[:i]:
            max_len = i
            # print('i :', i)
            # print('max_len :', max_len)
    return max_len

def merge_texts_by_char(a, b):
    overlap = find_max_char_overlab(a,b)
    print('char_overlap :', overlap)
    if overlap == 0:
        return a + b
    else:
        return a + b[overlap:]

# word based
def find_max_word_overlab(a_words, b_words):
    # 앞, 뒤 텍스트의 최대 중복구간을 찾아 위치를 반환
    max_len = 0
    min_len = min(len(a_words), len(b_words))
    for i in range(1, min_len+1):
        if a_words[-i:] == b_words[:i]:
            max_len = i
    return max_len

def merge_texts_by_word(a, b):
    a_words = a.split(' ')
    b_words = b.split(' ')
    overlap = find_max_word_overlab(a_words,b_words)
    print('word_overlap :', overlap)
    if overlap == 0:
        merged = a_words + b_words
    else:
        merged = a_words + b_words[overlap:]
    return ' '.join(merged)

def calculate_document_dup_rate(txt_list):
    dup_char_cnt = 0
    dup_word_cnt = 0 
    total_char_len = len(''.join(txt_list))
    total_word_len = len(''.join(txt_list).split(' '))
    dup_chunk_cnt = 0 
    for i in range(len(txt_list) - 1):
        cand_sentence =txt_list[i]
        ref_sentence = txt_list[i+1]
        cand_words = cand_sentence.split(' ')
        ref_words = ref_sentence.split(' ')

        dup_c_cnt = find_max_char_overlab(cand_sentence, ref_sentence)
        dup_w_cnt = find_max_word_overlab(cand_words, ref_words)
        dup_char_cnt += dup_c_cnt
        dup_word_cnt += dup_w_cnt

        if 0 < (dup_c_cnt + dup_w_cnt):
            dup_chunk_cnt += 1

    dup_char_rate = round((dup_char_cnt/total_char_len), 4)
    dup_word_rate = round((dup_word_cnt/total_word_len), 4)
    result = {'dup_char_rate': dup_char_rate, 'dup_word_rate':dup_word_rate, 'dup_chunk_rate':round((dup_chunk_cnt/len(txt_list)),4)}
    return result

##################################
# 정보 손실율
##################################

def calculate_rouge(ref_text, cand_text):
    # 점수 계산
    if len(ref_text) < 100000:
        scores = rouge_scorer_.score(ref_text, cand_text)
        result = {'rouge1': round(scores['rouge1'].fmeasure,4), 'rouge2': round(scores['rouge2'].fmeasure,4), 'rougeL':round(scores['rougeL'].fmeasure,4)}
    else:
        scores = rouge_scorer_1.score(ref_text, cand_text)
        result = {'rouge1': round(scores['rouge1'].fmeasure,4), 'rouge2': round(scores['rouge1'].fmeasure,4), 'rougeL':round(scores['rouge1'].fmeasure,4)}
    return result

def calculate_document_error_rate(ref_text, cand_text):
    w_er = wer(ref_text, cand_text)
    c_er = cer(ref_text, cand_text)
    char_filter_ref_text = re.sub(r'[^가-힣a-zA-Z0-9]', '', ref_text)
    char_filter_cand_text = re.sub(r'[^가-힣a-zA-Z0-9]', '', cand_text)
    f_c_er = cer(char_filter_ref_text, char_filter_cand_text)

    result = {'wer': round(w_er,4), 'cer':round(c_er,4), 'filter_cer':round(f_c_er,4)}
    return result

##################################
# 청크간 형태기반 유사율
##################################

def calculate_document_meteor(txt_list):
    meteor_score_list = list()
    for i in range(len(txt_list) - 1):
        cand_sentence =word_tokenize(txt_list[i])
        ref_sentence = word_tokenize(txt_list[i+1])
        
        score = meteor_score([cand_sentence], ref_sentence)
        meteor_score_list.append(score)
    #     print(f'{i+1}번 청크와 {i+2} 청크의 Meteo Score: {score:.4f}')

    # print(f"Inter-chunk Meteo Score 평균: {np.mean(meteor_score_list):.4f}")

    document_meteor_score = round(float(np.mean(meteor_score_list)),4)

    return document_meteor_score

def lcs_ratio_func(text1, text2):
    seq = difflib.SequenceMatcher(None, text1, text2)
    return seq.ratio()

def calculate_document_lcs_ratio(txt_list):
    lcs_ratio_list = list()
    for i in range(len(txt_list) - 1):
        cand_sentence =txt_list[i]
        ref_sentence = txt_list[i+1]
        lcs_ratio = lcs_ratio_func(cand_sentence, ref_sentence)
        lcs_ratio_list.append(lcs_ratio)

    document_lcs_ratio = round(float(np.mean(lcs_ratio_list)), 4)
    
    return document_lcs_ratio

######################################################
def whitespace_tokenize(text):
    return text.lower().split()

def compute_tf(tokens):
    tf = Counter(tokens)
    total = len(tokens)
    return {word: count/total for word, count in tf.items()}

def compute_idf(all_tokens_list):
    N = len(all_tokens_list)
    idf = {}
    all_words = set(word for tokens in all_tokens_list for word in tokens)
    for word in all_words:
        containing = sum(1 for tokens in all_tokens_list if word in tokens)
        idf[word] = math.log((N+1)/(containing +1)) + 1
    return idf

def compute_tfidf(tokens, idf):
    tf = compute_tf(tokens)
    return {word: tf.get(word, 0)*idf[word] for word in idf}

def cosine_sim(vec1, vec2):
    common_words = set(vec1.keys()) | set(vec2.keys())
    dot = sum(vec1.get(w,0) * vec2.get(w,0) for w in common_words)
    norm1 = math.sqrt(sum((vec1.get(w,0))**2 for w in common_words))
    norm2 = math.sqrt(sum((vec2.get(w,0))**2 for w in common_words))
    return dot / (norm1*norm2) if norm1 and norm2 else 0

def plagiarism_rate_cosine(text1, text2):
    tokens1 = whitespace_tokenize(text1)
    tokens2 = whitespace_tokenize(text2)
    idf = compute_idf([tokens1, tokens2])
    tfidf1 = compute_tfidf(tokens1, idf)
    tfidf2 = compute_tfidf(tokens2, idf)
    return cosine_sim(tfidf1, tfidf2)
    
def calculate_document_cos_sim_tfidf(txt_list):
    cos_sim_tfidf_list = list()
    for i in range(len(txt_list) - 1):
        cand_sentence =txt_list[i]
        ref_sentence = txt_list[i+1]
        cosine_sim = plagiarism_rate_cosine(cand_sentence, ref_sentence)
        cos_sim_tfidf_list.append(cosine_sim)

    document_cos_sim_tfidf = round(float(np.mean(cos_sim_tfidf_list)), 4)
    
    return document_cos_sim_tfidf

##################################
# 청크간 의미기반 유사율
##################################

def calculate_document_bert_f1(txt_list):
    agentic_f1 = []
    for i in range(len(txt_list) - 1):
        # cands_short = [clamp(t) for t in txt_list[i]]
        # refs_short = [clamp(t) for t in txt_list[i+1]]
        precision, recall, f1 = bert_scorer.score([txt_list[i]], [txt_list[i+1]])
        # precision, recall, f1 = bert_scorer.score(cands_short, refs_short)
        agentic_f1.append(float(f1[0]))
    #     print(f'{i+1}번 청크와 {i+2}번 청크의 f1 score: {f1}')
    # print(f"Inter-chunk Similarity 평균: {np.mean(agentic_f1):.4f}")
    document_f1 = round(float(np.mean(agentic_f1)), 4)
    
    return document_f1

def calculate_document_embedding_cos_sim(txt_list):
    agentic_chunks = []
    for i in range(len(txt_list)-1):
        first = txt_list[i]
        second = txt_list[i+1]
        # first = [clamp(t) for t in txt_list[i]]
        # second = [clamp(t) for t in txt_list[i+1]]
        chunks =[first, second]
        agentic_chunks.append(chunks)
        
    chunk_similarities = []
    chunks_sim = []
    for chunks in agentic_chunks:
        vecs = snt_tf_model.encode(chunks)
        sim = cosine_similarity([vecs[0]], [vecs[1]])[0][0]
        chunk_similarities.append(sim)
        chunks_sim.append(sim)
    
    # for i in range(len(chunks_sim)):
    #     print(f'{i+1}번 청크와 {i+2}번 청크의 f1 score: {chunks_sim[i]}')
        
    # print(f"Inter-chunk Similarity 평균: {np.mean(chunk_similarities):.4f}") # 968MiB
    document_cos_sim = round(float(np.mean(chunk_similarities)),4)
    
    return document_cos_sim

##################################
# json 형태의 결과 생성
##################################

def sanitize_json(value):
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    elif isinstance(value, dict):
        return {k: sanitize_json(v) for k,v in value.items()}
    elif isinstance(value, (list, tuple)):
        return [sanitize_json(v) for v in value]
    else:
        return value

def process_metric_list(raw_txt, model_result_list, metric_list):
    return_dict = dict()
    
    # 원본 텍스트
    input_raw_text = preprocessing_test_text(raw_txt.replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_').replace('\x00',''))
    
    # 모델 결과
    text_list = [dict_['origin_text'] for dict_ in model_result_list]
    join_test_text = ''.join(text_list)
    input_result_text = preprocessing_test_text(join_test_text)

    ## 청크간 중복률
    if 'metric1' in metric_list:
        metric1_result = calculate_document_dup_rate(text_list)
        return_dict['metric1'] = dict()
        return_dict['metric1']['dup_rate'] = metric1_result
        
    ## 정보 손실율
    if 'metric2' in metric_list:
        metric2_result1 = calculate_rouge(input_raw_text, input_result_text)
        metric2_result2 = calculate_document_error_rate(input_raw_text, input_result_text)
        return_dict['metric2'] = dict()
        return_dict['metric2']['rouge'] = metric2_result1
        return_dict['metric2']['error_rate'] = metric2_result2
        
    ## 청크간 형태기반 일치율
    if 'metric3' in metric_list:
        metric3_result1 = calculate_document_meteor(text_list)
        metric3_result2 = calculate_document_lcs_ratio(text_list)
        metric3_result3 = calculate_document_cos_sim_tfidf(text_list)
        return_dict['metric3'] = dict()
        if metric3_result1 in [None] or (isinstance(metric3_result1, float) and math.isnan(metric3_result1)):
            return_dict['metric3']['meteor'] = -1.0
        else:
            return_dict['metric3']['meteor'] = metric3_result1
        if metric3_result2 in [None] or (isinstance(metric3_result2, float) and math.isnan(metric3_result2)):
            return_dict['metric3']['lcs'] = -1.0
        else:
            return_dict['metric3']['lcs'] = metric3_result2
        if metric3_result3 in [None] or (isinstance(metric3_result3, float) and math.isnan(metric3_result3)):
            return_dict['metric3']['ti_cos_sim'] = -1.0
        else:
            return_dict['metric3']['ti_cos_sim'] = metric3_result3
        
    ## 청크간 의미기반 유사율
    if 'metric4' in metric_list:
        metric4_result1 = calculate_document_bert_f1(text_list)
        metric4_result2 = calculate_document_embedding_cos_sim(text_list)
        return_dict['metric4'] = dict()
        if metric4_result1 in [None] or (isinstance(metric4_result1, float) and math.isnan(metric4_result1)):
            return_dict['metric4']['bert'] = -1.0
        else:
            return_dict['metric4']['bert'] = metric4_result1
        if metric4_result2 in [None] or (isinstance(metric4_result1, float) and math.isnan(metric4_result1)):
            return_dict['metric4']['em_cos_sim'] = -1.0
        else:
            return_dict['metric4']['em_cos_sim'] = metric4_result2

    return return_dict




















    