from fastapi import FastAPI, UploadFile, File, Form, Depends, Request
from pydantic import BaseModel
from typing import Optional
import uvicorn
import os
import time
import pickle
import re
import math
from itertools import chain
import traceback
import configparser
import json
import asyncio
import gc
from utils.logger.python_logger import logger

from main_module_pv import process_metric_list, sanitize_json

app = FastAPI(docs_url = "/docs", redoc_url = "/redoc")

# processing_lock = asyncio.Lock()
# is_processing = False


@app.get("/cbc/health")
def get_health():

    return {"msg": "ok"}


@app.post("/cbc/pv")
async def performance_validation(request:Request):

    # global is_processing

    # if is_processing:
    #     # print(f"is_active : {is_processing}")

    #     return {"is_processing": is_processing}

    # async with processing_lock:
    #     is_processing = True    

    #     start_time = time.time()
        
    #     json_dict = await request.json()
    #     loop = asyncio.get_running_loop()
    #     return_result = await loop.run_in_executor(None, lambda: add_masking_info_to_json(json_dict))# add_masking_info_to_json(json_dict)

    #     elapsed_time = time.time() - start_time

    #     logger.info("Personal Info Masking Done")
    #     logger.info(f"elapsed_time : {elapsed_time}")
    #     logger.info(f"{'-' * 25} END {'-' * 25}")
    
    #     is_processing = False
    # is_processing = False
    start_time = time.time()
    json_dict = await request.json()
    raw_txt = json_dict['raw_txt']
    model_result_list = json_dict['model_result_list']
    filename = json_dict['filename']

    if 'request_metrics' in json_dict:
        metric_list = json_dict['request_metrics']
        if not metric_list:
            metric_list = ['metric1','metric2','metric3','metric4']
    else:
        metric_list = ['metric1','metric2','metric3','metric4'] # []

    logger.info(f"Filename : {filename}")
    logger.info(f"Request metrics : {metric_list}")
    return_result = process_metric_list(raw_txt, model_result_list, metric_list)
    return_result = sanitize_json(return_result)
    
    elapsed_time = time.time() - start_time

    logger.info("Performance Validation Done")
    logger.info(f"elapsed_time : {elapsed_time}")
    logger.info(f"{'-' * 25} END {'-' * 25}")
    
    return return_result
    
if __name__ == "__main__":
    uvicorn.run(app, host = "0.0.0.0", port = 10097, access_log = False, timeout_keep_alive = 120)


