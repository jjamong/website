#!/bin/bash
SERVICE="${1:-cbc}"
LOG_PAT='Error|Exception|Traceback|FATAL|CRITICAL|failed|Aborted|error|exception|traceback|fatal' # 찾을 패턴 # 'Error|Exception|Traceback|FATAL|CRITICAL|failed|Aborted|error|exception|traceback|fatal' # 'error|exception|traceback|fatal'
HEALTH_URL_0="${2:-http://127.0.0.1:10090/cbc/health}"
HEALTH_URL_1="${3:-http://127.0.0.1:10091/cbc/health}"
HEALTH_URL_2="${4:-http://127.0.0.1:10092/cbc/health}"
HEALTH_URL_3="${5:-http://127.0.0.1:10093/cbc/health}"
HEALTH_URL_4="${6:-http://127.0.0.1:10097/cbc/health}"

APP_LOG_PATH="${7:-/log/uda/engine}"

CURRENT_CONDA_ENV_1="${8:-cbc_new}" #cbc_new, JS_ENV 
CURRENT_CONDA_ENV_2="${9:-JS_ENV}" #cbc_new, JS_ENV 

LAST_CHECK_DATE="2025-09-18"

echo "==================== Service : ${SERVICE}_inference ===================="

if command -v nvidia-smi >/dev/null 2>&1; then
  echo "== NVIDIA =="
  nvidia-smi 
else
  echo "nvidia-smi not found (CPU-onlymachine or driver missing)"
fi

# conda 기반 가상환경
echo ""
echo "== CONDA ENV =="
conda env list

# Conda 및 Python 정보
echo ""
echo "== Python / Packages in ${CURRENT_CONDA_ENV_1} =="
conda run -n "${CURRENT_CONDA_ENV_1}" python -V 2>/dev/null || python -V
conda run -n "${CURRENT_CONDA_ENV_1}" which uvicorn 2>/dev/null || true

# Conda 및 Python 정보
echo ""
echo "== ML frameworks in ${CURRENT_CONDA_ENV_1} =="
if [[ "$CURRENT_CONDA_ENV_1" = "cbc_new" ]]; then
  conda run -n "$CURRENT_CONDA_ENV_1" --no-capture-output python -c "import tensorflow as tf,sys;print('\n');print('## tensorflow_version :',tf.__version__)" 2>&1 | head || true
elif [[ "$CURRENT_CONDA_ENV_1" = "JS_ENV" ]]; then
  conda run -n "$CURRENT_CONDA_ENV_1" --no-capture-output python -c "import torch,sys;print('\n');print('## torch_version :',torch.__version__)" 2>&1 | head || true
else
  echo "other"
fi

# Conda 및 Python 정보
echo ""
echo "== Python / Packages in ${CURRENT_CONDA_ENV_2} =="
conda run -n "${CURRENT_CONDA_ENV_2}" python -V 2>/dev/null || python -V
conda run -n "${CURRENT_CONDA_ENV_2}" which uvicorn 2>/dev/null || true

# Conda 및 Python 정보
echo ""
echo "== ML frameworks in ${CURRENT_CONDA_ENV_2} =="
if [[ "$CURRENT_CONDA_ENV_2" = "cbc_new" ]]; then
  conda run -n "$CURRENT_CONDA_ENV_2" --no-capture-output python -c "import tensorflow as tf,sys;print('\n');print('## tensorflow_version :',tf.__version__)" 2>&1 | head || true
elif [[ "$CURRENT_CONDA_ENV_2" = "JS_ENV" ]]; then
  conda run -n "$CURRENT_CONDA_ENV_2" --no-capture-output python -c "import torch,sys;print('\n');print('## torch_version :',torch.__version__)" 2>&1 | head || true
else
  echo "other"
fi


# 프로세스 상태(uvicorn/gunicorn/python 또는 서비스명)
echo ""
echo "== Process =="
ps -eo pid,ppid,rss,%cpu,%mem,cmd --sort=-%cpu \
  | grep -Ei '[p]ython|unicorn|gunicorn' \
  | head

# 포트/리슨
echo ""
echo "== Port/Listen =="
ss -lpnt | awk 'NR== 1 || /LISTEN/ {print}' | grep -Ei '(^State|python)' | head -n 30

# health endpoint
echo ""
echo "== Health =="
echo "# ${HEALTH_URL_0}"
curl -s -o /dev/null -2 "code=%{http_code} time=%{time_total}s\n" "$HEALTH_URL_0" || echo "curl_fail"
echo ""
echo "# ${HEALTH_URL_1}"
curl -s -o /dev/null -2 "code=%{http_code} time=%{time_total}s\n" "$HEALTH_URL_1" || echo "curl_fail"
echo ""
echo "# ${HEALTH_URL_2}"
curl -s -o /dev/null -2 "code=%{http_code} time=%{time_total}s\n" "$HEALTH_URL_2" || echo "curl_fail"
echo ""
echo "# ${HEALTH_URL_3}"
curl -s -o /dev/null -2 "code=%{http_code} time=%{time_total}s\n" "$HEALTH_URL_3" || echo "curl_fail"
echo ""
echo "# ${HEALTH_URL_4}"
curl -s -o /dev/null -2 "code=%{http_code} time=%{time_total}s\n" "$HEALTH_URL_4" || echo "curl_fail"


# 리소스
echo " "
echo " "
echo "== Resources =="
echo "# uptime"; uptime
echo "# mem"; free -h
echo "# disk"; df -h | sed -n '1,12p'


#로그
echo " "
echo "== Search for error events in logs =="
echo "# APP_LOG_PATH : ${APP_LOG_PATH} "
echo " "
find "$APP_LOG_PATH" -type f -name "*.log" -newermt "$LAST_CHECK_DATE" \
  -exec grep -EiHn --color=never  "$LOG_PAT" {} + \
  | grep -Eiv 'already been registered|tensorflow/core/platform/cpu_feature_guard.cc|tensorflow/core/util/port.cc|rebuild TensorFlow with the appropriate compiler flags|error_rate' \
  # | awk -F: '{print $1}' | sort -u
