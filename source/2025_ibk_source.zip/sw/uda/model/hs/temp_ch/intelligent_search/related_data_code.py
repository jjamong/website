import os
from functools import reduce
from glob import glob
import configparser
import re
import json
import math
import time
from call_api import *


def make_path(path):

    replaces = ('\\', '/'), ('', '')
    
    return reduce(lambda p, rpls: p.replace(*rpls), replaces, path)

def find_files(directory, pattern = '**/*.pdf'):
    
    files = sorted(glob(os.path.join(directory, pattern), recursive = True))
    
    return [make_path(file) for file in files]
    
def chunk_filtering(text, filter=['char_cnt', 'token_cnt', 'avg_token_len']):
    if 'char_cnt' in filter:
        char_cnt = len(re.findall(r'[a-zA-Z가-힣\d]',text))
        if char_cnt < 5:
            return False
            
    if 'token_cnt' in filter:
        token_cnt = len(text.strip().split())
        if token_cnt < 2:
            return False

    if 'avg_token_len' in filter:
        tokens = text.strip().split()
        avg_token_len = math.fsum([len(t) for t in tokens if len(t) is not None and not(isinstance(len(t), float) and math.isnan(len(t)))])/max(1e-8,len(tokens))
        if avg_token_len <= 1:
            return False
            
    return True

def preprocessing_json_data(sys_code, code, files):
    print(f"Preprocessing task started. [ sys_code : '{sys_code}' , code : '{code}' ]")
    preprocess_data = list()
    excluded_cnt = 0
    for json_file in files:
        doc_uid = '.'.join(json_file.split('/')[-1].split('.')[:-1]) # json_file.split('/')[-1].split('.')[0]
        try:
            req_name_dict = {'docUid':doc_uid}
            # response_dict = get_origin_doc_name(req_name_dict)
            doc_name = response_dict['docName']
            print("## doc_name get succeeded")
        except:
            doc_name = ''
            # print(f"## doc_name get failed [ doc_uid = {doc_uid} ]") # 테스트를 위해 print 주석 처리 추후 로깅을 위해 주석 제거
            
        with open(json_file, 'r', encoding='utf-8') as rjf:
            json_dict = json.load(rjf)

        if 'data' in json_dict:
            for dict_ in json_dict['data']:
                if 'chunk' in dict_ and 'page' in dict_ and 'chunk_seq' in dict_:
                    chunk = dict_['chunk']
                    filtering_result = chunk_filtering(chunk)
                    if filtering_result:
                        insert_row = {
                            'sys_code': sys_code,
                            'code': code,
                            'doc_uid': doc_uid,
                            'doc_name': doc_name,
                            'chunk_seq': dict_['chunk_seq'],
                            'page': dict_['page'],
                            'text': dict_['chunk']
                        }
                        preprocess_data.append(insert_row)
                    else:
                        # print(f"## doc_uid = {doc_uid} , chunk_seq = {dict_['chunk_seq']} was excluded because it met the filtering conditions.") # 테스트를 위해 print 주석 처리 추후 로깅을 위해 주석 제거
                        excluded_cnt += 1
                        # if sys_code == 'iemiea':
                        #     print(doc_uid)
                        #     print('#'*50)
                        #     print(chunk)
                        #     print('#'*50)
    print('\n')
    print(f"# After preprocessing, a total of {len(preprocess_data)} items were generated and {excluded_cnt} itmes were excluded  [ sys_code = '{sys_code}' , code = '{code}' ].")
    return preprocess_data


def embed_and_store_data(base_home_path, input_date_str):
    input_date_path = '/'.join([base_home_path, input_date_str])
    for sys_code in os.listdir(input_date_path):
        
        sys_path = '/'.join([input_date_path, sys_code])
        dirs = [os.path.join(sys_path, d) for d in os.listdir(sys_path) if os.path.isdir(os.path.join(sys_path, d)) and d not in ['.ipynb_checkpoints']]
        
        if not dirs:
            code = ''
            start_time = time.time()
            
            files = find_files(sys_path, '**/*.json')
            doc_key = sys_code
            
            preprocess_data = preprocessing_json_data(sys_code, code, files)
            
            # embedding 작업 시작
            ##################################

            ##################################
            elapsed_time = time.time() - start_time

            print(f"elapsed_time : {elapsed_time}")
            print(f"{'-' * 25} END {'-' * 25}", "\n")
        else:
            for code in os.listdir(sys_path):
                code_path = '/'.join([sys_path, code])
                start_time = time.time()
                
                files = find_files(code_path, '**/*.json')
                doc_key = '_'.join([sys_code, code])
                
                preprocess_data = preprocessing_json_data(sys_code, code, files)
                
                # embedding 작업 시작
                ##################################

                ##################################
                elapsed_time = time.time() - start_time

                print(f"elapsed_time : {elapsed_time}")
                print(f"{'-' * 25} END {'-' * 25}", "\n")

if __name__ == "__main__":
    
    base_home_path = "/data/train_data/embeddings_json"
    
    input_date_str = "20251001"

    embed_and_store_data(base_home_path, input_date_str)
