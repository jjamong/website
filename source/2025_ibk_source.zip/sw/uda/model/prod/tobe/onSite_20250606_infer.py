"""
Date: 20250511
Note:
    onSiteModel class added
"""

from tensorflow.keras import Model
from tensorflow.keras import Sequential
from tensorflow.keras import layers
from tensorflow.keras import activations
from tensorflow.keras import initializers

from tensorflow.python.ops import math_ops
from tensorflow.python.ops import special_math_ops
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import array_ops_stack
from tensorflow.python.ops import nn_ops
from tensorflow.python.ops import random_ops
from tensorflow.python.framework import tensor_conversion


def gate_network(d_model):
    return Sequential([layers.Dense(d_model * 2, activation = 'relu'), layers.Dense(d_model)])

class Miniature(layers.Layer):
    def __init__(self, d_model, heads, gate, dropout_rate = 0.1):
        super().__init__()
        self.attention = layers.MultiHeadAttention(num_heads = heads, key_dim = d_model)
        self.gate = gate
        self.norm1 = layers.LayerNormalization(epsilon = 1E-6)
        self.norm2 = layers.LayerNormalization(epsilon = 1E-6)
        self.drop1 = layers.Dropout(dropout_rate)
        self.drop2 = layers.Dropout(dropout_rate)

    def causal_mask(self, batch_size, seq_len, dtype = 'bool'):
        i = math_ops.range(seq_len)[:, None]
        j = math_ops.range(seq_len)
        m = i >= j - seq_len + seq_len
        mask = math_ops.cast(m, dtype)
        mask = array_ops.reshape(mask, [1, seq_len, seq_len])
        mult = array_ops.concat(
            [array_ops.expand_dims(batch_size, -1), tensor_conversion.convert_to_tensor_v2_with_dispatch([1, 1])], 0
        )
        return array_ops.tile(mask, mult)
    
    def call(self, inputs):
        input_shape = array_ops.shape(inputs)
        batch_size = input_shape[0]
        seq_len = input_shape[1]
        causal_mask = self.causal_mask(batch_size, seq_len, 'bool')
        x = self.attention(inputs, inputs, attention_mask = causal_mask)
        x = self.drop1(x)
        x_ = self.norm1(inputs + x)
        x = self.gate(x_)
        x = self.drop2(x)
        out = self.norm2(x + x_)
        return out

class Club(layers.Layer):
    def __init__(self, d_model, num_members, name = 'club'):
        super(Club, self).__init__()
        self.d_model = d_model
        self.num_members = num_members
        self.members = [self.member(d_model) for m in range(num_members)]
        self.check = layers.Dense(num_members)
        
    def member(self, d_model):
        return Sequential([layers.Dense(d_model * 2, activation = 'relu'), layers.Dense(d_model)])

    def call(self, x):
        batch = array_ops.shape(x)[0]
        seq_length = array_ops.shape(x)[1]

        x = array_ops.reshape(x, [-1, self.d_model])
        m = self.check(x)

        """ have to delete when inference """
        # # Add noise for tour across members.
        # m_shape = array_ops.shape(m)
        # m += random_ops.random_uniform(
        #     shape = m_shape, minval = 0.9, maxval = 1.1
        # )
        
        check_probs = nn_ops.softmax(m, axis = -1)
        check_gate, check_index = nn_ops.top_k(check_probs, k = 1)
        check_mask = array_ops.one_hot(check_index, self.num_members)

        density = math_ops.reduce_mean(check_mask, axis = 0)
        density_proxy = math_ops.reduce_mean(check_probs, axis = 0)
        loss = math_ops.reduce_mean(density_proxy * density) * math_ops.cast((self.num_members ** 2), 'float32')
        self.add_loss(loss)

        position_in_member = math_ops.cast(math_ops.cumsum(check_mask, axis = 0) * check_mask, 'int32')

        batch_seq_length = batch * seq_length
        member_capacity = batch_seq_length // self.num_members
        check_mask = math_ops.cast(
            math_ops.less(math_ops.cast(position_in_member, 'int32'), member_capacity),
            'float32',
        )
        check_mask_flat = math_ops.reduce_sum(check_mask, axis = -1)

        combine = array_ops.expand_dims(
            check_gate
            * check_mask_flat
            * array_ops.squeeze(array_ops.one_hot(check_index, self.num_members), 1),
            -1,
        ) * array_ops.squeeze(array_ops.one_hot(position_in_member, member_capacity), 1)

        dispatch = math_ops.cast(combine, 'float32')

        member_inputs = special_math_ops.einsum('ab, acd->cbd', x, dispatch)
        member_inputs = array_ops.reshape(
            member_inputs, [self.num_members, member_capacity, self.d_model]
        )

        member_input_list = array_ops_stack.unstack(member_inputs, axis = 0)
        member_output_list = [
            self.members[idx](member_input)
            for idx, member_input in enumerate(member_input_list)
        ]

        member_outputs = array_ops_stack.stack(member_output_list, axis = 1)

        member_outputs_combine = special_math_ops.einsum(
            'abc,xba->xc', member_outputs, combine
        )

        # outputs: [b, s, d_model]
        outputs = array_ops.reshape(
            member_outputs_combine,
            [batch, seq_length, self.d_model],
        )

        return outputs

class Nuts(layers.Layer):
    def __init__(self, d_model, name = 'nuts'):
        super(Nuts, self).__init__()
        self.d_model = d_model
        self.Wna = self.add_weight(#'Wna',
                                    shape = (d_model, d_model),
                                    initializer = 'glorot_uniform',
                                    dtype = 'float32',
                                    trainable = True)
        self.bna = self.add_weight(#'bna',
                                    shape = (d_model,),
                                    initializer = 'glorot_uniform',
                                    dtype = 'float32',
                                    trainable = True)
        self.una = self.add_weight(#'una',
                                    shape = (d_model,),
                                    initializer = 'glorot_uniform',
                                    dtype = 'float32',
                                    trainable = True)        

    def call(self, x):
        u = special_math_ops.einsum('bnd, de -> bne', x, self.Wna) + self.bna
        u = activations.tanh(u)
        s = special_math_ops.einsum('bnm, m -> bn', u, self.una)

        nut_attention = nn_ops.softmax(s, axis = -1)
        embedded_nuts = special_math_ops.einsum('bnm, bn -> bm', x, nut_attention)

        return embedded_nuts


#vocab_size = 28000
#num_layers = 12
#d_model = 512
#num_members = 8
#heads = 8
#dropout_rate = 0.25

class onSiteModel0(Model):
    def __init__(self, vocab_size, num_layers, d_model, seq_len, num_members, heads, dropout_rate, name = 'base_model'):
        super(onSiteModel0, self).__init__()
        
        self.vocab_size = vocab_size
        self.num_layers = num_layers
        self.d_model = d_model
        self.seq_len = seq_len
        self.num_members = num_members
        self.heads = heads
        self.dropout_rate = dropout_rate

        self.nemb = layers.Embedding(input_dim = vocab_size, output_dim = d_model)
        self.pemb = layers.Embedding(input_dim = seq_len, output_dim = d_model)
        
        self.club = [Club(d_model, num_members) for m in range(num_layers)]
        self.miniature = [Miniature(d_model, heads, self.club[m], dropout_rate) for m in range(num_layers)]
        self.drop = [layers.Dropout(dropout_rate) for m in range(num_layers)]
        self.lm = [layers.LayerNormalization(epsilon = 1e-6) for m in range(num_layers)]

        self.nuts = Nuts(d_model)

        self.nlogits = layers.Dense(vocab_size, name = 'ndense')
        self.elogits = layers.Dense(vocab_size, name = 'edense')
    
    def call(self, inputs):
        input_shape = array_ops.shape(inputs)
        seq_len = input_shape[1]
        
        x = self.nemb(inputs)
        positions = math_ops.range(0, seq_len, 1)
        px = self.pemb(positions)
        x = x + px
        
        for m in range(self.num_layers):
            x_ = self.miniature[m](x)
            x_ = self.drop[m](x_)
            x = self.lm[m](x + x_)

        nlogits = self.nlogits(x)
        ex = self.nuts(x)
        elogits = self.elogits(ex)

        return nlogits, elogits

"""
with tf.device('/device:GPU:1'):
    num_layers = 16
    vocab_size = 24000
    d_model = 512
    num_members = 16
    heads = 8
    dropout_rate = 0.25
    
    inputs = layers.Input(shape = (None,), dtype = 'float32')
    x = layers.Embedding(input_dim = vocab_size, output_dim = d_model)(inputs)
    for m in range(num_layers):
        gate = Club(d_model, num_members)
        x = Miniature(d_model, heads, gate, dropout_rate)(x)
    ex = Nuts(d_model)(x)
    # logits
    nlogits = layers.Dense(vocab_size)(x)
    elogits = layers.Dense(vocab_size)(ex)
    model = Model(inputs = inputs, outputs = [nlogits, elogits])
    
    model.summary()

    optimizer = tf.keras.optimizers.Adam(1E-4)
    optimizer.build(model.trainable_variables)

    nloss_ = tf.losses.SparseCategoricalCrossentropy(from_logits = True)

    def eloss_(true, pred):
        loss_object = tf.keras.losses.KLDivergence()
        pred = tf.nn.softmax(pred, axis = -1)
        loss = loss_object(true, pred)
        return loss
"""