import math
import configparser
import gc

config = configparser.ConfigParser()
config.read("model_config.ini")
infer_config = config["INFER"]

import tensorflow as tf

import common_infer as c
from utils.chunking.overapping_func import *
from utils.logger.python_logger import logger
from utils.masking.personal_masking import *

n_pages_split = infer_config.getint("n_pages_split")
def make_chunk_page(model, ml, contents, split_len = 95, num_trail_nut = 0):

    total_txt = contents
    
    page_txt = []
    for page in total_txt.split("\n\n</page>\n\n"):
    # for page in total_txt.split("\n</page>"):
    # for page in total_txt.split("</page>"):    
        if page.strip():
            page_txt.append(re.sub("<page num='[0-9]+'>\n\n", "", page))
            # page_txt.append(re.sub("<page num='[0-9]+'>\n", "", page))    

    n_pages = len(page_txt)
    steps = math.ceil(n_pages / 10)
    TEST_BATCH_SIZE = 1
    nuts_total, splitted_data_total, chunked_total, sentence_distns_total = [], [], [], []
    for i in range(steps):
        nuts = c.get_document_nuts_page(page_txt[i * 10:(i+1) * 10]) # .pdf, .hwp
        # nuts, txt, n_pages = get_txt_document_nuts(path) # .txt
        # print("#" * 50)
        logger.info("#" * 50)
        nuts = c.nutcracker(nuts)
            
        sentences = c.get_splits(nuts, split_len, num_trail_nut)
        # print(f"n_splits : {len(sentences)}")
        logger.info(f"n_splits : {len(sentences)}")
        dataset = tf.ragged.constant(sentences)
        test_dataset = (tf.data.Dataset.from_tensor_slices(dataset))
        test_dataset = (test_dataset.map(ml.get_test_example)
                            .padded_batch(TEST_BATCH_SIZE, padded_shapes = ((None,), (None,)), drop_remainder = False)
                        )
        
        splitted_data = []
        for nuts_ in sentences:
            # print(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            splitted_data.append(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            
        sentence_distns = c.get_sentence_distns(model, test_dataset)
        # sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns]).tolist()
        
        chunked = []
        for idx in range(len(sentences)):
            order = c.one_step_chunking(sentence_distns, idx, verbose = True)
            chunked.append(order.tolist())

        nuts_total.extend(nuts)
        splitted_data_total.extend(splitted_data)
        chunked_total.append(chunked)
        sentence_distns_total.extend(sentence_distns)

    return nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total

def make_chunk(model, ml, contents, split_len = 95, num_trail_nut = 0):

    # print(f"Info : chunk using model {ml.model_name}")
    logger.info(f"chunk using model {ml.model_name}")
    
    TEST_BATCH_SIZE = 1
    nuts, txt, n_pages = c.get_document_nuts(contents) # .pdf, .hwp
    # print(n_pages)
    logger.info(f"n_pages : {n_pages}")
    # nuts, txt, n_pages = get_txt_document_nuts(path) # .txt
    check_contents_dict = make_page_text_dict(txt)
    if not check_contents_dict:
        # qt_chunk_dict = {'data': []}
        # for i in range(1,n_pages+1):
        #     qt_chunk_dict['data'].append({'page': i, 'chunk_seq': i, 'chunk': ''})
        # qt_chunk_dict = {'data': [{'page': 1, 'chunk_seq': 1, 'chunk': ''}]}
        # filename = os.path.splitext(path.split("/")[-1])[0]
        qt_chunk_dict = {}
        
        return qt_chunk_dict, [], n_pages

    if n_pages < n_pages_split:
        
        # print("#" * 50)
        logger.info("#" * 50)
        nuts = c.nutcracker(nuts)
            
        sentences = c.get_splits(nuts, split_len, num_trail_nut)
        dataset = tf.ragged.constant(sentences)
        test_dataset = (tf.data.Dataset.from_tensor_slices(dataset))
        test_dataset = (test_dataset.map(ml.get_test_example)
                            .padded_batch(TEST_BATCH_SIZE, padded_shapes = ((None,), (None,)), drop_remainder = False)
                        )
    
        splitted_data = []
        for nuts_ in sentences:
            # print(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            splitted_data.append(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
    
        # print(f"Info : The number of splits -> {len(splitted_data)}")
        logger.info(f"The number of splits -> {len(splitted_data)}")
        
        sentence_distns = c.get_sentence_distns(model, test_dataset)
        # sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns])
        sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns]).tolist()
        
        chunked = []
        for idx in range(len(sentences)):
            order = c.one_step_chunking(sentence_distns, idx, verbose = True)
            chunked.append(order.tolist())
    
        # print("111111111", splitted_data)
        qt_chunk_dict = qt_chunking_output(splitted_data, chunked, txt, len(nuts), sentence_distns_)
        # qt_chunk_dict = qt_chunking_output___(splitted_data, chunked, txt)
        if "ieb" in ml.model_name:
            qt_chunk_dict['maxPage'] = n_pages

        #########################
        # del nuts
        # del txt
        # del sentence_distns
        # del sentence_distns_
        # del order
        # del chunked
        # gc.collect()
        #########################
            
        return qt_chunk_dict, chunked, n_pages

    else:
        nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total = make_chunk_page(model, ml, contents)
        
        # sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns_total])
        sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns_total]).tolist()
        chunked_cc = c.prcess_and_concatenate(chunked_total)
        # logger.info(f"sssssssss : {splitted_data_total}")
        # logger.info(f"ccccccccc : {chunked_cc}")
        
        qt_chunk_dict = qt_chunking_output(splitted_data_total, chunked_cc, total_txt, len(nuts_total), sentence_distns_)
        if "ieb" in ml.model_name:
            qt_chunk_dict['maxPage'] = n_pages        

        #########################
        # del nuts_total
        # del total_txt
        # del sentence_distns_total
        # del sentence_distns_
        # del chunked_cc
        # gc.collect()
        #########################
        
        return qt_chunk_dict, chunked_cc, n_pages

def make_chunk_page_ci(models, mls, contents, split_len = 95, num_trail_nut = 0):

    total_txt = contents
    
    page_txt = []
    for page in total_txt.split("\n\n</page>\n\n"):
    # for page in total_txt.split("\n</page>"):
    # for page in total_txt.split("</page>"):    
        if page.strip():
            page_txt.append(re.sub("<page num='[0-9]+'>\n\n", "", page))
            # page_txt.append(re.sub("<page num='[0-9]+'>\n", "", page))    

    n_pages = len(page_txt)
    steps = math.ceil(n_pages / 10)
    TEST_BATCH_SIZE = 1
    nuts_total, splitted_data_total, chunked_total, sentence_distns_total = [], [], [], []
    for i in range(steps):
        sd_collections, sentence_distns_ci = [], []

        nuts = c.get_document_nuts_page(page_txt[i * 10:(i+1) * 10]) # .pdf, .hwp
        # nuts, txt, n_pages = get_txt_document_nuts(path) # .txt
        # print("#" * 50)
        logger.info("#" * 50)
        nuts = c.nutcracker(nuts)
            
        sentences = c.get_splits(nuts, split_len, num_trail_nut)
        # print(f"n_splits : {len(sentences)}")
        logger.info(f"n_splits : {len(sentences)}")

        splitted_data = []
        for nuts_ in sentences:
            # print(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            splitted_data.append(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            
        for model, ml in zip(models, mls):
            dataset = tf.ragged.constant(sentences)
            test_dataset = (tf.data.Dataset.from_tensor_slices(dataset))
            test_dataset = (test_dataset.map(ml.get_test_example)
                                .padded_batch(TEST_BATCH_SIZE, padded_shapes = ((None,), (None,)), drop_remainder = False)
                            )
            
            sentence_distns = c.get_sentence_distns(model, test_dataset)
            # sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns])

            sd_collections.append(sentence_distns)
        
        for sd1, sd2, sd3 in zip(sd_collections[0], sd_collections[1], sd_collections[2]):
            # print(sd1.shape, sd2.shape, sd3.shape)
            sd = tf.concat([sd2, sd3, sd1], -1) # 1 : 2025, 2 : 2024, 3 : 2025+2024
            # sd = tf.concat([sd3, sd2, sd1], -1) # 1 : 2025, 2 : 2024, 3 : 2025+2024
            sd = sd / tf.reduce_sum(sd, -1)
            # print(sd.shape)
            sentence_distns_ci.append(sd)
            
        chunked = []
        for idx in range(len(sentences)):
            order = c.one_step_chunking(sentence_distns_ci, idx, verbose = True)
            chunked.append(order.tolist())

        nuts_total.extend(nuts)
        splitted_data_total.extend(splitted_data)
        chunked_total.append(chunked)
        sentence_distns_total.extend(sentence_distns_ci)

    return nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total

def make_chunk_ci(models, mls, contents, split_len = 95, num_trail_nut = 0):

    for ml in mls:
        # print(f"Info : chunk using model {ml.model_name}")
        logger.info(f"Info : chunk using model {ml.model_name}")
    
    TEST_BATCH_SIZE = 1
    nuts, txt, n_pages = c.get_document_nuts(contents) # .pdf, .hwp
    # print(f"Info : n_pages -> {n_pages}")
    logger.info(f"n_pages -> {n_pages}")
    # nuts, txt, n_pages = get_txt_document_nuts(path) # .txt
    check_contents_dict = make_page_text_dict(txt)
    if not check_contents_dict:
        # qt_chunk_dict = {'data': []}
        # for i in range(1,n_pages+1):
        #     qt_chunk_dict['data'].append({'page': i, 'chunk_seq': i, 'chunk': ''})
        # qt_chunk_dict = {'data': [{'page': 1, 'chunk_seq': 1, 'chunk': ''}]}
        # filename = os.path.splitext(path.split("/")[-1])[0]
        qt_chunk_dict = {}
        
        return qt_chunk_dict, [], n_pages

    if n_pages < n_pages_split:

        sd_collections, sentence_distns_ci = [], []
        
        # print("#" * 50)
        logger.info("#" * 50)
        nuts = c.nutcracker(nuts)

        sentences = c.get_splits(nuts, split_len, num_trail_nut)

        splitted_data = []
        for nuts_ in sentences:
            # print(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
            splitted_data.append(''.join(nuts_).replace(chr(18), ' ').replace('_', '').replace(chr(20), '\r').replace(chr(25), '\n'))
    
        # print(f"Info : The number of splits -> {len(splitted_data)}")
        logger.info(f"The number of splits -> {len(splitted_data)}")
        # for collective intelligence
        ####################################################
        for model, ml in zip(models, mls):
            dataset = tf.ragged.constant(sentences)
            test_dataset = (tf.data.Dataset.from_tensor_slices(dataset))
            test_dataset = (test_dataset.map(ml.get_test_example)
                                .padded_batch(TEST_BATCH_SIZE, padded_shapes = ((None,), (None,)), drop_remainder = False)
                            )
            sentence_distns = c.get_sentence_distns(model, test_dataset)
            # sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns])

            sd_collections.append(sentence_distns)
            
        for sd1, sd2, sd3 in zip(sd_collections[0], sd_collections[1], sd_collections[2]):
            # print(sd1.shape, sd2.shape, sd3.shape)
            sd = tf.concat([sd2, sd3, sd1], -1) # 1 : 2025, 2 : 2024, 3 : 2025+2024
            # sd = tf.concat([sd3, sd2, sd1], -1) # 1 : 2025, 2 : 2024, 3 : 2025+2024
            sd = sd / tf.reduce_sum(sd, -1)
            # print(sd.shape)
            sentence_distns_ci.append(sd)

        ####################################################
        sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns_ci]).tolist()
        
        chunked = []
        for idx in range(len(sentences)):
            order = c.one_step_chunking(sentence_distns_ci, idx, verbose = True)
            chunked.append(order.tolist())
    
        # print("111111111", splitted_data)
        qt_chunk_dict = qt_chunking_output(splitted_data, chunked, txt, len(nuts), sentence_distns_)
        # qt_chunk_dict = qt_chunking_output___(splitted_data, chunked, txt)
        name_check = [True if "ieb" in ml.model_name else False for ml in mls]
        if all(name_check):
            qt_chunk_dict['maxPage'] = n_pages

        #########################
        # del nuts
        # del txt
        # del sentence_distns
        # del sentence_distns_ci
        # del sentence_distns_
        # del order
        # del chunked
        # gc.collect()
        #########################        
            
        return qt_chunk_dict, chunked, n_pages

    else:
        nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total = make_chunk_page_ci(models, mls, contents)
        
        sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns_total]).tolist()
        chunked_cc = c.prcess_and_concatenate(chunked_total)
        
        qt_chunk_dict = qt_chunking_output(splitted_data_total, chunked_cc, total_txt, len(nuts_total), sentence_distns_)
        name_check = [True if "ieb" in ml.model_name else False for ml in mls]
        if all(name_check):
            qt_chunk_dict['maxPage'] = n_pages

        #########################
        # del nuts_total
        # del total_txt
        # del sentence_distns_total
        # del sentence_distns_
        # del chunked_cc
        # gc.collect()
        #########################        
        
        return qt_chunk_dict, chunked_cc, n_pages


def add_masking_info_to_json(json_dict):
    result_dict = {"data":[]}

    if 'data' not in json_dict:
        return json_dict
    elif len(json_dict['data']) < 1:
        return json_dict
    
    for input_dict in json_dict["data"]:
        new_dict = dict()
        new_dict["page"] = input_dict["page"]
        new_dict["chunk_seq"] = input_dict["chunk_seq"]
        
        text = input_dict['chunk']
        masking_text, be_list = detect_personal_info(text)
        new_dict["chunk"] = masking_text
        new_dict['be'] = be_list
        result_dict['data'].append(new_dict)

    return result_dict
        















