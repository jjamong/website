##########################################################
# 원천시스템 구분
# iemiea    내규
# iemieb    업무메뉴얼
# aikkms    지식샘
# kmswpt    업무포탈

# 업무포탈 업무구분
# 공지      120000107537
# 인사발령	120000107533
# 제도	    120000107428
# 여신관리	120000107487
# 상품	    120000107483
# 경영평가	120000107529
# 마케팅	120000107517
##########################################################

from fastapi import FastAPI, UploadFile, File, Form, Depends, Request
from pydantic import BaseModel
from typing import Optional
import uvicorn
import os
import time
import pickle
import re
import math
from itertools import chain
import traceback
import configparser
import json
import asyncio
import gc
import requests
from utils.logger.python_logger import logger

config = configparser.ConfigParser()
config.read("model_config.ini")
infer_config = config["INFER"]
server_config = config["SERVER"]
port_config = config["ENGINEPORT"]
endpoint_config = config["ENDPOINT"]

server =  server_config.get("local")
port = port_config.get("dev_perfor")
perfor_endpoint = endpoint_config.get("perfor_url")

import common_infer as c

import tensorflow as tf

from ModelLoad import ModelLoad
from main_module_0 import make_chunk, make_chunk_ci, add_masking_info_to_json

""" init config for tf """
gpu = infer_config.getint("gpu_index_0")
gpus = tf.config.experimental.list_physical_devices('GPU')
tf.config.experimental.set_visible_devices(gpus[gpu], 'GPU')
tf.config.experimental.set_memory_growth(gpus[gpu], True)

app = FastAPI(docs_url = "/docs", redoc_url = "/redoc")

class InputData(BaseModel):
    system_name: str = Form()
    code: str = Form()
    year: str = Form()

# iemiea
ml_iemiea = ModelLoad("./iemiea/data/unique_nuts_.tlp", "./iemiea/weights/6_12_deploy_model.weights.h5", "iemiea")
model_iemiea = ml_iemiea.load_model()

# iemieb
ml_iemieb = ModelLoad("./iemieb/data/unique_nuts_.tlp", "./iemieb/weights/6_12_deploy_model.weights.h5", "iemieb")
model_iemieb = ml_iemieb.load_model()

# wpt - hr
ml_kmswpt_hr = ModelLoad("./kmswpt/120000107533/data/unique_nuts_.tlp", "./kmswpt/120000107533/weights/6_12_deploy_model.weights.h5", "kmswpt_hr")
model_kmswpt_hr = ml_kmswpt_hr.load_model()

# wpt - goods
ml_kmswpt_goods = ModelLoad("./kmswpt/120000107483/data/unique_nuts_.tlp", "./kmswpt/120000107483/weights/6_12_deploy_model.weights.h5", "kmswpt_goods")
model_kmswpt_goods = ml_kmswpt_goods.load_model()

# wpt - eval
ml_kmswpt_eval = ModelLoad("./kmswpt/120000107529/data/unique_nuts_.tlp", "./kmswpt/120000107529/weights/6_12_deploy_model.weights.h5", "kmswpt_eval")
model_kmswpt_eval = ml_kmswpt_eval.load_model()

# wpt - marketing
ml_kmswpt_marketing = ModelLoad("./kmswpt/120000107517/data/unique_nuts_.tlp", "./kmswpt/120000107517/weights/6_12_deploy_model.weights.h5", "kmswpt_marketing")
model_kmswpt_marketing = ml_kmswpt_marketing.load_model()

# wpt - policy
ml_kmswpt_policy = ModelLoad("./kmswpt/120000107428/data/unique_nuts_.tlp", "./kmswpt/120000107428/weights/6_12_deploy_model.weights.h5", "kmswpt_policy")
model_kmswpt_policy = ml_kmswpt_policy.load_model()

# wpt - notice
ml_kmswpt_notice_1 = ModelLoad("./kmswpt/120000107537/data/unique_nuts_1.tlp", "./kmswpt/120000107537/weights/1/6_12_deploy_model.weights.h5", "kmswpt_notice_1")
model_kmswpt_notice_1 = ml_kmswpt_notice_1.load_model()

ml_kmswpt_notice_2 = ModelLoad("./kmswpt/120000107537/data/unique_nuts_2.tlp", "./kmswpt/120000107537/weights/2/6_12_deploy_model.weights.h5", "kmswpt_notice_2")
model_kmswpt_notice_2 = ml_kmswpt_notice_2.load_model()

ml_kmswpt_notice_3 = ModelLoad("./kmswpt/120000107537/data/unique_nuts_3.tlp", "./kmswpt/120000107537/weights/3/6_12_deploy_model.weights.h5", "kmswpt_notice_3")
model_kmswpt_notice_3 = ml_kmswpt_notice_3.load_model()

# csmcsm
ml_csmcsm = ModelLoad("./csmcsm/data/unique_nuts_.tlp", "./csmcsm/weights/6_12_deploy_model.weights.h5", "csmcsm")
model_csmcsm = ml_csmcsm.load_model()

# aikkms
ml_aikkms = ModelLoad("./aikkms/data/unique_nuts_.tlp", "./aikkms/weights/6_12_deploy_model.weights.h5", "aikkms")
model_aikkms = ml_aikkms.load_model()

# kmsepn
ml_kmsepn_announce = ModelLoad("./kmsepn/PLZEPN001/data/unique_nuts_.tlp", "./kmsepn/PLZEPN001/weights/6_12_deploy_model.weights.h5", "kmsepn_announce")
model_kmsepn_announce = ml_kmsepn_announce.load_model()

ml_kmsepn_invest = ModelLoad("./kmsepn/PLZEPN002/data/unique_nuts_.tlp", "./kmsepn/PLZEPN002/weights/6_12_deploy_model.weights.h5", "kmsepn_invest")
model_kmsepn_invest = ml_kmsepn_invest.load_model()

ml_kmsepn_rule = ModelLoad("./kmsepn/PLZEPN003/data/unique_nuts_.tlp", "./kmsepn/PLZEPN003/weights/6_12_deploy_model.weights.h5", "kmsepn_rule")
model_kmsepn_rule = ml_kmsepn_rule.load_model()

ml_kmsepn_goods = ModelLoad("./kmsepn/PLZEPN004/data/unique_nuts_.tlp", "./kmsepn/PLZEPN004/weights/6_12_deploy_model.weights.h5", "kmsepn_goods")
model_kmsepn_goods = ml_kmsepn_goods.load_model()

# iisiis
ml_iisiis = ModelLoad("./iisiis/data/unique_nuts_.tlp", "./iisiis/weights/6_12_deploy_model.weights.h5", "iisiis")
model_iisiis = ml_iisiis.load_model()

processing_lock = asyncio.Lock()
is_processing = False

@app.get("/cbc/health")
def get_health():

    return {"msg": "ok"}

@app.post("/cbc/inference")
async def context_based_chunking(input_data: InputData = Depends(), file: UploadFile = File()):

    global is_processing

    if is_processing:
        # print(f"is_active : {is_processing}")

        return {"is_processing": is_processing}

    async with processing_lock:
        is_processing = True
        
        try:
                    
            fn = file.filename
            sn = input_data.system_name
            cd = input_data.code
            if input_data.year == "":
                yr = 0
            else:
                yr = int(input_data.year)
    
            # print(f"Info : filename : {fn}")
            # print(f"Info : system name : {sn}")
            # print(f"Info : code : {cd}")
            logger.info(f"filename : {fn}")
            logger.info(f"system name : {sn}")
            logger.info(f"code : {cd}")
    
            start_time = time.time()
                    
            contents = await file.read()
            contents_ = contents.decode("utf-8")
            await file.close()
            # print(contents_)
    
            loop = asyncio.get_running_loop()
    
            if sn == "iemiea":
                # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_iemiea, ml_iemiea, contents_))
                qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_iemiea, ml_iemiea, contents_))

            elif sn == "csmcsm":
                # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_csmcsm, ml_csmcsm, contents_))
                qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_csmcsm, ml_csmcsm, contents_))

            elif sn == "aikkms":
                # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kms, ml_aikkms, contents_))
                qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_aikkms, ml_aikkms, contents_))
    
            elif sn == "iemieb":    
                # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_iemieb, ml_iemieb, contents_))
                qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_iemieb, ml_iemieb, contents_))
    
            elif sn == "kmswpt":
                if cd == "120000107533": # 인사발령
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_hr, ml_kmswpt_hr, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_hr, ml_kmswpt_hr, contents_))
    
                elif cd == "120000107483": # 상품
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_goods, ml_kmswpt_goods, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_goods, ml_kmswpt_goods, contents_))
                        
                elif cd == "120000107529": # 경영평가
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_eval, ml_kmswpt_eval, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_eval, ml_kmswpt_eval, contents_))
                        
                elif cd == "120000107517": # 마케팅        
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_marketing, ml_kmswpt_marketing, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_marketing, ml_kmswpt_marketing, contents_))
                                        
                elif cd == "120000107428": # 제도
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_policy, ml_kmswpt_policy, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmswpt_policy, ml_kmswpt_policy, contents_))
                
                elif cd == "120000107537": # 공지
                    # 1. 모델 3개 sentence_distns 계산
                    # 2. 3개 sentence_distns 합쳐서 result 계산    
                    models = [model_kmswpt_notice_1, model_kmswpt_notice_2, model_kmswpt_notice_3]
                    mls = [ml_kmswpt_notice_1, ml_kmswpt_notice_2, ml_kmswpt_notice_3]
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk_ci(models, mls, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk_ci(models, mls, contents_))
                    
                else:
                    elapsed_time = time.time() - start_time

                    # logger.info(f"elapsed_time : {elapsed_time}")
                    # logger.warning(f"Invalid kmswpt code -> {cd}")
                    
                    result = {"is_success": 0, "filename": fn, "elapsed_time": elapsed_time, "error_msg": "Invalid kmswpt code"}
                    return result
            
            elif sn in ["kmsplz", "kmsepn"]:
                if cd == "PLZEPN001":
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_epn_announce, ml_kmsepn_announce, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmsepn_announce, ml_kmsepn_announce, contents_))

                elif cd == "PLZEPN002":
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_epn_invest, ml_kmsepn_invest, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmsepn_invest, ml_kmsepn_invest, contents_))

                elif cd == "PLZEPN003":
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_epn_rule, ml_kmsepn_rule, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmsepn_rule, ml_kmsepn_rule, contents_))

                elif cd == "PLZEPN004":
                    # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_epn_goods, ml_kmsepn_goods, contents_))
                    qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_kmsepn_goods, ml_kmsepn_goods, contents_))

                else:
                    elapsed_time = time.time() - start_time

                    # logger.info(f"elapsed_time : {elapsed_time}")
                    # logger.warning(f"Invalid kmswpt code -> {cd}")
                    
                    result = {"is_success": 0, "filename": fn, "elapsed_time": elapsed_time, "error_msg": "Invalid kmsplz, kmsepn code"}
                    return result

            elif sn == "iisiis":
                # qt_chunk_dict = await loop.run_in_executor(None, lambda: make_chunk(model_iis, ml_iisiis, contents_))
                qt_chunk_dict, _, _ = await loop.run_in_executor(None, lambda: make_chunk(model_iisiis, ml_iisiis, contents_)) 
            
            else:
                elapsed_time = time.time() - start_time

                # logger.info(f"elapsed_time : {elapsed_time}")
                # logger.error(f"Invalid system name -> {sn}")
                
                result = {"is_success": 0, "filename": fn, "elapsed_time": elapsed_time, "error_msg": "Invalid system name"}
                return result
            if qt_chunk_dict:
                perfor_res = requests.post(f"http://{server}:{port}/{perfor_endpoint}", json = {'raw_txt' : contents_, 'model_result_list':qt_chunk_dict["result"], 'request_metrics':[], 'filename': fn})
                perfor_metrics = perfor_res.json()
                for metric, value in perfor_metrics.items():
                    logger.info(f"{metric} : {value}")
            else:
                perfor_metrics = {}
            
            elapsed_time = time.time() - start_time
            # print(f"Info : elapsed_time : {elapsed_time}")
            logger.info(f"elapsed_time : {elapsed_time}")
            
            # result = {"is_success": 1, "filename": fn, "elapsed_time": elapsed_time, "chunked": {"data": qt_chunk_dict["data"]}, "chunked_split": {"result": qt_chunk_dict["result"]}}
            result = {"is_success": 1, "filename": fn, "elapsed_time": elapsed_time, "chunked": qt_chunk_dict, "perfor_metrics": perfor_metrics}
            
            del qt_chunk_dict
            gc.collect()
    
        except Exception as e:
            
            # print("!!!Error!!!")
            # print(traceback.format_exc())
            elapsed_time = time.time() - start_time
            
            logger.error("!!!Error!!!")
            logger.error(f"filename : {fn}")
            logger.error(f"elapsed_time : {elapsed_time}")
            for eline in traceback.format_exc().split("\n"):
                logger.error(eline)
            
            # print(f"Error : filename : {fn}")
            # print(f"Error : elapsed_time : {elapsed_time}")
            
            result = {"is_success": 0, "filename": fn, "elapsed_time": elapsed_time, "error_msg": str(traceback.format_exc())}
    
        finally:
            is_processing = False
            logger.info(f"{'-' * 25} END {'-' * 25}")

    return result

@app.post("/cbc/masking")
async def update_json_with_masking(request:Request):

    global is_processing

    if is_processing:
        # print(f"is_active : {is_processing}")

        return {"is_processing": is_processing}

    async with processing_lock:
        is_processing = True    

        start_time = time.time()
        
        json_dict = await request.json()
        loop = asyncio.get_running_loop()
        return_result = await loop.run_in_executor(None, lambda: add_masking_info_to_json(json_dict))# add_masking_info_to_json(json_dict)

        elapsed_time = time.time() - start_time

        logger.info("Personal Info Masking Done")
        logger.info(f"elapsed_time : {elapsed_time}")
        logger.info(f"{'-' * 25} END {'-' * 25}")
    
        is_processing = False
    is_processing = False
    
    return return_result
    
if __name__ == "__main__":
    uvicorn.run(app, host = "0.0.0.0", port = 10090, access_log = False, timeout_keep_alive = 120)


