# -*- coding: utf-8 -*-
"""
Created on Thu Apr 17 15:06:59 2025

@author: kimchk
"""

import re
import numpy as np
import networkx as nx
from konlpy.tag import Mecab
from collections import Counter
from difflib import SequenceMatcher
from unicodedata import normalize as jaso

clean_pattern = re.compile(r'[가-힣a-zA-Z0-9]+')

# Mecab 형태소 분석기 초기화
tagger = Mecab(dicpath = '/app/anaconda3/mecab/mecab-ko-dic-2.1.1-20180720').tagger

from utils.logger.python_logger import logger

def clean_text_line(text):
    return ''.join(clean_pattern.findall(text))

def levenshtein_distance(first, second):
    if len(first) > len(second):
        first, second = second, first
    if len(second) == 0:
        return len(first)

    first_length = len(first) + 1
    second_length = len(second) + 1

    distance_matrix = [[0] * second_length for x in range(first_length)]
    for i in range(first_length):
        distance_matrix[i][0] = i
        for j in range(second_length):
            distance_matrix[0][j] = j

    for i in range(1, first_length):
        for j in range(1, second_length):
            deletion = distance_matrix[i - 1][j] + 1
            insertion = distance_matrix[i][j - 1] + 1
            substitution = distance_matrix[i - 1][j - 1]
            if first[i - 1] != second[j - 1]:
                substitution += 1
            distance_matrix[i][j] = min(insertion, deletion, substitution)

    return distance_matrix[first_length - 1][second_length - 1]


def word_similarity(first, second):
    if max(len(first), len(second)) < 1:
        return 0.

    first = [char for char in jaso("NFD", first)]
    second = [char for char in jaso("NFD", second)]

    return 1 - levenshtein_distance(first, second) / max(len(first), len(second))


def most_similar_word(word, word_set):
    max_sim = -1.0
    sim_word = ""
    for ref_word in word_set:
        sim = word_similarity(word, ref_word)
        if sim > max_sim:
            max_sim = sim
            sim_word = ref_word
    return sim_word, max_sim



def make_pos_result(pos_result_str):
    pos_str_list = pos_result_str.split('\n')
    pos_result = list()
    for pos_str in pos_str_list:
        if '\t' in pos_str:
            word = pos_str.split('\t')[0]
            remain = pos_str.split('\t')[1]
            pos = remain.split(',')[0]
            desc = remain.split(',')[1]
            comb = remain.split(',')[-1]
            pos_result.append([word, pos,desc,comb])
    return pos_result

# 형태소분석기 기반 종결어미 - 폐기
def pos_based_ef_method(line):

    split_lines = line.split(' ')

    last_ef_seat = None

    for si, split_ in enumerate(split_lines):
        
        pos_result_str = tagger.parse(split_)

        pos_result = make_pos_result(pos_result_str)
        
        if len(pos_result) == 0:
            pass
        elif pos_result[-1][1] in ['ETN', 'EF']:
            last_ef_seat = si
        elif '+ETN' in pos_result[-1][1]:
            last_ef_seat = si
        elif 1 < len(pos_result) and pos_result[-1][1] == 'SF' and pos_result[-2][1] in ['ETN', 'EF']:
            last_ef_seat = si
        elif 1 < len(pos_result) and pos_result[-1][1] == 'SF' and '+ETN' in pos_result[-2][1]:
            last_ef_seat = si

    if last_ef_seat == None:
        match_text = None
        after_text = line
    else:
        match_text = ' '.join(split_lines[:last_ef_seat+1])
        after_text = ' '.join(split_lines[last_ef_seat+1:])

    last_ef_seat = None
    match_text = None
    after_text = line
    return last_ef_seat, match_text, after_text

def get_frequent_specials(text, min_count = 2):
    # 특수문자만 추출
    specials = list()
    for match in re.finditer(r'[^\w\s]', text):
        idx = match.start()
        prev_ = text[idx-1] if idx > 0 else ''
        next_ = text[idx+1] if idx+1 < len(text) else ''
        if prev_.isdecimal() and next_.isdecimal():
            continue
        elif  prev_.isdecimal() and not next_.isdecimal():
            continue
        specials.append(match.group())
        
    counter = Counter(specials)
    # return_list = [re.escape(sym) for sym, cnt in counter.items() if cnt >= min_count]
    return_list = [sym for sym, cnt in counter.items() if cnt >= min_count]
    return_list = [char for char in return_list if char not in [')',']','>','}','.',',', '|','<', '/','(','[','{']]
    return return_list

def split_text_smart(text, min_distance= 6, min_special_count = 2):
    # 종결 어미 또는 닫히는 괄호 줄바꿈
    text = re.sub(r'((다|요|함|니다|했다|였다|오|임|됨|있음|없음|듬|음)[.)])', r'\1\n', text) # text = re.sub(r'((다|요|함|니다|했다|였다)[.)])', r'\1\n', text)
    text = re.sub(r'([)}\]])(?!(\s*[가-힣]))', r'\1\n', text)

    # 2회이상 등장한 특수문자 탐지
    specials = get_frequent_specials(text, min_count = min_special_count)
    
    if not specials:
        return text.strip()

    specials_set = set(specials)
    lines = text.split('\n')
    result_lines = list()
    
    for line in lines:
        if not line.strip():
            continue
        buffer = ''
        for char in line:
            if char in specials_set:
                if len(buffer.strip()) >= min_distance:
                    result_lines.append(buffer.strip())
                    buffer = ''
                buffer += char
            else:
                buffer += char
        if buffer.strip():
            result_lines.append(buffer.strip())

    clean = [line.strip() for line in result_lines if line.strip()]
    return '\n'.join(clean)

# 정규표현식 기반 종결어미
def reg_based_ef_method(line, flag, char_length=128):
    split_text = split_text_smart(line)
    lines = split_text.split('\n')
    # print(len(lines))
    if len(lines) == 0:
        last_ef_seat = None
    else:
        last_ef_seat = True

    if last_ef_seat == None:
        match_text = None
        after_text = split_text
    else:
        if flag == 'below':
            match_text = ''
            for li, line in enumerate(lines):
                match_text  = ' '.join([match_text, line])
                # print(char_length < len(match_text), len(match_text))
                if char_length < len(match_text):
                    break
            # print(match_text)
            after_text = ' '.join(lines[li+1:])

        else:
            after_text = ''
            for li in range(1,len(lines)+1):
                line = lines[-1*li]
                after_text = line + ' ' + after_text
                if char_length < len(after_text):
                    break
            match_text = ' '.join(lines[:-1*li])
    
    return last_ef_seat, match_text, after_text

# 정규표현식 기반 종결어미
def reg_based_ef_method_(line):
    inform_dict = dict()
    regex_list = [
        r'(?<=[가-힣])다\.[\s\r]{1,}(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])요\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])니다\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])죠\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])오\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])네\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', # 종결어미
        r'(?<=[가-힣])함\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])임\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])됨\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'있음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'없음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])',
        r'(?<=[가-힣])음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])',
        r'(?<=[가-힣])듬\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', # 명사형 종결
        r'\)\.[\s\r]?(?=[^\(\[\<\{])',
        r'\]\.[\s\r]?(?=[^\(\[\<\{])',
        r'\>\.[\s\r]?(?=[^\(\[\<\{])', # 닫히는 괄호
    
    
        r'(?<=[가-힣])다[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])요[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])니다[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])죠[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])오[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])네[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', # 종결어미
        r'(?<=[가-힣])함[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])임[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])됨[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'있음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'없음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])듬[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', # 명사형 종결
        r'\)[\s\r]?(?=[^가-힣\s\r\(\[\<\{])',
        r'\][\s\r]?(?=[^가-힣\s\r\(\[\<\{])',
        r'\>[\s\r]?(?=[^가-힣\s\r\(\[\<\{])', # 닫히는 괄호
    
    
        r'(?<=[가-힣])다\.[\s\r]{1,}$', 
        r'(?<=[가-힣])요\.[\s\r]{1,}$', 
        r'(?<=[가-힣])니다\.[\s\r]{1,}$', 
        r'(?<=[가-힣])죠\.[\s\r]{1,}$', 
        r'(?<=[가-힣])오\.[\s\r]{1,}$', 
        r'(?<=[가-힣])네\.[\s\r]{1,}$', # 종결어미
        r'(?<=[가-힣])함\.[\s\r]{1,}$', 
        r'(?<=[가-힣])임\.[\s\r]{1,}$', 
        r'(?<=[가-힣])됨\.[\s\r]{1,}$', 
        r'있음\.[\s\r]{1,}$', 
        r'없음\.[\s\r]{1,}$',
        r'(?<=[가-힣])음\.[\s\r]{1,}$',
        r'(?<=[가-힣])듬\.[\s\r]{1,}$', # 명사형 종결    r'(?<=[가-힣])다$', 
        r'\)\.[\s\r]{1,}$',
        r'\]\.[\s\r]{1,}$',
        r'\>\.[\s\r]{1,}$', # 닫히는 괄호
    
        r'(?<=[가-힣])다[\s\r]{1,}$', 
        r'(?<=[가-힣])요[\s\r]{1,}$', 
        r'(?<=[가-힣])니다[\s\r]{1,}$', 
        r'(?<=[가-힣])죠[\s\r]{1,}$', 
        r'(?<=[가-힣])오[\s\r]{1,}$', 
        r'(?<=[가-힣])네[\s\r]{1,}$', # 종결어미
        r'(?<=[가-힣])함[\s\r]{1,}$', 
        r'(?<=[가-힣])임[\s\r]{1,}$', 
        r'(?<=[가-힣])됨[\s\r]{1,}$', 
        r'있음[\s\r]{1,}$', 
        r'없음[\s\r]{1,}$',
        r'(?<=[가-힣])음[\s\r]{1,}$',
        r'(?<=[가-힣])듬[\s\r]{1,}$', # 명사형 종결
        r'\)[\s\r]{1,}$',
        r'\][\s\r]{1,}$',
        r'\>[\s\r]{1,}$', # 닫히는 괄호
    
        r'(?<=[가-힣])다\.$', 
        r'(?<=[가-힣])요\.$', 
        r'(?<=[가-힣])니다\.$', 
        r'(?<=[가-힣])죠\.$', 
        r'(?<=[가-힣])오\.$', 
        r'(?<=[가-힣])네\.$', # 종결어미
        r'(?<=[가-힣])함\.$', 
        r'(?<=[가-힣])임\.$', 
        r'(?<=[가-힣])됨\.$', 
        r'있음\.$', 
        r'없음\.$',
        r'(?<=[가-힣])음\.$',
        r'(?<=[가-힣])듬\.$', # 명사형 종결    r'(?<=[가-힣])다$', 
        r'\)\.$',
        r'\]\.$',
        r'\>\.$', # 닫히는 괄호
    
        # r'(?<=[가-힣])다$', 
        # r'(?<=[가-힣])요$', 
        r'(?<=[가-힣])니다$', 
        # r'(?<=[가-힣])죠$', 
        # r'(?<=[가-힣])오$', 
        # r'(?<=[가-힣])네$', # 종결어미
        # r'(?<=[가-힣])함$', 
        # r'(?<=[가-힣])임$', 
        r'(?<=[가-힣])됨$', 
        r'있음$', 
        r'없음$',
        # r'(?<=[가-힣])음$', # ###
        # r'(?<=[가-힣])듬$', # 명사형 종결 ###
        r'\)$',
        r'\]$',
        r'\>$', # 닫히는 괄호
        ]

    split_lines = line.split(' ')

    inform_dict = dict()
    for si, split_ in enumerate(split_lines):
        
        if split_ in ['', '\r', '\t']:
            pass
        
        elif si + 1 == len(split_lines):
            if split_ in ['', '\r', '\t']:
                pass
            else:
                check_text = split_
                
                for regex in regex_list:
                    regex_comp = re.compile(regex)
                    re_iter = regex_comp.finditer(check_text)
                    for re_result in re_iter:
                        inform = re_result.group()
                        start = re_result.start()
                        end = re_result.end()
                        inform_text = check_text[:end]
                        if inform_text not in inform_dict:
                            inform_dict[inform_text] = [si, regex]
        else:
            
            for ni in range((si+1),len(split_lines)):
                if split_lines[ni] not in ['', '\r', '\t']:
                    break
            next_split = split_lines[ni]
            
            check_text = ' '.join([split_, next_split])
     
            for regex in regex_list:
                regex_comp = re.compile(regex)
                re_iter = regex_comp.finditer(check_text)
                for re_result in re_iter:
                    inform = re_result.group()
                    start = re_result.start()
                    end = re_result.end()
                    inform_text = check_text[:end]
                    if inform_text not in inform_dict:
                        inform_dict[inform_text] = [min(si, len(split_lines)), regex]

    if len(inform_dict) == 0:
        last_ef_seat = None
    else:
        sorted_inform_list = sorted([[info,inform_dict[info]] for info in inform_dict], key = lambda x : x[1][0], reverse = True)
        
        last_ef_seat = sorted_inform_list[0][1][0]

    if last_ef_seat == None:
        match_text = None
        after_text = line
    else:
        match_text = ' '.join(split_lines[:last_ef_seat+1])
        after_text = ' '.join(split_lines[last_ef_seat+1:])
    
    return last_ef_seat, match_text, after_text


# 표 헤더
def only_nouns_line_method(line):
    pos_result_str = tagger.parse(line)
    pos_result = make_pos_result(pos_result_str)
    
    if line.strip(' ') not in ['', ' '] and 1 < len(line.strip(' ').strip('\r').strip(' ')):
        nn_flag = 'Y'
        for pos_li in pos_result:
            
            if pos_li[1] in ['SC', 'SY', 'XSN']:
                pass
            elif pos_li[1][0] not in ['N', 'M']:
                nn_flag = 'N'

    else:
        nn_flag = 'N'
    return nn_flag

# 목차성 텍스트 1
def toc_form_method(line):
    toc_form_flag = 'N'
    line = line.strip()
    # pattern = re.compile(r'^[\d\W]+\s?[가-힣][가-힣\s]*$')
    pattern = re.compile(r'^(?:\d|[^\w\s])+ ?[가-힣][가-힣\s]*$')
    # 15글자 미만 라인 중 조건에 맞는 것만 출력
    if len(line.strip()) < 15 and pattern.match(line):
        toc_form_flag = 'Y'
    return toc_form_flag

# 목차성 텍스트 2
def legal_form_method(line):
    line = line.strip()
    regex_list = [
        r'^(제\s*)?\d+\s?(편|장|절|조|관|목|항)',
        r'(?<=[가-힣]\.)[\s\r]*제\d+조(?:\([가-힣]+\))?',
        r'^부\s*칙',
        r'^별\s*지',
        r'^\(붙\s*임',
        r'^\(별\s*지',
        r'^\[붙\s*임',
        r'^\[별\s*지',
        r'^\<붙\s*임',
        r'^\<별\s*지',
        ]
    
    before_text = None
    match_text = None
    
    for regex in regex_list:
        regex_comp = re.compile(regex)
        re_iter = regex_comp.finditer(line)
        for re_result in re_iter:
            start = re_result.start()
            end = re_result.end()
            if start != 0:
                before_text = line[:start]
                match_text = line[start:]
            else:
                before_text = None
                match_text = line
                
    return before_text, match_text
    
def split_by_eomi_reg(line):
    split_text = split_text_smart(line)
    sentences = split_text.split('\n')
    return sentences

def split_by_eomi_reg_(line):
    regex_list = [
        r'(?<=[가-힣])다\.[\s\r]{1,}(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])요\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])니다\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])죠\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])오\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])네\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', # 종결어미
        r'(?<=[가-힣])함\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])임\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'(?<=[가-힣])됨\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'있음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', 
        r'없음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])',
        r'(?<=[가-힣])음\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])',
        r'(?<=[가-힣])듬\.[\s\r]?(?=[^\(\[\<\{\)\]\>\}])', # 명사형 종결
        r'\)\.[\s\r]?(?=[^\(\[\<\{])',
        r'\]\.[\s\r]?(?=[^\(\[\<\{])',
        r'\>\.[\s\r]?(?=[^\(\[\<\{])', # 닫히는 괄호
    
    
        r'(?<=[가-힣])다[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])요[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])니다[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])죠[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])오[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])네[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', # 종결어미
        r'(?<=[가-힣])함[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])임[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'(?<=[가-힣])됨[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'있음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', 
        r'없음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])음[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])',
        r'(?<=[가-힣])듬[\s\r]?(?=[^가-힣\s\r\(\[\<\{\.\)\]\>\}])', # 명사형 종결
        r'\)[\s\r]?(?=[^가-힣\s\r\(\[\<\{])',
        r'\][\s\r]?(?=[^가-힣\s\r\(\[\<\{])',
        r'\>[\s\r]?(?=[^가-힣\s\r\(\[\<\{])', # 닫히는 괄호
    
    
        r'(?<=[가-힣])다\.[\s\r]{1,}$', 
        r'(?<=[가-힣])요\.[\s\r]{1,}$', 
        r'(?<=[가-힣])니다\.[\s\r]{1,}$', 
        r'(?<=[가-힣])죠\.[\s\r]{1,}$', 
        r'(?<=[가-힣])오\.[\s\r]{1,}$', 
        r'(?<=[가-힣])네\.[\s\r]{1,}$', # 종결어미
        r'(?<=[가-힣])함\.[\s\r]{1,}$', 
        r'(?<=[가-힣])임\.[\s\r]{1,}$', 
        r'(?<=[가-힣])됨\.[\s\r]{1,}$', 
        r'있음\.[\s\r]{1,}$', 
        r'없음\.[\s\r]{1,}$',
        r'(?<=[가-힣])음\.[\s\r]{1,}$',
        r'(?<=[가-힣])듬\.[\s\r]{1,}$', # 명사형 종결    r'(?<=[가-힣])다$', 
        r'\)\.[\s\r]{1,}$',
        r'\]\.[\s\r]{1,}$',
        r'\>\.[\s\r]{1,}$', # 닫히는 괄호
    
        r'(?<=[가-힣])다[\s\r]{1,}$', 
        r'(?<=[가-힣])요[\s\r]{1,}$', 
        r'(?<=[가-힣])니다[\s\r]{1,}$', 
        r'(?<=[가-힣])죠[\s\r]{1,}$', 
        r'(?<=[가-힣])오[\s\r]{1,}$', 
        r'(?<=[가-힣])네[\s\r]{1,}$', # 종결어미
        r'(?<=[가-힣])함[\s\r]{1,}$', 
        r'(?<=[가-힣])임[\s\r]{1,}$', 
        r'(?<=[가-힣])됨[\s\r]{1,}$', 
        r'있음[\s\r]{1,}$', 
        r'없음[\s\r]{1,}$',
        r'(?<=[가-힣])음[\s\r]{1,}$',
        r'(?<=[가-힣])듬[\s\r]{1,}$', # 명사형 종결
        r'\)[\r]{1,}$',
        r'\][\r]{1,}$',
        r'\>[\r]{1,}$', # 닫히는 괄호
        r'\)[\s\r]{3,}$',
        r'\][\s\r]{3,}$',
        r'\>[\s\r]{3,}$', # 닫히는 괄호
        
        r'(?<=[가-힣])다\.$', 
        r'(?<=[가-힣])요\.$', 
        r'(?<=[가-힣])니다\.$', 
        r'(?<=[가-힣])죠\.$', 
        r'(?<=[가-힣])오\.$', 
        r'(?<=[가-힣])네\.$', # 종결어미
        r'(?<=[가-힣])함\.$', 
        r'(?<=[가-힣])임\.$', 
        r'(?<=[가-힣])됨\.$', 
        r'있음\.$', 
        r'없음\.$',
        r'(?<=[가-힣])음\.$',
        r'(?<=[가-힣])듬\.$', # 명사형 종결    r'(?<=[가-힣])다$', 
        r'\)\.$',
        r'\]\.$',
        r'\>\.$', # 닫히는 괄호
    
        # r'(?<=[가-힣])다$', 
        # r'(?<=[가-힣])요$', 
        r'(?<=[가-힣])니다$', 
        # r'(?<=[가-힣])죠$', 
        # r'(?<=[가-힣])오$', 
        # r'(?<=[가-힣])네$', # 종결어미
        # r'(?<=[가-힣])함$', 
        # r'(?<=[가-힣])임$', 
        r'(?<=[가-힣])됨$', 
        r'있음$', 
        r'없음$',
        # r'(?<=[가-힣])음$', # ###
        # r'(?<=[가-힣])듬$', # 명사형 종결 ###
        ]
    
    sentences = list()
    max_range = len(line.split(' '))
    check_line = None
    for i in range(max_range):
        if not check_line:
            check_line = line
        split_lines = check_line.split(' ')
        inform_dict = dict()
        for si, split_ in enumerate(split_lines):
            if split_ in ['', '\r', '\t']:
                pass
            
            elif si + 1 == len(split_lines):
                if split_ in ['', '\r', '\t']:
                    pass
                else:
                    check_text = split_
        
                    for regex in regex_list:
                        regex_comp = re.compile(regex)
                        re_iter = regex_comp.finditer(check_text)
                        for re_result in re_iter:
                            inform = re_result.group()
                            start = re_result.start()
                            end = re_result.end()
                            inform_text = check_text[:end]
                            if inform_text not in inform_dict:
                                inform_dict[inform_text] = [si, regex]
            else:
                
                for ni in range((si+1),len(split_lines)):
                    if split_lines[ni] not in ['', '\r', '\t']:
                        break
                next_split = split_lines[ni]
                
                check_text = ' '.join([split_, next_split])
         
                for regex in regex_list:
                    regex_comp = re.compile(regex)
                    re_iter = regex_comp.finditer(check_text)
                    for re_result in re_iter:
                        inform = re_result.group()
                        start = re_result.start()
                        end = re_result.end()
                        inform_text = check_text[:end]
                        if inform_text not in inform_dict:
                            inform_dict[inform_text] = [min(si, len(split_lines)), regex]
        
        if len(inform_dict) == 0:
            last_ef_seat = None
        else:
            sorted_inform_list = sorted([[info,inform_dict[info]] for info in inform_dict], key = lambda x : x[1][0], reverse = True)
            
            last_ef_seat = sorted_inform_list[0][1][0]
        
        if last_ef_seat:
            match_text = ' '.join(split_lines[:last_ef_seat+1])
            sentences.append(match_text)
            check_line = ' '.join(split_lines[last_ef_seat+1:])
            
        if not inform_dict:
            sentences.append(check_line)
            break
            
        if not check_line.strip():
            break
            
    return sentences

def split_by_special_char(text):
    result = list()
    buffer = ""
    i = 0
    length = len(text)

    while i < length:
        char = text[i]
        prev_char = text[i-1] if i >0 else ''
        next_char = text[i+1] if i+1 < length else ''

        if char in '.!?':
            if re.match(r'[가-힣]', prev_char):
                buffer += char
                i += 1
                continue
            elif char in '.,':
                if prev_char.isdigit() and next_char.isdigit():
                    buffer += char
                    i += 1
                    continue
        if char == '%' and prev_char.isdigit():
            buffer += char
            i += 1
            continue

        if char in "(){}[]<>":
            buffer += char
            i += 1
            continue

        if re.match(r'[^\w\s가-힣.,!?%\(\)\[\]\{\}<>]',char):
            if buffer.strip():
                result.append(buffer.strip())
                buffer = ""
            buffer += char
            i += 1
            continue

        buffer += char
        i += 1

    if buffer.strip():
        result.append(buffer.strip())

    return result


def get_line_pattern_type(line):
    line = line.strip()
    if not line:
        return None
        
    first_char = line[0]
    if re.match(r'^[^\d+]', line) and first_char.isdigit() and 1 < len(line):
        return 'first_digit'
        
    elif not re.match(r'^(\||</?td>)',line) and re.match(r'^[^\w\s]\s*', line) and 1 < len(line):
        return 'first_special'

    elif not re.match(r'^(\||</?td>)',line) and re.match(r'^[^\w\s\u3130-\u318F\uAC00-\uD7A3\u1100-\u11FF]\s*', line) and 1 < len(line):
        return 'first_special'
    
    elif re.match(r'^[가-힣a-zA-Z]\s*[\.\,]', line) and 1 < len(line):
        return 'first_onechar'

    elif re.match(r'^[\d+]\s*[\.\,]{0,1}', line) and 1 < len(line):
        return 'first_numdot'

    elif first_char.isdigit() and 1 < len(line):
        return 'first_digit'

    return None

def extract_same_pattern_lines(lines, flag):
    if flag == 'below':
        last_valid_seat = 0
        valid_cnt = 0
        for si, line in enumerate(lines):
            if get_line_pattern_type(line):
                valid_cnt += 1
                last_valid_seat = si
        if valid_cnt == 0:
            result_lines = list()
        elif valid_cnt == 1:
            result_lines = list()
            for li, line in enumerate(lines):
                if li == last_valid_seat:
                    break
                result_lines.append(line)
        else:
            candidate_lines = lines[:last_valid_seat]
            result_lines = list()
            result_lines.append(candidate_lines[0])
            before_type = get_line_pattern_type(candidate_lines[0])
            for li, line in enumerate(candidate_lines[1:]):
                pattern_type = get_line_pattern_type(line)
                if not before_type and pattern_type:
                    before_type = pattern_type
                if not pattern_type:
                    result_lines.append(line)
                elif before_type == pattern_type:
                    result_lines.append(line)
                else:
                    break
    else:
        last_valid_seat = 0
        valid_cnt = 0
        for si in range(1,len(lines)+1):
            line = lines[-si]
            if get_line_pattern_type(line):
                valid_cnt += 1
                last_valid_seat = -si
        if valid_cnt == 0:
            result_lines = list()
        elif valid_cnt == 1:
            result_lines = list()
            for li in range(1,len(lines)+1):
                line = lines[-li]
                result_lines = [line] + result_lines
                if -li == last_valid_seat:
                    break
        else:
            candidate_lines = lines[last_valid_seat:]
            result_lines = list()
            result_lines.append(candidate_lines[-1])
            before_type = get_line_pattern_type(candidate_lines[-1])
            for li in range(2,len(candidate_lines)+1):
                line = candidate_lines[-li]
                pattern_type = get_line_pattern_type(line)
                if not before_type and pattern_type:
                    before_type = pattern_type
                if not pattern_type:
                    result_lines = [line] + result_lines
                elif before_type == pattern_type:
                    result_lines = [line] + result_lines
                else:
                    break
                    
    return result_lines


def chunk_resizing(text, division_num = 800):
    clean_raw_text = clean_text(text)
    if re.findall(r"\n\n\</page\>\n\n|<page\s+num='\d+'>\n\n|\n\n\</page\>",clean_raw_text):
        clean_raw_text = clean_raw_text.replace('\n\n','\r\n')
        clean_raw_text = clean_raw_text.replace("\r\r\n\n", "\r\n\r\n")

    lines = list()
    for text_split in clean_raw_text.split('\r\n'):
        n_split = [li for li in text_split.split('\n') if li.strip()]
        lines.extend(n_split)
    # print(lines)
    result = list()
    quotient = len(text.replace('\r\n','\n').replace('<td>','').replace('</td>',''))//division_num
    if quotient == 1:
        quotient = 2
    char_range = len(text.replace('\r\n','\n').replace('<td>','').replace('</td>',''))//quotient
    current_chunk = ''
    for line in lines:
        if 300 <= len(line):
            eomi_based_split = split_by_eomi_reg(line)
            sublines = list()
            for sentence in eomi_based_split:
                sentence = sentence.replace('<td>','').replace('</td>',' ')
                if 300 <= len(sentence):
                    split_sentence = split_by_special_char(sentence)
                    # print('split_sentence :',split_sentence)
                    for spl_sent in split_sentence:
                        if 300 <= len(spl_sent.replace('\r\n','\n').replace('<td>','').replace('</td>','')):
                            # print('spl_sent :', spl_sent)
                            in_sent = ''
                            for space_split in spl_sent.split(' '):
                                if 300 <= len(space_split.replace('\r\n','\n').replace('<td>','').replace('</td>','')):
                                    for nsp_i, nsp_char in enumerate(space_split):
                                        if len(in_sent.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+1 > 300:
                                            sublines.append(in_sent)
                                            in_sent = nsp_char
                                        else:
                                            if nsp_i == 0:
                                                in_sent += ' ' + nsp_char
                                            else:
                                                in_sent += nsp_char
                                elif len(in_sent.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+len(space_split.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+1 > 300:
                                    sublines.append(in_sent)
                                    in_sent = space_split
                                else:
                                    in_sent += ' ' + space_split
                            if in_sent:
                                sublines.append(in_sent)

                        else:
                            sublines.append(spl_sent)
                else:
                    sublines.append(sentence)
            # print('#', sublines,  '#')
            # print(sublines)
            for sub in sublines:
                sub = sub.strip()
                if not sub:
                    continue
                if len(current_chunk.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+len(sub.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+1 > char_range:
                    result.append(current_chunk)
                    current_chunk = sub
                else:
                    current_chunk += ' ' + sub
        else:
            line = line.strip()
            if not line:
                continue
            if len(current_chunk.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+len(line.replace('\r\n','\n').replace('<td>','').replace('</td>',''))+1 > char_range:
                result.append(current_chunk)
                current_chunk = line
            else:
                current_chunk += '\r\n' + line

    if current_chunk:
        if len(current_chunk.replace('\r\n','\n').replace('<td>','').replace('</td>','')) + len(result[-1].replace('\r\n','\n').replace('<td>','').replace('</td>','')) < 900:
            result[-1] = result[-1] + '\r\n' + current_chunk
        else:
            result.append(current_chunk.strip())
    
    return result

# 청크 후방 오버래핑
def below_overlapping(below_text, process_flag = 'initial'):
    clean_below_text = clean_text(below_text)
    lines = []
    for text_split in clean_below_text.split('\r\n'):
        n_split = [li for li in text_split.split('\n') if li.strip()]
        lines.extend(n_split)

    if process_flag == 'initial':
        if len(lines) < 16:
            check_target_lines = lines[:int(len(lines)//2)+1]
        else:
            check_target_lines = lines[:8]
    else:
        check_target_lines = lines[:2]
    # 목차성 문자 처리
    toc_result_list = list()
    toc_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        toc_flag = toc_form_method(line)
        before_text, match_text = legal_form_method(line)
        toc_result_list.append([toc_flag, before_text, match_text])
        if toc_flag == 'Y' or match_text != None:
            toc_slice_flag = 'Y'

    # 텍스트 첫 패턴 처리
    # pattern_related_lines = extract_same_pattern_lines(check_target_lines, 'below')
    if len(check_target_lines) < 4:
        pattern_related_lines = extract_same_pattern_lines(check_target_lines, 'below')
    else:
        pattern_related_lines = extract_same_pattern_lines(check_target_lines[:4], 'below')
        
    # td tag 처리
    td_flag = 'N'
    for line in check_target_lines:
        if re.search(r"</?td>|^\|(?:[^\|]*\|){1,}", line):
            td_flag = 'Y'
    td_related_lines = extract_td_related_lines(check_target_lines, 'below')
            
    
    # 표형태 문자 처리
    table_result_list = list()
    table_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        nn_flag = only_nouns_line_method(line)

        table_result_list.append(nn_flag)
        if nn_flag == 'Y':
            table_slice_flag = 'Y'

    # 종결어미 문자처리
    ef_result_list = list()
    ef_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        pos_last_ef_seat, pos_match_text, pos_after_text = pos_based_ef_method(line)
        reg_last_ef_seat, reg_match_text, reg_after_text = reg_based_ef_method(line,flag='below')
        
        ef_result_list.append([[pos_last_ef_seat, pos_match_text, pos_after_text], [reg_last_ef_seat, reg_match_text, reg_after_text]])
        if pos_last_ef_seat != None or reg_last_ef_seat != None:
            ef_slice_flag = 'Y'

    if toc_slice_flag == 'Y':
        overlapping_list = list()
        for line, (toc_flag, before_text, match_text) in zip(check_target_lines, toc_result_list):
            if toc_flag == 'N' and match_text == None:
                overlapping_list.append(line)
            elif toc_flag == 'Y':
                break
            elif match_text != None and before_text == None:
                break
            elif match_text != None and before_text != None:
                overlapping_list.append(before_text)
                break

    elif pattern_related_lines:
        overlapping_list = pattern_related_lines    
    
    elif td_flag == 'Y':
        overlapping_list = td_related_lines

    elif table_slice_flag == 'Y':
        overlapping_list = list()
        for line,  nn_flag in zip(check_target_lines, table_result_list):
            if nn_flag == 'N':
                overlapping_list.append(line)
            else:
                break

    elif ef_slice_flag == 'Y':
        overlapping_list = list()
        for line, (pos_result, reg_result) in zip(check_target_lines, ef_result_list):
            if pos_result[0] == None and reg_result[0] == None:
                overlapping_list.append(line)
            elif pos_result[0] != None:
                overlapping_list.append(pos_result[1])
                break
            elif reg_result[0] != None:
                overlapping_list.append(reg_result[1])
                break

    else:
        overlapping_list = check_target_lines[:2]

    if not overlapping_list:
        overlapping_list = check_target_lines[:2]
        
    overlapping_text = '\r\n'.join(overlapping_list+[''])
    return overlapping_text

def extract_td_related_lines(text_lines, flag):
    td_pattern = re.compile(r"</?td>|^\|(?:[^\|]*\|){1,}")
    result_lines = []
    if not text_lines:
        return result_lines
    
    if flag == 'below':
        # 탐색 첫 라인에 td tag가 존재
        if td_pattern.search(text_lines[0]):
            result_lines.append(text_lines[0])
            for line in text_lines[1:]:
                if td_pattern.search(line):
                    result_lines.append(line)
                else:
                    break # 더이상 td tag 없으면 종료
                    
        # 탐색 첫 라인에 td tag 미존재
        else:
            result_lines.append(text_lines[0])
            for line in text_lines[1:]:
                if td_pattern.search(line):
                    break
                result_lines.append(line)
    else:
        # 탐색 첫 라인에 td tag가 존재
        if td_pattern.search(text_lines[-1]):
            result_lines.append(text_lines[-1])
            for li in range(2,len(text_lines)+1):
                line = text_lines[-li]
                if td_pattern.search(line):
                    result_lines = [line] + result_lines
                else:
                    break
        # 탐색 첫 라인에 td tag 미존재
        else:
            result_lines.append(text_lines[-1])
            for li in range(2,len(text_lines)+1):
                line = text_lines[-li]
                if td_pattern.search(line):
                    break
                result_lines = [line] + result_lines

    return result_lines

# 청크 전방 오버래핑
def above_overlapping(above_text, process_flag = 'initial'):
    clean_above_text = clean_text(above_text)
    lines = []
    for text_split in clean_above_text.split('\r\n'):
        n_split = [li for li in text_split.split('\n') if li.strip()]
        lines.extend(n_split)

    if process_flag == 'initial':
        if len(lines) < 16:
            check_target_lines = lines[int(len(lines)//2):]
        else:
            check_target_lines = lines[-7:]
    else:
        check_target_lines = lines[-2:]

    # 목차성 문자 처리
    toc_result_list = list()
    toc_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        toc_flag = toc_form_method(line)
        before_text, match_text = legal_form_method(line)
        toc_result_list.append([toc_flag, before_text, match_text])
        if toc_flag == 'Y' or match_text != None:
            toc_slice_flag = 'Y'

    # 텍스트 첫 패턴 처리
    # pattern_related_lines = extract_same_pattern_lines(check_target_lines, 'above')
    if len(check_target_lines) < 4:
        pattern_related_lines = extract_same_pattern_lines(check_target_lines, 'above')
    else:
        pattern_related_lines = extract_same_pattern_lines(check_target_lines[-4:], 'above')
        
    # td tag 처리
    td_flag = 'N'
    for line in check_target_lines:
        if re.search(r"</?td>|^\|(?:[^\|]*\|){1,}", line):
            td_flag = 'Y'
    td_related_lines = extract_td_related_lines(check_target_lines, 'above')
    
    # 표형태 문자 처리
    table_result_list = list()
    table_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        nn_flag = only_nouns_line_method(line)

        table_result_list.append(nn_flag)
        if nn_flag == 'Y':
            table_slice_flag = 'Y'

    # 종결어미 문자처리
    ef_result_list = list()
    ef_slice_flag = 'N'
    for line in check_target_lines:
        line = line.strip()
        pos_last_ef_seat, pos_match_text, pos_after_text = pos_based_ef_method(line)
        reg_last_ef_seat, reg_match_text, reg_after_text = reg_based_ef_method(line,flag='above')
        
        ef_result_list.append([[pos_last_ef_seat, pos_match_text, pos_after_text], [reg_last_ef_seat, reg_match_text, reg_after_text]])
        if pos_last_ef_seat != None or reg_last_ef_seat != None:
            ef_slice_flag = 'Y'

    if toc_slice_flag == 'Y':
        overlapping_list = list()
        for li in range(1,len(check_target_lines)+1):
            line = check_target_lines[-1*li]
            toc_flag, before_text, match_text = toc_result_list[-1*li]
            if toc_flag == 'N' and match_text == None:
                overlapping_list = [line]+overlapping_list
            elif toc_flag == 'Y':
                overlapping_list = [line]+overlapping_list
                break
            elif match_text != None:
                overlapping_list = [match_text]+overlapping_list
                break

    elif pattern_related_lines:
        overlapping_list = pattern_related_lines
    
    elif td_flag == 'Y':
        overlapping_list = td_related_lines
    
    elif table_slice_flag == 'Y':
        overlapping_list = list()
        for li in range(1,len(check_target_lines)+1):
            line = check_target_lines[-1*li]
            nn_flag = table_result_list[-1*li]
            if nn_flag == 'N':
                overlapping_list = [line]+overlapping_list
            else:
                overlapping_list = [line]+overlapping_list
                
                if li < len(check_target_lines):
                    next_flag = table_result_list[-1*(li+1)]
                    if next_flag != 'Y':
                        break
                else:
                    break

    elif ef_slice_flag == 'Y':
        overlapping_list = list()
        for li in range(1,len(check_target_lines)+1):
            line = check_target_lines[-1*li]
            pos_result = ef_result_list[-1*li][0]
            reg_result = ef_result_list[-1*li][1]
        
            if pos_result[0] == None and reg_result[0] == None:
                overlapping_list = [line]+overlapping_list
            elif pos_result[0] != None:
                overlapping_list = [pos_result[2]]+overlapping_list
                break
            elif reg_result[0] != None:
                overlapping_list = [reg_result[2]]+overlapping_list
                break

    else:
        overlapping_list = check_target_lines[-2:]

    if not overlapping_list:
        overlapping_list = check_target_lines[-2:]
    
    overlapping_text = '\r\n'.join(['']+overlapping_list)
    
    return overlapping_text

# # 청크 후방 오버래핑
# def below_overlapping(below_text):
#     clean_below_text = clean_text(below_text)
#     lines = []
#     for text_split in clean_below_text.split('\r\n'):
#         n_split = [li for li in text_split.split('\n') if li.strip()]
#         lines.extend(n_split)

#     if len(lines) < 16:
#         check_target_lines = lines[:int(len(lines)//2)+1]
#     else:
#         check_target_lines = lines[:8]

#     # 목차성 문자 처리
#     toc_result_list = list()
#     toc_slice_flag = 'N'
#     for line in check_target_lines:
#         toc_flag = toc_form_method(line)
#         before_text, match_text = legal_form_method(line)
#         toc_result_list.append([toc_flag, before_text, match_text])
#         if toc_flag == 'Y' or match_text != None:
#             toc_slice_flag = 'Y'

#     # 표형태 문자 처리
#     table_result_list = list()
#     table_slice_flag = 'N'
#     for line in check_target_lines:
#         nn_flag = only_nouns_line_method(line)

#         table_result_list.append(nn_flag)
#         if nn_flag == 'Y':
#             table_slice_flag = 'Y'

#     # 종결어미 문자처리
#     ef_result_list = list()
#     ef_slice_flag = 'N'
#     for line in check_target_lines:
#         pos_last_ef_seat, pos_match_text, pos_after_text = pos_based_ef_method(line)
#         reg_last_ef_seat, reg_match_text, reg_after_text = reg_based_ef_method(line)
        
#         ef_result_list.append([[pos_last_ef_seat, pos_match_text, pos_after_text], [reg_last_ef_seat, reg_match_text, reg_after_text]])
#         if pos_last_ef_seat != None or reg_last_ef_seat != None:
#             ef_slice_flag = 'Y'

#     if toc_slice_flag == 'Y':
#         overlapping_list = list()
#         for line, (toc_flag, before_text, match_text) in zip(check_target_lines, toc_result_list):
#             if toc_flag == 'N' and match_text == None:
#                 overlapping_list.append(line)
#             elif toc_flag == 'Y':
#                 break
#             elif match_text != None and before_text == None:
#                 break
#             elif match_text != None and before_text != None:
#                 overlapping_list.append(before_text)
#                 break

#     elif table_slice_flag == 'Y':
#         overlapping_list = list()
#         for line,  nn_flag in zip(check_target_lines, table_result_list):
#             if nn_flag == 'N':
#                 overlapping_list.append(line)
#             else:
#                 break

#     elif ef_slice_flag == 'Y':
#         overlapping_list = list()
#         for line, (pos_result, reg_result) in zip(check_target_lines, ef_result_list):
#             if pos_result[0] == None and reg_result[0] == None:
#                 overlapping_list.append(line)
#             elif pos_result[0] != None:
#                 overlapping_list.append(pos_result[1])
#                 break
#             elif reg_result[0] != None:
#                 overlapping_list.append(reg_result[1])
#                 break

#     else:
#         overlapping_list = check_target_lines[:2]

#     overlapping_text = '\r\n'.join(overlapping_list+[''])
    
#     return overlapping_text

# # 청크 전방 오버래핑
# def above_overlapping(above_text):
#     clean_above_text = clean_text(above_text)
#     lines = []
#     for text_split in clean_above_text.split('\r\n'):
#         n_split = [li for li in text_split.split('\n') if li.strip()]
#         lines.extend(n_split)

#     if len(lines) < 16:
#         check_target_lines = lines[int(len(lines)//2):]
#     else:
#         check_target_lines = lines[-7:]

#     # 목차성 문자 처리
#     toc_result_list = list()
#     toc_slice_flag = 'N'
#     for line in check_target_lines:
#         toc_flag = toc_form_method(line)
#         before_text, match_text = legal_form_method(line)
#         toc_result_list.append([toc_flag, before_text, match_text])
#         if toc_flag == 'Y' or match_text != None:
#             toc_slice_flag = 'Y'

#     # 표형태 문자 처리
#     table_result_list = list()
#     table_slice_flag = 'N'
#     for line in check_target_lines:
#         nn_flag = only_nouns_line_method(line)

#         table_result_list.append(nn_flag)
#         if nn_flag == 'Y':
#             table_slice_flag = 'Y'


#     # 종결어미 문자처리
#     ef_result_list = list()
#     ef_slice_flag = 'N'
#     for line in check_target_lines:
#         pos_last_ef_seat, pos_match_text, pos_after_text = pos_based_ef_method(line)
#         reg_last_ef_seat, reg_match_text, reg_after_text = reg_based_ef_method(line)
        
#         ef_result_list.append([[pos_last_ef_seat, pos_match_text, pos_after_text], [reg_last_ef_seat, reg_match_text, reg_after_text]])
#         if pos_last_ef_seat != None or reg_last_ef_seat != None:
#             ef_slice_flag = 'Y'

#     if toc_slice_flag == 'Y':
#         overlapping_list = list()
#         for li in range(1,len(check_target_lines)+1):
#             line = check_target_lines[-1*li]
#             toc_flag, before_text, match_text = toc_result_list[-1*li]
#             if toc_flag == 'N' and match_text == None:
#                 overlapping_list = [line]+overlapping_list
#             elif toc_flag == 'Y':
#                 overlapping_list = [line]+overlapping_list
#                 break
#             elif match_text != None:
#                 overlapping_list = [match_text]+overlapping_list
#                 break

#     elif table_slice_flag == 'Y':
#         overlapping_list = list()
#         for li in range(1,len(check_target_lines)+1):
#             line = check_target_lines[-1*li]
#             nn_flag = table_result_list[-1*li]
#             if nn_flag == 'N':
#                 overlapping_list = [line]+overlapping_list
#             else:
#                 overlapping_list = [line]+overlapping_list
#                 break

#     elif ef_slice_flag == 'Y':
#         overlapping_list = list()
#         for li in range(1,len(check_target_lines)+1):
#             line = check_target_lines[-1*li]
#             pos_result = ef_result_list[-1*li][0]
#             reg_result = ef_result_list[-1*li][1]
        
#             if pos_result[0] == None and reg_result[0] == None:
#                 overlapping_list = [line]+overlapping_list
#             elif pos_result[0] != None:
#                 overlapping_list = [pos_result[2]]+overlapping_list
#                 break
#             elif reg_result[0] != None:
#                 overlapping_list = [reg_result[2]]+overlapping_list
#                 break

#     else:
#         overlapping_list = check_target_lines[-2:]

#     overlapping_text = '\r\n'.join(['']+overlapping_list)
    
#     return overlapping_text

# 텍스트 정제
def clean_text(raw_text):

    # 1. \\r\\n → \n 처리
    cleaned = raw_text.replace("\\r\\n", "\r\n").replace("\\n", "\n").replace("\\r", "\r")
    # 3. \' → ' 로 변경
    cleaned = cleaned.replace("\\'", "'").replace("'", "'")
    # # 4. \\ → \ 또는 제거 (원하는 처리 방식에 따라 조절 가능)
    # cleaned = cleaned.replace("\\\\", "\\")
    return cleaned

# page정보기반 텍스트 생성
def make_page_text_dict(raw_text):
    clean_raw_text = clean_text(raw_text)
    if re.findall(r"\n\n\</page\>\n\n|<page\s+num='\d+'>\n\n|\n\n\</page\>",clean_raw_text):
        clean_raw_text = clean_raw_text.replace('\n\n','\r\n')
        clean_raw_text = clean_raw_text.replace("\r\r\n\n", "\r\n\r\n")
    # print('$'*50)
    # print(raw_text)
    # print('$'*50)
    # print(clean_raw_text)
    # print('$'*50)

    raw_lines = []
    for text_split in clean_raw_text.split('\r\n'):
        n_split = [li for li in text_split.split('\n') if li.strip()]
        raw_lines.extend(n_split)
    page_num = None
    page_text_dict = dict()
  
    for raw_line in raw_lines:
        page_start_pattern = re.compile(r"<page\s+num='(\d+)'>")
        num_pattern = re.compile(r'\d+')
        page_end_pattern = re.compile(r"\</page\>")   
        
        if page_end_pattern.match(raw_line):
            page_num = None
            
        if page_num != None:
            if page_num not in page_text_dict:
                page_text_dict[page_num] = [raw_line]
            else:
                page_text_dict[page_num].append(raw_line)
        
    
        if page_start_pattern.match(raw_line):
            page_num = int(re.search(r'(\d+)', raw_line).group())

    return page_text_dict

# unidirectional connection
def unidirectional_connection(splitted_data, graph_th_result, check_length = -2, post_processing = True):
    chunk_info_list = []

    if  len(splitted_data) == 0:
        pass
    elif len(splitted_data) < 4:
        chunk_info_list.append([splitted_data.join('')])

    elif len(splitted_data) == 4 and len(splitted_data[-1]) <= 110:
        chunk_info_list.append([''.join(splitted_data)])

    else:
        
        for ri, result_row in enumerate(graph_th_result):
            if chunk_info_list == []:
                chunk_info_list.append([result_row[0]])
                
            # elif ri+1 == len(graph_th_result) and len(splitted_data[-1]) <= 110:
            #     chunk_info_list[-1].append(result_row[0])
                            
            else:
                input_flag = 'N'
                
                for split_id in chunk_info_list[-1][check_length:]:
                    
                    if split_id in result_row[1:-1]:
                        input_flag = 'Y'           
                    # elif result_row[0] in graph_th_result[int(split_id)][1:check_length+1]:
                    #     input_flag = 'Y'

                        
                if input_flag == 'Y':
                    chunk_info_list[-1].append(result_row[0])
                else:
                    chunk_info_list.append([result_row[0]])
                    
    if post_processing == True:
        new_chunk_info_list= list()

        for list_ in chunk_info_list:
            if len(new_chunk_info_list) == 0:
                new_chunk_info_list.append(list_)
            else:
                if len(new_chunk_info_list[-1]) == 1:
                    new_chunk_info_list[-1].extend(list_)
                elif len(list_) == 1:
                    new_chunk_info_list[-1].extend(list_)
                else:
                    new_chunk_info_list.append(list_)
        chunk_info_list = new_chunk_info_list

    text_chunk_list = list()
    for list_ in chunk_info_list:
        text = ''.join(splitted_data[int(list_[0]):int(list_[-1])+1])
        text_chunk_list.append(text)

    return chunk_info_list, text_chunk_list

# bidirectional connection
def bidirectional_connection(splitted_data, graph_th_result, check_length = -2, post_processing = False):
    chunk_info_list = []
    text_chunk_list = list()
    if  len(splitted_data) == 0:
        pass
    elif len(splitted_data) < 4:
        text_chunk_list.append(''.join(splitted_data))

    elif len(splitted_data) == 4 and len(splitted_data[-1]) <= 110:
        text_chunk_list.append(''.join(splitted_data))

    else:
        for ri, result_row in enumerate(graph_th_result):
            if chunk_info_list == []:
                chunk_info_list.append([result_row[0]])
                
            # elif ri+1 == len(graph_th_result) and len(splitted_data[-1]) <= 110:
            #     chunk_info_list[-1].append(result_row[0])
                            
            else:
                # input_flag = 'N'
                id_in_flag = 'N'
                upper_check = []
                
                for split_id in chunk_info_list[-1][check_length:]:
                    upper_check.extend(graph_th_result[int(split_id)][1:])
                  
                    if split_id in result_row[1:]:
                        id_in_flag = 'Y'  

                if result_row[0] in upper_check and id_in_flag == 'Y':
                    chunk_info_list[-1].append(result_row[0])
                else:
                    chunk_info_list.append([result_row[0]])   
        if post_processing == True:
            new_chunk_info_list= list()
    
            for list_ in chunk_info_list:
                if len(new_chunk_info_list) == 0:
                    new_chunk_info_list.append(list_)
                else:
                    if len(new_chunk_info_list[-1]) == 1:
                        new_chunk_info_list[-1].extend(list_)
                    elif len(list_) == 1:
                        new_chunk_info_list[-1].extend(list_)
                    else:
                        new_chunk_info_list.append(list_)
            chunk_info_list = new_chunk_info_list
        
        
        for list_ in chunk_info_list:
            text = ''.join(splitted_data[int(list_[0]):int(list_[-1])+1])
            text_chunk_list.append(text)
        
    return chunk_info_list, text_chunk_list

# 오버랩핑 청크 생성
def make_overlapping_chunk_list(text_chunk_list):
    overlapping_chunk_list = list()
    model_result_list = list()
    # print('$'*70)
    # print(text_chunk_list)
    # print('$'*70)
    if len(text_chunk_list) == 0:
        overlapping_chunk_list.append({'chunk_seq':1, 'contents':'', 'origin_text':''})
        model_result_list.append({'seq':1, 'origin_text':'', 'below_join_text':'', 'above_join_text':''})
    elif len(text_chunk_list) == 1:
        overlapping_chunk_list.append({'chunk_seq':1, 'contents':text_chunk_list[0], 'origin_text':text_chunk_list[0]})
        model_result_list.append({'seq':1, 'origin_text':text_chunk_list[0], 'below_join_text':'', 'above_join_text':''})
    else:
        for ti, text in enumerate(text_chunk_list):
            if ti == 0:
                main_text = text
                below_text = text_chunk_list[ti+1]
                below_join_text = below_overlapping(below_text)
                chunk_text = ''.join([main_text, below_join_text])

                above_join_text = ''
                
            elif ti + 1 == len(text_chunk_list):
                main_text = text
                above_text = text_chunk_list[ti-1]
                above_join_text = above_overlapping(above_text)
                chunk_text = ''.join([above_join_text, main_text])

                below_join_text = ''
            
            else:
                main_text = text
                below_text = text_chunk_list[ti+1]
                below_join_text = below_overlapping(below_text)
                above_text = text_chunk_list[ti-1]
                above_join_text = above_overlapping(above_text)
                chunk_text = ''.join([above_join_text,main_text, below_join_text])
                
            overlapping_chunk_list.append({'chunk_seq':ti+1, 'contents':chunk_text, 'origin_text':text})
            model_result_list.append({'seq':ti+1, 
                                      'origin_text':text.replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_'),
                                      'below_join_text':below_join_text.replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_'),
                                      'above_join_text':above_join_text.replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')
                                     })
            
    return overlapping_chunk_list, model_result_list

def chunk_restructuring(chunk_list, max_char_length = 1280):
    restructure_chunk_list = list()
    chunk_seq = 1
    for chunk_dict in chunk_list:
        text = chunk_dict['contents']
        replace_text = text.replace('\r\n','\n').replace('<td>','').replace('</td>','')
        if max_char_length < len(replace_text):
            resized_chunks = chunk_resizing(text)
            resized_len = len(resized_chunks)
            chunk_dict_id = chunk_dict['chunk_seq']
            # print('chunk_dict_id :', chunk_dict_id, 'max_char_length over') # info log
            logger.info(f'chunk_dict_id : {chunk_dict_id} max_char_length over')
            # print(f"Proceed with resizing on Chunk{chunk_dict_id} : split into {resized_len}") # info log
            logger.info(f"Proceed with resizing on Chunk{chunk_dict_id} : split into {resized_len}")
            if len(resized_chunks) == 1:
                # print('## check :', len(resized_chunks[0])) # info log
                logger.info(f'## check : {len(resized_chunks[0])}')
                restructure_chunk_list.append({'chunk_seq':chunk_seq, 'contents':resized_chunks[0], 'origin_text':chunk_dict['origin_text']})
                chunk_seq += 1
            else:
                for ri, resized_chunk in enumerate(resized_chunks):
                    if ri == 0:
                        main_text = resized_chunk
                        below_text = resized_chunks[ri+1]
                        below_join_text = below_overlapping(below_text, process_flag = 're')
                        chunk_text = '\r\n'.join([main_text, below_join_text])
                    elif ri+1 == len(resized_chunks):
                        main_text = resized_chunk
                        above_text = resized_chunks[ri-1]
                        above_join_text = above_overlapping(above_text, process_flag = 're')
                        chunk_text = '\r\n'.join([above_join_text, main_text])
                    else:
                        main_text = resized_chunk
                        below_text = resized_chunks[ri+1]
                        below_join_text = below_overlapping(below_text, process_flag = 're')
                        above_text = resized_chunks[ri-1]
                        above_join_text = above_overlapping(above_text, process_flag = 're')
                        chunk_text = '\r\n'.join([above_join_text,main_text, below_join_text])

                    restructure_chunk_list.append({'chunk_seq':chunk_seq, 'contents':chunk_text, 'origin_text':chunk_dict['origin_text']})
                    chunk_seq += 1
        else:
            restructure_chunk_list.append({'chunk_seq':chunk_seq, 'contents':chunk_dict['contents'], 'origin_text':chunk_dict['origin_text']})
            chunk_seq += 1
        
    return restructure_chunk_list

def normalize_text(text):
    text = ''.join(text.split())
    text = re.sub(r'[^w\uAC00-\uD7A3]', '', text)
    return ''.join(text.split())

def is_valid_page_transition(prev_page, new_page, score, hard_threshold=0.85, soft_threshold=0.7, allow_backward=1):
    if prev_page is None:
        return True
        
    if new_page < prev_page - allow_backward:
        return False

    if new_page < prev_page:
        return score >= hard_threshold
        
    return score >= soft_threshold

def find_best_matching_page(page_text_dict, target_text_list, prev_page_num, score_tolerance=0.01):
    best_page = -1
    best_score = 0.0
    pages = sorted(page_text_dict.keys())
    target_text = '\n'.join(target_text_list)

    normalized_target = normalize_text(target_text)
    for i in range(len(pages)):
        page_num = pages[i]
        page_lines = page_text_dict[page_num]
        page_text = '\n'.join(page_lines)
        current_text = normalize_text(page_text)

        score1 = SequenceMatcher(None, normalized_target, current_text).ratio()
        if score1 > best_score:
            best_score = score1
            best_page = page_num

        if i + 1 < len(pages):
            next_page_num = pages[i+1]
            next_page_lines = page_text_dict[next_page_num]
            next_page_text = '\n'.join(next_page_lines)
            
            merged_text = normalize_text(page_text + ' ' + next_page_text)
            merged_score = SequenceMatcher(None, normalized_target, merged_text).ratio()
            if merged_score > best_score :
                best_score = merged_score

                score2 = SequenceMatcher(None, normalized_target, next_page_text).ratio()
                if abs(score2-merged_score) < score_tolerance:
                    best_page = next_page_num
                else:
                    best_page = page_num
    # print('best_page :', best_page, '  best_score :', best_score) # info log
    logger.info(f'best_page : {best_page} best_score : {best_score}')
    if is_valid_page_transition(prev_page_num, best_page, best_score):
        return best_page, best_score
    else:
        return prev_page_num, 0.0

def check_occurrence_of_value(lst, value):
    count = Counter(lst)
    freq = count.get(value, 0)
    if freq <= 1:
        return True
    else:
        return False

# 유사도까지
def make_output_dict(overlapping_chunk_list, page_text_dict, sim_threshold = 0.85):
    document_lines = []
    for page_key in page_text_dict:
        for p_line in page_text_dict[page_key]:
            if p_line.strip():  # 빈 문자열을 제외하는 로직 추가
                document_lines.append([p_line, page_key, len(document_lines) + 1])
    dup_check_list = [clean_text_line(row[0]) for row in document_lines]
    output_dict = {'data': []}
    text_loc_list = []
    already_added_chunk_seq = set()
    # print('%'*50, 'document_lines')
    # print(len(document_lines))

    for overlapping_chunk_dict in overlapping_chunk_list:
        # print("chunk_seq : ", overlapping_chunk_dict['chunk_seq']) # info log
        logger.info(f"chunk_seq : {overlapping_chunk_dict['chunk_seq']}")
        if overlapping_chunk_dict['chunk_seq'] in already_added_chunk_seq:
            continue

        chunk_contents = overlapping_chunk_dict['contents']
        # print('*'*50)
        # print('seq :', overlapping_chunk_dict['chunk_seq'])
        # print(chunk_contents)
        # print('*'*50)
        if not chunk_contents:
            output_dict['data'].append({'page': 1, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk': ''})
            already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
            continue

        # check_line_list = [line for line in chunk_contents.split('\r\n') if line.strip()]
        check_line_list = []
        for split_line in chunk_contents.split('\r\n'):
            if split_line.strip():
                n_split = [li for li in split_line.split('\n') if li.strip()]
                check_line_list.extend(n_split)
            
        chunk_len = len(check_line_list)
        check_point_num = max(int(chunk_len//2) - int(chunk_len//4), 0)
        page_detection = False
        page_detection2 = False
        detection_range = 0
        search_start_index = text_loc_list[-1]['check_point_line_loc'] if text_loc_list else 0
        search_start_index = min(search_start_index, len(document_lines)-1)

        candidate_lines_texts = [line_row[0] for line_row in document_lines[search_start_index:]]
        # print('# ## # # #  check_line_list :', check_line_list)
        # print('chunk_len :', chunk_len)
        for cii, check_line in enumerate(check_line_list):
            if not re.search(r"[a-zA-Z0-9가-힣]", check_line):
                continue
            check_line_clean = clean_text_line(check_line)
            if not check_occurrence_of_value(dup_check_list, check_line_clean):
                # print('dup :', check_line)
                continue
            found_exact = False
            found_sim = False
            # print('check_line :', check_line)
            for idx, line_row in enumerate(document_lines[search_start_index:]):
                line_text, page_i, line_i = line_row
                start_idx = max(0, line_i - 1 - cii)
                end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                line_text_clean = clean_text_line(line_text)

                if check_line_clean == line_text_clean:
                    # print('#exa'*50)
                    # print(cii)
                    # print('check_line :', check_line)
                    # print('chunk_len :', chunk_len)
                    # print('s-e :', [line[0] for line in document_lines[start_idx:end_idx]])
                    # print('&'*50)
                    # print(overlapping_chunk_dict['contents'])
                    # print('*'*50)
                    # print(matched_text)
                    # print('*'*50)
                    output_dict['data'].append({
                        'page': page_i,
                        'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                        'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                    })
                    text_loc_list.append({
                        'page': page_i,
                        'start_line_loc': line_i,
                        'end_line_loc': line_i + chunk_len,
                        # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                        'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                    })
                    already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                    detection_range = 0
                    page_detection = True
                    found_exact = True
                    break

                if ((detection_range+chunk_len)*2+10) < idx:
                    break

            if not found_exact:
                
                for li, lt in enumerate(candidate_lines_texts):
                    score = word_similarity(check_line_clean[:128], clean_text_line(lt)[:128])
                    if score >= sim_threshold:
                        best_match_idx = li
                        best_match_line_data = document_lines[search_start_index + best_match_idx]
                        page_i, line_i = best_match_line_data[1], best_match_line_data[2]
                        start_idx = max(0, line_i - 1 - cii)
                        end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                        matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                        # print('#sim'*50, check_line_clean[:128])
                        # print(overlapping_chunk_dict['contents'])
                        # print('*'*50)
                        # print(matched_text)
                        # print('*'*50)
                        output_dict['data'].append({
                            'page': page_i,
                            'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                            'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                        })
                        text_loc_list.append({
                            'page': page_i,
                            'start_line_loc': line_i,
                            'end_line_loc': line_i + chunk_len,
                            # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                            'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                        })
                        already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                        detection_range = 0
                        page_detection = True
                        found_sim = True
                        break
                    if ((detection_range+chunk_len)*2+10) < li:
                        break
            if not found_exact and not found_sim:
                if len(check_line_clean) < 8:
                    continue
                for idx, line_row in enumerate(document_lines[search_start_index:]):
                    line_text, page_i, line_i = line_row
                    start_idx = max(0, line_i - 1 - cii)
                    end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                    matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                    line_text_clean = clean_text_line(line_text)
    
                    if check_line_clean in line_text_clean:
                        output_dict['data'].append({
                            'page': page_i,
                            'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                            'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                        })
                        text_loc_list.append({
                            'page': page_i,
                            'start_line_loc': line_i,
                            'end_line_loc': line_i + chunk_len,
                            # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                            'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                        })
                        already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                        detection_range = 0
                        page_detection = True
                        break
                    if ((detection_range+chunk_len)*2+10) < idx:
                        break

            if page_detection:
                break

        if not page_detection:
            # print('page_detection2 process is ongoing') # info log
            logger.info('page_detection2 process is ongoing')
            page_detection2 = False
            search_start_index = None

            if text_loc_list:
                for d_line in document_lines:
                    if d_line[1] == text_loc_list[-1]['page']:
                        search_start_index = d_line[2]
                        break
            else:
                search_start_index = 0
            if not search_start_index:
                search_start_index = 0
            search_start_index = min(search_start_index, len(document_lines)-1)
            
            candidate_lines_texts = [line_row[0] for line_row in document_lines[search_start_index:]]
            # print('# ## # # #  check_line_list :', check_line_list)
            # print('chunk_len :', chunk_len)
            for cii, check_line in enumerate(check_line_list):
                if not re.search(r"[a-zA-Z0-9가-힣]", check_line):
                    continue
                check_line_clean = clean_text_line(check_line)
                if not check_occurrence_of_value(dup_check_list, check_line_clean):
                    # print('dup :', check_line)
                    continue
                found_exact = False
                found_sim = False
                # print('check_line :', check_line)
                for idx, line_row in enumerate(document_lines[search_start_index:]):
                    line_text, page_i, line_i = line_row
                    start_idx = max(0, line_i - 1 - cii)
                    end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                    matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                    line_text_clean = clean_text_line(line_text)
    
                    if check_line_clean == line_text_clean:
                        # print('#exa'*50)
                        # print(cii)
                        # print('check_line :', check_line)
                        # print('chunk_len :', chunk_len)
                        # print('s-e :', [line[0] for line in document_lines[start_idx:end_idx]])
                        # print('&'*50)
                        # print(overlapping_chunk_dict['contents'])
                        # print('*'*50)
                        # print(matched_text)
                        # print('*'*50)
                        output_dict['data'].append({
                            'page': page_i,
                            'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                            'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                        })
                        text_loc_list.append({
                            'page': page_i,
                            'start_line_loc': line_i,
                            'end_line_loc': line_i + chunk_len,
                            # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                            'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                        })
                        already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                        detection_range = 0
                        page_detection2 = True
                        found_exact = True
                        break
                    if ((detection_range+chunk_len)*2+10) < idx:
                        break
                if not found_exact:
                    
                    for li, lt in enumerate(candidate_lines_texts):
                        score = word_similarity(check_line_clean[:128], clean_text_line(lt)[:128])
                        if score >= sim_threshold:
                            best_match_idx = li
                            best_match_line_data = document_lines[search_start_index + best_match_idx]
                            page_i, line_i = best_match_line_data[1], best_match_line_data[2]
                            start_idx = max(0, line_i - 1 - cii)
                            end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                            matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                            # print('#sim'*50, check_line_clean[:128])
                            # print(overlapping_chunk_dict['contents'])
                            # print('*'*50)
                            # print(matched_text)
                            # print('*'*50)
                            output_dict['data'].append({
                                'page': page_i,
                                'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                                'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                            })
                            text_loc_list.append({
                                'page': page_i,
                                'start_line_loc': line_i,
                                'end_line_loc': line_i + chunk_len,
                                # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                                'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                            })
                            already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                            detection_range = 0
                            page_detection2 = True
                            found_sim = True
                            break
                        if ((detection_range+chunk_len)*2+10) < li:
                            break
                            
                if not found_exact and not found_sim:
                    if len(check_line_clean) < 8:
                        continue
                    for idx, line_row in enumerate(document_lines[search_start_index:]):
                        line_text, page_i, line_i = line_row
                        start_idx = max(0, line_i - 1 - cii)
                        end_idx = min(line_i + chunk_len - 1, len(document_lines))  # 문서 길이 초과 방지
                        matched_text = '\r\n'.join([line[0] for line in document_lines[start_idx:end_idx]])
                        line_text_clean = clean_text_line(line_text)
        
                        if check_line_clean in line_text_clean:
                            output_dict['data'].append({
                                'page': page_i,
                                'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                                'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')# matched_text # overlapping_chunk_dict['contents']
                            })
                            text_loc_list.append({
                                'page': page_i,
                                'start_line_loc': line_i,
                                'end_line_loc': line_i + chunk_len,
                                # 'check_point_line_loc': max(0, line_i + check_point_num - cii)
                                'check_point_line_loc': max(0, line_i + (chunk_len//3)*2 - cii) # max(0, line_i + ((chunk_len - cii)//3)*2) # max(0, line_i + chunk_len - cii - 2)
                            })
                            already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
                            detection_range = 0
                            page_detection2 = True
                            break
                        if ((detection_range+chunk_len)*2+10) < idx:
                            break
                            
                if page_detection2:
                    break

        if not page_detection and not page_detection2:
            # print('page_detection3 process is ongoing') # info log
            logger.info('page_detection3 process is ongoing')
            if page_text_dict:
                chunk_seq_num = overlapping_chunk_dict['chunk_seq']
                if chunk_seq_num == 1:
                    e_page = document_lines[0][1] if 0 < len(document_lines) else 1
                else:
                    origin_text_set = list()
                    for ovlp_chunk_dict in overlapping_chunk_list:
                        ovlp_seq = ovlp_chunk_dict['chunk_seq']
                        ovlp_origin = ovlp_chunk_dict['origin_text']
                        if ovlp_seq < chunk_seq_num:
                            if ovlp_origin not in origin_text_set:
                                origin_text_set.append(ovlp_origin)
                        else:
                            break
                    
                    check_origin_text = ''.join(origin_text_set)
                    check_line_list_ = []
                    for check_split_line in check_origin_text.split('\r\n'):
                        if check_split_line.strip():
                            check_n_split = [li for li in check_split_line.split('\n') if li.strip()]
                            check_line_list_.extend(check_n_split)
            
                    try:
                        line_seat_page = document_lines[len(check_line_list_)][1]
                        b_line_seat_page = document_lines[len(check_line_list_)-1][1]
                        if abs(line_seat_page - b_line_seat_page) < 2:
                            line_seat = max(0, len(check_line_list_)-1)
                            l_seat = min(line_seat, len(document_lines)-1)
                            e_page = document_lines[l_seat][1]
                        else:
                            line_seat = max(0, len(check_line_list_))
                            l_seat = min(line_seat, len(document_lines)-1)
                            e_page = document_lines[l_seat][1]
                    except:
                        line_seat = max(0, len(check_line_list_)-1)
                        l_seat = min(line_seat, len(document_lines)-1)
                        e_page = document_lines[l_seat][1]
            else:
                e_page = 1
                # print('#'*3) # info log
                logger.info('#'*3)
                # print(f"Chunk 위치 미발견: chunk_seq={overlapping_chunk_dict['chunk_seq']}") # info log
                logger.info(f"Chunk 위치 미발견: chunk_seq={overlapping_chunk_dict['chunk_seq']}")
                
            # print('&'*100, 'e_page :', e_page)
            output_dict['data'].append({
                'page': e_page, # None
                'chunk_seq': overlapping_chunk_dict['chunk_seq'],
                'chunk': overlapping_chunk_dict['contents'].replace('\r\n','\n').replace('<td>','').replace('</td>',' ').replace('\u001a',' ').replace('\u0005','_')
            })
            already_added_chunk_seq.add(overlapping_chunk_dict['chunk_seq'])
            detection_range += chunk_len

    return output_dict
    
def make_output_dict_(overlapping_chunk_list, page_text_dict):
    document_lines = list()
    for page_key in page_text_dict:
        for p_line in page_text_dict[page_key]:
            document_lines.append([p_line, page_key, (len(document_lines)+1)])
    
    output_dict = {'data':list()}
    text_loc_list = list()
    already_added_chunk_seq = list()

    for overlapping_chunk_dict in overlapping_chunk_list:
        if overlapping_chunk_dict['chunk_seq'] == 1 and overlapping_chunk_dict['contents'] == '' and overlapping_chunk_dict['origin_text'] == '':
            output_dict['data'].append({'page':1, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':''})
        else:
            check_line_list = [line for line in overlapping_chunk_dict['contents'].split('\r\n') if 1 < len(line) and line not in ['', '\r', ' ', None]]
            chunk_len = len([line for line in overlapping_chunk_dict['contents'].split('\r\n')])
            if 20 <= chunk_len:
                check_point_num = chunk_len - 10
            else:
                check_point_num = int(chunk_len//2) - int(chunk_len//4)
                
            page_detection = 'N'
            for check_line in check_line_list:

                if len(text_loc_list) == 0:
                    for line_row in document_lines:
                        line_text = line_row[0]
                        page_i = line_row[1]
                        line_i = line_row[2]
                        
                        if check_line == line_text or check_line == line_text.lstrip("'") or ''.join([char for char in check_line if re.match(r'[가-힣a-zA-Z0-9]',char)]) ==  ''.join([char for char in line_text if re.match(r'[가-힣a-zA-Z0-9]',char)]):
                            if overlapping_chunk_dict['chunk_seq'] not in already_added_chunk_seq:
                                output_dict['data'].append({'page':page_i, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':overlapping_chunk_dict['contents']})
                                text_loc_list.append({'page':page_i, 'start_line_loc':line_i, 'end_line_loc':line_i+chunk_len, 'check_point_line_loc':line_i+check_point_num})
                                page_detection = 'Y'
                                already_added_chunk_seq.append(overlapping_chunk_dict['chunk_seq'])
                                break
                            
                else:
                    for line_row in document_lines[text_loc_list[-1]['check_point_line_loc']:]:
                        line_text = line_row[0]
                        page_i = line_row[1]
                        line_i = line_row[2]
                        
                        if check_line == line_text or check_line == line_text.lstrip("'") or ''.join([char for char in check_line if re.match(r'[가-힣a-zA-Z0-9]',char)]) ==  ''.join([char for char in line_text if re.match(r'[가-힣a-zA-Z0-9]',char)]):
                            if overlapping_chunk_dict['chunk_seq'] not in already_added_chunk_seq:
                                output_dict['data'].append({'page':page_i, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':overlapping_chunk_dict['contents']})
                                text_loc_list.append({'page':page_i, 'start_line_loc':line_i, 'end_line_loc':line_i+chunk_len, 'check_point_line_loc':line_i+check_point_num})
                                page_detection = 'Y'
                                already_added_chunk_seq.append(overlapping_chunk_dict['chunk_seq'])
                                break

                if page_detection == 'Y':
                    break
                
            if page_detection == 'N':
                try:
                    if len(output_dict['data']) == 0:
                        output_dict['data'].append({'page':1, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':overlapping_chunk_dict['contents']})
                    else:
                        page_i = document_lines[text_loc_list[-1]['end_line_loc']][1]
                        line_i = document_lines[text_loc_list[-1]['end_line_loc']][2]
                        
                        output_dict['data'].append({'page':document_lines[text_loc_list[-1]['check_point_line_loc']][1], 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':overlapping_chunk_dict['contents']})
                        text_loc_list.append({'page':page_i, 'start_line_loc':line_i, 'end_line_loc':line_i+chunk_len, 'check_point_line_loc':line_i+check_point_num})
                        already_added_chunk_seq.append(overlapping_chunk_dict['chunk_seq'])
                        
                except:
                    output_dict['data'].append({'page':1, 'chunk_seq': overlapping_chunk_dict['chunk_seq'], 'chunk':overlapping_chunk_dict['contents']})
                    already_added_chunk_seq.append(overlapping_chunk_dict['chunk_seq'])

    return output_dict

def cosine_similarity(vectors):
    vectors = np.array(vectors)

    # 각 벡터의 L2 노름 계산(벡터크기)
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    
    # 0으로 나누는 것 방지
    norms[norms == 0] = 1e-10
    
    # 정규화
    normalized = vectors/norms
    
    # 유사도 행렬 : 정규화된 벡터 행렬과 그 전치행렬의 곱
    sim_matrix = np.dot(normalized, normalized.T)

    return sim_matrix

def calculate_chunk_count(total_tokens, chunk_size=400, overlap=50):
    """
    total_tokens: 전체 문서의 토큰 수
    chunk_size: 권장 청크 크기 (기본값: 400 토큰)
    overlap: 겹치는 토큰 수 (기본값: 50 토큰)
    
    returns: 적절한 청크 개수
    """
    
    if total_tokens <= 0:
        return 0
    
    step_size = chunk_size - overlap

    # 청크 개수 계산
    chunk_count = (total_tokens - overlap + step_size - 1) // step_size

    return chunk_count


def check_max_diameter(graph_th_result):
    G = nx.Graph()
    for group in graph_th_result:
        src = group[0]
        for dest in group[1:]:
            G.add_edge(src, dest)
    
    # 최대 간접 연결 단계 (그래프 지름)
    if nx.is_connected(G):
        max_diameter = nx.diameter(G)
        # print("** Maximum indirect connection steps in the entire graph : ", max_diameter) # info log
        logger.info(f"** Maximum indirect connection steps in the entire graph : {max_diameter}")

    else:
        components = nx.connected_components(G)
        diameters = [nx.diameter(G.subgraph(c)) for c in components]
        max_diameter = max(diameters)
        # print("** The graph is divided into multiple connected components,") # info log
        logger.info("** The graph is divided into multiple connected components,")
        # print("** and the maximum indirect connection steps of the largest component : ", max_diameter) # info log
        logger.info(f"** and the maximum indirect connection steps of the largest component : {max_diameter}")
    
    return max_diameter

def split_on_repeated_singletons(lists, threshold = 5):
    result = list()
    current_chunk = list()
    singleton_cnt = 0
    for sublist in lists:
        if len(sublist) == 1:
            current_chunk.append(sublist)

        else:
            if len(current_chunk) == 0:
                result.append(['norm',sublist])
            elif len(current_chunk) < threshold:
                for clist in current_chunk:
                    result.append(['norm',clist])
                current_chunk = list()
                result.append(['norm', sublist])
            else:
                result.append(['separate', current_chunk])
                current_chunk = list()
                result.append(['norm', sublist])

    if current_chunk:
        if len(current_chunk) < threshold:
            for clist in current_chunk:
                result.append(['norm',clist])
            current_chunk = list()
        else:
            result.append(['separate', current_chunk])  
    return result
    
def group_by_intra_cohesion_with_drop(previous_chunk, separate_list, sentence_distns, cosine_threshold=0.36, drop_num=2):
    groups = []
    prev_cohesion = 1.0
    drop_count = 0
    previous_flag = 'N'

    if previous_chunk == []:
        current_group = [separate_list[0][0]]
        start = 1
    else:
        current_group = previous_chunk.copy()
        start = 0

    for idx in range(start, len(separate_list)):
        candidate_group = current_group + [separate_list[idx][0]]
        vectors = np.vstack([sentence_distns[i] for i in candidate_group])

        if len(vectors) > 1:
            sim_matrix = cosine_similarity(vectors)
            upper_tri_ix = np.triu_indices(len(vectors), k=1)
            intra_cohesion = np.mean(sim_matrix[upper_tri_ix])
        else:
            intra_cohesion = 1.0

        if intra_cohesion < cosine_threshold:
            if previous_chunk and current_group[:len(previous_chunk)] == previous_chunk:
                previous_flag = 'Y'
            groups.append(current_group)
            current_group = [separate_list[idx][0]]
            prev_cohesion = 1.0
            drop_count = 0

        elif intra_cohesion < prev_cohesion:
            drop_count += 1
            if drop_count >= drop_num:
                split_point = current_group.pop()
                if current_group:
                    if previous_chunk and current_group[:len(previous_chunk)] == previous_chunk:
                        previous_flag = 'Y'
                    groups.append(current_group)
                    # split_point를 무조건 안전하게 추가
                    current_group = [split_point, separate_list[idx][0]]
                    vectors = np.vstack([sentence_distns[i] for i in current_group])
                    sim_matrix = cosine_similarity(vectors)
                    upper_tri_ix = np.triu_indices(len(vectors), k=1)
                    prev_cohesion = np.mean(sim_matrix[upper_tri_ix])
                    drop_count = 1

        else:
            prev_cohesion = intra_cohesion
            current_group.append(separate_list[idx][0])

    # 반복문 종료 후 최종 그룹 추가
    if current_group:
        if previous_chunk and current_group[:len(previous_chunk)] == previous_chunk:
            previous_flag = 'Y'
        groups.append(current_group)

    grouped_indices = sorted([int(i) for group in groups for i in group])
    expected_indices = sorted([int(li[0]) for li in separate_list])
    
    try:
        if previous_flag == 'Y':
            try:
                assert grouped_indices[len(previous_chunk):] == expected_indices, "중복 또는 누락 발생"
            except:
                assert grouped_indices[len(previous_chunk)-1:] == expected_indices, "중복 또는 누락 발생"
        else:
            assert grouped_indices == expected_indices, "중복 또는 누락 발생"
            
    except AssertionError as e:
        # print(f"Assertion 경고 (계속 진행됨): {e}") # info log
        logger.info(f"Assertion 경고 (계속 진행됨): {e}")

    return groups, previous_flag

def group_by_intra_cohesion_with_drop_(previous_chunk, separate_list, sentence_distns, cosine_threshold = 0.36, drop_num = 2):
    groups = list()
    prev_cohesion = 1.0 # 초기 응집도는 최대값
    drop_count = 0 # 연속 하락 횟수
    previous_flag = 'N'
    if previous_chunk == []:
        current_group = [separate_list[0][0]]
        start = 1
    else:
        current_group = previous_chunk
        start = 0
        
    for idx in range(start, len(separate_list)):
        candidate_group = current_group + [separate_list[idx][0]]
        vectors = np.vstack([sentence_distns[i] for i in candidate_group])
        
        if len(vectors) > 1:
            sim_matrix = cosine_similarity(vectors)
            upper_tri_ix = np.triu_indices(len(vectors), k=1)
            intra_cohesion = np.mean(sim_matrix[upper_tri_ix])
        else:
            intra_cohesion = 1.0

        # 임계값 미만
        if intra_cohesion < cosine_threshold:
            if previous_chunk != [] and previous_chunk == current_group[:len(previous_chunk)]:
                previous_flag = 'Y'
            groups.append(current_group)
            current_group = [separate_list[idx][0]]
            prev_cohesion = 1.0
            drop_count = 0
            
        elif intra_cohesion < prev_cohesion:
            drop_count += 1
            if drop_count >= 2:
                #하락이 시작된 직전 항목부터 새그룹으로 분리
                split_point = current_group.pop()
                if current_group:
                    if previous_chunk != [] and previous_chunk == current_group[:len(previous_chunk)]:
                        previous_flag = 'Y'
                    groups.append(current_group)
                # 새그룹은 하락 시작 항목부터 현재 항목까지
                current_group = [split_point, separate_list[idx][0]]
                # 새그룹 시작시 바로 cohesion 계산
                vectors = np.vstack([sentence_distns[i] for i in current_group])
                sim_matrix = cosine_similarity(vectors)
                upper_tri_ix = np.triu_indices(len(vectors), k=1)
                prev_cohesion = np.mean(sim_matrix[upper_tri_ix])
                drop_count = 1
            else:
                current_group.append(separate_list[idx][0])
                prev_cohesion = intra_cohesion

        else:
            drop_count = 0
            current_group.append(separate_list[idx][0])
            prev_cohesion = intra_cohesion
    # 마지막 그룹 추가(누락방지)
    if current_group:
        if previous_chunk != [] and previous_chunk == current_group[:len(previous_chunk)]:
            previous_flag = 'Y'
        groups.append(current_group)

    # grouped_indices = [i for group in groups for i in group]
    grouped_indices = sorted([int(i) for group in groups for i in group])
    expected_indices = sorted([int(li[0]) for li in separate_list])
    # print(previous_flag)
    if previous_flag == 'Y':
        # print('grouped_indices[len(previous_chunk):]', '\n', grouped_indices[len(previous_chunk):])
        # print('expected_indices','\n', expected_indices)
        try:
            assert grouped_indices[len(previous_chunk):] == expected_indices, "중복 또는 누락 발생"
        except:
            assert grouped_indices[len(previous_chunk)-1:] == expected_indices, "중복 또는 누락 발생"
    else:
        assert grouped_indices == expected_indices, "중복 또는 누락 발생"

    if previous_flag == 'N' and groups[0][:len(previous_chunk)] == previous_chunk:
        groups[0] = groups[0][len(previous_chunk):] 
    
    return groups, previous_flag

    
def group_by_intra_cohesion_with_drop__(previous_chunk, separate_list, sentence_distns, cosine_threshold = 0.36, drop_num = 3):
    result = list()
    current_group = list()
    prev_intra_cohesion = 1.0 # 초기 응집도는 최대값
    drop_count = 0 # 연속 하락 횟수
    
    if previous_chunk != []:
        current_group = list()
    else:
        current_group = previous_chunk
    for single_list in separate_list:
        idx = single_list[0]
        # print('idx :', idx)
        if current_group == []:
            current_group = single_list
        else:
            candidate_group = current_group + [idx]
            # vectors = [sentence_distns[i] for i in candidate_group]
            vectors = np.vstack([sentence_distns[i] for i in candidate_group])
            # print('candidate_group :', candidate_group)
            if len(vectors) > 1:
                sim_matrix = cosine_similarity(vectors)
                upper_tri_ix = np.triu_indices(len(vectors), k=1)
                intra_cohesion = np.mean(sim_matrix[upper_tri_ix])

            else:
                intra_cohesion = 1.0
            # print('intra_cohesion :', intra_cohesion)
            # print('prev_intra_cohesion :', prev_intra_cohesion)
            # 이전보다 내부 응집도가 떨어졌는지 체크
            if intra_cohesion < prev_intra_cohesion:
                drop_count += 1
            else:
                drop_count = 0
            # print('drop_count :', drop_count)
            # 그룹을 끊는 조건 체크(임계치)
            if intra_cohesion < cosine_threshold:
                result.append(current_group)
                current_group = [idx] # 새그룹 초기화
                drop_count = 0 # 새그룹 초기화
                prev_intra_cohesion = 1.0 # 새그룹 초기화

            # 여기에 연속 몇번 같은거 넣고 싶은데...

            else:
                current_group.append(idx)
                prev_intra_cohesion = intra_cohesion
                    
    if current_group:
        result.append(current_group)
    
    return result

def has_duplicates(list_):
    flatten_list = [item for sublist in list_ for item in sublist]
    return len(flatten_list) != len(set(flatten_list))
    
def cohesion_based_postprocessing(lists, sentence_distns):
    split_lists = split_on_repeated_singletons(lists)

    result_groups = list()
    for row in split_lists:
        if row[0] == 'norm':
            result_groups.append(row[1])
        else:
            if result_groups == []:
                previous_chunk = []
            else:
                previous_chunk = result_groups[-1]
            cohesion_based_result, previous_flag = group_by_intra_cohesion_with_drop(previous_chunk, row[1], sentence_distns)
            if previous_flag == 'N':
                result_groups.extend(cohesion_based_result)
            else:
                result_groups[-1] = cohesion_based_result[0]
                result_groups.extend(cohesion_based_result[1:])
    if result_groups:
        if has_duplicates(result_groups):
            # print("Re-running the 'group_by_intra_cohesion_with_drop' function with an empty list.") # info log
            logger.info("Re-running the 'group_by_intra_cohesion_with_drop' function with an empty list.")
            result_groups = list()
            for row in split_lists:
                if row[0] == 'norm':
                    result_groups.append(row[1])
                else:
                    if result_groups == []:
                        previous_chunk = []
                    else:
                        previous_chunk = result_groups[-1]
                    cohesion_based_result, previous_flag = group_by_intra_cohesion_with_drop([], row[1], sentence_distns)
                    if previous_flag == 'N':
                        result_groups.extend(cohesion_based_result)
                    else:
                        result_groups[-1] = cohesion_based_result[0]
                        result_groups.extend(cohesion_based_result[1:])
    return result_groups


def cohesion_based_postprocessing_(lists, sentence_distns):
    split_lists = split_on_repeated_singletons(lists)
    result_groups = list()
    for row in split_lists:
        if row[0] == 'norm':
            result_groups.append(row[1])
        else:
            if result_groups == []:
                previous_chunk = []
            else:
                previous_chunk = result_groups[-1]
            cohesion_based_result, previous_flag = group_by_intra_cohesion_with_drop(previous_chunk, row[1], sentence_distns)
            if previous_flag == 'N':
                result_groups.extend(cohesion_based_result)
            else:
                result_groups[-1] = cohesion_based_result[0]
                result_groups.extend(cohesion_based_result[1:])
            
    return result_groups

# bidirectional
def group_by_bidirectional_connection(graph_th_result, sentence_distns, length_threshold=2, post_processing = True, re_group = False): # 1은 "직접연결"만, 2는 "1차 간접연결"까지, 3은 "2차 간접연결"까지,

    # 그래프 생성
    G = nx.Graph()
    for group in graph_th_result:
        if len(group) == 1:
            group = group*5
        src = group[0]
        for dest in group[1:]:
            G.add_edge(src, dest)
    
    # 유효한 그룹핑 함수
    max_num = len(G)-1
    groups = []
    current_group = [0]

    for i in range(max_num):
        a, b = i, i+1

        connected = False
        if a in G and b in G:
            if nx.has_path(G, a, b):
                shortest_length = nx.shortest_path_length(G, a, b)
                if shortest_length <= length_threshold:  # 최대 2단계 간접연결 (3개의 edge까지 허용)
                    connected = True
        else:
            # print(f"그래프에 없는 노드 발견 : {a} 또는 {b}") # info log
            logger.info(f"그래프에 없는 노드 발견 : {a} 또는 {b}")

        if connected:
            current_group.append(b)
        else:
            groups.append(current_group)
            current_group = [b]

    if current_group:
        groups.append(current_group)
    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')
    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
    
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')
           
        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

# unidirectional
def group_by_unidirectional_connection(graph_th_result, sentence_distns, length_threshold=2, post_processing = True, re_group = False):

    # 방향 그래프 생성
    G = nx.DiGraph()
    for group in graph_th_result:
        src = group[0]
        for dest in group[1:]:
            G.add_edge(src, dest)  # 단방향으로만 추가
            
    # 유효한 그룹핑 함수
    max_num = len(G)-1
    groups = []
    current_group = [0]

    for i in range(max_num):
        a, b = i, i+1

        connected = False
        if a in G and b in G:        
            if nx.has_path(G, a, b):
                shortest_length = nx.shortest_path_length(G, a, b)
                if shortest_length <= length_threshold:
                    connected = True
        else:
            # print(f"그래프에 없는 노드 발견 : {a} 또는 {b}") # info log
            logger.info(f"그래프에 없는 노드 발견 : {a} 또는 {b}")
            
        if connected:
            current_group.append(b)
        else:
            groups.append(current_group)
            current_group = [b]

    if current_group:
        groups.append(current_group)

    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')
    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
    
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')

        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

# custum bidirectional
def custum_group_by_bidirectional_connection(graph_th_result, sentence_distns, check_length = -2, post_processing = True, re_group = False):
    groups = []
    for ri, result_row in enumerate(graph_th_result):
        if groups == []:
            groups.append([result_row[0]])
  
        else:
            id_in_flag = 'N'
            upper_check = []
            
            for split_id in groups[-1][check_length:]:
                upper_check.extend(graph_th_result[int(split_id)][1:])
              
                if split_id in result_row[1:]:
                    id_in_flag = 'Y'  

            if result_row[0] in upper_check and id_in_flag == 'Y':
                groups[-1].append(result_row[0])
            else:
                groups.append([result_row[0]])   

    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')

    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
        
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')

        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

# custum unidirectional
def custum_group_by_unidirectional_connection(graph_th_result, sentence_distns, check_length = -2, post_processing = True, re_group = False):
    groups = []
    for ri, result_row in enumerate(graph_th_result):
        if groups == []:
            groups.append([result_row[0]])                 
        else:
            input_flag = 'N'
            
            for split_id in groups[-1][check_length:]:
                
                if split_id in result_row[1:-1]:
                    input_flag = 'Y'
       
            if input_flag == 'Y':
                groups[-1].append(result_row[0])
            else:
                groups.append([result_row[0]])

    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')
    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
    
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')
            
        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

def sliding_window(list_length, window_size): # [num for num in group if num < list_length])
    return [[n for n in range(i, i + window_size) if n < list_length] for i in range(list_length - window_size + 2)]

def group_by_frequency(graph_th_result, sentence_distns, window_size = 2, threshold=1, post_processing = True, re_group = False):
    
    data = [row[1:] for row in graph_th_result]
    
    list_length = len(data)
    window_group = sliding_window(list_length, window_size)
    appeared_list = [0] * len(window_group)
    for list_ in data:
        for gi, group in enumerate(window_group):
            appeared = sum([1 for i in group if i in list_])
            if 2 <= appeared:
                appeared_list[gi] += 1
    #그룹구성
    grouped_flags = [False]*list_length
    groups = []
    current_group = []
    # total_ = set()
    # length = len(window_group)

    for wi, w_group in enumerate(window_group):
        if appeared_list[wi] >= threshold:
            for num in w_group:
                if not grouped_flags[num]:
                    current_group.append(num)
                    grouped_flags[num] = True
        else:
            if current_group:
                groups.append(current_group)
                current_group = list()

    if current_group:
        groups.append(current_group)

    #누락된 인텍스는 자기 자신만 갖는 그룹으로 삽입
    all_indices = set(range(list_length))
    grouped_indices = set(i for group in groups for i in group)
    missing_indices = sorted(all_indices - grouped_indices)

    #누락된 위치에 맞게 순차적으로 삽입
    full_result = list()
    used = set()
    for i in range(list_length):
        inserted = False
        for group in groups:
            if i == group[0] and tuple(group) not in used:
                full_result.append(group)
                used.add(tuple(group))
                inserted = True
                break
        if not inserted and i in missing_indices:
            full_result.append([i])
            
    groups =  full_result
    # groups = [sorted(group) for group in groups]    
    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')
    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
        
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')

        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

def group_by_frequency_(graph_th_result, sentence_distns, window_size = 2, threshold=1, post_processing = True, re_group = False):
    
    data = [row[1:] for row in graph_th_result]
    
    list_length = len(data)
    window_group = sliding_window(list_length, window_size)
    appeared_list = [0] * len(window_group)
    for list_ in data:
        for gi, group in enumerate(window_group):
            appeared = sum([1 for i in group if i in list_])
            if 2 <= appeared:
                appeared_list[gi] += 1

    groups = []
    current_group = []
    total_ = set()
    length = len(window_group)

    for wi, w_group in enumerate(window_group):
        if appeared_list[wi] >= threshold:
            for num in w_group:
                if num not in total_:
                    current_group.append(num)
                    total_.add(num)
        else:
            # 다음 그룹 존재 여부 및 빈도 충족 여부 체크
            next_satisfy = (wi + 1 < length) and (appeared_list[wi + 1] >= threshold)

            if next_satisfy:
                # 다음 그룹이 빈도를 만족하면 현재 그룹은 무시하고 넘어감
                continue
            else:
                # 다음 그룹이 불만족이면 처리되지 않은 숫자 개별 처리
                for num in w_group:
                    if num not in total_:
                        if current_group:
                            groups.append(current_group)

                        current_group = [num]
                        total_.add(num)
                        groups.append(current_group)
                        current_group = []

    if current_group:
        groups.append(current_group)

    groups = [sorted(group) for group in groups]    
    # print('** Length of groups before post-processing :', len(groups)) # info log
    logger.info(f'** Length of groups before post-processing : {len(groups)}')
    if re_group == True:
        # print('** re_group :', 'True') # info log
        logger.info('** re_group : True')
        groups = cohesion_based_postprocessing(groups, sentence_distns)
        # print('** Length of re_group :', len(groups)) # info log
        logger.info(f'** Length of re_group : {len(groups)}')
        
    post_groups = list()
    if post_processing == True:
        # print('** post_processing :', 'True') # info log
        logger.info('** post_processing : True')

        new_groups= list()
        for list_ in groups:
            if len(new_groups) == 0:
                new_groups.append(list_)
            else:
                if len(new_groups[-1]) == 1:
                    new_groups[-1].extend(list_)
                elif len(list_) == 1:
                    new_groups[-1].extend(list_)
                else:
                    new_groups.append(list_)
        post_groups = new_groups
        # print('** Length of groups after post-processing :', len(post_groups)) # info log
        logger.info(f'** Length of groups after post-processing : {len(post_groups)}')
    else:
        post_groups = groups
    return groups, post_groups

def select_grouping_method(splitted_data, graph_th_result, total_tokens, sentence_distns, input_diameter = 3, input_freq_threshold = 2, sorting_basis='abs', method_list = ['bi', 'uni', 'freq'], re_group =False):

    chunk_info_list = []
    text_chunk_list = list()
    if  len(splitted_data) == 0:
        pass
    elif len(splitted_data) < 4:
        text_chunk_list.append(''.join(splitted_data))

    elif len(splitted_data) == 4 and len(splitted_data[-1]) <= 110:
        text_chunk_list.append(''.join(splitted_data))

    else:
        if total_tokens < 1200:
            max_chunk_count = calculate_chunk_count(total_tokens, chunk_size=95*4, overlap=95*4//8)
            # re_group= True
            post_processing_flag=True
        else:
            max_chunk_count = calculate_chunk_count(total_tokens, chunk_size=95*4, overlap=95*4//8)
            # re_group_flag= True
            post_processing_flag=True
            
        # print("* Total_tokens_count :", total_tokens) # info log
        logger.info(f"* Total_tokens_count : {total_tokens}")
        # print("* Maximum chunk count :", max_chunk_count) # info log
        logger.info(f"* Maximum chunk count : {max_chunk_count}")
        max_diameter = min(input_diameter, check_max_diameter(graph_th_result))
        # print("* Maximum indirect connection steps for selecting connection methodology : ", max_diameter) # info log
        logger.info(f"* Maximum indirect connection steps for selecting connection methodology : {max_diameter}")
        # print("* sorting_basis : ", sorting_basis,'\n') # info log
        logger.info(f"* sorting_basis : {sorting_basis}")

        grouping_results = []
        for method in method_list:
            if method == 'bi':
                for thr_ in range(1,max_diameter+1):
                    # print('* method :', 'bidirectional') # info log
                    logger.info('* method : bidirectional')
                    # print('* length_threshold :', thr_) # info log
                    logger.info(f'* length_threshold : {thr_}')
                    origin, groups = group_by_bidirectional_connection(graph_th_result, sentence_distns, length_threshold=thr_, post_processing = post_processing_flag)
                    for idx, group in enumerate(groups):
                        # print(f"*** Group {idx}: {group}") # info log
                        logger.info(f"*** Group {idx}: {group}")
                    # print('\n') # info log
                    # logger.info('\n')
                    grouping_results.append([len(grouping_results), len(groups), 'bidirectional', thr_, groups, origin])
            
                # print('* method :', 'custum bidirectional') # info log
                logger.info('* method : custum bidirectional')
                origin, groups = custum_group_by_bidirectional_connection(graph_th_result, sentence_distns, post_processing = post_processing_flag)
                for idx, group in enumerate(groups):
                    # print(f"*** Group {idx}: {group}") # info log
                    logger.info(f"*** Group {idx}: {group}")
                # print('\n') # info log
                # logger.info('\n')
                grouping_results.append([len(grouping_results), len(groups), 'custum bidirectional', -2, groups, origin])
                
            elif method == 'uni':
                for thr_ in range(1,max_diameter+1):
                    # print('* method :', 'unidirectional') # info log
                    logger.info('* method : unidirectional')
                    # print('* length_threshold :', thr_) # info log
                    logger.info(f'* length_threshold : {thr_}')
                    origin, groups = group_by_unidirectional_connection(graph_th_result, sentence_distns, length_threshold=thr_, post_processing = post_processing_flag)
                    for idx, group in enumerate(groups):
                        # print(f"*** Group {idx}: {group}") # info log
                        logger.info(f"*** Group {idx}: {group}")
                    # print('\n') # info log
                    # logger.info('\n')
                    grouping_results.append([len(grouping_results), len(groups), 'unidirectional', thr_, groups, origin])

                # print('* method :', 'custum unidirectional') # info log
                logger.info('* method : custum unidirectional')
                origin, groups = custum_group_by_unidirectional_connection(graph_th_result, sentence_distns, post_processing = post_processing_flag)
                for idx, group in enumerate(groups):
                    # print(f"*** Group {idx}: {group}") # info log
                    logger.info(f"*** Group {idx}: {group}")
                # print('\n') # info log
                # logger.info('\n')
                grouping_results.append([len(grouping_results), len(groups), 'custum unidirectional', -2, groups, origin])

            elif method == 'freq':
                freq_list = [(input_freq_threshold-i) for i in range(input_freq_threshold)]
                for freq_thr in freq_list:
                    # print('* method :', 'frequency') # info log
                    logger.info('* method : frequency')
                    # print('* frequency_threshold :', freq_thr) # info log
                    logger.info(f'* frequency_threshold : {freq_thr}')
                    origin, groups = group_by_frequency(graph_th_result, sentence_distns, threshold=freq_thr, post_processing = post_processing_flag)
                    for idx, group in enumerate(groups):
                        # print(f"*** Group {idx}: {group}") # info log
                        logger.info(f"*** Group {idx}: {group}")
                    # print('\n') # info log
                    # logger.info('\n')
                    grouping_results.append([len(grouping_results), len(groups), 'frequency', freq_thr, groups, origin])

        if re_group == True:
            for method in method_list:
                if method == 'bi':
                    for thr_ in range(1,max_diameter+1):
                        # print('* method :', 'bidirectional_regroup') # info log
                        logger.info('* method : bidirectional_regroup')
                        # print('* length_threshold :', thr_) # info log
                        logger.info(f'* length_threshold : {thr_}')
                        origin, groups = group_by_bidirectional_connection(graph_th_result, sentence_distns, length_threshold=thr_, post_processing = post_processing_flag, re_group = True)
                        if len(graph_th_result) == len([item for sublist in groups for item in sublist]):
                            for idx, group in enumerate(groups):
                                # print(f"*** Group {idx}: {group}") # info log
                                logger.info(f"*** Group {idx}: {group}")
                            # print('\n') # info log
                            # logger.info('\n')
                            grouping_results.append([len(grouping_results), len(groups), 'bidirectional_regroup', thr_, groups, origin])
                        else:
                            # print("* This method's result is excluded.",'\n') # info log
                            logger.info("* This method's result is excluded.")
                
                    # print('* method :', 'custum bidirectional_regroup') # info log
                    logger.info('* method : custum bidirectional_regroup')
                    origin, groups = custum_group_by_bidirectional_connection(graph_th_result, sentence_distns, post_processing = post_processing_flag, re_group = True)
                    if len(graph_th_result) == len([item for sublist in groups for item in sublist]):
                        for idx, group in enumerate(groups):
                            # print(f"*** Group {idx}: {group}") # info log
                            logger.info(f"*** Group {idx}: {group}")
                        # print('\n') # info log
                        # logger.info('\n')
                        grouping_results.append([len(grouping_results), len(groups), 'custum bidirectional_regroup', -2, groups, origin])
                    else:
                        # print("* This method's result is excluded.",'\n') # info log
                        logger.info("* This method's result is excluded.")
                    
                elif method == 'uni':
                    for thr_ in range(1,max_diameter+1):
                        # print('* method :', 'unidirectional_regroup') # info log
                        logger.info('* method : unidirectional_regroup')
                        # print('* length_threshold :', thr_) # info log
                        logger.info(f'* length_threshold : {thr_}')
                        origin, groups = group_by_unidirectional_connection(graph_th_result, sentence_distns, length_threshold=thr_, post_processing = post_processing_flag, re_group = True)
                        if len(graph_th_result) == len([item for sublist in groups for item in sublist]):
                            for idx, group in enumerate(groups):
                                # print(f"*** Group {idx}: {group}") # info log
                                logger.info(f"*** Group {idx}: {group}")
                            # print('\n') # info log
                            # logger.info('\n')
                            grouping_results.append([len(grouping_results), len(groups), 'unidirectional_regroup', thr_, groups, origin])
                        else:
                            # print("* This method's result is excluded.",'\n') # info log
                            logger.info("* This method's result is excluded.")
    
                    # print('* method :', 'custum unidirectional_regroup') # info log
                    logger.info('* method : custum unidirectional_regroup')
                    origin, groups = custum_group_by_unidirectional_connection(graph_th_result, sentence_distns, post_processing = post_processing_flag, re_group = True)
                    if len(graph_th_result) == len([item for sublist in groups for item in sublist]):
                        for idx, group in enumerate(groups):
                            # print(f"*** Group {idx}: {group}") # info log
                            logger.info(f"*** Group {idx}: {group}")
                        # print('\n') # info log
                        # logger.info('\n')
                        grouping_results.append([len(grouping_results), len(groups), 'custum unidirectional_regroup', -2, groups, origin])
                    else:
                        # print("* This method's result is excluded.",'\n') # info log
                        logger.info("* This method's result is excluded.")
    
                elif method == 'freq':
                    freq_list = [(input_freq_threshold-i) for i in range(input_freq_threshold)]
                    for freq_thr in freq_list:
                        # print('* method :', 'frequency_regroup') # info log
                        logger.info('method : frequency_regroup')
                        # print('* frequency_threshold :', freq_thr) # info log
                        logger.info(f'* frequency_threshold : {freq_thr}')
                        origin, groups = group_by_frequency(graph_th_result, sentence_distns, threshold=freq_thr, post_processing = post_processing_flag, re_group = True)
                        if len(graph_th_result) == len([item for sublist in groups for item in sublist]):
                            for idx, group in enumerate(groups):
                                # print(f"*** Group {idx}: {group}") # info log
                                logger.info(f"*** Group {idx}: {group}")
                            # print('\n') # info log
                            # logger.info('\n')
                            grouping_results.append([len(grouping_results), len(groups), 'frequency_regroup', freq_thr, groups, origin])
                        else:
                            # print("* This method's result is excluded.",'\n') # info log
                            logger.info("* This method's result is excluded.")
        
        if sorting_basis == 'abs':
            sorted_grouping_results = sorted(grouping_results, key = lambda x : [abs(x[1]-max_chunk_count),x[0]])
        elif sorting_basis == 'max':
            sorted_grouping_results = sorted(grouping_results, key = lambda x : [(x[1]*-1),x[0]])
            
        chunk_info_list = sorted_grouping_results[0][-2]
        pe_data = [row for row in sorted_grouping_results[0][-1] if 1<len(row)]
        # print('*'*50) # info log
        logger.info('*'*50)
        # print('* Length of the selected grouping result :', len(chunk_info_list)) # info log
        logger.info(f'* Length of the selected grouping result : {len(chunk_info_list)}')
        # print('* selected result information :', sorted_grouping_results[0][2:4]) # info log
        logger.info(f'* selected result information : {sorted_grouping_results[0][2:4]}')
        # print('* selected result ==>','\n', chunk_info_list,'\n') # info log
        logger.info(f'selected result ==> {chunk_info_list}')

        for list_ in chunk_info_list:
            text = ''.join(splitted_data[int(list_[0]):int(list_[-1])+1])
            text_chunk_list.append(text)
        
    return chunk_info_list, text_chunk_list

def qt_chunking_output(splitted_data, graph_th_result, raw_text, total_tokens, sentence_distns):
    chunk_info_list, text_chunk_list = select_grouping_method(splitted_data, graph_th_result, total_tokens, sentence_distns, re_group =False) # re_group =True
    # print('@'*50)
    # print(text_chunk_list)
    # print('@'*50)
    overlapping_chunk_list, model_result_list = make_overlapping_chunk_list(text_chunk_list)
    # print('!'*50)
    # print(overlapping_chunk_list)
    # print('!'*50) 
    overlapping_chunk_list = chunk_restructuring(overlapping_chunk_list)
    # print('chunk_restructuring completed')
    page_text_dict = make_page_text_dict(raw_text)
    # print('*'*50)
    # print(page_text_dict)
    # print('*'*50)
    # print('start make output dict')
    output_dict = make_output_dict(overlapping_chunk_list, page_text_dict)
    output_dict['result'] = model_result_list
    
    return output_dict

def qt_chunking_output___(splitted_data, graph_th_result, raw_text, method = 'bi'): # or method = 'uni'
    if method == 'bi':
        chunk_info_list, text_chunk_list = bidirectional_connection(splitted_data, graph_th_result)
        # print('connection_result :', chunk_info_list) # info log
        logger.info(f'connection_result : {chunk_info_list}')
        overlapping_chunk_list = make_overlapping_chunk_list(text_chunk_list)
        page_text_dict = make_page_text_dict(raw_text)
        output_dict = make_output_dict(overlapping_chunk_list, page_text_dict)
        return output_dict
    
    elif method == 'uni':
        chunk_info_list, text_chunk_list = unidirectional_connection(splitted_data, graph_th_result)
        # print('connection_result :', chunk_info_list) # info log
        logger.info(f'connection_result : {chunk_info_list}')
        overlapping_chunk_list = make_overlapping_chunk_list(text_chunk_list)
        page_text_dict = make_page_text_dict(raw_text)
        output_dict = make_output_dict(overlapping_chunk_list, page_text_dict)
        return output_dict
    
    else:
        # print('Please check the method value.') # info log
        logger.info('Please check the method value.')
