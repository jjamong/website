import logging
import logging.handlers

# INFO_LOG_HOME_PATH = "/log/uda/engine"
# ERROR_LOG_HOME_PATH = "/log/uda/engine"

formatter = logging.Formatter('[%(name)s | %(asctime)s | %(levelname)s | %(filename)s | %(funcName)s | %(lineno)d] :: %(message)s')

# LOG_FILE_CNT = 30

# logger = logging.getLogger("uda")
# logger.setLevel(logging.INFO)
# info_handler = logging.handlers.TimeRotatingFileHandler(filename = INFO_LOG_HOME_PATH, backupCount = LOG_FILE_CNT, when = "midnight", interval = 1, encoding = "utf-8")
# info_handler.setFormatter(formatter)
# info_handler.suffix = "%Y-%m-%d"
# logger.addHandler(info_handler)
# stream_handler = logging.StreamHandler()
# logger.addHandler(stream_handler)

# error_logger = logging.getLogger("uda")
# error_logger.setLevel(logging.ERROR)
# error_handler = logging.handlers.TimeRotatingFileHandler(filename = ERROR_LOG_HOME_PATH, backupCount = LOG_FILE_CNT, when = "midnight", interval = 1, encoding = "utf-8")
# error_handler.setFormatter(formatter)
# error_handler.suffix = "%Y-%m-%d"
# error_logger.addHandler(error_handler)

logger = logging.getLogger("uda")
logger.setLevel(logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)

# error_logger = logging.getLogger("uda")
# error_logger.setLevel(logging.ERROR)
# error_stream_handler = logging.StreamHandler()
# error_stream_handler.setFormatter(formatter)
# error_logger.addHandler(error_stream_handler)