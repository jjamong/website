import re
import pickle
from call_db_api import get_regex_list
from utils.logger.python_logger import logger
##########################################################
# 비식별화 항목
# 주민등록번호(resident_num)     deid_data_id : 1
# 외국인등록번호(alien_num)      deid_data_id : 2
# 휴대폰번호(mobile_num)         deid_data_id : 3
# 유선전화번호(landline_num)     deid_data_id : 4
# 이메일(email)                  deid_data_id : 5
# 카드번호(card_num)             deid_data_id : 6
# 계좌번호(account_num)          deid_data_id : 7
# 여권번호(passport_num)         deid_data_id : 8
# 운전면허번호(driver_num)       deid_data_id : 9
# 주소(address)                  deid_data_id : 10
##########################################################


# regex_dict = dict()

# # 주민등록번호 - resident_num
# regular_expression_list = [r'(\d{2}([0]\d|[1][0-2])([0][1-9]|[1-2]\d|[3][0-1])[-\s]*[1-4]{1}\d{6})',
#                           r'\d{6}[-]?[1-4]\d{6}']

# regex_dict['resident_num'] = {'regex_list': regular_expression_list}

# # 외국인 등록번호 - alien_num
# regular_expression_list = [r'\d{6}[ -]?[5-8]\d{6}']

# regex_dict['alien_num'] = {'regex_list': regular_expression_list}

# # 휴대폰번호 - mobile_num
# regular_expression_list = [r'([0]([1][0]|[2]|[3456]{1}\d{1})\){1}[-\s]*\d{3,4}[-\s]*\d{4})',
#                            r'([0]([1][0]|[2]|[3456]{1}\d{1})[-\s]*\d{3,4}[-\s]*\d{4})',
#                            r'([0]([1][0]|[2]|[3456]{1}\d{1})[-\)\s]*\d{3,4}[-\s]*\d{4})',
#                            r'01[016789]-?\d{3,4}-?\d{4}']


# regular_expression_list = [r'([0]([1][0])[-\s]*\d{3,4}[-\s]*\d{4})',
#                            r'([0]([1][0])[-\)\s]*\d{3,4}[-\s]*\d{4})',
#                            r'01[016789]-?\d{3,4}-?\d{4}']

# regex_dict['mobile_num'] = {'regex_list': regular_expression_list}

# # 유선전화번호 - landline_num
# regular_expression_list = [r'0(2|[3-6][1-4])[-]?\d{3,4}[-]?\d{4}',
#                            r'([0]([2]|[3456]{1}\d{1})\){1}[-\s]*\d{3,4}[-\s]*\d{4})',
#                            r'([0]([2]|[3456]{1}\d{1})[-\s]*\d{3,4}[-\s]*\d{4})',
#                            r'([0]([2]|[3456]{1}\d{1})[-\)\s]*\d{3,4}[-\s]*\d{4})',
#                           ]
#                           # r'(\d{4}[-\s]*\d{4})']

# regex_dict['landline_num'] = {'regex_list': regular_expression_list}

# # 이메일 - email
# # regular_expression_list = [r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}',
# #                            r'((?!/)[a-zA-Z0-9+-\_.]+\s{0,1}@{0,1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)',
# #                            r'([a-zA-Z]{1}\s{0,1}[a-zA-Z0-9+-\_.\s]+\s{0,1}@{0,1}[a-zA-Z0-9-\s]+\s{0,1}\.[a-zA-Z0-9-.]+)',
# #                            r'((?!/)[a-zA-Z0-9+-\_.]+\s{0,1}@{0,1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)',
# #                            r'((?<=[/])[a-zA-Z0-9+-\_.\s]+\s{0,1}@{0,1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)']

# regular_expression_list = [r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
#                            r'((?!/)[a-zA-Z0-9+-\_.]+\s{0,1}@{1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)',
#                            r'([a-zA-Z]{1}\s{0,1}[a-zA-Z0-9+-\_.\s]+\s{0,1}@{1}[a-zA-Z0-9-\s]+\s{0,1}\.[a-zA-Z0-9-.]+)',
#                            r'((?!/)[a-zA-Z0-9+-\_.]+\s{0,1}@{1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)',
#                            r'((?<=[/])[a-zA-Z0-9+-\_.\s]+\s{0,1}@{1}[a-zA-Z0-9-]+\s{0,1}\.[a-zA-Z0-9-.]+)']

# regex_dict['email'] = {'regex_list': regular_expression_list}

# # 카드번호 - card_num
# regular_expression_list = [r'\d{4}-\d{4}-\d{4}-\d{4}',
#                           r'\d{4}[-\s]+\d{4}[-\s]+\d{4}[-\s]+\d{4}']

# regex_dict['card_num'] = {'regex_list': regular_expression_list}

# # 계좌번호 - account_num
# regular_expression_list = [r'(\d{3,6}[-\s]+(\d{2,7}[-\s]+){1,}(\d{2,7}))',
#                            r'([0-9]{3,7}[-\s]+([0-9]{2,8}[-\s]+){1,}([0-9]{2,8}))',
#                            r'([0]([1][0]|[2]|[3456]{1}\d{1})\d{3,4}[\s]+\d{4}[\s]+\d{,3})',
#                            r'\d{3}-\d{6}-\d{2}', # 기업은행 계좌번호
#                           ]# r'([0]\s?[0-9]\s{9,14})']

# regular_expression_list = [r'\b\d{3}[-\s]+\d{6}[-\s]+\d{2}[-\s]+\d{3}\b', # IBK기업 3-6-2-3
#                            r'\b\d{3}[-\s]+\d{2,3}[-\s]+\d{6}\b' # IBK기업 3-(2,3)-6
#                            r'\b\d{3}[-\s]+\d{2}[-\s]+\d{6}\b', # 우리,국민 등 3-2-6
#                            r'\b\d{3}[-\s]+\d{3}[-\s]+\d{6}\b', # 신한, 농협 등 3-3-6
#                            r'\b\d{3}[-\s]+\d{4}[-\s]+\d{4}[-\s]+\d{2}\b', # 농협 3-4-4-2
#                            r'\b\d{4}[-\s]+\d{4}[-\s]+\d{4}\b', # 농협 4-4-4
#                            r'\b\d{4}[-\s]+\d{2}[-\s]+\d{7}\b', # 카카오 4-2-7
                           
#                            r'\b\d{6}[-\s]+\d{2}[-\s]+\d{6}\b', # 하나, 새마을 금고 6-2-6
#                            r'\b\d{5,6}[-\s]+\d{6}\b', #우체국 (5,6)-6
#                            r'\b\d{3}[-\s]+\d{6}[-\s]+\d{2}\b', # 3-6-2
#                            r'\b\d{2}[-\s]+\d{2}[-\s]+\d{6}\b', # 2-2-6
#                            r'(\d{3,6}[-\s]+(\d{2,7}[-\s]+){1,}(\d{5,7}))',
#                            # r'\b\d{3}[-\s]+\d{6}\b', # 3-6
#                            # r'\b\d{4}[-\s]+\d{6}\b', # 4-6
#                            # r'\b(?:\d{2,4}-){1,3}\d{2,7}\b', # 숫자 하이픈 혼합 10~16자리
#                           ]# r'([0]\s?[0-9]\s{9,14})']

# # regular_expression_list = [r'(?<![-\d])(\d{3}[-\s]+\d{2,3}[-\s]+\d{6})(?![-\d])' # IBK기업 3-(2,3)-6
# #                            r'(?<![-\d])(\d{3}[-\s]+\d{2}[-\s]+\d{6})(?![-\d])', # 우리,국민 등 3-2-6
# #                            r'(?<![-\d])(\d{3}[-\s]+\d{3}[-\s]+\d{6})(?![-\d])', # 신한, 농협 등 3-3-6
# #                            r'(?<![-\d])(\d{3}[-\s]+\d{4}[-\s]+\d{4}[-\s]+\d{2})(?![-\d])', # 농협 3-4-4-2
# #                            r'(?<![-\d])(\d{4}[-\s]+\d{4}[-\s]+\d{4})(?![-\d])', # 농협 4-4-4
# #                            r'(?<![-\d])(\d{4}[-\s]+\d{2}[-\s]+\d{7})(?![-\d])', # 카카오 4-2-7
# #                            r'(?<![-\d])(\d{6}[-\s]+\d{2}[-\s]+\d{6})(?![-\d])' # 하나, 새마을 금고 6-2-6
# #                            r'(?<![-\d])(\d{5,6}[-\s]+\d{6})(?![-\d])' #우체국 (5,6)-6
# #                            r'(?<![-\d])(\d{3}[-\s]+\d{6}[-\s]+\d{2})(?![-\d])', # 3-6-2
# #                            r'(?<![-\d])(\d{2}[-\s]+\d{2}[-\s]+\d{6})(?![-\d])', # 2-2-6
# #                            r'(?<![-\d])(\d{3}[-\s]+\d{6})(?![-\d])', # 3-6
# #                            r'(?<![-\d])(\d{4}[-\s]+\d{6})(?![-\d])', # 4-6
# #                            r'(?<![-\d])((?:\d{2,4}-){1,3}\d{2,7})(?![-\d])', # 숫자 하이픈 혼합 10~16자리
# #                           ]# r'([0]\s?[0-9]\s{9,14})']


# # regular_expression_list = [r'(?<![-\d])\d{3}[-\s]+\d{2,3}[-\s]+\d{6}(?![-\d])' # IBK기업 3-(2,3)-6
# #                            r'(?<![-\d])\d{3}[-\s]+\d{2}[-\s]+\d{6}(?![-\d])', # 우리,국민 등 3-2-6
# #                            r'(?<![-\d])\d{3}[-\s]+\d{3}[-\s]+\d{6}(?![-\d])', # 신한, 농협 등 3-3-6
# #                            r'(?<![-\d])\d{3}[-\s]+\d{4}[-\s]+\d{4}[-\s]+\d{2}(?![-\d])', # 농협 3-4-4-2
# #                            r'(?<![-\d])\d{4}[-\s]+\d{4}[-\s]+\d{4}(?![-\d])', # 농협 4-4-4
# #                            r'(?<![-\d])\d{4}[-\s]+\d{2}[-\s]+\d{7}(?![-\d])', # 카카오 4-2-7
# #                            r'(?<![-\d])\d{6}[-\s]+\d{2}[-\s]+\d{6}(?![-\d])' # 하나, 새마을 금고 6-2-6
# #                            r'(?<![-\d])\d{5,6}[-\s]+\d{6}(?![-\d])' #우체국 (5,6)-6
# #                            r'(?<![-\d])\d{3}[-\s]+\d{6}[-\s]+\d{2}(?![-\d])', # 3-6-2
# #                            r'(?<![-\d])\d{2}[-\s]+\d{2}[-\s]+\d{6}(?![-\d])', # 2-2-6
# #                            r'(?<![-\d])\d{3}[-\s]+\d{6}(?![-\d])', # 3-6
# #                            r'(?<![-\d])\d{4}[-\s]+\d{6}(?![-\d])', # 4-6
# #                            r'(?<![-\d])(?:\d{2,4}-){1,3}\d{2,7}(?![-\d])', # 숫자 하이픈 혼합 10~16자리
# #                           ]# r'([0]\s?[0-9]\s{9,14})']

# regular_expression_list = [
#                            r'\b\d{3}[-\s]+\d{6}[-\s]+\d{2}[-\s]+\d{3}\b', # IBK기업 3-6-2-3
#                            r'\d{3}[-\s]+\d{2,3}[-\s]+\d{6}', # IBK기업 3-(2,3)-6
#                            r'\d{3}[-\s]+\d{2}[-\s]+\d{6}', # 우리,국민 등 3-2-6
#                            r'\b\d{3}[-\s]+\d{3}[-\s]+\d{6}\b', # 신한, 농협 등 3-3-6
#                            r'\b\d{3}[-\s]+\d{4}[-\s]+\d{4}[-\s]+\d{2}\b', # 농협 3-4-4-2
#                            r'(?<![-\d])\d{4}[-\s]+\d{4}[-\s]+\d{4}(?![-\d])', # 농협 4-4-4
#                            r'\b\d{4}[-\s]+\d{2}[-\s]+\d{7}\b', # 카카오 4-2-7
#                            r'\b\d{6}[-\s]+\d{2}[-\s]+\d{6}\b', # 하나, 새마을 금고 6-2-6
#                            r'\b\d{5,6}[-\s]+\d{6}\b', #우체국 (5,6)-6
#                            r'(?<![-\d])\d{3}[-\s]+\d{6}[-\s]+\d{2}(?![-\d])', # 3-6-2
#                            r'(?<![-\d])\d{2}[-\s]+\d{2}[-\s]+\d{6}(?![-\d])', # 2-2-6
#                            r'(\d{3,6}[-\s]+(\d{2,7}[-\s]+){1,}(\d{5,7}))',
#                            # r'\b\d{3}[-\s]+\d{6}\b', # 3-6
#                            # r'\b\d{4}[-\s]+\d{6}\b', # 4-6
#                            # r'\b(?:\d{2,4}-){1,3}\d{2,7}\b', # 숫자 하이픈 혼합 10~16자리
#                           ]# r'([0]\s?[0-9]\s{9,14})']

# regex_dict['account_num'] = {'regex_list': regular_expression_list}



# # 여권번호 - passport_num
# regular_expression_list = [r'([MSGRDE]\d{8}|[A-Z]{2}\d{7})']

# regex_dict['passport_num'] = {'regex_list': regular_expression_list}

# # 운전면허번호 - driver_num
# regular_expression_list = [r'\d{2}-\d{2}-\d{6}-\d{2}',
#                           r'\d{2}[-\s]+\d{2}[-\s]+\d{6}[-\s]+\d{2}',
#                           r'\d{2}[-\s]+\d{2}[-\s]+\d{6}(?:-\d{2})?',
#                           r'\d{2}[-\s]+\d{6}[-\s]+\d{2}']

# regex_dict['driver_num'] = {'regex_list': regular_expression_list}



# # 주소 - address
# regular_expression_list = [# r'(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)[^\n]{1,30}(로|길|동|읍|면|리|가)',
#                           r'([\w가-힣]+(로|길|가|대로|거리)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:층)\s?\d{1,4}(?:호실|호))',
#                           r'([\w가-힣]+(로|길|가|대로|거리)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:호실|호|층))',
#                           r'([\w가-힣]+(동|읍|면|리|군)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:층)\s?\d{1,4}(?:호실|호))',
#                           r'([\w가-힣]+(동|읍|면|리|군)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:호실|호|층))',]

# regular_expression_list = [# r'(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)[^\n]{1,30}(로|길|동|읍|면|리|가)',
#                           r'([\w가-힣]+((?<!으)로|길|가|대로|거리)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:층)\s?(?<!제\s)(?<!제)(?<!각\s)(?<!각)(?<!항\s)(?<!항)\d{1,4}(?:호실|호))',
#                           r'([\w가-힣]+((?<!으)로|길|가|대로|거리)\s+[\w가-힣A-Za-z\-.,\( ]*?(?<!제\s)(?<!제)(?<!각\s)(?<!각)(?<!항\s)(?<!항)\d{1,4}(?:호실|호|층))',
#                           r'([\w가-힣]+(동|읍|면|리|군)\s+[\w가-힣A-Za-z\-.,\( ]*?\d{1,4}(?:층)\s?(?<!제\s)(?<!제)(?<!각\s)(?<!각)(?<!항\s)(?<!항)\d{1,4}(?:호실|호))',
#                           r'([\w가-힣]+(동|읍|면|리|군)\s+[\w가-힣A-Za-z\-.,\( ]*?(?<!제\s)(?<!제)(?<!각\s)(?<!각)(?<!항\s)(?<!항)\d{1,4}(?:호실|호|층))',]
# regex_dict['address'] = {'regex_list': regular_expression_list}


# pickle.dump(regex_dict, open('./personal_regex_dict.pkl','wb'))

def mask_partial(text, regex_list, key, mask_char='*'):
    match_cnt = 0
    def mask_func_visible_chars(m):
        s = m.group()
        total = len(s)
        if total <= first + last:
            return mask_char * total
        return s[:first]+ mask_char *(total-first-last) + s[-last:] if last > 0 else s[:first] + mask_char * (total-first)

    def mask_func_masked_chars(m):
        s = m.group()
        total = len(s)
        if total <= first + last:
            return mask_char * total
        return mask_char * first + s[first:total-last]+ mask_char * last
    
    def mask_func_position(m):
        s = m.group()
        total = len(s)
        replace_text = ''
        for ci, char in enumerate(s):
            if ci in mask_position:
                replace_text += mask_char
            else:
                replace_text += char
        mask_cnt = replace_text.count('*')
        if mask_cnt < len(mask_position) :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        # return s[:first]+ mask_char *(total-first-last) + s[-last:] if last > 0 else s[:first] + mask_char * (total-first)
        return replace_text

    def mask_func_phone(m):
        s = m.group()
        total = len(s)
        split_list = re.split(r'[-\s]+', s)

        if len(split_list) < 2 :
            if s[0] == '0':
                return s[:int(total)//2] + mask_char * (total-int(total)//2)
            else:
                return s
                
        if '-' in s:
            join_char = '-'
        else:
            join_char = ' '

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = split
            elif si in [1]:
                replace_text += join_char + mask_char*len(split)
            else:
                replace_text += join_char + split
        
        mask_cnt = replace_text.count('*')
        if mask_cnt < 3 :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        return replace_text

    def mask_func_card_num(m):
        s = m.group()
        total = len(s)
        split_list = re.split(r'[-\s]+', s)

        if len(split_list) < 2 :
            return s
            
        if '-' in s:
            join_char = '-'
        else:
            join_char = ' '

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = split
            elif si in [1]:
                replace_text += join_char + split[:2]+mask_char*(len(split)-2)
            elif si in [2]:
                replace_text += join_char + mask_char*len(split)
            else:
                replace_text += join_char + split
        
        mask_cnt = replace_text.count('*')
        if mask_cnt < 6 :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        return replace_text

    def mask_func_account_num(m):
        s = m.group()
        total = len(s)
        split_list = re.split(r'[-\s]+', s)

        if len(split_list) < 2 :
            return s
            
        if '-' in s:
            join_char = '-'
        else:
            join_char = ' '

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = split
            elif si in [1]:
                replace_text += join_char + split[:-2]+mask_char*(2)
            else:
                replace_text += join_char + mask_char*len(split)
        
        mask_cnt = replace_text.count('*')
        if mask_cnt < 5 :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        return replace_text

    def mask_func_email(m):
        s = m.group()
        total = len(s)
        split_list = s.split('@')

        if len(split_list) < 2 :
            return s

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = split[:2] + mask_char*(len(split)-2)
            else:
                replace_text += '@' + split
        
        mask_cnt = replace_text.count('*')
        if mask_cnt < 2 :
            return  mask_char * (total-int(total)//2) + s[int(total)//2:]
        return replace_text

    def mask_func_driver_num(m):
        s = m.group()
        total = len(s)
        split_list = re.split(r'[-\s]+', s)

        if len(split_list) < 2 :
            return s
            
        if '-' in s:
            join_char = '-'
        else:
            join_char = ' '

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = split[:-1]+mask_char
            elif si == len(split_list)-1:
                replace_text += join_char + mask_char + split[-1]
            elif 5 < len(split):
                replace_text += join_char + split[:(len(split)-2)] + mask_char*2
            else:
                replace_text += join_char + split
        
        mask_cnt = replace_text.count('*')
        if mask_cnt < 3 :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        return replace_text

    def mask_func_address(m):
        s = m.group()
        total = len(s)
        split_list = re.split(r'[\s]+', s)

        if len(split_list) < 2 :
            return s

        replace_text = ''
        for si, split in enumerate(split_list):
            if si == 0 :
                replace_text = mask_char*(len(split)-1) + split[-1]
            elif re.search(r'\d',split):
                replace_text += ' ' + re.sub(r'\d', mask_char, split)
            else:
                replace_text += ' ' + mask_char*len(split)
                
        mask_cnt = replace_text.count('*')
        if mask_cnt < 5 :
            return s[:int(total)//2] + mask_char * (total-int(total)//2)
        return replace_text

    # ['resident_num', 'mobile_num', 'landline_num', 'email', 'account_num', 'card_num', 'passport_num', 'driver_num', 'alien_num', 'address']
    # if key in ['resident_num']: # from file
    if key in [1]:
        first = 0
        last = 6
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_masked_chars, text)
            
    # elif key in ['passport_num']: # from file
    elif key in [8]:
        mask_position = [1,6,7,8]
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_position, text)   

    # elif key in ['alien_num']: # from file
    elif key in [2]:
        first = 7
        last = 0
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_visible_chars, text)  
    
    # elif key in ['mobile_num', 'landline_num']: # from file
    elif key in [3, 4]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_phone, text)

    # elif key in ['email']: # from file
    elif key in [5]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_email, text)

    # elif key in ['account_num']: # from file
    elif key in [7]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_account_num, text)
            
    # elif key in ['card_num']: # from file
    elif key in [6]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_card_num, text)    

    # elif key in ['driver_num']: # from file
    elif key in [9]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_driver_num, text) 
            
    # elif key in ['address']: # from file
    elif key in [10]:
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_address, text)
    else:
        first = 0
        last = 10
        for pattern in regex_list:
            match_cnt += len(re.findall(pattern, text))
            text = re.sub(pattern, mask_func_masked_chars, text)
    return text, match_cnt

def masking_personal_text(text, key_list=[]):
    # regex_dict = pickle.load(open('./utils/masking/personal_regex_dict.pkl', 'rb')) # from file
    regex_dict = get_regex_dict()
    count_dict = dict()
    if not key_list:
        key_list = list(regex_dict.keys())
        
    for key in key_list:
        dict_ = regex_dict[key]
        regex_list = dict_['regex_list']
        text, cnt = mask_partial(text, regex_list, key)
        if key not in count_dict:
            count_dict[key] = cnt
        else:
            count_dict[key] += cnt
    return text, count_dict

def is_overlapping_info(start, end, spans):
    for s, e in spans:
        if not (end <= s or start >= e):
            return True
    return False

def normalize_db_regex(pat):
    pat = pat.replace("\u20A9", "\u005C")
    pat = re.sub(r"\\{2,}", r"\\", pat)
    # pat = pat.replace("\)", ")").replace("\(", "(").replace("\-", "-")
    return pat

def get_regex_dict():
    
    regex_dict = {}
    res = get_regex_list()
    for row in res:
        deid_data_id = row["deidDataId"]
        # regex_pattern = row["regexPattern"].replace("\\\\", "\\")
        regex_pattern = normalize_db_regex(row["regexPattern"])
        if deid_data_id not in regex_dict:
            regex_dict[deid_data_id] = {"regex_list": [regex_pattern]}
        else:
            regex_dict[deid_data_id]["regex_list"].append(regex_pattern)

    return regex_dict

def detect_personal_info(text, key_list = []):
    # regex_dict = pickle.load(open('./utils/masking/personal_regex_dict.pkl', 'rb')) # from file
    regex_dict = get_regex_dict()
    
    personal_info = list()
    matched_spans = list()
    be_list = list()
    if not key_list:
        key_list = list(regex_dict.keys())

    for key in key_list:
        dict_ = regex_dict[key]
        regex_list = dict_['regex_list']
        try:
            # print(f"\n[Key : {key}]")
            for pattern in regex_list:
                # print(f"[Pattern: {pattern}]")
                for match in re.finditer(pattern, text):
                    start = match.start()
                    end = match.end()
                    if not is_overlapping_info(start, end, matched_spans):
                        matched_spans.append((start,end))
                        # print(f"Match : {match.group()} | Start : {start} | End : {end}")
                        be_list.append({'type':key, 'start':start, 'end':end})
                    
            text, cnt = mask_partial(text, regex_list, key)
        except Exception as e:
            logger.info(f"An error occurred because one of th regular expressions associated with the stored key '{key}' is invalid.")
            continue
            
    return text, be_list

# text = """이름 : 김창근
# 주민등록번호 : 890716-1232847
# 외국인등록번호 : 900101-5123456
# 여권번호 : M12345678
# 운전면허번호 : 11-21-126548-12
# 카드번호 : 1234-5678-9012-3456
# 핸드폰번호 : 010-6206-0000
# 집전화 : 031-257-1234
# 주소 : 서울특별시 강남구 성수2가 3동 123-45 현대아파트 101동 101호'
# 이메일 : changgeun.kim@quantum-ai.ai
# 계좌번호 : 127-02-246691
# 계좌번호 : 422-123456-01-234
# 회사 주소 :
# 서울특별시 중구 퇴계로 186 쌍림빌딩 9층
# """
# masked_text, count_dict = masking_personal_text(text, ['account_num'])
# masked_text, count_dict = masking_personal_text(text)

# print('@'*50)
# print(masked_text)
# print('@'*50)
# print(count_dict)





