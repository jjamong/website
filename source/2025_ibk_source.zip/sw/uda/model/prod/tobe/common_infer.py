import pypdfium2 as pdfium
import numpy as np
import matplotlib.pyplot as plt
import re
import time
import sys
import os
import json
from glob import glob
from functools import reduce
import pickle
import copy

from konlpy.tag import Mecab

import tensorflow as tf

from utils.chunking.overapping_func import *
from utils.logger.python_logger import logger
import temp_make_text as tmt

from call_db_api import get_special_symbols

mecab = Mecab(dicpath = '/app/anaconda3/mecab/mecab-ko-dic-2.1.1-20180720')

# chinese_chars = pickle.load(open("new_unique_chinese_char_list.tlp", "rb")) # from file
# special_chars = pickle.load(open("new_unique_special_char_list.tlp", "rb")) # from file
SC = get_special_symbols()

kl = tf.keras.losses.KLDivergence()

def make_path(path):

    replaces = ('\\', '/'), ('', '')
    
    return reduce(lambda p, rpls: p.replace(*rpls), replaces, path)

def find_files(directory, pattern = '**/*.pdf'):

    files = sorted(glob(os.path.join(directory, pattern), recursive = True))
        
    return [make_path(file) for file in files]

# nutize2 card for <td>, </td>
def nutize2(chr_sequence, SC = SC):
    
    """ How to handle special chracters? Need to add it. """
    # chr(26) : substitute character -> '^' for special characters
    # SC = tuple()
    # SC = chinese_chars + special_chars
    SC = [ord(char) for char in SC]
    chr_sequence = ''.join([c if (ord(c) in (10, 13)) or (32 <= ord(c) <= 128) or (0xAC00 <= ord(c) <= 0xD7A3) or (ord(c) in SC) else chr(26) for c in chr_sequence])
    chr_sequence = re.sub('(\x1a){2,}', '\x1a', chr_sequence)

    
    # step 1 : control nut
    chr_sequence = chr_sequence.replace(' ', chr(18)).replace('_', chr(5)).replace('\r', chr(20)).replace('\n', chr(25))
    
    # step 1-1 : quantum ai morpheme
    # <td>, </td> replace other chars
    chr_sequence = chr_sequence.replace("<td>", "\u3FFD").replace("</td>", "\u493F")
    
    # step 2 : nut <- mecab <- korean 
    wrd_sequence = mecab.morphs(chr_sequence)
    
    # step 3 : ascii sequence -> character
    
    nuts = list()
    for w in wrd_sequence:

        if w not in ["\u3FFD", "\u493F"]:
            if w.isascii():
                nuts.extend(list(w))
            else:
                nuts.append(w)
        else:
            if w == "\u3FFD":
                nuts.append("<td>")
            elif w == "\u493F":
                nuts.append("</td>")
            # add replacement 
            else:
                nuts.append("")
    
    return nuts

def nutize2_old(chr_sequence):
    
    """ How to handle special chracters? Need to add it. """
    # chr(26) : substitute character -> '^' for special characters
    # SC = tuple()
    SC = chinese_chars + special_chars
    SC = [ord(char) for char in SC]
    chr_sequence = ''.join([c if (ord(c) in (10, 13)) or (32 <= ord(c) <= 128) or (0xAC00 <= ord(c) <= 0xD7A3) or (ord(c) in SC) else chr(26) for c in chr_sequence])
    chr_sequence = re.sub('(\x1a){2,}', '\x1a', chr_sequence)

    
    # step 1 : control nut
    chr_sequence = chr_sequence.replace(' ', chr(18)).replace('_', chr(5)).replace('\r', chr(20)).replace('\n', chr(25))
    
    # step 1-1 : quantum ai morpheme
    
    # step 2 : nut <- mecab <- korean 
    wrd_sequence = mecab.morphs(chr_sequence)
    
    # step 3 : ascii sequence -> character
    
    nuts = list()
    for w in wrd_sequence:
        
        if w.isascii():
            nuts.extend(list(w))
        else:
            nuts.append(w)
    
    return nuts

def nutcracker(nuts):

    ctrl_nut = [chr(1), chr(2), chr(5), chr(18), chr(20), chr(25)]
    
    trail_nuts = list()
    
    # check starting nut
    if nuts[0].isascii():
        trail_nuts.append(nuts[0])
    elif len(nuts) > 1:
        if nuts[1] in ctrl_nut:
            trail_nuts.append(nuts[0])
        elif nuts[1] not in ctrl_nut:
            trail_nuts.append(nuts[0] + '_')
    
    for pos in range(1, len(nuts) - 1):
    
        if nuts[pos].isascii():
            trail_nuts.append(nuts[pos])
        else:
            trail_nut = str()
            if nuts[pos - 1].isascii() and nuts[pos + 1].isascii(): 
                
                if nuts[pos - 1] in ctrl_nut and nuts[pos + 1] in ctrl_nut:
                    trail_nut = nuts[pos] 
                elif nuts[pos - 1] in ctrl_nut and nuts[pos + 1] not in ctrl_nut:
                    trail_nut = nuts[pos] + '_'
                elif nuts[pos - 1] not in ctrl_nut and nuts[pos + 1] in ctrl_nut:
                    trail_nut = '_' + nuts[pos] 
                elif nuts[pos - 1] not in ctrl_nut and nuts[pos + 1] not in ctrl_nut:
                    trail_nut = '_' + nuts[pos] + '_'
                    
            elif nuts[pos - 1].isascii() and not nuts[pos + 1].isascii(): 
                trail_nut= nuts[pos] + '_'
            elif not nuts[pos - 1].isascii() and nuts[pos + 1].isascii(): 
                trail_nut = '_' + nuts[pos]
            elif not nuts[pos - 1].isascii() and not nuts[pos + 1].isascii(): 
                trail_nut = '_' + nuts[pos] + '_'
        
            trail_nuts.append(trail_nut)
                
    # check ending nut
    if nuts[-1].isascii() and len(nuts) > 1:
        trail_nuts.append(nuts[-1])
    elif len(nuts) > 1:
        if nuts[-2] in ctrl_nut:
            trail_nuts.append(nuts[-1])
        elif nuts[-2] not in ctrl_nut:
            trail_nuts.append('_' + nuts[-1])
    elif not nuts[-1].isascii():
        trail_nuts.append(nuts[-1])

    return trail_nuts

# only txt file
def get_document_nuts(contents):

    total_txt = contents
    
    page_txt = []
    for page in total_txt.split("\n\n</page>\n\n"):
    # for page in total_txt.split("\n</page>"):
    # for page in total_txt.split("</page>"):    
        if page.strip():
            page_txt.append(re.sub("<page num='[0-9]+'>\n\n", "", page))
            # page_txt.append(re.sub("<page num='[0-9]+'>\n", "", page))

    doc = str()
    n_pages = len(page_txt)
    for txt in page_txt:
        ctxt = re.sub(r" ?\\r\\n ?", "\r\n", txt)        
        ctxt = re.sub("(\r\n){2,}", "\r\n", ctxt)

        # check page start and end
        if ctxt[:2] != "\r\n":
            # print("!!!")
            ctxt = "\r\n" + ctxt

        if ctxt[-2:] != "\r\n":
            # print("!!!")
            ctxt = ctxt + "\r\n"
            
        ctxt = re.sub("\r\n", " \r\n ", ctxt)
        ctxt = re.sub(" {2,}", " ", ctxt)
        doc += ctxt# + chr(20) + chr(25)

        # print(repr(doc))
        # print(repr(ctxt))
        # print("-" * 10)
    
    doc = doc.replace('<td>','').replace('</td>',' ') #######################
    
    if len(doc) > 6400:
        nuts = []
        frames = len(doc) // 6400
        # print(frames)
        
        positions = list(range(6400, len(doc), 6400)) + [len(doc)]
        # print(positions)
        
        # texts = list()
        spos = 0
        for epos in positions:
            # print(spos, epos)
            if epos < len(doc):
                for p in range(epos, len(doc), 1):
                    # if document[p] == chr(20) and document[p + 1] == chr(25):
                    if doc[p] == '\r' and doc[p + 1] == '\n':
                        # print(p, spos, epos, doc[p])
                        # texts.append(doc[spos:(p + 2)])
                        nuts_ = nutize2(doc[spos:(p + 2)])
                        nuts.extend(nuts_)
                        spos = p + 2
                        break
            else:
                # print("=" * 10)
                # print(doc[spos:epos])
                nuts_ = nutize2(doc[spos:epos])
                nuts.extend(nuts_)
                
    else:
        # 2025/05/26 업무메뉴얼
        if len(doc) < 1:
            #print('Info: check file - null document %d - return chr(12).' % len(doc), file)
            doc = chr(12) # page spliter        
            
        nuts = nutize2(doc)    
        
    return nuts, total_txt, n_pages

def get_document_nuts_old(file):

    ext = os.path.splitext(file)[-1].lower()
    if ext == ".pdf":
        pdf = pdfium.PdfDocument(file)
        
        doc, total_txt = str(), str()
        n_pages = len(pdf)
        for i, page in enumerate(pdf):
            
            textpage = page.get_textpage()
            text = textpage.get_text_range()
            doc += text + chr(20) + chr(25)
    
            total_txt += f"<page num='{i+1}'>\n\n" + text + "\n\n</page>\n\n"
            
        # print(total_txt)
        # print(len(doc), file)

    elif ext == ".hwp":
        doc_text = tmt.v5hConverter(file, min_record = 2)
        
        doc, total_txt = str(), str()
        n_pages = len(doc_text)
        for i, dt in enumerate(doc_text):
            total_txt += f"<page num='{i+1}'>\n\n" + dt + "\n\n</page>\n\n"
            doc += dt

        # print(total_txt)

    elif ext == ".txt":
        with open(file, "r", encoding = "UTF-8", newline = '') as f:
            total_txt = f.read()
    
        page_txt = []
        for page in total_txt.split("\n\n</page>\n\n"):
        # for page in total_txt.split("\n</page>"):
        # for page in total_txt.split("</page>"):    
            if page.strip():
                page_txt.append(re.sub("<page num='[0-9]+'>\n\n", "", page))
                # page_txt.append(re.sub("<page num='[0-9]+'>\n", "", page))
    
        doc = str()
        n_pages = len(page_txt)
        for txt in page_txt:
            ctxt = re.sub(r" ?\\r\\n ?", "\r\n", txt)        
            ctxt = re.sub("(\r\n){2,}", "\r\n", ctxt)
    
            # check page start and end
            if ctxt[:2] != "\r\n":
                # print("!!!")
                ctxt = "\r\n" + ctxt
    
            if ctxt[-2:] != "\r\n":
                # print("!!!")
                ctxt = ctxt + "\r\n"
                
            ctxt = re.sub("\r\n", " \r\n ", ctxt)
            ctxt = re.sub(" {2,}", " ", ctxt)
            doc += ctxt# + chr(20) + chr(25)
    
            # print(repr(doc))
            # print(repr(ctxt))
            # print("-" * 10)
    
    doc = doc.replace('<td>','').replace('</td>',' ') #######################
    
    if len(doc) > 6400:
        nuts = []
        frames = len(doc) // 6400
        # print(frames)
        
        positions = list(range(6400, len(doc), 6400)) + [len(doc)]
        # print(positions)
        
        # texts = list()
        spos = 0
        for epos in positions:
            # print(spos, epos)
            if epos < len(doc):
                for p in range(epos, len(doc), 1):
                    # if document[p] == chr(20) and document[p + 1] == chr(25):
                    if doc[p] == '\r' and doc[p + 1] == '\n':
                        # print(p, spos, epos, doc[p])
                        # texts.append(doc[spos:(p + 2)])
                        nuts_ = nutize2(doc[spos:(p + 2)])
                        nuts.extend(nuts_)
                        spos = p + 2
                        break
            else:
                # print("=" * 10)
                # print(doc[spos:epos])
                nuts_ = nutize2(doc[spos:epos])
                nuts.extend(nuts_)
                
    else:
        # 2025/05/26 업무메뉴얼
        if len(doc) < 1:
            #print('Info: check file - null document %d - return chr(12).' % len(doc), file)
            doc = chr(12) # page spliter
            
        nuts = nutize2(doc)    
        
    return nuts, total_txt, n_pages

def get_splits(nuts, split_len, num_trail_nut = 0):
    splits = list()
    for pos in range(0, len(nuts), split_len - num_trail_nut):
        # split = ''.join(nuts[pos:(pos + split_len)])
        split = nuts[pos:(pos + split_len)]
        splits.append(split)

    last_sent_len = len(splits[-1])
    if last_sent_len < split_len:
        splits[-1] = splits[-1] + [''] * (split_len - last_sent_len)
    
    return splits

def get_sentence_distns(model, test_dataset):
    target_distns = list()
    for inputs, _ in test_dataset:
        _, embeded_distn = model.predict(inputs, verbose = 0)
        nuts_distn = tf.nn.softmax(embeded_distn, axis = -1)        
        target_distns.append(nuts_distn)

    return target_distns

def one_step_chunking(sentence_distns, base_idx, verbose = False):

    base_sentence_distn = sentence_distns[base_idx]
    # print(base_sentence_distn)

    results = list()
    for idx, target_distn in enumerate(sentence_distns):

        # kl_divergence = tf.reduce_sum(base_distn * tf.math.log(base_distn / target_distn)).numpy()
        kl_divergence = kl(base_sentence_distn, target_distn).numpy()
        results.append(kl_divergence)
        
        # print(idx, kl_divergence)
    
    order = np.argsort(results)
    if verbose:
        # print(order[:5])
        logger.info(order[:5])
        # print(np.sort(results)[:5])

    return order[:5]

# def make_chunk_ci(path, obj_dir, nuts, txt, n_pages, splitted_data, sentences, sentence_distns):

#     if n_pages < 50:
        
#         if not nuts:
#             filename = os.path.splitext(path.split("/")[-1])[0]
#             qt_chunk_dict = {}
#             json.dump(qt_chunk_dict, open("/".join([obj_dir, filename + ".json"]), "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)
            
#             return qt_chunk_dict, [], n_pages, "/".join([obj_dir, filename + ".json"])
            
#         sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns])
        
#         chunked = []
#         for idx in range(len(sentences)):
#             order = one_step_chunking(sentence_distns, idx, verbose = True)
#             chunked.append(order.tolist())
    
#         # print("111111111", splitted_data)
#         qt_chunk_dict = qt_chunking_output(splitted_data, chunked, txt, len(nuts), sentence_distns_)
#         # qt_chunk_dict = qt_chunking_output___(splitted_data, chunked, txt)
    
#         filename = os.path.splitext(path.split("/")[-1])[0]
        
#         # page error check
#         pages = [row["page"] for row in qt_chunk_dict["data"]]
#         if 999999 in pages:
#             json.dump(qt_chunk_dict, open("/".join([obj_dir, filename + "_e.json"]), "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)
#         else:
#             json.dump(qt_chunk_dict, open("/".join([obj_dir, filename + ".json"]), "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)
            
#     return qt_chunk_dict, chunked, n_pages, "/".join([obj_dir, filename + ".json"])

#####
def get_document_nuts_page(page_txt):
    
    doc = str()
    n_pages = len(page_txt)
    for txt in page_txt:
        ctxt = re.sub(r" ?\\r\\n ?", "\r\n", txt)        
        ctxt = re.sub("(\r\n){2,}", "\r\n", ctxt)

        # check page start and end
        if ctxt[:2] != "\r\n":
            # print("!!!")
            ctxt = "\r\n" + ctxt

        if ctxt[-2:] != "\r\n":
            # print("!!!")
            ctxt = ctxt + "\r\n"
            
        ctxt = re.sub("\r\n", " \r\n ", ctxt)
        ctxt = re.sub(" {2,}", " ", ctxt)
        doc += ctxt# + chr(20) + chr(25)

        # print(repr(doc))
        # print(repr(ctxt))
        # print("-" * 10)

    if len(doc) > 6400:
        nuts = []
        frames = len(doc) // 6400
        # print(frames)
        
        positions = list(range(6400, len(doc), 6400)) + [len(doc)]
        # print(positions)
        
        # texts = list()
        spos = 0
        for epos in positions:
            # print(spos, epos)
            if epos < len(doc):
                for p in range(epos, len(doc), 1):
                    # if document[p] == chr(20) and document[p + 1] == chr(25):
                    if doc[p] == '\r' and doc[p + 1] == '\n':
                        # print(p, spos, epos, doc[p])
                        # texts.append(doc[spos:(p + 2)])
                        nuts_ = nutize2(doc[spos:(p + 2)])
                        nuts.extend(nuts_)
                        spos = p + 2
                        break
            else:
                # print("=" * 10)
                # print(doc[spos:epos])
                nuts_ = nutize2(doc[spos:epos])
                nuts.extend(nuts_)
                
    else:
        # 2025/05/26 업무메뉴얼
        if len(doc) < 1:
            #print('Info: check file - null document %d - return chr(12).' % len(doc), file)
            doc = chr(12) # page spliter
            
        nuts = nutize2(doc)    
    
    return nuts

def prcess_and_concatenate(lists):
    result = list()
    increment = 0

    for lst in lists:
        modified = list()
        for sub in lst:
            if len(sub) < 5:
                sub_ = sub + [sub[0]] * (5 - len(sub))
                modified.append([x + increment for x in sub_])
            else:
                modified.append([x + increment for x in sub])

        result.extend(modified)

        increment += lst[-1][0] + 1

    return result

# def make_chunk_ci_page(path, obj_dir, nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total):#, split_len = 95, num_trail_nut = 0):

#     # nuts_total, total_txt, n_pages, splitted_data_total, chunked_total, sentence_distns_total = make_chunk_page(path)
#     sentence_distns_ = np.array([distn[0].numpy() for distn in sentence_distns_total])
#     chunked_cc = prcess_and_concatenate(chunked_total)
    
#     qt_chunk_dict = qt_chunking_output(splitted_data_total, chunked_cc, total_txt, len(nuts_total), sentence_distns_)
    
#     filename = os.path.splitext(path.split("/")[-1])[0]
    
#     # page error check
#     pages = [row["page"] for row in qt_chunk_dict["data"]]
#     if 999999 in pages:
#         json.dump(qt_chunk_dict, open("/".join([obj_dir, filename + "_e.json"]), "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)
#     else:
#         json.dump(qt_chunk_dict, open("/".join([obj_dir, filename + ".json"]), "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)


#     return qt_chunk_dict, chunked_cc, n_pages, "/".join([obj_dir, filename + ".json"])
