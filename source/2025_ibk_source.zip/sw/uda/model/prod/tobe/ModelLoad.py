import pickle
import configparser

config = configparser.ConfigParser()
config.read("model_config.ini")
infer_config = config["INFER"]

import tensorflow as tf

from tensorflow.keras import Model
from tensorflow.keras import Sequential
from tensorflow.keras import layers
from tensorflow.keras import activations
from tensorflow.keras import initializers

from tensorflow.python.ops import math_ops
from tensorflow.python.ops import special_math_ops
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import array_ops_stack
from tensorflow.python.ops import nn_ops

import onSite_20250606_infer as o

class ModelLoad():
    
    def __init__(self, unique_nuts_path, weights_path, model_name):
                
        self.unique_nuts_path = unique_nuts_path
        self.weights_path = weights_path
        self.model_name = model_name

        self.num_layers = infer_config.getint("num_layers")
        self.d_model = infer_config.getint("d_model")
        self.num_members = infer_config.getint("num_members")
        self.heads = infer_config.getint("heads")
        self.dropout_rate = infer_config.getfloat("dropout_rate")    
        self.seq_len = infer_config.getint("seq_len")

        _, _ = self.get_nuts_vocab()
    
    def get_unique_nuts(self):
        sorted_nuts, unique_nuts = pickle.load(open(self.unique_nuts_path, "rb"))

        return sorted_nuts, unique_nuts

    def get_nuts_vocab(self):
        
        _, unique_nuts = self.get_unique_nuts()
        self.vocab_size = len(unique_nuts) + 2
        print('vocab size', self.vocab_size)
        
        self.nut_to_idx = tf.keras.layers.StringLookup(
            vocabulary = unique_nuts, num_oov_indices = 1, mask_token = '', oov_token = chr(0),
        )
        
        self.idx_to_nut = tf.keras.layers.StringLookup(
            vocabulary = self.nut_to_idx.get_vocabulary(), invert = True,  num_oov_indices = 1, mask_token = '', oov_token = chr(0)
        )
        
        print('# of nuts :', len(self.nut_to_idx.get_vocabulary()), len(unique_nuts))
        
        self.NUTS_DISTRIBUTION_LENGTH = len(self.nut_to_idx.get_vocabulary())

        print(self.nut_to_idx.get_vocabulary()[:20])
        print(self.nut_to_idx.get_vocabulary()[-20:])

        return self.nut_to_idx, self.idx_to_nut

    def load_model(self):

        inputs = layers.Input(shape = (None,), dtype = 'float32')
        nlogits, elogits = o.onSiteModel0(self.vocab_size, self.num_layers, self.d_model, self.seq_len, self.num_members, self.heads, self.dropout_rate)(inputs)
        model = Model(inputs = inputs, outputs = [nlogits, elogits])
        ########################################################################################################
        model.load_weights(self.weights_path)
        print(f"Info : model loaded ({self.weights_path})")
        ########################################################################################################
        model.summary()

        return model

    def get_test_example(self, nuts): # nuts length = 95 without start/end.
        label = self.nut_to_idx(nuts)
        target = tf.one_hot(label[1:], self.NUTS_DISTRIBUTION_LENGTH)
        target = tf.reduce_sum(target, axis = 0)
        target = tf.cast(tf.math.not_equal(target, tf.constant(0., tf.float32)), tf.float32)
        target = target / tf.reduce_sum(target)
    
        return label[:-1], target

