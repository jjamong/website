#!/bin/bash

export VAR=$1

__conda_setup="$('/app/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
	        eval "$__conda_setup"
	else
		        source "/app/anaconda3/etc/profile.d/conda.sh" 
fi

conda activate cbc_new

case $VAR in
    start)
        nohup python main_0.py 1> /log/uda/engine/cbc_engine_0_$(date -d "today" +"%F").log 2>&1 &
    	;;
    stop)
        export PORTCHK=$(ps -ef | grep -v grep | grep main_0.py | awk '{print $2}')
    	kill -9 $PORTCHK
    	;;
    restart)
        $0 stop
        $0 start
        ;;
    status)
        echo -e "`date`\n"
        ps -ef | grep -v grep | grep '^UID\|main_0.py'
        ;;
    log)
        tail -f /log/uda/engine/cbc_engine_0_$(date -d "today" +"%F").log
    	;;
    *)
        echo -e "\nUsage : $0 {start|stop|restart|status|log}\n"
        ;;
esac

