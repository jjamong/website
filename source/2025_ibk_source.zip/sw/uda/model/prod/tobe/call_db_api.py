import configparser
import requests
from typing import Dict
import os

config = configparser.ConfigParser()
config.read("model_config.ini")
server_config = config["SERVER"]
port_config = config["BACKPORT"]
endpoint_config = config["ENDPOINT"]

hostname = os.getenv('HOSTNAME')
if hostname[0] == "d":
    server = server_config.get("dev")
    port = port_config.get("dev")
else:
    server = server_config.get("prod_0")
    port = port_config.get("prod")
    
tmc_endpoint = endpoint_config.get("tmc_url")
tmu_endpoint = endpoint_config.get("tmu_url")
sp_endpoint = endpoint_config.get("sp_url")
regex_endpoint = endpoint_config.get("regex_url")

tmc_url = f"http://{server}:{port}/{tmc_endpoint}"
tmu_url = f"http://{server}:{port}/{tmu_endpoint}"
sp_url = f"http://{server}:{port}/{sp_endpoint}"
regex_url = f"http://{server}:{port}/{regex_endpoint}"

def insert_training_model(data: Dict):

    res = requests.post(tmc_url, json = data)

    return res.json()

def update_training_model(data: Dict):

    res = requests.post(tmu_url, json = data)

    return res.json()

def get_special_symbols():

    res = requests.get(sp_url)

    return res.json()["data"]

def get_regex_list():

    res = requests.get(regex_url)

    return res.json()["data"]
    