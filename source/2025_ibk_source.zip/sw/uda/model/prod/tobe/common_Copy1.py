# -*- coding: utf-8 -*-
"""
Created on 2025/04/16
@author: hyunsoo
"""

from functools import reduce
from glob import glob
import os

import olefile
import pypdfium2 as pdfium
import zlib
import struct
import re

from konlpy.tag import Mecab
mecab = Mecab(dicpath = '/app/anaconda3/mecab/mecab-ko-dic-2.1.1-20180720')

import time
import pickle
import string
import numpy as np

import traceback

from call_db_api import get_special_symbols

# chinese_chars = pickle.load(open("new_unique_chinese_char_list.tlp", "rb")) # from file
# special_chars = pickle.load(open("new_unique_special_char_list.tlp", "rb")) # from file
SC = get_special_symbols()

def make_path(path):

    replaces = ('\\', '/'), ('', '')
    
    return reduce(lambda p, rpls: p.replace(*rpls), replaces, path)



def find_files(directory, pattern = '**/*.pdf'):
    
    files = sorted(glob(os.path.join(directory, pattern), recursive = True))
    
    return [make_path(file) for file in files]
    

def gethText(file):
    MAGIC = b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
    H5SIGNATURE = ['\x05HwpSummaryInformation']
    BODY_START_SIGN = '\x02捤獥\x00\x00\x00\x00\x02\x02汤捯\x00\x00\x00\x00\x02'
    TABLE_START_SIGN = '\x0b氠瑢\x00\x00\x00\x00\x0b'
    CTRL_SIGN = '\tྠ\x00Ā\x00\x00\x00\t'
    
    # ole check
    fp = open(file, 'rb')
    fp.seek(0)
    header = fp.read(512)
    fp.close()
    isOle = True
    if len(header) != 512 and header[:8] != MAGIC:
        print('NotOle', file)
        isOle = False

    if not isOle:
        return {0: '\r\n'}

    # open and proceed to get text in ole
    ole = olefile.OleFileIO(file)
    contents = ole.listdir()

    # is hwp 5.0 ?
    if  H5SIGNATURE not in contents:
        print('This file is invalid hwp 5.0. Check !', file)
        
    # compression check
    fileHeader = ole.openstream('FileHeader')
    header = fileHeader.read()
    headerName = header[:17]
    compress = True if header[36] == 1 else False

    # arrange section by id and get sections
    sectionId = list()
    for content in contents:
        if content[0] == 'BodyText':
            sectionId.append(int(content[1][len('Section'):]))
    #print('Info: This document has %d sections' % len(sectionId))

    sections = ['BodyText/Section%d' % id for id in sorted(sectionId)]

    # get body text
    P = 0x04
    UNKNOWN_SIZE = 0x7fffffff
    HWPTAG_BEGIN = 0x010
    H, T, L = 50, 51, 53

    nrecord, nchars, itext = -1, 1, dict()
    for section in sections:

        sectionObj = ole.openstream(section)
        record = sectionObj.read()
        record = record if not compress else zlib.decompress(record, -15)
        eos = len(record) # end of section : section stream size
    
        """ text in section """
        i = 0
        while i < eos:
            header = struct.unpack_from('<I', record, i)[0]
            tagId = header & 0x3ff
            dataLen = (header >> 20) & 0xfff

            if tagId == HWPTAG_BEGIN + 50:
                rdata = record[(i + P):(i + P + dataLen)]
                nchars = struct.unpack_from('<I', rdata, 0)[0] & UNKNOWN_SIZE
    
            if nchars > 1 and  tagId == HWPTAG_BEGIN + T:
                rdata = record[(i + P):(i + P + dataLen)]
                
                try:
                    text = rdata.decode('utf-16')
                except:
                    print('unicode decode error - illegal bytes detected. Check this file!', file)
                    pass
                    
                text.replace(chr(31), '')
                text = re.sub('( ){2,}', ' ', text)

                if BODY_START_SIGN in text:
                    text = text.replace(BODY_START_SIGN, '')
                elif TABLE_START_SIGN in text:
                    text = text.replace(TABLE_START_SIGN, '')
                elif CTRL_SIGN in text:
                    text = text.replace(CTRL_SIGN, '')

                if len(text) > 2:
                    nrecord += 1
                    itext[nrecord] = text + '\n'
    
            i += P + dataLen
            
    return itext


# nutize2 not card
def nutize2_old(chr_sequence):

    """ How to handle special chracters? Need to add it. """
    # chr(26) : substitute character -> '^' for special characters
    # SC = tuple()
    SC = chinese_chars + special_chars
    SC = [ord(char) for char in SC]
    chr_sequence = ''.join([c if (ord(c) in (10, 13)) or (32 <= ord(c) <= 128) or (0xAC00 <= ord(c) <= 0xD7A3) or (ord(c) in SC) else chr(26) for c in chr_sequence])
    chr_sequence = re.sub('(\x1a){2,}', '\x1a', chr_sequence)
    
    # step 1 : control nut
    chr_sequence = chr_sequence.replace(' ', chr(18)).replace('_', chr(5)).replace('\r', chr(20)).replace('\n', chr(25))
    
    # step 2 : nut <- mecab <- korean 
    wrd_sequence = mecab.morphs(chr_sequence)
    
    # step 3 : ascii sequence -> character
    nuts = list()
    for w in wrd_sequence:
        
        if w.isascii():
            nuts.extend(list(w))
        else:
            nuts.append(w)
    
    return nuts

# nutize2 card for <td>, </td>
def nutize2(chr_sequence, SC = SC):
    
    """ How to handle special chracters? Need to add it. """
    # chr(26) : substitute character -> '^' for special characters
    # SC = tuple()
    # SC = chinese_chars + special_chars
    SC = [ord(char) for char in SC]
    chr_sequence = ''.join([c if (ord(c) in (10, 13)) or (32 <= ord(c) <= 128) or (0xAC00 <= ord(c) <= 0xD7A3) or (ord(c) in SC) else chr(26) for c in chr_sequence])
    chr_sequence = re.sub('(\x1a){2,}', '\x1a', chr_sequence)

    
    # step 1 : control nut
    chr_sequence = chr_sequence.replace(' ', chr(18)).replace('_', chr(5)).replace('\r', chr(20)).replace('\n', chr(25))
    
    # step 1-1 : quantum ai morpheme
    # <td>, </td> replace other chars
    chr_sequence = chr_sequence.replace("<td>", "\u3FFD").replace("</td>", "\u493F")
    
    # step 2 : nut <- mecab <- korean 
    wrd_sequence = mecab.morphs(chr_sequence)
    
    # step 3 : ascii sequence -> character
    
    nuts = list()
    for w in wrd_sequence:

        if w not in ["\u3FFD", "\u493F"]:
            if w.isascii():
                nuts.extend(list(w))
            else:
                nuts.append(w)
        else:
            if w == "\u3FFD":
                nuts.append("<td>")
            elif w == "\u493F":
                nuts.append("</td>")
            # add replacement 
            else:
                nuts.append("")
    
    return nuts


def nutcracker(nuts):

    ctrl_nut = [chr(1), chr(2), chr(5), chr(18), chr(20), chr(25)]
    
    trail_nuts = list()
    
    # check starting nut
    if nuts[0].isascii():
        trail_nuts.append(nuts[0])
    elif len(nuts) > 1:
        if nuts[1] in ctrl_nut:
            trail_nuts.append(nuts[0])
        elif nuts[1] not in ctrl_nut:
            trail_nuts.append(nuts[0] + '_')
    
    for pos in range(1, len(nuts) - 1):
    
        if nuts[pos].isascii():
            trail_nuts.append(nuts[pos])
        else:
            trail_nut = str()
            if nuts[pos - 1].isascii() and nuts[pos + 1].isascii(): 
                
                if nuts[pos - 1] in ctrl_nut and nuts[pos + 1] in ctrl_nut:
                    trail_nut = nuts[pos] 
                elif nuts[pos - 1] in ctrl_nut and nuts[pos + 1] not in ctrl_nut:
                    trail_nut = nuts[pos] + '_'
                elif nuts[pos - 1] not in ctrl_nut and nuts[pos + 1] in ctrl_nut:
                    trail_nut = '_' + nuts[pos] 
                elif nuts[pos - 1] not in ctrl_nut and nuts[pos + 1] not in ctrl_nut:
                    trail_nut = '_' + nuts[pos] + '_'
                    
            elif nuts[pos - 1].isascii() and not nuts[pos + 1].isascii(): 
                trail_nut= nuts[pos] + '_'
            elif not nuts[pos - 1].isascii() and nuts[pos + 1].isascii(): 
                trail_nut = '_' + nuts[pos]
            elif not nuts[pos - 1].isascii() and not nuts[pos + 1].isascii(): 
                trail_nut = '_' + nuts[pos] + '_'
        
            trail_nuts.append(trail_nut)
                
    # check ending nut
    if nuts[-1].isascii() and len(nuts) > 1:
        trail_nuts.append(nuts[-1])
    elif len(nuts) > 1:
        if nuts[-2] in ctrl_nut:
            trail_nuts.append(nuts[-1])
        elif nuts[-2] not in ctrl_nut:
            trail_nuts.append('_' + nuts[-1])
    elif not nuts[-1].isascii():
        trail_nuts.append(nuts[-1])

    return trail_nuts        

# get_document_nuts for get_page_nuts
def getdNuts(file):

    ext = os.path.splitext(file)[-1].lower()

    try:
        if ext == ".hwp":
            itext = gethText(file)
            doc = ''.join(list(itext.values()))
            # print(doc)
    
        # """ pdf handler can be added hear!!!! """
        elif ext == ".pdf":
        
            pdf = pdfium.PdfDocument(file)
            doc = str()
            for page in pdf:        
                textpage = page.get_textpage()
                text = textpage.get_text_range()
                doc += text + chr(20) + chr(25)

        elif ext == ".txt":
            doc = get_txt_document(file)
            
        else:
            return []

        if len(doc) > 6400:
            dNuts = []
            frames = len(doc) // 6400
            # print(frames)
            
            positions = list(range(6400, len(doc), 6400)) + [len(doc)]
            # print(positions)
            
            # texts = list()
            spos = 0
            for epos in positions:
                # print(spos, epos)
                if epos < len(doc):
                    for p in range(epos, len(doc), 1):
                        # if document[p] == chr(20) and document[p + 1] == chr(25):
                        if doc[p] == '\r' and doc[p + 1] == '\n':
                            # print(p, spos, epos, doc[p])
                            # texts.append(doc[spos:(p + 2)])
                            nuts_ = nutize2(doc[spos:(p + 2)])
                            dNuts.extend(nuts_)
                            spos = p + 2
                            break
                else:
                    # print("=" * 10)
                    # print(doc[spos:epos])
                    nuts_ = nutize2(doc[spos:epos])
                    dNuts.extend(nuts_)                
        else:
            # 2025/05/26 업무메뉴얼
            if len(doc) < 1:
                #print('Info: check file - null document %d - return chr(12).' % len(doc), file)
                doc = chr(12) # page spliter
                
            dNuts = nutize2(doc)
            
        nuts = nutcracker(dNuts)

        return nuts

    except Exception as e:
        print("!!!Error!!!")
        print("------> ", file)
        print(e)
        print(traceback.format_exc())
        return []


def getuNuts(files, MIN_CNTS = 8):
    start_time = time.time()
        
    storage_nuts = list()
    for i, file in enumerate(files):
        storage_nuts += getdNuts(file)
        print('\r%d' % i,  sep = '', end = '')
    
    values, counts = np.unique(storage_nuts, return_counts = True)    
    nuts_distn = list(zip(values, counts))
    
    sorted_nuts = sorted(nuts_distn, key = lambda x: (x[1], x[0]), reverse = True)
    sorted_nuts = [(str(nut), cnt) for nut, cnt in sorted_nuts if cnt >= MIN_CNTS]
    unique_nuts = [nut for nut, cnt in sorted_nuts]
    
    print('\nGetting unique nuts took %.4fs.' % (time.time() - start_time))
    print('This storage has %d unique nuts(min_cnts = %d).' % (len(unique_nuts), MIN_CNTS))

    return sorted_nuts, unique_nuts


def get_sentences(document, frame_size, frame_step):

    N = len(document)
    num_frames = 1 + (N - frame_size) // frame_step
    #print('len doc:', len(document), '# of frames:', num_frames)
    positions = np.random.randint(4, len(document) - 8 * 3, num_frames)

    sentences = list()
    for pos in positions:
        pchar = document[pos]
        #print('pos, pidx', pos, chr(pchar))
        for p in range(pos - 1, 0, -1):
            if document[p] == chr(18) or document[p] == chr(25):
                break
    
        spos = p + 1
        #print('start, start char', spos, "<" + chr(document[spos]) + ">")
        
        epos = spos + frame_size
        if epos < len(document):
            for p in range(epos, spos, -1):
                if document[p] == chr(18) or document[p] == chr(20):
                    break
            epos = p
        else:
            epos = len(document)
    
        #print('end, end char', epos, document[epos - 1])
        
        sentence = document[spos:epos]

        if len(sentence) > 8 * 3:
            sentences.append(sentence)
    
    return sentences


def make_dataset(corpus_path, frame_size, frame_step, min_sen = 16, num_docs = 100):

    start_time = time.time()
    
    files = find_files(corpus_path, pattern = '**/*.txt')
    np.random.shuffle(files)
    
    files = files[:num_docs]
    
    dataset = list()
    for idx, file in enumerate(files):
        
        page = getdNuts(file)
        
        if len(page) < (min_sen - 1) * frame_step + frame_size:
            print('check file', len(page), file)
            continue
        
        sentences = get_sentences(page, frame_size, frame_step)
    
        if len(sentences) > 0:
            dataset.extend(sentences)
        
    print('\nDataset generated for learning. \n# of examples : %d took %.4fsec' % (len(dataset), (time.time() - start_time)))
    
    return dataset


def make_dataset_deploy(deploy_files, frame_size, frame_step, min_sen = 16, num_docs = 100):

    files = deploy_files
    
    start_time = time.time()
    
    np.random.shuffle(files)
    
    files = files[:num_docs]
    
    dataset = list()
    for idx, file in enumerate(files):
        
        page = getdNuts(file)
        
        if len(page) < (min_sen - 1) * frame_step + frame_size:
            print('check file', len(page), file)
            continue
        
        sentences = get_sentences(page, frame_size, frame_step)
    
        if len(sentences) > 0:
            dataset.extend(sentences)
        
    print('\nDataset generated for learning. \n# of examples : %d took %.4fsec' % (len(dataset), (time.time() - start_time)))
    
    return dataset

def get_txt_document(file):
    
    with open(file, "r", encoding = "UTF-8", newline = '') as f:
        total_txt = f.read()

    page_txt = []
    for page in total_txt.split("\n\n</page>\n\n"):
    # for page in total_txt.split("\n\n</page>"):
    # for page in total_txt.split("</page>"):    
        if page.strip():
            page_txt.append(re.sub("<page num='[0-9]+'>\n\n", "", page))
            # page_txt.append(re.sub("<page num='[0-9]+'>\n", "", page))

    doc = str()
    for txt in page_txt:
        ctxt = re.sub(r" ?\\r\\n ?", "\r\n", txt)
        ctxt = re.sub("(\r\n){2,}", "\r\n", ctxt)

        # check page start and end
        if ctxt[:2] != "\r\n":
            # print("!!!")
            ctxt = "\r\n" + ctxt

        if ctxt[-2:] != "\r\n":
            # print("!!!")
            ctxt = ctxt + "\r\n"
            
        ctxt = re.sub("\r\n", " \r\n ", ctxt)
        ctxt = re.sub(" {2,}", " ", ctxt)
        doc += ctxt# + chr(20) + chr(25)

    return doc





