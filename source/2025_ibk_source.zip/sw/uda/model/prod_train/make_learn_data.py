import time
import common_Copy1 as c

from konlpy.tag import Mecab
mecab = Mecab(dicpath = '/app/anaconda3/mecab/mecab-ko-dic-2.1.1-20180720')

import pickle
import string
import numpy as np
import os
import configparser
import json
from typing import Iterable, List, Tuple, Union
import traceback
from datetime import datetime
from utils.assessment import ItemAssessor

from call_db_api import insert_training_model, update_training_model

StrOrList = Union[str, Iterable[str]]

config = configparser.ConfigParser()
config.read("model_config.ini")
window_size_cofig = config["DATA"]
train_config = config["TRAIN"]

predefinition_json_str = window_size_cofig.get("predefinition_per_doc")

predefinition_per_doc = json.loads(predefinition_json_str)

def make_predefinition_dict(predefinition_per_doc):
    predefinition_dict = dict()
    for di_ in predefinition_per_doc:
        di_sys_nm = di_['system_name']
        di_cd = di_['code']
        if di_cd:
            p_key = '_'.join([di_sys_nm, di_cd])
        else:
            p_key = di_sys_nm
    
        predefinition_dict[p_key] = {'window_size': di_['window_size'], 'model_arch':di_['model_arch']}
    return predefinition_dict
    
def _to_list(x:StrOrList) -> List[str]:
    if isinstance(x, str):
        return [x]
    list_ = list(x)
    sorted_list_ = sorted(x, key = lambda k : k, reverse= False)# True)
    return sorted_list_

def get_target_files(raw_storage, target_ext=['txt'], byte_cutoff = 150): # target_ext=['txt'] # target_ext=['hwp', 'pdf', 'txt']
    total_files = []
    if 'hwp' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.hwp') + c.find_files(raw_storage, pattern = '**/*.HWP')

    if 'pdf' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.pdf') + c.find_files(raw_storage, pattern = '**/*.PDF')

    if 'txt' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.txt') + c.find_files(raw_storage, pattern = '**/*.TXT')

    filter_files = []

    for f_path in total_files:
        if os.path.getsize(f_path) > byte_cutoff:
            filter_files.append(f_path)
    
    return filter_files

def data_assessment(target_files, already_files=[], cap = 2500):
    files = list()
    for file_path in target_files:
        if file_path not in already_files:
            files.append(file_path)
    ass = ItemAssessor()
    picked = ass.assessor(files, boundary=cap)
    return picked

def recent_year_detection(target_path, range=3):
    recent_years = list()
    sorted_dir = sorted(os.listdir(target_path), key = lambda x : int(x), reverse=True)
    for year_dir in sorted_dir[:range]:
        recent_years.append(year_dir)
    return recent_years

def recent_year_detection(target_path, range=3):
# def recent_year_detection(target_path, range=4):
    recent_years = list()
    sorted_dir = sorted([str_ for str_ in os.listdir(target_path) if int(str_)<2700], key = lambda x : int(x), reverse=True)
    for year_dir in sorted_dir[:range]:
        recent_years.append(year_dir)
    return recent_years

def make_doc_nuts_pickle(files):
    sorted_nuts, unique_nuts = c.getuNuts(files, MIN_CNTS = 0)
    
    if 40000 <= len(sorted_nuts):
        sorted_nuts, unique_nuts = c.getuNuts(files, MIN_CNTS = 2)
        
    return sorted_nuts, unique_nuts

def get_most_recent_directory(path):
    dirs = [os.path.join(path, d) for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)) and d not in ['.ipynb_checkpoints']]
    if not dirs:
        return 0
    # most_recent_path = max(dirs, key=os.path.getmtime)
    most_recent_path = max(dirs, key=lambda d: os.stat(d).st_ctime)
    most_recent = most_recent_path.split('/')[-1]
    return most_recent
    
def ensure_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"디렉토리를 생성했습니다 : {path}")
    else:
        print(f"이미 디렉토리가 존재합니다 : {path}")

def make_pkl_data_total(system_names, codes, base_home_path, save_path):
    sys_list = _to_list(system_names)
    code_list = _to_list(codes)
    
    files = list()
    for system_name in sys_list:
        for code in code_list:
            if code:
                raw_storage = '/'.join([base_home_path, system_name, code])
            else:
                raw_storage = '/'.join([base_home_path, system_name])

            files += get_target_files(raw_storage)

    print('This storage has %d files.' % len(files))

    sorted_nuts, unique_nuts = make_doc_nuts_pickle(files)
    print(f"Nuts 개수 : {len(unique_nuts)}")
    np.random.shuffle(files)
    pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
    pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))

    print(sorted_nuts[:10])
    print(sorted_nuts[-10:])

    return len(files), len(unique_nuts)

def make_pkl_data_collective_intelligence_core3(system_names, codes, base_home_path, save_path, recent_years, k_cap = 2500):
    
    print('recent_years :', recent_years)
    sys_list = _to_list(system_names)
    code_list = _to_list(codes)

    files_by_years = dict()
    for system_name in sys_list:
        for code in code_list:
            if code:
                raw_storage = '/'.join([base_home_path, system_name, code])
            else:
                raw_storage = '/'.join([base_home_path, system_name])

            for yi, year_str in enumerate(recent_years):
                year_dir = '/'.join([raw_storage, year_str])
                if yi not in files_by_years:
                    files_by_years[yi] = get_target_files(year_dir)
                else:
                    files_by_years[yi] += get_target_files(year_dir)

    total_cnt = sum([len(files_by_years[yi]) for yi in files_by_years])
    
    if not recent_years:
        files = []
    elif 3 <= len(recent_years):
        if 2500 <= len(files_by_years[0]) and k_cap*3 <= len(files_by_years[1]):
            print('recent_years :', recent_years, '   case1')
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[1], [])
            files3 = data_assessment(files_by_years[0] + files_by_years[1], files1+files2)
        elif len(files_by_years[0]) < k_cap and k_cap*3 <= len(files_by_years[1]):
            print('recent_years :', recent_years, '   case2')
            files1 = files_by_years[0] + data_assessment(files_by_years[1], [], length = (k_cap-len(files_by_years[0])))
            files2 = data_assessment(files_by_years[1], files1)
            files3 = data_assessment(files_by_years[0] + files_by_years[1], files1+files2)
        elif len(files_by_years[0]) < k_cap and len(files_by_years[1]) < k_cap*3:
            print('recent_years :', recent_years, '   case3')
            files1 = files_by_years[0] + data_assessment(files_by_years[1], [], length = (k_cap-len(files_by_years[0])))
            files2 = data_assessment(files_by_years[1], files1)
            files3 = data_assessment(files_by_years[2], [])
        else:
            print('recent_years :', recent_years, '   case4')
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[1], [])
            files3 = data_assessment(files_by_years[2], [])
            
    elif len(recent_years) == 2:
        if 2500 <= len(files_by_years[0]) and k_cap*3 <= len(files_by_years[1]):
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[1], [])
            files3 = data_assessment(files_by_years[0] + files_by_years[1], files1+files2)
        elif len(files_by_years[0]) < k_cap and k_cap*3 <= len(files_by_years[1]):
            files1 = files_by_years[0] + data_assessment(files_by_years[1], [], length = (k_cap-len(files_by_years[0])))
            files2 = data_assessment(files_by_years[1], files1)
            files3 = data_assessment(files_by_years[0] + files_by_years[1], files1+files2)
        elif len(files_by_years[0]) < k_cap and len(files_by_years[1]) < k_cap*3:
            files1 = files_by_years[0] + data_assessment(files_by_years[1], [], length = (k_cap-len(files_by_years[0])))
            files2 = data_assessment(files_by_years[1], files1)
            files3 = data_assessment(files_by_years[0] + files_by_years[1], [])
        else:
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[1], [])
            files3 = data_assessment(files_by_years[0] + files_by_years[1], [])
            
    elif len(recent_years) == 1:
        if 5000 <= len(files_by_years[0]):
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[0], files1)
            files3 = data_assessment(files_by_years[0], [])
        else:
            files1 = data_assessment(files_by_years[0], [])
            files2 = data_assessment(files_by_years[0], [])
            files3 = data_assessment(files_by_years[0], [])
    
    sorted_nuts1, unique_nuts1 = make_doc_nuts_pickle(files1)
    np.random.shuffle(files1)
    pickle.dump(files1, open('/'.join([save_path,"stage_que1.tlp"]), "wb"))
    pickle.dump((sorted_nuts1, unique_nuts1), open('/'.join([save_path,'unique_nuts_1.tlp']), 'wb'))
    print(sorted_nuts1[:10])
    print(sorted_nuts1[-10:])
    print(f"Nuts 개수 : {len(unique_nuts1)}")
    print('\n')
    sorted_nuts2, unique_nuts2 = make_doc_nuts_pickle(files2)
    np.random.shuffle(files2)
    pickle.dump(files2, open('/'.join([save_path,"stage_que2.tlp"]), "wb"))
    pickle.dump((sorted_nuts2, unique_nuts2), open('/'.join([save_path,'unique_nuts_2.tlp']), 'wb'))
    print(sorted_nuts2[:10])
    print(sorted_nuts2[-10:])
    print(f"Nuts 개수 : {len(unique_nuts2)}")
    print('\n')
    sorted_nuts3, unique_nuts3 = make_doc_nuts_pickle(files3)
    np.random.shuffle(files3)
    pickle.dump(files3, open('/'.join([save_path,"stage_que3.tlp"]), "wb"))
    pickle.dump((sorted_nuts3, unique_nuts3), open('/'.join([save_path,'unique_nuts_3.tlp']), 'wb'))
    print(sorted_nuts3[:10])
    print(sorted_nuts3[-10:])
    print(f"Nuts 개수 : {len(unique_nuts3)}")
    print('\n')

    tot_unique_nuts = list(set(unique_nuts1 + unique_nuts2 + unique_nuts3))
        
    return total_cnt, len(tot_unique_nuts)


def make_pkl_data_single(system_names, codes, base_home_path, save_path, recent_years, doc_cutoff = 6000, k_cap = 2500):
    
    print('recent_years :', recent_years)
    sys_list = _to_list(system_names)
    code_list = _to_list(codes)

    files_by_years = dict()
    for system_name in sys_list:
        for code in code_list:
            if code:
                raw_storage = '/'.join([base_home_path, system_name, code])
            else:
                raw_storage = '/'.join([base_home_path, system_name])

            for yi, year_str in enumerate(recent_years):
                year_dir = '/'.join([raw_storage, year_str])
                if yi not in files_by_years:
                    files_by_years[yi] = get_target_files(year_dir)
                else:
                    files_by_years[yi] += get_target_files(year_dir)

    total_cnt = sum([ len(files_by_years[yi]) for yi in files_by_years])
    tfiles = list()
    for yi in files_by_years:
        tfiles += files_by_years[yi]
        
    print('This storage has %d files.' % total_cnt)
    if total_cnt <= doc_cutoff:
        files = list()
        for yi in files_by_years:
            files += files_by_years[yi]
            
    else:
        files = list()
        for yi in list(files_by_years.keys())[:2]:
            files += files_by_years[yi]

        if doc_cutoff+2000 < len(files):
            files = data_assessment(files, [])
    # print(files)
    sorted_nuts, unique_nuts = make_doc_nuts_pickle(files)
    tsorted_nuts, tunique_nuts = make_doc_nuts_pickle(tfiles)
    print(f"Nuts 개수 : {len(unique_nuts)}")
    np.random.shuffle(files)
    pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
    pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))

    print(sorted_nuts[:10])
    print(sorted_nuts[-10:])
        
    return total_cnt, len(tunique_nuts)

def make_preprocessed_pkl_data(system_names, codes, base_home_path, result_home_path, predefinition_dict, recent_years=[], doc_cutoff = 6000, k_cap = 2500):

    try:
        sys_list = _to_list(system_names)
        code_list = _to_list(codes)
        main_sys = sys_list[0]
        main_code = code_list[0]
        print('main_sys :', main_sys, '  main_code :', main_code)

        if main_code:
            result_storage = '/'.join([result_home_path, main_sys, main_code])
            ensure_directory('/'.join([result_home_path,main_sys]))
            ensure_directory(result_storage)
            m_key = '_'.join([main_sys, main_code])
        else:
            result_storage = '/'.join([result_home_path, main_sys])
            ensure_directory(result_storage)
            m_key = main_sys
        
        model_arch, tm_id = "", ""
        model_arch = predefinition_dict[m_key]['model_arch']
    
        # DB insert - main_sys, main_code
        if model_arch != "ci":
            if main_code:
                res = insert_training_model({"sourceSystemCode": main_sys.upper(), "classificationCode": main_code})
            else:
                res = insert_training_model({"sourceSystemCode": main_sys.upper(), "classificationCode": None})
            tm_id = res["data"]["trainingModelId"]
        else:
            tm_ids = []
            for i in [1, 2, 3]: # range 예약어 사용 중
                if main_code:
                    res = insert_training_model({"sourceSystemCode": main_sys.upper(), "classificationCode": main_code})
                else:
                    res = insert_training_model({"sourceSystemCode": main_sys.upper(), "classificationCode": None})
                tm_id = res["data"]["trainingModelId"]
                tm_ids.append(tm_id)
            
        dir_seq = int(get_most_recent_directory(result_storage))+1
        save_path = '/'.join([result_storage, str(dir_seq)])
        ensure_directory(save_path)
    
        if not recent_years and model_arch != 'to':
            recent_years_list = list()
            for system_name in sys_list:
                for code in code_list:
                    if code:
                        raw_storage = '/'.join([base_home_path, system_name, code])
                        w_key = '_'.join([system_name,code])
                    else:
                        raw_storage = '/'.join([base_home_path, system_name])
                        w_key = system_name
                    range = predefinition_dict[w_key]['window_size']
                    recent_years_ = recent_year_detection(raw_storage, range)
                    for r_year in recent_years_:
                        if r_year not in recent_years_list:
                            recent_years_list.append(r_year)
            sorted_recent_years_list = sorted(recent_years_list, key = lambda x : x, reverse = True)
            recent_years = sorted_recent_years_list[:range]
    
        if model_arch == 'to':        
            # 전처리 수행
            files_cnt, nuts_cnt = make_pkl_data_total(system_names, codes, base_home_path, save_path)
            
            # 파일 수, 토큰 수 update
            res = update_training_model({"trainingModelId": tm_id, "documentCount": files_cnt, "tokenCount": nuts_cnt, "updatedBy": "engine"})
            # dictionary 추가
            if main_code:
                sys2id["_".join([main_sys, main_code])] = tm_id
            else:
                sys2id[main_sys] = tm_id
                
        elif model_arch == 'si':
            # 전처리 수행
            files_cnt, nuts_cnt = make_pkl_data_single(system_names, codes, base_home_path, save_path, recent_years, doc_cutoff, k_cap)
            
            # 파일 수, 토큰 수 update
            res = update_training_model({"trainingModelId": tm_id, "documentCount": files_cnt, "tokenCount": nuts_cnt, "updatedBy": "engine"})
            # dictionary 추가
            if main_code:
                sys2id["_".join([main_sys, main_code])] = tm_id
            else:
                sys2id[main_sys] = tm_id
                
        elif model_arch == 'ci':
            # 전처리 수행
            files_cnt, nuts_cnt = make_pkl_data_collective_intelligence_core3(system_names, codes, base_home_path, save_path, recent_years, k_cap)
            
            for i, tm_id in enumerate(tm_ids):
                # 파일 수, 토큰 수 update
                res = update_training_model({"trainingModelId": tm_id, "documentCount": files_cnt, "tokenCount": nuts_cnt, "updatedBy": "engine"})
                # dictionary 추가
                if main_code:
                    sys2id["_".join([main_sys, main_code, str(i+1)])] = tm_id
                else:
                    sys2id["_".join([main_sys, str(i+1)])] = tm_id

        return files_cnt, nuts_cnt, sys2id

    except Exception as e:
        print(traceback.format_exc())
        if model_arch != "ci":
            res = update_training_model({"trainingModelId": tm_id, "status": "FAIL", "logFilePath": f"/log/uda/engine/train/mld_{datetime.strftime(datetime.today(), '%Y-%m-%d')}.log", "updatedBy": "engine"})
        else:
            for i, tm_id in enumerate(tm_ids):
                res = update_training_model({"trainingModelId": tm_id, "status": "FAIL", "logFilePath": f"/log/uda/engine/train/mld_{datetime.strftime(datetime.today(), '%Y-%m-%d')}.log", "updatedBy": "engine"})
        
        return 0, 0, sys2id

    





if __name__ == "__main__":

    print(f"{datetime.strftime(datetime.today(), '%Y-%m-%d')} 배치 실행")

    try:
        # base_home_path = "/data/train_data/rawdata"
        base_home_path = train_config.get("base_home_path")
        # result_home_path = '/sw/uda/model/hs/temp_ch/custum_func/make_learning_data/ppp_data' # '/sw/uda/model/hs/temp_ch/make_learningdata_set/ppdata_'
        result_home_path = train_config.get("result_home_path")
        
        predefinition_dict = make_predefinition_dict(predefinition_per_doc)
    
        # learn_group_list = [
                            # ['csmcsm', '' ,['2025','2024']],
                            # ['iemiea', '' ,[]],
                            # ['iemieb', '' ,[str((2025-i)) for i in range(8,12)]],
                            # ['iemieb', '' ,[str((2025-i)) for i in range(4,8)]],
                            # ['iemieb', '' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107428' ,[str((2025-i)) for i in range(8,12)]],
                            # ['kmswpt', '120000107428' ,[str((2025-i)) for i in range(4,8)]],
                            # ['kmswpt', '120000107428' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107483' ,[str((2025-i)) for i in range(8,12)]],
                            # ['kmswpt', '120000107483' ,[str((2025-i)) for i in range(4,8)]],
                            # ['kmswpt', '120000107483' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107517' ,[str((2025-i)) for i in range(8,12)]],
                            # ['kmswpt', '120000107517' ,[str((2025-i)) for i in range(4,8)]],
                            # ['kmswpt', '120000107517' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107529' ,[str((2025-i)) for i in range(8,12)]],
                            # ['kmswpt', '120000107529' ,[str((2025-i)) for i in range(4,8)]],
                            # ['kmswpt', '120000107529' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107533' ,[str((2025-i)) for i in range(8,12)]],
                            # ['kmswpt', '120000107533' ,[str((2025-i)) for i in range(4,8)]],
                            # ['kmswpt', '120000107533' ,[str((2025-i)) for i in range(0,4)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(10,12)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(8,10)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(6,8)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(4,6)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(2,4)]],
                            # ['kmswpt', '120000107537' ,[str((2025-i)) for i in range(0,2)]],
    ########################
            # ['aikkms', '', [str((2025-i)) for i in range(10,12)]],
            # ['aikkms', '', [str((2025-i)) for i in range(8,10)]],
            # ['aikkms', '', [str((2025-i)) for i in range(6,8)]],
            # ['aikkms', '', [str((2025-i)) for i in range(4,6)]],
            # ['aikkms', '', [str((2025-i)) for i in range(2,4)]],
            # ['aikkms', '', [str((2025-i)) for i in range(0,2)]],
    #########################
        learn_group_list = [
                            ['csmcsm', '' ,[]],
                            ['iemiea', '' ,[]],
                            ['iemieb', '' ,[]],
                            ['kmswpt', '120000107428' ,[]],
                            ['kmswpt', '120000107483' ,[]],
                            ['kmswpt', '120000107517' ,[]],
                            ['kmswpt', '120000107529' ,[]],
                            ['kmswpt', '120000107533' ,[]],
                            ['kmswpt', '120000107537' ,[]],
                            ['aikkms', '', []],
                            ['iisiis', '', []],
                            ['kmsepn', 'PLZEPN001', []],
                            ['kmsepn', 'PLZEPN002', []],
                            ['kmsepn', 'PLZEPN003', []],
                            [['kmsepn', 'kmsplz'], 'PLZEPN004', []],
                           ]
        sys2id = {}
        for row in learn_group_list:
            system_name = row[0]
            code = row[1]
            recent_years = row[2]
            # if system_name != 'kmswpt':
            #     code = ''
    
            files_cnt, nuts_cnt, sys2id = make_preprocessed_pkl_data(system_name, code, base_home_path, result_home_path, predefinition_dict, recent_years)
            # print("!!!!!!!!!!!!!!!!!!!!!!!!")
            # print(files_cnt, nuts_cnt)
    
            # make_preprocessed_pkl_data(system_name, code, base_home_path, result_home_path, recent_years, doc_cutoff = 6000, k_cap = 2500)
    
        json.dump(sys2id, open("sys2id.json", "w", encoding = "UTF-8"), ensure_ascii = False, indent = 4)
        print(f"{'-' * 25} END {'-' * 25}")
        
    except Exception as e:
        print(traceback.format_exc())
        print(f"{'-' * 25} END {'-' * 25}")
        
