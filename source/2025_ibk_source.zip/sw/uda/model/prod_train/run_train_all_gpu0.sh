#!/bin/bash

nohup sh run_train_gpu0.sh > /dev/null 2>&1 &


