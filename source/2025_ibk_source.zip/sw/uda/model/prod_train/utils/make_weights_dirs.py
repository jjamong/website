import os
from datetime import datetime
import configparser
import json

config = configparser.ConfigParser()
config.read("model_config.ini")
window_size_cofig = config["DATA"]

predefinition_json_str = window_size_cofig.get("predefinition_per_doc")
predefinition_per_doc = json.loads(predefinition_json_str)

def make_predefinition_dict(predefinition_per_doc):
    predefinition_dict = dict()
    for di_ in predefinition_per_doc:
        di_sys_nm = di_['system_name']
        di_cd = di_['code']
        if di_cd:
            p_key = '_'.join([di_sys_nm, di_cd])
        else:
            p_key = di_sys_nm
    
        predefinition_dict[p_key] = {'window_size': di_['window_size'], 'model_arch':di_['model_arch']}
    return predefinition_dict

def make_sn_dir(system_name: str):

    names = os.listdir("./")
    dirs = [name for name in names if os.path.isdir(f"./{name}")]
    dirs = [dir_ for dir_ in dirs if dir_ != ".ipynb_checkpoints"]
    if system_name not in dirs:
        os.mkdir(f"./{system_name}")
    

def make_weights_dirs_nocode(system_name: str, model_arch: str, ds_idx: str):
    
    today = datetime.today().strftime("%Y%m%d")
    
    dirs = os.listdir(f"./{system_name}")
    dirs = [dir_ for dir_ in dirs if dir_ != ".ipynb_checkpoints"]

    if model_arch != "ci":
        if len(dirs) == 0: # weights 폴더가 없을 경우
            os.mkdir(f"./{system_name}/weights")
        else:
            # today 아닌 date 만 있을 경우
            date_dirs = [dir_.split("_")[-1] for dir_ in dirs if len(dir_.split("_")[-1]) == 8]
            # print(date_dirs)
            if today not in date_dirs:
                os.rename(f"./{system_name}/weights", f"./{system_name}/weights_{today}")
        
            # today 있을 경우
            else:
                today_dirs = [dir_ for dir_ in dirs if today in dir_]
                today_dirs_rvs = sorted(today_dirs, reverse = True)
                for dir_ in today_dirs_rvs:
                    if len(dir_.split("_")) == 2:
                        os.rename(f"./{system_name}/weights_{today}", f"./{system_name}/weights_{today}_1")
                        os.rename(f"./{system_name}/weights", f"./{system_name}/weights_{today}")
                    elif len(dir_.split("_")) == 3:
                        idx = dir_.split("_")[-1]
                        os.rename(f"./{system_name}/weights_{today}_{idx}", f"./{system_name}/weights_{today}_{int(idx)+1}")
                    else:
                        print(f"Check Directory!!! -> {dir_}")
                        pass
            
            os.mkdir(f"./{system_name}/weights")

    else:
        if len(dirs) == 0: # weights 폴더가 없을 경우
            os.mkdir(f"./{system_name}/weights")
            sub_dirs = os.listdir(f"./{system_name}/weights") # idx 폴더가 없을 경우
            sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
            if str(ds_idx) not in sub_dirs:
                os.mkdir(f"./{system_name}/weights/{ds_idx}")            
        else:
            sub_dirs = os.listdir(f"./{system_name}/weights") # idx 폴더가 없을 경우
            sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
            if str(ds_idx) not in sub_dirs:
                os.mkdir(f"./{system_name}/weights/{ds_idx}")
                
            else:
                # today 아닌 date 만 있을 경우
                date_dirs = [dir_.split("_")[-1] for dir_ in dirs if len(dir_.split("_")[-1]) == 8]
                # print(date_dirs)
                if today not in date_dirs:
                    os.rename(f"./{system_name}/weights", f"./{system_name}/weights_{today}")
            
                # today 있을 경우
                else:
                    today_dirs = [dir_ for dir_ in dirs if today in dir_]
                    today_dirs_rvs = sorted(today_dirs, reverse = True)
                    for dir_ in today_dirs_rvs:
                        if len(dir_.split("_")) == 2:
                            os.rename(f"./{system_name}/weights_{today}", f"./{system_name}/weights_{today}_1")
                            os.rename(f"./{system_name}/weights", f"./{system_name}/weights_{today}")
                        elif len(dir_.split("_")) == 3:
                            idx = dir_.split("_")[-1]
                            os.rename(f"./{system_name}/weights_{today}_{idx}", f"./{system_name}/weights_{today}_{int(idx)+1}")
                        else:
                            print(f"Check Directory!!! -> {dir_}")
                            pass
                
                os.mkdir(f"./{system_name}/weights")
                sub_dirs = os.listdir(f"./{system_name}/weights") # idx 폴더가 없을 경우
                sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
                if str(ds_idx) not in sub_dirs:
                    os.mkdir(f"./{system_name}/weights/{ds_idx}")        

def make_weights_dirs_code(system_name: str, code: str, model_arch: str, ds_idx: str):
    
    today = datetime.today().strftime("%Y%m%d")

    rdirs = os.listdir(f"./{system_name}")
    rdirs = [rdir_ for rdir_ in rdirs if rdir_ != ".ipynb_checkpoints"]

    if code not in rdirs:
        os.mkdir(f"./{system_name}/{code}")
        
    dirs = os.listdir(f"./{system_name}/{code}")
    dirs = [dir_ for dir_ in dirs if dir_ != ".ipynb_checkpoints"]
    
    if model_arch != "ci": # ci 가 아니면
        if len(dirs) == 0: # weights 폴더가 없을 경우
            os.mkdir(f"./{system_name}/{code}/weights")
        else:
            # today 아닌 date 만 있을 경우
            date_dirs = [dir_.split("_")[-1] for dir_ in dirs if len(dir_.split("_")[-1]) == 8]
            # print(date_dirs)
            if today not in date_dirs:
                os.rename(f"./{system_name}/{code}/weights", f"./{system_name}/{code}/weights_{today}")
        
            # today 있을 경우
            else:
                today_dirs = [dir_ for dir_ in dirs if today in dir_]
                today_dirs_rvs = sorted(today_dirs, reverse = True)
                for dir_ in today_dirs_rvs:
                    if len(dir_.split("_")) == 2:
                        os.rename(f"./{system_name}/{code}/weights_{today}", f"./{system_name}/{code}/weights_{today}_1")
                        os.rename(f"./{system_name}/{code}/weights", f"./{system_name}/{code}/weights_{today}")
                    elif len(dir_.split("_")) == 3:
                        idx = dir_.split("_")[-1]
                        os.rename(f"./{system_name}/{code}/weights_{today}_{idx}", f"./{system_name}/{code}/weights_{today}_{int(idx)+1}")
                    else:
                        print(f"Check Directory!!! -> {dir_}")
                        pass
            
            os.mkdir(f"./{system_name}/{code}/weights")

    else:
        if len(dirs) == 0: # weights 폴더가 없을 경우
            os.mkdir(f"./{system_name}/{code}/weights")
            sub_dirs = os.listdir(f"./{system_name}/{code}/weights") # idx 폴더가 없을 경우
            sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
            if str(ds_idx) not in sub_dirs:
                os.mkdir(f"./{system_name}/{code}/weights/{ds_idx}")
        else:
            sub_dirs = os.listdir(f"./{system_name}/{code}/weights") # idx 폴더가 없을 경우
            sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
            if str(ds_idx) not in sub_dirs:
                os.mkdir(f"./{system_name}/{code}/weights/{ds_idx}")

            else:
                # today 아닌 date 만 있을 경우
                date_dirs = [dir_.split("_")[-1] for dir_ in dirs if len(dir_.split("_")[-1]) == 8]
                # print(date_dirs)
                if today not in date_dirs:
                    os.rename(f"./{system_name}/{code}/weights", f"./{system_name}/{code}/weights_{today}")
            
                # today 있을 경우
                else:
                    today_dirs = [dir_ for dir_ in dirs if today in dir_]
                    today_dirs_rvs = sorted(today_dirs, reverse = True)
                    for dir_ in today_dirs_rvs:
                        if len(dir_.split("_")) == 2:
                            os.rename(f"./{system_name}/{code}/weights_{today}", f"./{system_name}/{code}/weights_{today}_1")
                            os.rename(f"./{system_name}/{code}/weights", f"./{system_name}/{code}/weights_{today}")
                        elif len(dir_.split("_")) == 3:
                            idx = dir_.split("_")[-1]
                            os.rename(f"./{system_name}/{code}/weights_{today}_{idx}", f"./{system_name}/{code}/weights_{today}_{int(idx)+1}")
                        else:
                            print(f"Check Directory!!! -> {dir_}")
                            pass
                
                os.mkdir(f"./{system_name}/{code}/weights")
                sub_dirs = os.listdir(f"./{system_name}/{code}/weights") # idx 폴더가 없을 경우
                sub_dirs = [sub_dir_ for sub_dir_ in sub_dirs if sub_dir_ != ".ipynb_checkpoints"]
                if str(ds_idx) not in sub_dirs:
                    os.mkdir(f"./{system_name}/{code}/weights/{ds_idx}")

def make_weights_dirs(system_name: str, code: str, ds_idx: str):

    predefinition_dict = make_predefinition_dict(predefinition_per_doc)

    make_sn_dir(system_name)
    
    if code:
        model_arch = predefinition_dict["_".join([system_name, code])]["model_arch"]
        make_weights_dirs_code(system_name, code, model_arch, ds_idx)

    else:
        model_arch = predefinition_dict[system_name]["model_arch"]
        make_weights_dirs_nocode(system_name, model_arch, ds_idx)

