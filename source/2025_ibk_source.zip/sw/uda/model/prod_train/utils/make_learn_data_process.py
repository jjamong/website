import time
import common_Copy1 as c

from konlpy.tag import Mecab
mecab = Mecab(dicpath = '/app/anaconda3/mecab/mecab-ko-dic-2.1.1-20180720')

import pickle
import string
import numpy as np
import os

"""
# case1. 연도별로 구분하지 않고 신규업데이트가 있으면 해당파일 덮어쓰는 경우(내규와 비슷한 경우)
## - 전체 데이터 사용

#---------------------------------------------------------------------------------------------

# case2-1. 연도별로 구분하여 저장하는 경우(시행문-공지 제외)
# 
## 최근 3개년치 디렉토리 path 파일 개수 체크
### 3개년치 파일 개수가 6000개 이하이면 전체 파일 사용
### 3개년치 파일 개수가 6000개 초과일 경우 2개년치 파일 개수 체크 후 사용
### 2개년치도 8000개 초과일 경우 2개년치에 대한 2500개 샘플링? or 1개년치만 사용

#---------------------------------------------------------------------------------------------

# case2-2. 연도별로 구분하여 저장하는 경우(시행문-공지)
# 
## 최근 3개년치 디렉토리 path 파일 개수 체크


#### 가장 최근 년도의 개수가 2500개 이상 & 다음년도 5000개 이상
##### 가장 최근 년도 2500 샘플링 & 다음년도 2500 샘플링 & 2개년도 합쳐서 비복원 추출

#### 가장 최근 년도의 개수가 2500개 미만 & 다음년도 5000개 이상
##### 가장 최근 년도 전체 포함 + 2500에 부족한 개수 만큼 다음년도 샘플링, 다음년도 대상으로 2500개 비복원 추출 2회

#### 가장 최근 년도의 개수가 2500개 미만 & 다음년도 5000개 미만
##### 가장 최근 년도 전체 포함 + 2500에 부족한 개수 만큼 다음년도 샘플링, 다음년도 대상으로 2500개 비복원 추출 1회, 다다음년도 대상으로 2500개 비복원 추출 1회

#---------------------------------------------------------------------------------------------

# case3. 은행상품설명서
# 
## 메타를 기준으로 문서명에 '상품','설명','약관'인 대상에 한하여 학습데이터 대상
## 파일을 읽어 '간이투자', '간이 투자', '간 이 투 자' 가 문서 초기에(700자이내)에 등장한 대상에 한하여 학습데이터 대상
## 학습데이터를 검증하면서 만들지 학습데이터 경로에 대상만 골라서 저장해줄지는 의사결정 또는 논의 필요
## 연도별 데이터 분포도 확인하여 전체데이터를 쓸지 아니면 연도를 제한해야할지 의사결정 필요(이 사항은 카드상품설명서도 유효함)

#---------------------------------------------------------------------------------------------

# 토큰 개수 전체 체크
## 40000개 미만이면 전체 사용
## 40000개 이상이면 2번이상 등장한 토큰 사용
## 인사만 num_docs를 1000으로 할지 토큰이 12000 또는 13000이하일 경우 num_docs를 1000으로 할지..

#---------------------------------------------------------------------------------------------

# 모델은 기동 또는 재기동시 지정된 디렉토리에 항상 최신 날짜의 weights만 읽어서 기동(아니면 기동을 위한 config파일을 db 배포이력 기반으로 생성이 필요)
# 테스트 데이터에 대한 결과는 api로할지 아니면 실행프로그램으로 할지 의사결정 필요
"""

def get_target_files(raw_storage, target_ext=['hwp','pdf','txt']):
    total_files = []
    if 'hwp' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.hwp') + c.find_files(raw_storage, pattern = '**/*.HWP')

    if 'pdf' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.pdf') + c.find_files(raw_storage, pattern = '**/*.PDF')

    if 'txt' in target_ext:
        total_files += c.find_files(raw_storage, pattern = '**/*.txt') + c.find_files(raw_storage, pattern = '**/*.TXT')
        
    return total_files

def sampling_without_replacement(target_files, already_files=[], length = 2500):
    files = list()
    for file_path in target_files:
        if file_path not in already_files:
            files.append(file_path)
    np.random.shuffle(files)
    sampling_files = files[:length]
    return sampling_files

def recent_year_detection(target_path, range=3):
    recent_years = list()
    sorted_dir = sorted(os.listdir(target_path), key = lambda x : int(x), reverse=True)
    for year_dir in sorted_dir[:range]:
        recent_years.append(year_dir)
    return recent_years

def recent_year_detection(target_path, range=3):
# def recent_year_detection(target_path, range=4):
    recent_years = list()
    sorted_dir = sorted([str_ for str_ in os.listdir(target_path) if int(str_)<2700], key = lambda x : int(x), reverse=True)
    for year_dir in sorted_dir[:range]:
        recent_years.append(year_dir)
    return recent_years

def make_doc_nuts_pickle(files, system_name):

    sorted_nuts, unique_nuts = c.getuNuts(files, MIN_CNTS = 0)
    print(sorted_nuts[:10])
    print(sorted_nuts[-10:])
    if 40000 <= len(sorted_nuts):
        sorted_nuts, unique_nuts = c.getuNuts(files, MIN_CNTS = 2)
                
    # pickle.dump((sorted_nuts, unique_nuts), open('unique_nuts_20250606.tlp', 'wb'))
    return sorted_nuts, unique_nuts

def get_most_recent_directory(path):
    dirs = [os.path.join(path, d) for d in os.listdir(path) if os.path.isdir(os.path.join(path, d)) and d not in ['.ipynb_checkpoints']]
    if not dirs:
        return 0
    # most_recent_path = max(dirs, key=os.path.getmtime)
    most_recent_path = max(dirs, key=lambda d: os.stat(d).st_ctime)
    most_recent = most_recent_path.split('/')[-1]
    return most_recent
    
def ensure_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"디렉토리를 생성했습니다 : {path}")
    else:
        print(f"이미 디렉토리가 존재합니다 : {path}")


def make_preprocessed_pkl_data(system_name, code, base_home_path, result_home_path, doc_cutoff = 6000, sample_cutoff = 2500):
    
    if code:
        raw_storage = '/'.join([base_home_path, system_name, code])
        # raw_storage = base_home_path
        result_storage = '/'.join([result_home_path, system_name, code])
    else:
        raw_storage = '/'.join([base_home_path, system_name])
        # raw_storage = base_home_path
        result_storage = '/'.join([result_home_path, system_name])

    if system_name in ["kmswpt"]:
        ensure_directory('/'.join([result_home_path,system_name]))
        if not code:
            print('Please check the code')
        # 시행문 - 공지 
        elif code in ["120000107537"]:
            ensure_directory('/'.join([result_home_path,system_name,code]))
            dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
            
            save_path = '/'.join([result_storage, str(dir_seq)])
            ensure_directory(save_path)
            
            recent_years = recent_year_detection(raw_storage)
            print(recent_years)
            files_by_years = dict()
            for yi, year_str in enumerate(recent_years):
                year_dir = '/'.join([raw_storage, year_str])
                files_by_years[yi] = get_target_files(year_dir)
                print(yi, ' path :', year_dir, ' len :', len(files_by_years[yi]))
    
            if not recent_years:
                files = []
            elif 3 <= len(recent_years):
                if 2500 <= len(files_by_years[0]) and sample_cutoff*3 <= len(files_by_years[1]):
                    print('recent_years :', recent_years, '   case1')
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[1], [])
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], files1+files2)
                elif len(files_by_years[0]) < sample_cutoff and sample_cutoff*3 <= len(files_by_years[1]):
                    print('recent_years :', recent_years, '   case2')
                    files1 = files_by_years[0] + sampling_without_replacement(files_by_years[1], [], length = (sample_cutoff-len(files_by_years[0])))
                    files2 = sampling_without_replacement(files_by_years[1], files1)
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], files1+files2)
                elif len(files_by_years[0]) < sample_cutoff and len(files_by_years[1]) < sample_cutoff*3:
                    print('recent_years :', recent_years, '   case3')
                    files1 = files_by_years[0] + sampling_without_replacement(files_by_years[1], [], length = (sample_cutoff-len(files_by_years[0])))
                    files2 = sampling_without_replacement(files_by_years[1], files1)
                    files3 = sampling_without_replacement(files_by_years[2], [])
                else:
                    print('recent_years :', recent_years, '   case4')
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[1], [])
                    files3 = sampling_without_replacement(files_by_years[2], [])
                    
            elif len(recent_years) == 2:
                if 2500 <= len(files_by_years[0]) and sample_cutoff*3 <= len(files_by_years[1]):
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[1], [])
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], files1+files2)
                elif len(files_by_years[0]) < sample_cutoff and sample_cutoff*3 <= len(files_by_years[1]):
                    files1 = files_by_years[0] + sampling_without_replacement(files_by_years[1], [], length = (sample_cutoff-len(files_by_years[0])))
                    files2 = sampling_without_replacement(files_by_years[1], files1)
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], files1+files2)
                elif len(files_by_years[0]) < sample_cutoff and len(files_by_years[1]) < sample_cutoff*3:
                    files1 = files_by_years[0] + sampling_without_replacement(files_by_years[1], [], length = (sample_cutoff-len(files_by_years[0])))
                    files2 = sampling_without_replacement(files_by_years[1], files1)
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], [])
                else:
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[1], [])
                    files3 = sampling_without_replacement(files_by_years[0] + files_by_years[1], [])
                    
            elif len(recent_years) == 1:
                if 5000 <= len(files_by_years[0]):
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[0], files1)
                    files3 = sampling_without_replacement(files_by_years[0], [])
                else:
                    files1 = sampling_without_replacement(files_by_years[0], [])
                    files2 = sampling_without_replacement(files_by_years[0], [])
                    files3 = sampling_without_replacement(files_by_years[0], [])
            
            sorted_nuts1, unique_nuts1 = make_doc_nuts_pickle(files1, system_name)
            np.random.shuffle(files1)
            pickle.dump(files1, open('/'.join([save_path,"stage_que1.tlp"]), "wb"))
            pickle.dump((sorted_nuts1, unique_nuts1), open('/'.join([save_path,'unique_nuts_1.tlp']), 'wb'))
            print('\n')
            sorted_nuts2, unique_nuts2 = make_doc_nuts_pickle(files2, system_name)
            np.random.shuffle(files2)
            pickle.dump(files2, open('/'.join([save_path,"stage_que2.tlp"]), "wb"))
            pickle.dump((sorted_nuts2, unique_nuts2), open('/'.join([save_path,'unique_nuts_2.tlp']), 'wb'))
            print('\n')
            sorted_nuts3, unique_nuts3 = make_doc_nuts_pickle(files3, system_name)
            np.random.shuffle(files3)
            pickle.dump(files3, open('/'.join([save_path,"stage_que3.tlp"]), "wb"))
            pickle.dump((sorted_nuts3, unique_nuts3), open('/'.join([save_path,'unique_nuts_3.tlp']), 'wb'))
            print('\n')
        ###########################################################################################################
        # 은행상품설명서
        # 추후 디렉토리 구조에 따라 변경 가능 - 현재는 전체 파일 사용하도록 작성됨
        elif code in ["INITBD000002"]:
            ensure_directory('/'.join([result_home_path, system_name]))
            dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
            
            save_path = '/'.join([result_storage, str(dir_seq)])
            ensure_directory(save_path)
            
            # files = get_target_files(raw_storage)
            # print('This storage has %d files.' % len(files))
        
            # sorted_nuts, unique_nuts = make_doc_nuts_pickle(files)
            # pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
            # pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
            recent_years = recent_year_detection(raw_storage, range=2)
        
            files_by_years = dict()
            for yi, year_str in enumerate(recent_years):
                year_dir = '/'.join([raw_storage, year_str])
                files_by_years[yi] = get_target_files(year_dir)
        
            total_cnt = sum([len(files_by_years[yi]) for yi in files_by_years])
            print('This storage has %d files.' % total_cnt)
            
            if total_cnt <= doc_cutoff:
                files = list()
                for yi in files_by_years:
                    files += files_by_years[yi]
        
            else:
                files = list()
                for yi in list(files_by_years.keys())[:2]:
                    files += files_by_years[yi]

                # 2년만 했는데도 6,000 + 2,000개 넘으면 sampling
                if doc_cutoff+2000 < len(files):
                    files = sampling_without_replacement(files, [])
        
            sorted_nuts, unique_nuts = make_doc_nuts_pickle(files, system_name)
            np.random.shuffle(files)
            pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
            pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
        
        # 기타 시행문
        else:
            ensure_directory('/'.join([result_home_path,system_name,code]))
            dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
            
            save_path = '/'.join([result_storage, str(dir_seq)])
            ensure_directory(save_path)

            if code in ['120000107533', '120000107529']:
                recent_years = recent_year_detection(raw_storage, range=5)
            elif code in ['120000107428']:
                recent_years = recent_year_detection(raw_storage)
            else:
                recent_years = recent_year_detection(raw_storage, range=4)
            print('recent_years :', recent_years)
            files_by_years = dict()
            for yi, year_str in enumerate(recent_years):
                year_dir = '/'.join([raw_storage, year_str])
                files_by_years[yi] = get_target_files(year_dir)
    
            total_cnt = sum([ len(files_by_years[yi]) for yi in files_by_years])
            print('This storage has %d files.' % total_cnt)
            if total_cnt <= doc_cutoff:
                files = list()
                for yi in files_by_years:
                    files += files_by_years[yi]
    
            else:
                files = list()
                for yi in list(files_by_years.keys())[:2]:
                    files += files_by_years[yi]
    
                # 2년만 했는데도 6,000 + 2,000개 넘으면 sampling
                if doc_cutoff+2000 < len(files):
                    files = sampling_without_replacement(files, [])
            # print(files)
            sorted_nuts, unique_nuts = make_doc_nuts_pickle(files, system_name)
            np.random.shuffle(files)
            pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
            pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
    
    # 카드상품 설명서 
    # 추후 디렉토리 구조에 따라 변경 가능
    elif system_name in ["csmcsm"]:
        ensure_directory('/'.join([result_home_path, system_name]))
        dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
        
        save_path = '/'.join([result_storage, str(dir_seq)])
        ensure_directory(save_path)
        
        # files = get_target_files(raw_storage)
        # print('This storage has %d files.' % len(files))
    
        # sorted_nuts, unique_nuts = make_doc_nuts_pickle(files)
        # pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
        # pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
        recent_years = recent_year_detection(raw_storage, range=2)
    
        files_by_years = dict()
        for yi, year_str in enumerate(recent_years):
            year_dir = '/'.join([raw_storage, year_str])
            files_by_years[yi] = get_target_files(year_dir, target_ext=['txt'])
    
        total_cnt = sum([len(files_by_years[yi]) for yi in files_by_years])
        print('This storage has %d files.' % total_cnt)
        
        if total_cnt <= doc_cutoff:
            files = list()
            for yi in files_by_years:
                files += files_by_years[yi]
    
        else:
            files = list()
            for yi in list(files_by_years.keys())[:2]:
                files += files_by_years[yi]

            # 2년만 했는데도 6,000 + 2,000개 넘으면 sampling
            if doc_cutoff+2000 < len(files):
                files = sampling_without_replacement(files, [])
    
        sorted_nuts, unique_nuts = make_doc_nuts_pickle(files, system_name)
        np.random.shuffle(files)
        pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
        pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
    
    # 내규 - 전체 데이터
    elif system_name in ["iemiea"]:
        ensure_directory('/'.join([result_home_path,system_name]))
        dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
        
        save_path = '/'.join([result_storage, str(dir_seq)])
        ensure_directory(save_path)
        
        # files = get_target_files(raw_storage, target_ext=['hwp'])
        files = get_target_files(raw_storage, target_ext=['txt'])
        print('This storage has %d files.' % len(files))
    
        sorted_nuts, unique_nuts = make_doc_nuts_pickle(files, system_name)
        np.random.shuffle(files)
        pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
        pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))
        
    # 기타 시스템
    else:
        ensure_directory('/'.join([result_home_path,system_name]))
        dir_seq = int(get_most_recent_directory(result_storage))+1 # len(os.listdir(result_storage))
        
        save_path = '/'.join([result_storage, str(dir_seq)])
        ensure_directory(save_path)
        
        if system_name in ['iemieb']:
            recent_years = recent_year_detection(raw_storage, range=4)
        elif system_name in ['aikkms']:
            recent_years = recent_year_detection(raw_storage, range=4)
        elif system_name in ['csmcsm']:
            recent_years = recent_year_detection(raw_storage, range=2)
        
        files_by_years = dict()
        for yi, year_str in enumerate(recent_years):
            year_dir = '/'.join([raw_storage, year_str])
            files_by_years[yi] = get_target_files(year_dir)
    
        total_cnt = sum([len(files_by_years[yi]) for yi in files_by_years])
        print('This storage has %d files.' % total_cnt)
        
        if total_cnt <= doc_cutoff:
            files = list()
            for yi in files_by_years:
                files += files_by_years[yi]
    
        else:
            files = list()
            for yi in list(files_by_years.keys())[:2]:
                files += files_by_years[yi]
    
            # 2년만 했는데도 6,000 + 2,000개 넘으면 sampling
            if doc_cutoff+2000 < len(files):
                files = sampling_without_replacement(files, [])
    
        sorted_nuts, unique_nuts = make_doc_nuts_pickle(files, system_name)
        np.random.shuffle(files)
        pickle.dump(files, open('/'.join([save_path,"stage_que.tlp"]), "wb"))
        pickle.dump((sorted_nuts, unique_nuts), open('/'.join([save_path,'unique_nuts_.tlp']), 'wb'))

# pickle 파일 생성 
# base_home_path = "/data/train_data"
# result_home_path = '/data/train_data/ppdata/'

# system_name = "kmswpt" # iemiea, iemieb, csmcsm, aikkms
# code = '120000107537'
# code = '120000107533'
# code = 'INITBD000002'
# code = '120000107428' # 제도
# code = '120000107517' # 마케팅
# code = '120000107529' # 경영평가
# code = '120000107483' # 상품
# code = '120000107537' # 공지
# code = '120000107533' # 인사발령

# system_name = sys.argv[1]
# if system_name == "kmswpt":
#     code = sys.argv[2]
# else:
#     code = ""

# make_preprocessed_pkl_data(system_name, code, base_home_path, result_home_path, doc_cutoff = 6000, sample_cutoff = 2500)

