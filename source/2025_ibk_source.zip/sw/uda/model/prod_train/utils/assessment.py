from __future__ import annotations
from typing import Iterable, List, Sequence, Protocol, TypeVar, Optional
import os, random, hashlib
import inspect
from time import time_ns

T = TypeVar("T")

class _Policy(Protocol[T]):
    def pick(self, items: Sequence[T], boundary: Optioanl[int]) -> List[T]: ...

class _AllPolicy(_Policy[T]):
    def pick(self, items: Sequence[T], boundary: Optional[int]) -> List[T]:
        if boundary is None or boundary >= len(items):
            return List(items)
        return list(items[:boundary])

class _DeterministicSubsetPolicy(_Policy[T]):
    def __init__(self, ratio: Optional[float]=None, seed: Optional[int]=None):
        self.ratio = ratio
        self.seed = seed

    def _score(self, obj: T) -> float:
        key = f"{repr(obj)}::{self.seed}"
        h = hashlib.blake2b(key.encode(), digest_size=4).hexdigest()
        return int(h, 16) / 0xFFFFFFFF

    def pick(self, items: Sequence[T], boundary: Optional[int]) -> List[T]:
        if not items:
            return []
        if self.ratio is not None:
            chosen = [x for x in items if self._score(x) < self.ratio]
            if boundary is not None:
                return chosen[:min(boundary, len(chosen))]
            return chosen
        if boundary is None or boundary >= len(items):
            return list(items)
        scored = sorted(((self._score(x), x) for x in items), key=lambda t: t[0])
        return [x for _, x in scored[:boundary]]

class _StochasticSubsetPolicy(_Policy[T]):
    def __init__(self, seed: Optional[int] = None):
        self._rng = random.Random(seed)
    def pick(self, items: Sequence[T], boundary: Optional[int]) -> List[T]:
        n = len(items)
        if boundary is None or boundary >= n:
            return list(itmes)
        return self._rng.sample(list(items), k=boundary)

def _get_env_float(name:str) -> Optional[float]:
    v = os.getenv(name)
    if not v:
        return None
    try:
        f = float(v)
        if 0.0 <= f <= 1.0:
            return f
    except Exception:
        pass
    return None

def _get_env_int(name:str) -> Optional[int]:
    v = os.getenv(name)
    if not v:
        return None
    try:
        return int(v)
    except Exception:
        return None

def _ctor(cls, **kwargs):
    params = set(inspect.signature(cls.__init__).parameters)
    filtered = {k:v for k, v in kwargs.items() if k in params}
    return cls(**filtered)
    
_MISSING = object()

class ItemAssessor:
    __slots__=("_policy",)

    def __init__(
        self,
        *,
        policy: str | None = None,
        ratio: float | None = None,
        seed: int | None | object = _MISSING,
    ) -> None:
        p = (policy or os.getenv("ASSESSOR_POLICY") or "deterministic").lower()
        r_env = ratio if ratio is not None else _get_env_float("ASSESSOR_RATIO")
        s_env = seed if seed is not None else _get_env_int("ASSESSOR_SEED")
        ratio = ratio if ratio is not None else (float(r_env) if r_env else None)
        if seed is _MISSING:
            seed = time_ns()
        else:
            seed = seed if seed is not None else (int(s_env) if s_env else None)

        if p == "all":
            self._policy = _AllPolicy()
        elif p == "stochastic":
            self._policy = _ctor(_StochasticSubsetPolicy, seed=seed)
        else:
            self._policy = _ctor(_DeterministicSubsetPolicy, ratio=ratio, seed=seed)

    def assessor(self, items: Iterable[T], boundary: Optional[int] = None) -> List[T]:
        seq = items if isinstance(items, Sequence) else list(items)
        return self._policy.pick(seq, boundary)

__all__ = ["ItemAssessor"]