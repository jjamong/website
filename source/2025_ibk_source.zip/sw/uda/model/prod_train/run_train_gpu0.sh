#!/bin/bash

__conda_setup="$('/app/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
                eval "$__conda_setup"
        else
                        source "/app/anaconda3/etc/profile.d/conda.sh"
fi

conda activate cbc_new

nohup python adaptive_csmcsm.py 1> /log/uda/engine/train/train_csmcsm_$(date -d "today" +"%F").log 2>&1
nohup python adaptive_iemieb.py 1> /log/uda/engine/train/train_iemieb_$(date -d "today" +"%F").log 2>&1
nohup python adaptive_kmswpt_120000107533.py 1> /log/uda/engine/train/train_kmswpt_120000107533_$(date -d "today" +"%F").log 2>&1
nohup python adaptive_aikkms.py 1> /log/uda/engine/train/train_aikkms_$(date -d "today" +"%F").log 2>&1

# nohup python adaptive_kmswpt_120000107537_1.py 1> /log/uda/engine/train/train_kmswpt_120000107537_1_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107537_2.py 1> /log/uda/engine/train/train_kmswpt_120000107537_2_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107537_3.py 1> /log/uda/engine/train/train_kmswpt_120000107537_3_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107428.py 1> /log/uda/engine/train/train_kmswpt_120000107428_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107483.py 1> /log/uda/engine/train/train_kmswpt_120000107483_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107517.py 1> /log/uda/engine/train/train_kmswpt_120000107517_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107529.py 1> /log/uda/engine/train/train_kmswpt_120000107529_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmswpt_120000107533.py 1> /log/uda/engine/train/train_kmswpt_120000107533_$(date -d "today" +"%F").log 2>&1

# nohup python adaptive_kmsepn_PLZEPN001.py 1> /log/uda/engine/train/train_kmsepn_PLZEPN001_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmsepn_PLZEPN002.py 1> /log/uda/engine/train/train_kmsepn_PLZEPN002_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmsepn_PLZEPN003.py 1> /log/uda/engine/train/train_kmsepn_PLZEPN003_$(date -d "today" +"%F").log 2>&1
# nohup python adaptive_kmsepn_PLZEPN004.py 1> /log/uda/engine/train/train_kmsepn_PLZEPN004_$(date -d "today" +"%F").log 2>&1