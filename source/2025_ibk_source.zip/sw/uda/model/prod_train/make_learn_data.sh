#!/bin/bash

# export SYSTEM_NAME=${1,,}
# export CODE=$2

# __conda_setup="$('/app/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
# if [ $? -eq 0 ]; then
# 	        eval "$__conda_setup"
# 	else
# 		        source "/app/anaconda3/etc/profile.d/conda.sh" 
# fi

# conda activate cbc

# if [ $SYSTEM_NAME == "kmswpt" ]; then
#     if [[ $CODE != "" ]]; then
#         nohup python make_learn_data.py $SYSTEM_NAME $CODE 1> /log/uda/engine/train/mld.log 2>&1 &
#     else
#         echo "ERROR: kmswpt needs to code"
#     fi
# else
#     nohup python make_learn_data.py $SYSTEM_NAME 1> /log/uda/engine/train/mld.log 2>&1 &
# fi

__conda_setup="$('/app/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
	        eval "$__conda_setup"
	else
		        source "/app/anaconda3/etc/profile.d/conda.sh" 
fi

conda activate cbc_new

nohup python make_learn_data.py 1> /log/uda/engine/train/mld_$(date -d "today" +"%F").log 2>&1 &