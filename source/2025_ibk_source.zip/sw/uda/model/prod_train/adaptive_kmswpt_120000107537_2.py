"""
Created on 2025/06/26
@author: QuantumAI
Note: 시행문 - 공지(120000107537) - ds2
load pickle path & make, weights dir
"""

import numpy as np
import pickle
import time
import common_Copy1 as c
from datetime import datetime
import configparser
import json
import traceback
import os

import tensorflow as tf
import keras

from tensorflow.keras import Model
from tensorflow.keras import Sequential
from tensorflow.keras import layers
from tensorflow.keras import activations
from tensorflow.keras import initializers

from tensorflow.python.ops import math_ops
from tensorflow.python.ops import special_math_ops
from tensorflow.python.ops import array_ops
from tensorflow.python.ops import array_ops_stack
from tensorflow.python.ops import nn_ops

import onSite_20250606 as o

from utils.make_learn_data_process import get_most_recent_directory
from utils.make_weights_dirs import make_weights_dirs
from call_db_api import update_training_model

try:
    config = configparser.ConfigParser()
    config.read("model_config.ini")
    train_config = config["TRAIN"]

    current_filename = os.path.splitext(os.path.abspath(__file__).split("/")[-1])[0]
    filename_splitted = current_filename.split("_")
    if len(filename_splitted) == 2:
        system_name = filename_splitted[-1]
        code = ""
        idx = ""
        sys_key = system_name
        print(f"TRAINING {system_name}")
        weights_path = f'./{system_name}/weights/6_12_deploy_model.weights.h5'
        history_path = f"./{system_name}/weights/history_model.tlp"        
        log_file_path = f"{train_config['log_home_path']}/train_{system_name}_{datetime.today().strftime('%Y-%m-%d')}.log"
        unique_nuts_filename = "unique_nuts_.tlp"
        stage_que_filename = "stage_que.tlp"
    elif len(filename_splitted) == 3:
        system_name = filename_splitted[1]
        if len(filename_splitted[2]) == 1 and filename_splitted[2].isdecimal():
            code = ""
            idx = filename_splitted[2]
            sys_key = "_".join([system_name, idx])
            weights_path = f'./{system_name}/weights/{idx}/6_12_deploy_model.weights.h5'
            history_path = f"./{system_name}/weights/{idx}/history_model.tlp"
            log_file_path = f"{train_config['log_home_path']}/train_{system_name}_{idx}_{datetime.today().strftime('%Y-%m-%d')}.log"
            unique_nuts_filename = f"unique_nuts_{idx}.tlp"
            stage_que_filename = f"stage_que{idx}.tlp"
        else:
            code = filename_splitted[2]
            idx = ""
            sys_key = "_".join([system_name, code])
            print(f"TRAINING {system_name} - {code}")
            weights_path = f'./{system_name}/{code}/weights/6_12_deploy_model.weights.h5'
            history_path = f"./{system_name}/{code}/weights/history_model.tlp"
            log_file_path = f"{train_config['log_home_path']}/train_{system_name}_{code}_{datetime.today().strftime('%Y-%m-%d')}.log"
            unique_nuts_filename = "unique_nuts_.tlp"
            stage_que_filename = "stage_que.tlp"
    else:
        system_name = filename_splitted[1]
        code = filename_splitted[2]
        idx = filename_splitted[3]
        sys_key = "_".join([system_name, code, idx])
        print(f"TRAINING {system_name} - {code} - {idx}")
        weights_path = f'./{system_name}/{code}/weights/{idx}/6_12_deploy_model.weights.h5'
        history_path = f"./{system_name}/{code}/weights/{idx}/history_model.tlp"        
        log_file_path = f"{train_config['log_home_path']}/train_{system_name}_{code}_{idx}_{datetime.today().strftime('%Y-%m-%d')}.log"
        unique_nuts_filename = f"unique_nuts_{idx}.tlp"
        stage_que_filename = f"stage_que{idx}.tlp"    

    gpu = train_config.getint("gpu_3_index")
    print('gpu index :', gpu)

    gpus = tf.config.experimental.list_physical_devices('GPU')
    tf.config.experimental.set_visible_devices(gpus[gpu], 'GPU')
    tf.config.experimental.set_memory_growth(gpus[gpu], True)    

    # 0. get training model id
    sys2id = json.load(open("sys2id.json"))    

    if sys_key not in sys2id:
        print("Not Exist training model id")
        # update_training_model({
        #     "trainingModelId": tm_id,
        #     "status": "FAIL",
        #     "logFilePath": f"{train_config['log_home_path']}/train_{system_name}_{datetime.today().strftime('%Y%m%d')}.log",
        #     "trainingCompletedAt": datetime.today().strftime("%Y-%m-%d %H:%M:%S"),
        #     "updatedBy": "engine"
        # })
    
    else:
        tm_id = sys2id[sys_key]
        
        # 1. get recent pickle dir
        result_home_path = train_config.get("result_home_path")
                
        if code:
            pkl_storage = '/'.join([result_home_path, system_name, code])
        else:
            pkl_storage = '/'.join([result_home_path, system_name])
        
        most_recent_dir = get_most_recent_directory(pkl_storage)
        pkl_dir_path = '/'.join([pkl_storage, most_recent_dir])
        print(pkl_dir_path)
        
        # 2. make weights directory
        make_weights_dirs(system_name, code, idx)
        
        (_, u) = pickle.load(open("/".join([pkl_dir_path, unique_nuts_filename]), 'rb'))
        vocab_size = len(u) + 2
        num_layers = train_config.getint("num_layers")
        d_model = train_config.getint("d_model")
        num_members = train_config.getint("num_members")
        heads = train_config.getint("heads")
        dropout_rate = train_config.getfloat("dropout_rate")
        learning_rate = train_config.getfloat("learning_rate")
        
        seq_len = train_config.getint("seq_len") # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        epochs = train_config.getint("epochs") # 32
        
        print("-" * 50)
        print("model parameters")
        print(f"VOCAB_SIZE : {vocab_size}")
        print(f"NUM_LAYERS : {num_layers}")
        print(f"D_MODEL : {d_model}")
        print(f"NUM_MEMBERS : {num_members}")
        print(f"HEADS : {heads}")
        print(f"DROPOUT_RATE : {dropout_rate}")
        print(f"LEARNING_RATE : {learning_rate}")
        print(f"SEQUENCE_LENGTH : {seq_len}")
        print(f"EPOCHS : {epochs}")
        print("-" * 50)
        print(f"STAGE_QUE : {'/'.join([pkl_dir_path, stage_que_filename])}")
        print(f"UNIQUE_NUTS : {'/'.join([pkl_dir_path, unique_nuts_filename])}")
        print(f"WEIGHTS : {weights_path}")
        print(f"LOG : {log_file_path}")
        print("-" * 50)
        
        inputs = layers.Input(shape = (None,), dtype = 'float32')
        nlogits, elogits = o.onSiteModel0(vocab_size, num_layers, d_model, seq_len, num_members, heads, dropout_rate)(inputs)
        model = Model(inputs = inputs, outputs = [nlogits, elogits])
        ########################################################################################################
        # model.load_weights('./weights/12_8_deploy_model_1.weights.h5')
        ########################################################################################################
        model.summary()
        
        optimizer = tf.keras.optimizers.Adam(learning_rate)
        optimizer.build(model.trainable_variables)
        
        nloss_ = tf.losses.SparseCategoricalCrossentropy(from_logits = True)
        
        def eloss_(true, pred):
            loss_object = tf.keras.losses.KLDivergence()
            pred = tf.nn.softmax(pred, axis = -1)
            loss = loss_object(true, pred)
            return loss
        
        @tf.function(reduce_retracing = True)
        def update(iepoch, inputs, ntargets, etargets, accumulated_gradients):
                
            with tf.GradientTape() as tape:
                logits, nuts_distn = model(inputs)    
                train_nloss = nloss_(ntargets, logits)
                train_eloss = eloss_(etargets, nuts_distn)
                train_loss = train_nloss + train_eloss
        
                gradients = tape.gradient(train_loss, model.trainable_variables)
                accumulated_gradients = [accumulated_gradient + gradient 
                                         for accumulated_gradient, gradient in zip(accumulated_gradients, gradients)]
                    
            if (iepoch + 1) % ACCUMULATION_STEP == 0:
                accumulated_gradients = [gradient / ACCUMULATION_STEP for gradient in accumulated_gradients]
                optimizer.apply_gradients(zip(accumulated_gradients, model.trainable_variables))
        
            return train_nloss, train_eloss, train_loss
        
        stage_que = pickle.load(open("/".join([pkl_dir_path, stage_que_filename]), "rb"))
        
        history = list()
        previous_loss = 1E+9 * 1.
        PATIENCE = 0
        for epoch in range(epochs):
        
            (_, unique_nuts) = pickle.load(open("/".join([pkl_dir_path, unique_nuts_filename]), 'rb'))
        
            frame_size = 95
            frame_step = 8
            min_sen = 8
            DEPLOY_SIZE = 500
            num_docs = DEPLOY_SIZE // 2
            
            stage_que = stage_que
            
            dataset = c.make_dataset_deploy(stage_que, frame_size, frame_step, min_sen, num_docs)
            np.random.shuffle(dataset)
            print('Info: raw dataset outlines', num_docs, len(dataset), len(dataset) // num_docs)
        
            BATCH_SIZE = 96
            ACCUMULATION_STEP = 1 # 128 mimic 16 GPUs
            UPDATE_STEPS = 256
            D_SIZE = (BATCH_SIZE * ACCUMULATION_STEP) * UPDATE_STEPS
            print(D_SIZE)
            
            #if D_SIZE > len(dataset):
            #    print('Info: generated dataset has %d examples. Asked %d D_SIZE larger than it. Skip %d epoch' % (len(dataset), D_SIZE, epoch) )
            #    pass
            if D_SIZE > len(dataset):
                print('Info: generated dataset has %d examples. Asked %d D_SIZE larger than it at %d epoch' % (len(dataset), D_SIZE, epoch) )
                # D_SIZE resizing
                ADJ_UPDATE_STEPS = len(dataset) // (BATCH_SIZE * ACCUMULATION_STEP) 
                D_SIZE = (BATCH_SIZE * ACCUMULATION_STEP) * ADJ_UPDATE_STEPS
                print("Recalculated D_SIZE : %d" % D_SIZE)
                print('Info: D_SIZE recalculated. ADJ_UPDATE_STEPS: %d' % ADJ_UPDATE_STEPS)
                
            dataset = dataset[:D_SIZE]
            np.random.shuffle(dataset)
        
            TRAIN_EXAMPLES = len(dataset)
            TRAIN_TAKE = TRAIN_EXAMPLES // BATCH_SIZE
            STEPS_PER_EPOCH = (TRAIN_TAKE // ACCUMULATION_STEP) * ACCUMULATION_STEP 
            INFERENCE_STEP = STEPS_PER_EPOCH
            print('Info: epoch steps:', TRAIN_EXAMPLES, TRAIN_TAKE, INFERENCE_STEP)
            # Nuts length
            # nuts_length = (len(unique_nuts) // 1000 + 1) * 1000
            nut_to_idx = tf.keras.layers.StringLookup(
                vocabulary = unique_nuts, num_oov_indices = 1, mask_token = '', oov_token = chr(0),
            )
        
            idx_to_nut = tf.keras.layers.StringLookup(
                vocabulary = nut_to_idx.get_vocabulary(), invert = True,  num_oov_indices = 1, mask_token = '', oov_token = chr(0)
            )
        
            NUTS_DISTRIBUTION_LENGTH = len(nut_to_idx.get_vocabulary())
        
            print('Info: # of nuts :', len(nut_to_idx.get_vocabulary()), len(unique_nuts))
        
            print(nut_to_idx.get_vocabulary()[:20])
            print(nut_to_idx.get_vocabulary()[-20:])
        
            def get_example(nuts):
                label = nut_to_idx(nuts)
                
                target = tf.one_hot(label[1:], NUTS_DISTRIBUTION_LENGTH)
                target = tf.reduce_sum(target, axis = 0)
                target = tf.cast(tf.math.not_equal(target, tf.constant(0., tf.float32)), tf.float32)
                target = target / tf.reduce_sum(target)
        
                return label[:-1], (label[1:], target)
                
            dataset = tf.ragged.constant(dataset)
            train_dataset = (tf.data.Dataset.from_tensor_slices(dataset))
            train_dataset = (train_dataset.map(get_example)
                                .padded_batch(BATCH_SIZE, padded_shapes = ((None,), ((None,), (None,))), drop_remainder = True)
                            )
        
            inputs, (outputs, target) = next(iter(train_dataset))
            print('Info: Feed data shapes', inputs.shape, outputs.shape, target.shape)
        
        
            eloss, tloss = 0., 0.
            enloss, tnloss = 0., 0.
            eeloss, teloss = 0., 0.
            
            accumulated_gradients = [tf.zeros_like(variable) for variable in model.trainable_variables]
                
            start_time = time.time()
            
            for iepoch , (inputs, (ntargets, etargets)) in enumerate(train_dataset.take(STEPS_PER_EPOCH)):
        
                train_nloss, train_eloss, train_loss = update(tf.constant(iepoch), inputs, ntargets, etargets, accumulated_gradients)
                
                inloss = train_nloss.numpy()
                tnloss += inloss
                enloss += inloss
            
                ieloss = train_eloss.numpy()
                teloss += ieloss
                eeloss += ieloss
            
                iloss = train_loss.numpy()
                tloss += iloss
                eloss += iloss
                    
                print('\r%03d' % (iepoch + 1), sep = '', end = '')
        
                if (iepoch + 1) % ACCUMULATION_STEP == 0:
                    print('\rloss at %04d: %.4f <%.4f, %.4f> took %.4fs' 
                          % ((iepoch + 1), 
                             tloss / ACCUMULATION_STEP, 
                             tnloss / ACCUMULATION_STEP, 
                             teloss / ACCUMULATION_STEP, 
                             (time.time() - start_time)), sep = '', end = '')
        
                    accumulated_gradients = [tf.zeros_like(variable) for variable in model.trainable_variables]
                    tloss, tnloss, teloss = 0., 0., 0.
                
                
            print('\n\t\t\t\t\t\t\tEpoch %03d - loss: %.4f <%.4f, %.4f>' % (epoch, (eloss / INFERENCE_STEP), (enloss / INFERENCE_STEP), (eeloss / INFERENCE_STEP) ) )
            history.append( [(eloss / INFERENCE_STEP), (enloss / INFERENCE_STEP), (eeloss / INFERENCE_STEP)] )
        
            print(datetime.today().strftime("%Y-%m-%d %H:%M:%S"))
            model.save_weights(weights_path)
            pickle.dump(history, open(history_path, "wb"))
            
            # Early Stopping
            if (enloss / INFERENCE_STEP) < 0.3 or (eeloss / INFERENCE_STEP) < 0.3:
                PATIENCE += 1
                print("\n\t\t\t\t\t\t\tTrain PATIENCE changed %d. ---> Epoch %03d" % (PATIENCE, epoch))
                
            if PATIENCE > 2:    
                print("\n\t\t\t\t\t\t\tTrain Early Stopped ---> Epoch %03d" % (epoch))
                break

        update_training_model({
            "trainingModelId": tm_id, 
            "status": "SUCCESS", 
            "logFilePath": log_file_path,
            "trainingCompletedAt": datetime.today().strftime("%Y-%m-%d %H:%M:%S"), 
            "updatedBy": "engine"
        })

except Exception as e:
    print(traceback.format_exc())
    update_training_model({
        "trainingModelId": tm_id,
        "status": "FAIL",
        "logFilePath": log_file_path,
        "trainingCompletedAt": datetime.today().strftime("%Y-%m-%d %H:%M:%S"),
        "updatedBy": "engine"
    })    
    
