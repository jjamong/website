/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  swcMinify: false,
  pageExtensions: ['js', 'jsx'],
  trailingSlash: false,
  images: {
      unoptimized: false,
    //   remotePatterns: [
    //       {
    //           protocol: 'https',
    //           // hostname: 'dongast-zarada.com',
    //           hostname: '10.1.243.105',
    //           port: '',
    //           pathname: '/**',
    //       },
    //   ],
  },
  async rewrites() {
      return [
          {
              source: '/api/:path*', // 사용할 api의 엔드포인트
              destination: process.env.NEXT_PUBLIC_API_SERVER_URL + '/api/:path*', // /app을 대체할 api 엔드포인트
          },
      ];
  },
};

export default nextConfig;
