# 개요

동아ST ZARADA 앱 고도화 프로젝트 Frontend (Next.js)

### 세트 프로젝트

- zarada_back
- zarada_front
- zarada_rn

# 실행

1. install

    ```
    npm install
    ```

2. `.env.development` File의 front/back 설정 ip 및 port가 제대로 설정 되어 있는지 확인

3. start

    ```
    npm run dev
    ```
   
# 로컬 환경에서 실제 운영방식으로 테스트 하는 법

1. build

    ```
    npm run build
    ```

2. build 후 생성 된 out폴더 복사 후 backend 소스경로(`src\main\resources`)에 붙여넣기

3. backend 실행 후 backend port로 접속 ex)`localhost:8080`
