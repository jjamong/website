import axios from "axios"
import {getAccessToken, removeAccessToken, setAccessToken} from '@/utils/Libs/Methods/authToken'

//사용자 지정 config로 axios 인스턴스 생성
const axiosClient = axios.create()

//전역 axios 기본값 설정
axiosClient.defaults.headers['Content-Type'] = 'application/json'
axiosClient.defaults.headers['Accept'] = 'application/json'
axiosClient.defaults.method = 'POST'
axiosClient.defaults.withCredentials = true

let isAlertShown = false

//요청 인터셉터
axiosClient.interceptors.request.use(
    config => {
        // 설정에 토큰 전달
        const token = getAccessToken()
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`
        }

        // 로그인 시 오류 alert 플래그 초기화
        if(config.url === '/api/extra/LoginController/autoLogin' || config.url === '/api/extra/LoginController/login') {
            isAlertShown = false
        }

        return config
    },
    error => {
        return Promise.reject(error)
    }
)

//응답 인터셉터
axiosClient.interceptors.response.use(
    // 응답 데이터
    res => {
        if(!res.data.status) {
            alert(res.data.msg)
            return Promise.reject(res)
        }

        return res
    },
    // 오류 응답 처리
    async err => {
        const originalConfig = err.config
        const { status } = err.response
        // 로그인이 아니고 응답이 존재할 때
        if (originalConfig.url !== '/api/extra/LoginController/login' && err.response) {
            // http status가 901(토큰 유효시간 만료) 이고 재시도 하지 않은 경우
            if (status === 901 && !originalConfig._retry) {
                originalConfig._retry = true

                try{
                    const response = await axios({
                        method: 'POST',
                        url: '/api/extra/LoginController/reissue',
                        data: {},
                        withCredentials: true
                    })

                    if(response.status) {
                        const access = response.data.data[0].accessToken

                        setAccessToken(access)
                    } else {
                        if(!isAlertShown) {
                            isAlertShown = true
                            alert(response.data.msg)

                            removeAccessToken()
                            sessionStorage.clear()

                            window.location.href = window.location.origin
                        }
                    }

                    return axiosClient(originalConfig)
                } catch (_error) {
                    if(!isAlertShown) {
                        isAlertShown = true
                        removeAccessToken()
                        sessionStorage.clear()
                        alert('세션이 만료되었습니다. 다시 로그인해 주세요')
                        window.location.href = window.location.origin

                        return Promise.reject(_error)
                    }
                }
            }
            // http status가 403(권한이 없는 경우)
            if (status === 403) {
                alert('권한이 없습니다.')

                // 이전 페이지로 이동
                window.history.back()

                return Promise.reject(err)
            }

            // http status가 900(토큰이 없거나 올바르지 않은 토큰일 때)
            if (status === 900) {
                if(!isAlertShown) {
                    isAlertShown = true
                    removeAccessToken()
                    sessionStorage.clear()
                    alert('토큰이 올바르지 않습니다. 다시 로그인해 주세요')
                    window.location.href = window.location.origin

                return Promise.reject(err)
                }
            }

            if (status === 902) {
                if(!isAlertShown) {
                    isAlertShown = true
                    removeAccessToken()
                    sessionStorage.clear()
                    alert('세션이 만료되었습니다. 다시 로그인해 주세요')
                    window.location.href = window.location.origin

                    return Promise.reject(err)
                }
            }

            return Promise.reject(err)
        }
    }
)

export default axiosClient
