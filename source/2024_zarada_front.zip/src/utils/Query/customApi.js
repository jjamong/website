import {useMutation, useQuery} from "@tanstack/react-query";
import axios from '@/utils/Axios/axiosInstance';


export const useCallQuery = ({url, param = {}, onSuccess, onError= undefined, enabled = false}) => {
    let {refetch, isFetching} = useQuery([url, param], async () => {
        const response =
            await axios({
                url:url,
                data: param,
            });
        return response.data.data;
    }, {
        enabled: enabled,
        onSuccess: onSuccess,
        onError: onError,
    });

    let response = {
        call: refetch,
        isReady: !isFetching,
    }

    return response;
}

export const useCallMutation = ({url, param = {}, onSuccess, onError=undefined}) => {
    let {mutate, isLoading } = useMutation([url, param], async () => {
        const response =
            await axios({
                url: url,
                data: param,
            });
        return response.data.data;
    }, {
        onSuccess: onSuccess,
        onError: onError,
    });

    let response = {
        call: mutate,
        isReady: !isLoading,
    }

    return response;
}

export const useCallApi = (data) => {
    const isSelect = data.url.toLowerCase().includes('select') || data.url.toLowerCase().includes('check') || data.url.toLowerCase().includes('find') || data.url.toLowerCase().includes('nice') || data.url.toLowerCase().includes('logincontroller');
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return isSelect ? useCallQuery(data) : useCallMutation(data);
}