import {atom} from "recoil";
import {recoilPersist} from "recoil-persist";

const sessionStorage =
  typeof window !== "undefined" ? window.sessionStorage : undefined;

//sessionStorage 사용을 위해 추가해야하는 코드
const{ persistAtom } = recoilPersist({
  key:'zarada',
  storage:sessionStorage
});

const recoilUser = atom({
  key:'user',
  default: {},
  effects_UNSTABLE:[persistAtom]
});

const recoilChild = atom({
  key:'child',
  default: {},
  effects_UNSTABLE:[persistAtom]
});

const recoilInjSeq = atom({
  key:'injSeq',
  default: 0,
  effects_UNSTABLE:[persistAtom]
});

const recoilGrowthSeq = atom({
  key:'growthSeq',
  default: 0,
  effects_UNSTABLE:[persistAtom]
});

const recoilMenuActive = atom({
  key: 'frontMenu',
  default: false,
  effects_UNSTABLE:[persistAtom]
})

const recoilDevice = atom({
  key: 'deviceType',
  default: 'web',
  effects_UNSTABLE:[persistAtom]
})

export { recoilUser, recoilChild, recoilInjSeq, recoilGrowthSeq, recoilMenuActive, recoilDevice }
