const AppStatBtn = (props) => {
    const {appStatClick} = props
    const {appStatCd} = props.selectUserDetailRes

    return (
        <>
            {
                // 미승인
                appStatCd === '10' &&
                    <div className='single-btn-area'>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('20')}>승인</div>
                        </div>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('40')}>차단</div>
                        </div>
                    </div>
            }
            {
                // 승인
                appStatCd === '20' &&
                    <div className='single-btn-area'>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('30')}>승인 취소</div>
                        </div>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('40')}>차단</div>
                        </div>
                    </div>
            }
            {
                // 승인 취소
                appStatCd === '30' &&
                    <div className='single-btn-area'>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('20')}>승인</div>
                        </div>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('40')}>차단</div>
                        </div>
                    </div>
            }
            {
                // 차단
                appStatCd === '40' &&
                    <div className='single-btn-area'>
                        <div className='single-btn'>
                            <div className='active btn' onClick={() => appStatClick('20')}>승인</div>
                        </div>
                    </div>
            }
        </>
    )
}

export default AppStatBtn