import LabelInput from "@/components/commons/LabelInput";
import LabelRadio from "@/components/commons/LabelRadio";
import LabelSelect from "@/components/commons/LabelSelect";

const ChildForm = (props) => {
    const {selectUserChildListRes, selectHospitalComboRes, items, childChangeHanlder} = props

    return (
        selectUserChildListRes.map((child, index) => {
            return (
                <div className="section child-section" key={child.childSeq}>
                    <div className="title">아이 정보</div>
                    <div className="content">
                        <LabelInput title={'아이 이름'}
                                    id={'childName'}
                                    type={'text'}
                                    value={child.childName}
                                    isReadOnly={true}
                                    isDisabled={true}
                                    inputClass={'disabled'}
                        />
                        <div className="form-item">
                            <label htmlFor="genderCd" className="tit">아이 성별</label>
                            <div className="radio-section">
                                <LabelRadio id={'childSexMan'}
                                            name={`genderCd-${index}`}
                                            value={'M'}
                                            checked={child.genderCd === 'M'}
                                            labelTitle={'남자'}
                                            isReadOnly={true}
                                            isDisabled={true}
                                            customClass={child.genderCd === 'M' ? undefined : 'disabled'}
                                />
                                <LabelRadio id={'childSexFemale'}
                                            name={`genderCd-${index}`}
                                            value={'F'}
                                            checked={child.genderCd === 'F'}
                                            labelTitle={'여자'}
                                            isReadOnly={true}
                                            isDisabled={true}
                                            customClass={child.genderCd === 'F' ? undefined : 'disabled'}
                                />
                            </div>
                        </div>
                        <LabelInput title={'아이 생년월일'}
                                    id={'birthday'}
                                    type={'date'}
                                    value={child.birthday}
                                    isReadOnly={true}
                                    isDisabled={true}
                                    inputClass={'disabled'}
                        />
                        <LabelSelect customClass={'itemCd'} id={`itemCd-${child.childSeq}`} title={'카트리지'}
                                     value={child.itemCd} changeHandler={childChangeHanlder} datas={items}/>
                        <LabelSelect customClass={'hospitalNm'} id={`hospitalNm-${child.childSeq}`} title={'병원명'}
                                     value={child.hospitalNm} changeHandler={childChangeHanlder}
                                     datas={selectHospitalComboRes}/>
                        <LabelInput title={'의사명'} id={`doctorNm-${child.childSeq}`} type={'text'} value={child.doctorNm}
                                    placeholder={'의사명을 입력해 주세요.'} changeHandler={childChangeHanlder}/>
                    </div>
                </div>
            )
        })
    )
}

export default ChildForm