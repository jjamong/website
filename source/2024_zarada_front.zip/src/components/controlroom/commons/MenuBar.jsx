import {useRouter} from "next/router";
import {removeAccessToken} from "@/utils/Libs/Methods/authToken";
import {useEffect} from "react";
import {useRecoilState} from "recoil";
import {recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";
import {cdNaConvert} from "@/utils/Libs/Methods/commonUtils";

const MenuBar = (props) => {
    const {menuActive, menuClose} = props;
    const router = useRouter();
    const [rUser, setRUser] = useRecoilState(recoilUser)

    const logoutObj = {
        url: '/api/user/LoginController/logout',
        param: {},
        onSuccess: (data) => {
            removeAccessToken()
            sessionStorage.clear()
            window.location.href = window.location.origin
        }
    }
    const logout = useCallApi(logoutObj)

    const logoutClick = () => {
        logout.isReady && logout.call()
    }

    useEffect(() => {
        if(!menuActive) {
            document.body.classList.remove('scroll-lock')
        }
    }, [menuActive]);

    return (
        <div className={`admin-menubar ${(menuActive) ? 'active' : ''}`}>
            <div className="top-area">
                <div className="top">
                    <div className="logo"><img src="/img/common_menu_logo.png" alt="zarada" /></div>
                    <div className="close btn" onClick={menuClose}>
                        <div className="img"><img src="/img/common_menu_close_btn.png" alt="zarada" /></div>
                    </div>
                </div>
                <div className="info-area">
                    <div className="child">
                        <div className="name-area"><span className="name">{rUser.userName}</span> / <span className="type">{cdNaConvert('role', rUser.role)}</span> </div>
                    </div>
                </div>
            </div>
            <ul className="main-menu-list">
                <li>
                    <div className="main-menu-area" onClick={() => router.push('/controlroom/users')}>
                        <div className="txt">회원 정보</div>
                        <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="회원정보 페이지 이동" /></div>
                    </div>
                </li>
                {
                    rUser.role === 'ROLE_ADMIN' &&
                    <li>
                        <div className="main-menu-area" onClick={() => router.push('/controlroom/admins')}>
                            <div className="txt">간호사 관리</div>
                            <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="사용자관리 페이지 이동"/></div>
                        </div>
                    </li>
                }
                <li>
                    <div className="main-menu-area" onClick={() => router.push('/controlroom/adminInjectionMethod')}>
                        <div className="txt">주사 방법</div>
                        <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="주사방법 페이지 이동"/></div>
                    </div>
                </li>
                <li>
                    <div className="main-menu-area" onClick={() => router.push('/controlroom/notice')}>
                        <div className="txt">공지사항</div>
                        <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="공지사항 페이지 이동" /></div>
                    </div>
                </li>
            </ul>
            <div className="logout-area" onClick={logoutClick}>
                <div className="logout btn">로그아웃</div>
            </div>
        </div>
    );
}

export default MenuBar;