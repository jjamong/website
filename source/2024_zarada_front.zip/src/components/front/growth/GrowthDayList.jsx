import {dateFormat, excelFunc, numberFormat} from "@/utils/Libs/Methods/commonUtils";

const GrowthDayList = (props) => {
    const {growthList, updateToGrowthForm} = props;

    return(
        <ul>
            {
                growthList.length > 0 ?
                    growthList.map((data, index) => {
                        return (
                            <li key={index}>
                                <div className="date-section">
                                    <div className="date">{dateFormat(data.recordDy, 'yymmdd', '.')}</div>
                                    <div className="administration-date">
                                        {Number(data.injDays) > 0 ? `투여+${data.injDays}` : ''}
                                    </div>
                                </div>
                                <div className="info-section">
                                    <div className="height">
                                        키 : <span className="numerical">{numberFormat(Number(data.childHeight), false, 1)}</span>cm / <span className="numerical">{numberFormat(Number(excelFunc('NORMSDIST', data.childHeightPercent)), false, 1)}</span>%
                                    </div>
                                    <div className="weight">
                                        몸무게 : <span className="numerical">{numberFormat(Number(data.childWeight), false, 1)}</span>kg / <span className="numerical">{numberFormat(Number(excelFunc('NORMSDIST',data.childWeightPercent)), false, 1)}</span>%
                                    </div>
                                    <div className="bmi">
                                        BMI : <span className="numerical">{numberFormat(Number(data.childBmi), false, 1)}</span>kg/㎡
                                        {
                                            (data.childBmiPercent > 0) ?
                                                <>/ <span className="numerical">{numberFormat(Number(excelFunc('NORMSDIST',data.childBmiPercent)), false, 1)}</span>%</>
                                                : <></>
                                        }
                                    </div>
                                </div>
                                <div className="btn-section">
                                    <div className="btn" onClick={() => updateToGrowthForm(data.recordDy)}><img src="/img/growth_day_list_btn.png" alt="수정"/></div>
                                </div>
                            </li>
                        );
                    })
                : <li><div className="nodata">기록 정보가 없습니다.</div></li>
            }
        </ul>
    );
}

export default GrowthDayList