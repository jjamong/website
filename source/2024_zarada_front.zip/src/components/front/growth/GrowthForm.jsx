import {recoilChild, recoilGrowthSeq} from "@/utils/Store/atom";
import {useRecoilState} from "recoil";
import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import {dateFormat, setParam} from "@/utils/Libs/Methods/commonUtils";
import {useCallApi} from "@/utils/Query/customApi";
import {saveGrowthValidate} from "@/utils/Libs/Methods/userValidate";

const today = new Date()
const year = today.getFullYear()
const month = today.getMonth() + 1
const date = today.getDate()
const _today = `${year}${month < 10 ? `0${month}` : month}${date < 10 ? `0${date}` : date}`

const GrowthForm = () => {
    const router = useRouter()
    const {growthYmd} = router.query

    // recoil
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const [growthSeq, setGrowthSeq] = useRecoilState(recoilGrowthSeq)
    const [growthDate, setGrowthDate] = useState('')

    // query
    // 성장기록 조회
    const [selectChlGrthRes, setSelectChlGrthRes] = useState({
        growthSeq: 0,
        recordDy: dateFormat(_today, 'yyyymmdd', '-'),
        childHeight: 0,
        childWeight: 0,
        recordComment: "",
        childSeq: rChild.childSeq,
    })
    const selectChlGrthObj = {
        url: '/api/user/GrowthController/selectMyChildGrowth',
        param: {
            childSeq: rChild.childSeq,
            recordDy: growthDate,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setGrowthSeq(0)
                setParam(setSelectChlGrthRes, {
                    recordDy: growthDate,
                })
                return
            }

            setSelectChlGrthRes(data[0])
            setGrowthSeq(data[0].growthSeq)
        }
    }
    const selectChlGrth = useCallApi(selectChlGrthObj)

    // 성장기록 저장
    const saveChlGrthObj = {
        url: '/api/user/GrowthController/saveMyChildGrowth',
        param: selectChlGrthRes,
        onSuccess: (res) => {
            alert('성장 기록이 저장되었습니다.')
            router.replace('/front/growth')
        }
    }

    const saveChlGrth = useCallApi(saveChlGrthObj)

    // func
    const inputChangeHandler = (id, e) => {
        const {value} = e.target

        if(id === 'growthDate') {
            setParam(setSelectChlGrthRes, {recordDy: value})
            setGrowthDate(value)
        }

        if(id === 'stature') {
            const nValue = Number(value)
            if(nValue >= 1000) return
            setParam(setSelectChlGrthRes, {childHeight: Math.floor(nValue * 10) / 10})
        }

        if(id === 'weight') {
            const nValue = Number(value)

            if(nValue >= 1000) return
            setParam(setSelectChlGrthRes, {childWeight: Math.floor(nValue * 10) / 10})
        }
    }

    const growthSave = () => {
        const {status, msg, elem} = saveGrowthValidate(selectChlGrthRes)

        if(!status) {
            alert(msg)
            return
        }

        if(Number(rChild.birthday.replaceAll('-', '') > Number(selectChlGrthRes.recordDy.replaceAll('-', '')))) {
            alert('생일 이전 날짜는 기록하실 수 없습니다.')
            return
        }

        if(!confirm('저장하시겠습니까?')) return

        saveChlGrth.isReady && saveChlGrth.call()
    }

    useEffect(() => {
        if(!router.isReady) return

        setGrowthDate(dateFormat(growthYmd, 'yyyymmdd', '-'))
    }, [router.isReady])

    useEffect(() => {
        if(!growthDate) return

        selectChlGrth.isReady && selectChlGrth.call()
    }, [growthDate])

    return (
        <main id="container" className="container growth day_form">
            <div className="wrap">
                <div className="content-area">
                    <div className="content">
                        <div className="date-area">
                            <div className="input"><input type="date" value={selectChlGrthRes.recordDy} onChange={(e) => inputChangeHandler('growthDate', e)}/></div>
                        </div>
                        <div className="form-area">
                            <div className="form-item">
                                <div className="input-area">
                                    <div className="input-text"><input id="stature" type="number" placeholder="키" value={selectChlGrthRes.childHeight === 0 ? '' : selectChlGrthRes.childHeight} onChange={(e) => inputChangeHandler('stature', e)}/></div>
                                    <span>cm</span>
                                </div>
                            </div>
                            <div className="form-item">
                                <div className="input-area">
                                    <div className="input-text"><input id="weight" type="number" placeholder="몸무게" value={selectChlGrthRes.childWeight === 0 ? '' : selectChlGrthRes.childWeight} onChange={(e) => inputChangeHandler('weight', e)}/>
                                    </div>
                                    <span>kg</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="noti-area">
                        <div className="noti">*소수점 1자리까지 입력해 주세요.</div>
                    </div>
                    <div className="btn-area">
                        <div className='btn' onClick={() => router.back()}>취소</div>
                        <div className="btn save active" onClick={growthSave}>성장기록</div>
                    </div>
                </div>
            </div>
        </main>
    )
}

export default GrowthForm
