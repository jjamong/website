import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import {excelFunc, numberFormat} from "@/utils/Libs/Methods/commonUtils";
import {CategoryScale, Chart as ChartJS, Filler, Legend, LinearScale, LineElement, PointElement, Title, Tooltip} from 'chart.js'
import {Line} from 'react-chartjs-2'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler)

const GrowthGraph = (props) => {
    const {selectGrowthChartRes, selectMyChildGrowthRes, graphViewType, graphViewTypeClickHandler, graphType, graphTypeClickHandler, addToGrowthForm} = props;
    const router = useRouter();
    const [data, setData] = useState()
    const [options, setOptions] = useState()

    useEffect(() => {
        if (selectGrowthChartRes && selectGrowthChartRes[0]) {

            let labels
            if (graphViewType === 'year') {
                labels = selectGrowthChartRes[0].age.split('/')
            } else {
                if (selectGrowthChartRes[0].month) {
                    labels = selectGrowthChartRes[0].month.split('/')
                }
            }

            let datasets = [
                {
                    borderColor: '#7C53DD',
                    backgroundColor: '#7C53DD',
                    pointRadius: 2,
                }
            ]
            if (graphType === 'height') {
                datasets[0].label = '우리아이'
                datasets[0].data = selectGrowthChartRes[0].childHeight.replaceAll('-1', undefined).split('/')

                datasets.push({
                    label: '상위 5%',
                    data: selectGrowthChartRes[0].val95.split('/'),
                    borderColor: '#FCE1E1',
                    backgroundColor: '#FCE1E1',
                    pointRadius: 2,
                })
                datasets.push({
                    label: '평균',
                    data: selectGrowthChartRes[0].val50.split('/'),
                    borderColor: '#CCF9DA',
                    backgroundColor: '#CCF9DA',
                    pointRadius: 2,
                })
                datasets.push({
                    label: '하위 5%',
                    data: selectGrowthChartRes[0].val5.split('/'),
                    borderColor: '#CCEFFF',
                    backgroundColor: '#CCEFFF',
                    pointRadius: 2,
                })
                
            } else if (graphType === 'weight') {
                datasets[0].label = '우리아이'
                datasets[0].data = selectGrowthChartRes[0].childWeight.replaceAll('-1', undefined).split('/')

                datasets.push({
                    label: '상위 5%',
                    data: selectGrowthChartRes[0].val95.split('/'),
                    borderColor: '#FCE1E1',
                    backgroundColor: '#FCE1E1',
                    pointRadius: 2,
                })
                datasets.push({
                    label: '평균',
                    data: selectGrowthChartRes[0].val50.split('/'),
                    borderColor: '#CCF9DA',
                    backgroundColor: '#CCF9DA',
                    pointRadius: 2,
                })
                datasets.push({
                    label: '하위 5%',
                    data: selectGrowthChartRes[0].val5.split('/'),
                    borderColor: '#CCEFFF',
                    backgroundColor: '#CCEFFF',
                    pointRadius: 2,
                })

            } else {
                datasets[0].label = '우리아이'
                datasets[0].data = selectGrowthChartRes[0].childBmi.replaceAll('-1', undefined).split('/')
                
                datasets.push({
                    label: '저체중',
                    data: selectGrowthChartRes[0].val5.split('/'),
                    borderColor: '#CCEFFF',
                    backgroundColor: '#CCEFFF',
                    pointRadius: 2,
                    fill: true
                })
                datasets.push({
                    label: '정상',
                    data: selectGrowthChartRes[0].val85.split('/'),
                    borderColor: '#CCF9DA',
                    backgroundColor: '#CCF9DA',
                    pointRadius: 2,
                    fill: true
                })
                datasets.push({
                    label: '과체중',
                    data: selectGrowthChartRes[0].val95.split('/'),
                    borderColor: '#FCE1E1',
                    backgroundColor: '#FCE1E1',
                    pointRadius: 2,
                    fill: true
                })
                datasets.push({
                    label: '비만',
                    data: [30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
                    borderColor: '#f78f8f',
                    backgroundColor: '#f78f8f',
                    pointRadius: 2,
                    fill: true
                })
            }
            
            setData({ labels, datasets })

            let totalDuration = 250;
            let delayBetweenPoints = totalDuration / 19;
            let previousY = (ctx) => ctx.index === 0 ? ctx.chart.scales.y.getPixelForValue(100) : ctx.chart.getDatasetMeta(ctx.datasetIndex).data[ctx.index - 1].getProps(['y'], true).y;
            let animation = {
                x: {
                    type: 'number',
                    easing: 'linear',
                    duration: delayBetweenPoints,
                    from: NaN, // the point is initially skipped
                    delay(ctx) {
                    if (ctx.type !== 'data' || ctx.xStarted) {
                        return 0;
                    }
                    ctx.xStarted = true;
                    return ctx.index * delayBetweenPoints;
                    }
                },
                y: {
                    type: 'number',
                    easing: 'linear',
                    duration: delayBetweenPoints,
                    from: previousY,
                    delay(ctx) {
                    if (ctx.type !== 'data' || ctx.yStarted) {
                        return 0;
                    }
                    ctx.yStarted = true;
                    return ctx.index * delayBetweenPoints;
                    }
                }
            };
            setOptions({
                responsive: true,
                animation,
                // x축, y축 설정
                scales: {
                    x: {
                        grid: {
                            drawOnChartArea: false,
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: (graphType === 'height') ? 'cm' : (graphType === 'weight') ? 'kg' : 'kg/㎡',
                            align : 'end'
                        },
                    },
                },
                // 마우스 오버 시 전체 항목 출력
                interaction: {
                    intersect: false,
                    mode: 'index',
                },
                plugins: {
                    legend: {
                        display: true,
                        labels: {
                            boxWidth: 6,
                            boxHeight: 6,
                            padding: 15,
                            font: {
                                size : 10
                            }
                        },
                    }
                }
            }) 
        }
    }, [selectGrowthChartRes])

    

    return (
        <>
            <div className="content-area-wrap">
                <div className="content-area">
                    <div className="tab-area">
                        <div onClick={() => graphTypeClickHandler('height')} className={`tab ${graphType === 'height' ? 'active' : ''}`}>
                            <div className="tit">키</div>
                            <div className="desc">
                                {selectMyChildGrowthRes ? numberFormat(Number(selectMyChildGrowthRes.childHeight), false, 1) : 0}cm
                            </div>
                            <div className="percent">{selectMyChildGrowthRes ? numberFormat(Number(excelFunc('NORMSDIST', selectMyChildGrowthRes.childHeightPercent)), false, 1) : ''}% 백분위</div>
                        </div>
                        <div onClick={() => graphTypeClickHandler('weight')} className={`tab ${graphType === 'weight' ? 'active' : ''}`}>
                            <div className="tit">몸무게</div>
                            <div className="desc">{selectMyChildGrowthRes ? selectMyChildGrowthRes.childWeight.toFixed(1) : 0}kg</div>
                            <div className="percent">{selectMyChildGrowthRes ? numberFormat(Number(excelFunc('NORMSDIST', selectMyChildGrowthRes.childWeightPercent)), false, 1) : ''}% 백분위</div>
                        </div>
                        <div onClick={() => graphTypeClickHandler('bmi')} className={`tab ${graphType === 'bmi' ? 'active' : ''}`}>
                            <div className="tit">BMI</div>
                            <div className="desc">{selectMyChildGrowthRes ? selectMyChildGrowthRes.childBmi.toFixed(1) : 0}kg/㎡</div>
                            <div className="percent">
                                {selectMyChildGrowthRes && selectMyChildGrowthRes.childBmiPercent ? <>{numberFormat(Number(excelFunc('NORMSDIST', selectMyChildGrowthRes.childBmiPercent)), false, 1)}% 백분위</> : ""}
                            </div>
                        </div>
                    </div>
                    <div className="graph-area">
                        <div className="graph">
                            {
                                (selectGrowthChartRes && selectGrowthChartRes[0] && data && options) ?
                                <Line options={options} data={data} width={315} height={264} />
                                : <div className="nodata">BMI 그래프는 2살 이후부터 확인 가능합니다.</div>
                            }
                        </div>
                        <div className="unit-area">
                            <div onClick={() => graphViewTypeClickHandler('year')} className={`unit ${graphViewType === 'year' ? 'active' : ''}`}><i></i><span>전체보기</span></div>
                            <div onClick={() => graphViewTypeClickHandler('month')} className={`unit ${graphViewType === 'month' ? 'active' : ''}`}><i></i><span>최근보기</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="guide-area" onClick={() => router.push('/front/growth/helper')}>
                <div className="guide">
                    <div className="tit">우리 아이 성장 도우미</div>
                    <div className="desc">성장하는데 도움이 되는<br />운동, 식단, 성장도표 등에 대해<br />알려드려요!</div>
                    <div className="img"><img src="/img/growth_helper_eatinghabits1_img.png" alt="식습관 이미지" /></div>
                </div>
            </div>
        </>
    )
}

export default GrowthGraph;