import GrowthDayList from "@/components/front/growth/GrowthDayList";

const GrowthDay = (props) => {
    const {updateToGrowthForm, showBtn, plusCount, pagingList} = props

    return (
        <>
            <div className="content-area">
                <div className="list-area">
                    <GrowthDayList growthList={pagingList} updateToGrowthForm={updateToGrowthForm}/>
                </div>
                {
                    showBtn &&
                    <div className="btn-area">
                        <div className="btn" onClick={plusCount}>+ 성장 일별표 더 보기</div>
                    </div>
                }
            </div>
        </>
    );
}

export default GrowthDay