const JoinLabelCheckBoxWithImg = (props) => {
    const {id, title, imgSrc, checked, changeHandler, clickHandler} = props;

    return(
        <>
            <div className="checkbox">
                <input type="checkbox" id={id} checked={checked} onChange={() => changeHandler(id)}/>
                <label htmlFor={id}>
                    <div className="img"></div>
                    <div className="txt">{title}</div>
                </label>
            </div>
            <div className="detail">
                <div className="img" onClick={clickHandler}><img src={imgSrc}
                                          alt="이용약관 동의(필수) 상세보기"/></div>
            </div>
        </>
    );
}

export default JoinLabelCheckBoxWithImg;