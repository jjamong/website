import AddrInput from "@/components/commons/AddrInput";
import LabelInput from "@/components/commons/LabelInput";
import LabelInputWithButton from "@/components/commons/LabelInputWithButton";
import NiceForm from "@/components/front/commons/NiceForm";
import DaumAddrMo from "@/components/front/commons/DaumAddrMo";

const JoinSecond = (props) => {
    const {
        nextEnabled,
        stepChangeHandler,
        stepValidate,
        addrChangeHandler,
        addrRef1,
        addrRef2,
        addrRef3,
        openAddr,
        openNice,
        niceFormRef,
        niceEncRef,
        niceBtnRef,
        joinInfo,
        setState,
        isEmbedVisible,
        fOnComplete,
        fCloseLayer
    } = props;
    const desc = [
        {descClass: 'desc', descTitle: '나이스평가정보에서 인증받은 휴대폰 번호를 사용하고 있습니다.'}
    ]

    return (
        <>
            <div className="desc-area">
                <p className="desc1">보호자 정보를 적어주세요</p>
            </div>
            <div className="content">
                <LabelInputWithButton customClass={'phone'} id={'phone'} isRequire={true} type={'text'}
                                      placeholder={'인증해 주세요.'} btnClass={'certification'} title={'휴대폰'}
                                      btnTitle={'인증하기'} value={joinInfo.phone} clickHandler={openNice}
                                      isDisabled={true} desc={desc}/>
                <LabelInput title={'보호자 이름'} id={'userName'} isRequire={true} type={'text'} value={joinInfo.userName}
                            placeholder={'인증해 주세요.'} changeHandler={undefined} isDisabled={true}
                            inputClass={'disabled'}/>
                <AddrInput id1={'zipCode'} id2={'addr'} id3={'addrDtl'} isRequire={true} type={'text'}
                           value1={joinInfo.zipCode} value2={joinInfo.addr} value3={joinInfo.addrDtl}
                           changeHandler={addrChangeHandler} inputRef1={addrRef1} inputRef2={addrRef2}
                           inputRef3={addrRef3} isDisabled={true} inputClass={'disabled'} openAddr={openAddr}/>
                <NiceForm niceFormRef={niceFormRef} niceEncRef={niceEncRef} niceBtnRef={niceBtnRef} duplCheck={true}
                          setState={setState}/>
                <DaumAddrMo isEmbedVisible={isEmbedVisible} fOnComplete={fOnComplete} fCloseLayer={fCloseLayer}/>
                <div className="btn-area">
                    <div className="btn" onClick={() => stepChangeHandler('prev')}>이전</div>
                    <div className={`btn ${nextEnabled ? 'active' : ''}`}
                         onClick={stepValidate}>다음
                    </div>
                </div>
            </div>
        </>
    );
}

export default JoinSecond;
