import {useRouter} from "next/router";

const JoinComplete = (props) => {
    const router = useRouter();
    const {childName} = props;

    return (
        <div className="content">
            <div className="complete">
                <div className="img"><img src="/img/join_complete_img.png" alt="회원가입 완료"/></div>
            </div>
            <div className="title-area">
                <div className="title">{`${childName} 어린이`}</div>
                <p className="desc">회원가입이 완료되었습니다.</p>
            </div>
            <p className="guide">
                담당 간호사의 승인 후 앱을<br/>사용하실 수 있습니다.<br/>조금만 기다려주세요<span className="space">:)</span>
            </p>
            <div className="btn-area">
                <div className="btn active" onClick={() => router.push('/')}>로그인</div>
            </div>
        </div>
    );
}

export default JoinComplete;