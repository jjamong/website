import JoinLabelCheckBoxWithImg from "@/components/front/join/JoinLabelCheckBoxWithImg";

const JoinFirst = (props) => {
    const {nextEnabled, agree, agreeChangeHandler, stepValidate, viewAgreeHandler} = props;

    return (
        <>
            <div className="desc-area">
                <p className="desc1">자라다 앱을 사용하려면 동의가 필요해요</p>
                <p className="desc2">성장 주사를 투여 중인 아이의 보호자만 담당 간호사의 승인 후 이용하실 수 있습니다.</p>
            </div>
            <div className="agree-area">
                <div className="agree-all-area">
                    <div className="checkbox">
                        <input type="checkbox" id="agreeAll" checked={agree['agreeAll']} onChange={() => agreeChangeHandler('agreeAll')}/>
                        <label htmlFor="agreeAll">
                            <div className="cover">
                                <div className="img"><img src="/img/agree_check1_icon.png" alt="이용약관 전체 동의"/></div>
                            </div>
                            <div className="txt">이용약관 전체 동의</div>
                        </label>
                    </div>
                </div>
                <div className="agree-unit-area">
                    <ul>
                        <li>
                            <JoinLabelCheckBoxWithImg id={'agree1'} title={'개인정보 처리방침 동의(필수)'} imgSrc={'../../../img/agree_detail_arrow_icon.png'} checked={agree['agree1']} changeHandler={agreeChangeHandler} clickHandler={viewAgreeHandler}/>
                        </li>
                    </ul>
                </div>
                <div className="section btn-section">
                    <div className="btn-area">
                        <div className={`btn ${nextEnabled ? 'active' : ''}`}
                             onClick={stepValidate}>다음
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default JoinFirst;