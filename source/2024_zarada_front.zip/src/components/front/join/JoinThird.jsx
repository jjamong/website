import LabelInputWithButton from "@/components/commons/LabelInputWithButton";
import LabelInput from "@/components/commons/LabelInput";

const JoinThird = (props) => {
    const {nextEnabled, stepChangeHandler, stepValidate, userInfo, userInfoChange, idDupl, userIdChk, userPwChk, userPw2Chk, userIdRef, userPwRef, userPw2Ref} = props;
    const desc1 = [
        {descClass: 'noti danger', descTitle: '아이디 중복확인을 해 주세요.'},
        {descClass: 'noti danger', descTitle: '중복된 아이디입니다.'},
        {descClass: 'noti confirm', descTitle: '중복확인 되었습니다.'},
    ]

    const desc2 = [
        {descClass: 'desc', descTitle: '영문, 숫자 8자리 이상 입력해 주세요. 특수문자는 사용불가입니다.'},
        {descClass: 'noti danger', descTitle: '8자리 이상 16자리 이하여야 합니다.'},
        {descClass: 'noti confirm', descTitle: '알맞은 비밀번호입니다.'},
        {descClass: 'noti danger', descTitle: '특수문자는 사용불가입니다.'},
    ]

    const desc3 = [
        {descClass: 'noti danger', descTitle: '비밀번호가 일치하지 않습니다.'},
        {descClass: 'noti confirm', descTitle: '비밀번호가 일치합니다.'},
    ]

    return(
        <>
            <div className="desc-area">
                <p className="desc1">아이디와 비밀번호를 적어주세요</p>
            </div>

            <div className="content">
                <LabelInputWithButton customClass={'id'} id={'userId'} isRequire={true} type={'text'} placeholder={'4~13자리 이내'} btnClass={'check'} title={'아이디'} btnTitle={'중복확인'} value={userInfo.userId} changeHandler={userInfoChange} clickHandler={idDupl} desc={desc1[userIdChk]} inputRef={userIdRef}/>
                <LabelInput title={'비밀번호'} id={'userPw'} isRequire={true} type={'password'} value={userInfo.userPw} placeholder={'비밀번호를 입력해 주세요.'} changeHandler={userInfoChange} desc={desc2[userPwChk]} inputRef={userPwRef}/>
                <LabelInput title={'비밀번호 확인'} id={'userPw2'} isRequire={true} type={'password'} value={userInfo.userPw2} placeholder={'비밀번호를 한번 더 입력해 주세요.'} changeHandler={userInfoChange} desc={desc3[userPw2Chk]} inputRef={userPw2Ref}/>
                <div className="btn-area">
                    <div className="btn" onClick={() => stepChangeHandler('prev')}>이전</div>
                    <div className={`btn ${nextEnabled ? 'active' : ''}`} onClick={stepValidate}>다음</div>
                </div>
            </div>
        </>
    );
}

export default JoinThird;