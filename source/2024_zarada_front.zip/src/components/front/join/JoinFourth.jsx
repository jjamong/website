import LabelInput from "@/components/commons/LabelInput"
import LabelRadio from "@/components/commons/LabelRadio"
import LabelSelect from "@/components/commons/LabelSelect"

const JoinFourth = (props) => {
    const {nextEnabled, stepChangeHandler, stepValidate, childInfo, childInfoChange, childNameRef, childBirthdayRef, childHospitalRef, selectHospitalComboRes} = props

    // 카트리지
    const itemData = [
        {value: '', text: '카트리지를 선택해 주세요.'},
        {value: '40', text: '카트리지 20IU'},
        {value: '50', text: '카트리지 30IU'},
    ]

    return (
        <>
            <div className="desc-area">
                <p className="desc1">아이 정보를 적어주세요.</p>
            </div>

            <div className="content">
                <LabelInput title={'아이 이름'} id={'childName'} isRequire={true} type={'text'} value={childInfo.childName}
                            placeholder={'아이 이름을 입력해 주세요.'} changeHandler={childInfoChange} inputRef={childNameRef}/>
                <LabelInput title={'아이 생년월일'} id={'childBirthday'} isRequire={true} type={'date'}
                            value={childInfo.childBirthday} changeHandler={childInfoChange} inputRef={childBirthdayRef}/>
                <div className="form-item">
                    <label htmlFor="childSex" className="tit">아이 성별<span className="require">*</span></label>
                    <div className="radio-section">
                        <LabelRadio id={'childSexMan'} name={'childGenderCd'} value={'M'}
                                    checked={childInfo.childGenderCd === 'M'} changeHandler={childInfoChange}
                                    labelTitle={'남자'}/>
                        <LabelRadio id={'childSexFemale'} name={'childGenderCd'} value={'F'}
                                    checked={childInfo.childGenderCd === 'F'} changeHandler={childInfoChange}
                                    labelTitle={'여자'}/>
                    </div>
                </div>
                <LabelSelect customClass={'itemCd'} id={'itemCd'} title={'카트리지'} value={childInfo.itemCd} changeHandler={childInfoChange} datas={itemData}/>
                <LabelSelect customClass={'hospitalNm'} id={'hospitalNm'} title={'병원명'} value={childInfo.hospitalNm} changeHandler={childInfoChange} datas={selectHospitalComboRes}/>
                <LabelInput title={'의사명'} id={'doctorNm'} type={'text'} value={childInfo.doctorNm} placeholder={'의사명을 입력해 주세요.'} changeHandler={childInfoChange}/>
                <div className="btn-area">
                    <div className="btn" onClick={() => stepChangeHandler('prev')}>이전</div>
                    <div className={`btn ${nextEnabled ? 'active' : ''}`}
                         onClick={stepValidate}>회원가입
                    </div>
                </div>
            </div>
        </>
    )
}

export default JoinFourth
