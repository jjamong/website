const ChildList = (props) => {
    const {selectMyChildListRes, moveChildDetail} = props

    return (
        <ul>
            {
                selectMyChildListRes.map((child) => {
                    return (
                        <li key={child.childSeq} onClick={() => moveChildDetail(child.childSeq)}>
                            <div className="profile-area">
                                <div className="profile">
                                    <div className="img">
                                        <img src={child.childFile === ''
                                            ? '/img/mypage_child_default_profile_icon.png'
                                            : child.childFile}
                                        alt="프로필 이미지" />
                                    </div>
                                </div>
                                <div className="info">
                                    <div className="name-area">
                                        <div className="name">{child.childName}</div>
                                    </div>
                                    <div className="date">{child.birthday}</div>
                                </div>
                            </div>
                            <div className="btn arrow">
                                <div className="img"><img src="/img/mypage_list_arrow_btn.png" alt="상세 이동"/>
                                </div>
                            </div>
                        </li>
                    )
                })
            }
        </ul>
    )
}

export default ChildList