const ChildImage = (props) => {
    const {imageSrc, changeHandler, imageDelete} = props

    return (
        <div className="profile-area">
            <div className="profile">
                <label htmlFor="file">
                    <div className="img">
                        <img src={`${imageSrc ? imageSrc : '/img/mypage_child_default_profile_icon.png'}`} alt="프로필 이미지"/>
                    </div>
                    <div className="delete" onClick={imageDelete}>삭제</div>
                    <div className="camera">
                        <img src="/img/mypage_child_camera_icon.png" alt="카메라 아이콘"/>
                    </div>
                </label>
                <input type="file" id="file" onChange={changeHandler ? (e) => changeHandler(e) : undefined}/>
            </div>
        </div>
    )
}

export default ChildImage