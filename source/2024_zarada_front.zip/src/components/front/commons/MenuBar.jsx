import {useRouter} from "next/router";
import {useEffect} from "react";
import {removeAccessToken} from "@/utils/Libs/Methods/authToken";
import {useRecoilState} from "recoil";
import {recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";

const MenuBar = (props) => {
    const {menuActive, setMenuActive, menuClose} = props;
    const router = useRouter();

    // recoil
    const [rUser, setRUser] = useRecoilState(recoilUser)

    const logoutObj = {
        url: '/api/user/LoginController/logout',
        param: {},
        onSuccess: (data) => {
            // RN으로 쿠키 세팅 호출
            if(window.ReactNativeWebView) {
                const msgType = 'SET_ANDROID_COOKIE'

                window.ReactNativeWebView.postMessage(JSON.stringify({ msgType }));
            }

            setMenuActive(false)
            removeAccessToken()
            sessionStorage.clear()
            window.location.href = window.location.origin
        }
    }
    const logout = useCallApi(logoutObj)

    const logoutClick = () => {
        logout.isReady && logout.call()
    }

    useEffect(() => {
        if(!menuActive) {
            document.body.classList.remove('scroll-lock')
        }
    }, [menuActive]);

    return (
        <div className={`menubar ${(menuActive) ? 'active' : ''}`}>
            <div className="top-area">
                <div className="top">
                    <div className="logo"><img src="/img/common_menu_logo.png" alt="zarada" /></div>
                    <div className="close btn" onClick={menuClose}>
                        <div className="img"><img src="/img/common_menu_close_btn.png" alt="zarada" /></div>
                    </div>
                </div>
                <div className="info-area">
                    <div className="user">
                        <div className="name-area">
                            <span className="name">{rUser.userName}</span> 보호자
                            <span className="id">{`(${rUser.userId})`}</span>
                        </div>
                    </div>
                </div>
            </div>
            <ul className="main-menu-list">
                <li>
                    <div className="main-menu-area" onClick={() => router.push('/front/notice')}>
                        <div className="txt">공지사항</div>
                        <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="공지사항 / 투약방법 페이지 이동" /></div>
                    </div>
                </li>
                <li>
                    <div className="main-menu-area">
                        <div className="txt">마이페이지</div>
                    </div>
                    <ul className="sub-menu-list">
                        <li>
                            <div className="sub-menu-area" onClick={() => router.push('/front/mypage/changePaInfo')}>
                                <div className="txt">보호자 정보 변경</div>
                                <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="보호자 정보 변경 페이지 이동" /></div>
                            </div>
                        </li>
                        <li>
                            <div className="sub-menu-area" onClick={() => router.push('/front/mypage/changePw')}>
                                <div className="txt">비밀번호 변경</div>
                                <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="비밀번호 변경 페이지 이동" /></div>
                            </div>
                        </li>
                        <li>
                            <div className="sub-menu-area" onClick={() => router.push('/front/mypage/manageFaInfo')}>
                                <div className="txt">가족 관리</div>
                                <div className="btn"><img src="/img/common_menu_arrow_btn.png" alt="가족관리 페이지 이동" /></div>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
            <div className="logout-area" onClick={logoutClick}>
                <div className="logout btn">로그아웃</div>
            </div>
        </div>
    );
}

export default MenuBar;
