import Tab from "@/components/commons/Tab";

const TabArea = (props) => {
    const {tabInfo} = props;

    return (
        <div className="top-tab-area">
            {tabInfo.map((data, index) => {
                return <Tab key={index} id={data.id} active={data.active} clickHandler={data.clickHandler} title={data.title}/>
            })}
        </div>
    );
}

export default TabArea;