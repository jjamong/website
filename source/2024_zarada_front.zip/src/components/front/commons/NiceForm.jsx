import axios from "@/utils/Axios/axiosInstance";
import {useEffect, useState} from "react";
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {useRecoilState} from "recoil";
import {recoilDevice} from "@/utils/Store/atom";

const NiceForm = (props) => {
    const {niceFormRef, niceEncRef, niceBtnRef, duplCheck=true, setState, setPopup} = props
    const [isRNWebview, setIsRNWebview] = useState(false);
    const [rDeviceType, setRDeviceType] = useRecoilState(recoilDevice)
    const niceUri = 'https://nice.checkplus.co.kr/CheckPlusSafeModel/checkplus.cb';

    const openNice = async () => {
        // 나이스 인증 후 redirect 받을 url
        let niceRedirectUrl = process.env.NEXT_PUBLIC_BASE_URL + "/front/nice";

        if (isRNWebview) {
            niceRedirectUrl = niceRedirectUrl + "/mobile";
        }

        // 나이스 인증 사이트 호출 시 필요한 암호화 데이터
        let encData = "";

        try {
            const response = await axios({
                url: process.env.NEXT_PUBLIC_BASE_URL + "/api/extra/NiceController/niceEncrypt",
                data: JSON.stringify({
                    returnUrl: niceRedirectUrl,
                    errorUrl: process.env.NEXT_PUBLIC_BASE_URL,
                }),
            });

            encData = response.data.data[0].encData;
        } catch (error) {
            // backend가 운영 종료할 경우 대비
            alert("현재 나이스 인증 암호화를 이용 할 수 없습니다.");
            return;
        }

        const formAction = niceUri;
        if (isRNWebview) {

            const msgType = "NICE";
            window.ReactNativeWebView.postMessage(
                JSON.stringify({ msgType, formAction, encData })
            );
        } else {
            const left = screen.width / 2 - 500 / 2;
            const top = screen.height / 2 - 800 / 2;
            const option = `status=no, menubar=no, toolbar=no, resizable=no, width=500, height=600, left=${left}, top=${top}`;

            const nicePopup = window.open(formAction, "nicePopup", option);

            if (nicePopup) {
                const form = niceFormRef.current;
                const encInput = niceEncRef.current;

                encInput ? (encInput.value = encData) : "";

                form?.submit();
            }
            setPopup && setPopup(nicePopup)
        }
    }

    const checkPhone = (phone) => {
        return new Promise((resolve, reject) => {
            axios({
                url: process.env.NEXT_PUBLIC_BASE_URL + "/api/extra/JoinController/checkDuplPhone",
                data: JSON.stringify({
                    phone: phone,
                }),
            }).then((res) => {
                resolve(res.data);
            }).catch((e) => {
                reject(e);
            });
        })
    }

    const niceSuccess = async (encData) => {
        try {
            const response = await axios({
                url: process.env.NEXT_PUBLIC_BASE_URL + "/api/extra/NiceController/niceDecrypt",
                data: JSON.stringify({
                    encData,
                }),
            });

            if(!duplCheck) {
                setParam(setState, {phone: response.data.data[0].mobileNo, userName: response.data.data[0].name})
                return
            }

            checkPhone(response.data.data[0].mobileNo).then((res) => {
                if(!res.status) {
                    alert(res.msg);
                    return;
                }

                if(res.data[0].count === 0){
                    setParam(setState, {phone: response.data.data[0].mobileNo, userName: response.data.data[0].name})
                } else {
                    setTimeout(() => {
                        alert('중복된 휴대폰번호입니다.');
                    }, 500)
                }
            }).catch((e) => {
                alert('휴대폰 중복확인에 실패하였습니다.');
            })

        } catch (error) {
            // backend가 운영 종료할 경우 대비
            alert("나이스 인증 복호화에 실패하였습니다.");
            return;
        }
    };

    const rnNice = (e) => {
        let data = null

        try{
            data = JSON.parse(e.data)
        } catch (e) {

        }

        data && niceSuccess(data.encodeData)
    }

    useEffect(() => {


        if(window.ReactNativeWebView) {
            setIsRNWebview(true)
        }

        if(window.ReactNativeWebView && rDeviceType === 'android') {
            /**
             * document.addEventListener
             * React Native Webview에서 webViewRef.current.postMessage() 시 해당 이벤트 호출
             */
            document.addEventListener("message", rnNice)

            return () => {
                document.removeEventListener('message', rnNice)
            }
        } else {
            /**
             * window.addEventListener
             * window.open으로 열린 자식창에서 window.opener.postMessage() 시 해당 이벤트 호출
             */
            window.addEventListener("message", rnNice)

            return () => {
                window.removeEventListener('message', rnNice)
            }
        }
    }, []);

    return (
        <>
            <form
                ref={niceFormRef}
                method="POST"
                name="form_chk"
                target="nicePopup"
                action={niceUri}
            >
                <input type="hidden" name="m" value="checkplusService"/>
                <input ref={niceEncRef} type="hidden" name="EncodeData" value={""}/>
                <input type="hidden" name="recvMethodType" value="get"/>
            </form>
            <button ref={niceBtnRef} onClick={openNice}></button>
        </>
    )
}

export default NiceForm
