import {useRouter} from "next/router";
import {useRecoilState} from "recoil";
import {recoilMenuActive} from "@/utils/Store/atom";
import {useEffect} from "react";

const NavFooter = () => {
    const router = useRouter();
    const [menuActive, setMenuActive] = useRecoilState(recoilMenuActive)

    const menuHandler = () => {
        setMenuActive((prevState) => !prevState)
    }

    useEffect(() => {
        if(menuActive) {
            document.body.classList.add('scroll-lock')
        } else {
            document.body.classList.remove('scroll-lock')
        }
    }, [menuActive]);

    return (
        <footer id="footer" className="footer">
            <nav>
                <ol>
                    <li className={`home ${router.pathname.indexOf('main') > -1 ? 'active' : ''}`} onClick={() => router.push('/front/main')}>
                        <div>
                            <div className="img"></div>
                            <span>홈</span>
                        </div>
                    </li>
                    <li className={`injection ${router.pathname.indexOf('injection') > -1 ? 'active' : ''}`} onClick={() => router.push('/front/injection')}>
                        <div>
                            <div className="img"></div>
                            <span>주사관리</span>
                        </div>
                    </li>
                    <li className={`growth ${router.pathname.indexOf('growth') > -1 ? 'active' : ''}`} onClick={() => router.push('/front/growth')}>
                        <div>
                            <div className="img"></div>
                            <span>성장관리</span>
                        </div>
                    </li>
                    <li className={`allmenu ${menuActive ? 'active' : ''}`} onClick={menuHandler}>
                        <div>
                            <div className="img"></div>
                            <span>전체</span>
                        </div>
                    </li>
                </ol>
            </nav>
        </footer>
    );
}

export default NavFooter;