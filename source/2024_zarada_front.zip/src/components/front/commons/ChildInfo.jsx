import {useRecoilState} from "recoil";
import {recoilChild} from "@/utils/Store/atom";
import {numberFormat} from "@/utils/Libs/Methods/commonUtils";

const ChildInfo = (props) => {
    const {selectMyChildDetailRes, openSelect, type} = props

    return (
        <div key={selectMyChildDetailRes.childSeq} className="child">
            <div className="profile" onClick={openSelect}>
                <div className="image-area">
                    <div className="img">
                        <img src={selectMyChildDetailRes.childFile
                            ? selectMyChildDetailRes.childFile
                            : '/img/mypage_child_default_profile_icon.png'}
                        alt="프로필 이미지" />
                    </div>
                    <div className="name">{selectMyChildDetailRes.childName}</div>
                    <div className="select-btn">
                        {
                            type === 'main'
                            ? <img src="../../../img/main_child_select_btn.png" alt="자녀선택" />
                            : <img src="/img/common_child_select_btn.png" alt="자녀선택" />
                        }
                    </div>
                </div>
                <div className="birth-age">
                    <div className="birth">{selectMyChildDetailRes.birthText}</div>
                    <div className="slash">/</div>
                    <div className="age">{selectMyChildDetailRes.ageText}</div>
                </div>
            </div>
            {
                type === 'main' ?
                <div className="profile-sub">
                    <div className="item">{`키 : ${selectMyChildDetailRes.recentlyChildHeight ? numberFormat(selectMyChildDetailRes.recentlyChildHeight, false, 1) : 0}cm`}</div>
                    <div className="item">{`몸무게 : ${selectMyChildDetailRes.recentlyChildWeight ? numberFormat(selectMyChildDetailRes.recentlyChildWeight, false, 1) : 0}kg`}</div>
                    <div className="item">{`BMI : ${selectMyChildDetailRes.recentlyChildBmi ? numberFormat(selectMyChildDetailRes.recentlyChildBmi, false, 1) : 0}kg/㎡`}</div>
                </div>
                : <></>
            }
        </div>
    )
}

export default ChildInfo;