// noinspection JSVoidFunctionReturnValueUsed

import {useEffect} from "react";
import {useRouter} from "next/router";
import {useRecoilState} from "recoil";
import {recoilChild, recoilDevice} from "@/utils/Store/atom";
import axios from "@/utils/Axios/axiosInstance";
import {getAccessToken} from "@/utils/Libs/Methods/authToken";

let init = false

const WebViewLayer = ({children}) => {
    const router = useRouter()
    const [rDeviceType, setRDeviceType] = useRecoilState(recoilDevice)
    const [rChild, setRChild] = useRecoilState(recoilChild)

    // FCM webview
    const tokenSuccess = (fcmToken) => {
        const jwtToken = getAccessToken()

        if(!jwtToken) return

        axios({
            url: '/api/user/LoginController/updateFcmToken',
            data: {
                fcmToken,
            },
        })
    }

    // push noti move
    const moveUrl = (url) => {
        // 로그인 및 기본 데이터 세팅 후에만 이동
        const login = window.sessionStorage.getItem('login')

        if(login == 'true') {
            router.push(url)
        }
    }

    useEffect(() => {
        // 디바이스 체크 및 셋팅
        const userAgent = navigator.userAgent.toLowerCase();
        let deviceType = 'web'
        // aos
        if ( userAgent.indexOf('android') > -1) {
            deviceType = "android"
            // ios
        } else if ( userAgent.indexOf("iphone") > -1||userAgent.indexOf("ipad") > -1||userAgent.indexOf("ipod") > -1 ) {
            deviceType = "ios"
            // ios pad13 이상
        } else if ( userAgent.indexOf('mac') > -1 && navigator.maxTouchPoints > 0 ) {
            deviceType = "ios"
        }

        setRDeviceType(deviceType)

        let callback = null

        if(window.ReactNativeWebView && deviceType === 'android') {
            callback = (e) => {
                let data = null

                try{
                    data = JSON.parse(e.data)
                } catch (e) {

                }

                if(data && data.msgType === 'GET_FCM_TOKEN') {tokenSuccess(data.fcmToken)}
                else if (data && data.msgType === 'MOVE_URL') {moveUrl(data.moveUrl)}
            }

            /**
             * document.addEventListener
             * React Native Webview에서 webViewRef.current.postMessage() 시 해당 이벤트 호출
             */
            document.addEventListener("message", callback)

            return () => {
                document.removeEventListener('message', callback)
            }
        } else if(window.ReactNativeWebView && deviceType === 'ios') {
            callback = (e) => {
                let data = null

                try {
                    data = JSON.parse(e.data)
                } catch (e) {

                }
                if(data && data.msgType === 'GET_FCM_TOKEN') {tokenSuccess(data.fcmToken)}
                else if (data && data.msgType === 'MOVE_URL') {moveUrl(data.moveUrl)}
            }

            /**
             * window.addEventListener
             * window.open으로 열린 자식창에서 window.opener.postMessage() 시 해당 이벤트 호출
             */
            window.addEventListener("message", callback)

            return () => {
                window.removeEventListener('message', callback)
            }
        }

    }, []);

    useEffect(() => {
        if(!router.isReady) return

        if(!window.ReactNativeWebView) return

        if(router.pathname !== '/front/main') return

        if(init) return

        const msgType = 'GET_FCM_TOKEN'

        window.ReactNativeWebView.postMessage(
            JSON.stringify({ msgType })
        )

        init = true

    }, [router.pathname]);

    return (
        <>
            {children}
        </>
    )
}

export default WebViewLayer
