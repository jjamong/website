import DaumPostcodeEmbed from "react-daum-postcode";

const DaumAddrMo = (props) => {
    const {isEmbedVisible, fOnComplete, fCloseLayer} = props

    return (
        <>
            <div className="layer addr" style={{display: isEmbedVisible}}>
                <header id="header" className="header">
                    <div className="left"></div>
                    <div className="center">
                        <div className="title">주소 찾기</div>
                    </div>
                    <div className="right">
                        <div className="del" onClick={fCloseLayer}>닫기</div>
                    </div>
                </header>
                <DaumPostcodeEmbed onComplete={fOnComplete} autoClose={false}/>
            </div>
        </>
    )
}

export default DaumAddrMo
