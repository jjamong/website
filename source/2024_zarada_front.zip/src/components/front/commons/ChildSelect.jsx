import {useRecoilState} from "recoil";
import {recoilChild} from "@/utils/Store/atom";

const ChildSelect = (props) => {
    const {selectMyChildListRes, closeSelect} = props
    const [rChild, setRChild] = useRecoilState(recoilChild)

    const changeChild = (child) => {
        if(child.childSeq === rChild.childSeq) return

        setRChild({childSeq: child.childSeq, birthday: child.birthday, injVol: child.injVol, itemCd: child.itemCd})
        closeSelect()
    }

    return (
        <>
            <div id="dim" className="dim" onClick={closeSelect}></div>
            <div id="select-child-list" className="select-child-list">
                <ul>
                    {selectMyChildListRes && selectMyChildListRes.map((child, index) => {
                        return (
                            <li key={index}>
                                <div className="child">
                                    <div className="profile" onClick={() => changeChild(child)}>
                                        <div className="image-area">
                                            {child.childRpstYn === 'Y' && <i></i>}
                                            <div className="img">
                                                <img src={!child.childFile || child.childFile === ''
                                                                            ? '/img/mypage_child_default_profile_icon.png'
                                                                            : child.childFile}
                                                                        alt="프로필 이미지" />
                                            </div>
                                            <div className="name">{child.childName}</div>
                                        </div>
                                        <div className="birth-age">
                                            <div className="birth">{child.birthday}</div>
                                            <div className="slash">/</div>
                                            <div className="age">{child.ageText}</div>
                                        </div>
                                    </div>
                                    <i className={`select ${child.childSeq === rChild.childSeq ? 'active' : ''}`}></i>
                                </div>
                            </li>
                        )
                    })}
                </ul>
            </div>
        </>
    )
}

export default ChildSelect