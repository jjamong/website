import {cdNaConvert} from "@/utils/Libs/Methods/commonUtils";

const CalendarForm = (props) => {
    const {calendar, moveInjection} = props

    return (
        <div className="calendar-area">
            <ul className="week-area">
                <li>일</li>
                <li>월</li>
                <li>화</li>
                <li>수</li>
                <li>목</li>
                <li>금</li>
                <li>토</li>
            </ul>
            <ul className="days-area">
                {calendar.map((data) => {
                    return (
                        <li key={data.recordDy} className={`day-area ${data.inMonth ? 'now' : ''}`} onClick={() => moveInjection(data.injectionSeq, data.recordDy)}>
                            <div className={`day ${data.isToday ? 'today' : ''}`}>{data.dd}</div>
                            <div className={`injection-info ${data.injPartCd.startsWith('L') ? 'left' : data.injPartCd.startsWith('R') ? 'right' : ''}`}>
                                {data.injPartCd ? cdNaConvert('injPartCd', data.injPartCd).replace(' ', '\n') : ''}
                            </div>
                            <div className="time">
                                {
                                    data.newItemYn === 'Y' &&
                                    <i><img src="/img/growth_calendar_cartridge_icon.png" alt="카트리지"/></i>
                                }
                                {data.recordTm.substring(0,5)}
                            </div>
                        </li>
                    )
                })}
            </ul>
        </div>
    )
}

export default CalendarForm