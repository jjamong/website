import AlarmDay from "@/components/front/injection/AlarmDay";
import LabelInput from "@/components/commons/LabelInput";

const InjectionAlarm = (props) => {
    const {selectAlarmRes, injVol, alYnChange, clickDay, alTmChange, saveAlram} = props;

    const days = [
        {value: 'monYn', title: '월'},
        {value: 'tueYn', title: '화'},
        {value: 'wedYn', title: '수'},
        {value: 'thuYn', title: '목'},
        {value: 'friYn', title: '금'},
        {value: 'satYn', title: '토'},
        {value: 'sunYn', title: '일'},
    ]

    return (
        <div className="content-area">
            <div className="desc-area">
                <div className="title-area">
                    <label className="tit" htmlFor="alarm">언제 알람을 울릴까요?</label>
                    <div className="input-toggle-checkbox"><input type="checkbox" id="alarm" checked={selectAlarmRes.alYn === 'Y'} onChange={(e) => alYnChange(e)}/></div>
                </div>
                <div className="desc">설정하면 해당 시간에 알림이 발송됩니다.</div>
            </div>
            <div className="content">
                <div className="time-area">
                    <div className="input-text">
                        <input type="time" value={selectAlarmRes.alTm} onChange={(e) => alTmChange(e)}/>
                    </div>
                </div>
                <div className="form-item day-area">
                    <label className="tit">반복<span className="require">*</span></label>
                    <div className="checkbox-section">
                        {days.map((day, index) => {
                            return (
                                <AlarmDay key={index} id={index} value={day.value} title={day.title} checked={selectAlarmRes[day.value] === 'Y'} changeHandler={() => clickDay(day.value, selectAlarmRes[day.value])}/>
                            )
                        })}
                    </div>
                </div>
                <LabelInput customClass={''} title={'주사 용량'} id={'alarmVol'} isRequire={true} type={'text'} value={injVol ?? '0'} isReadOnly={true} isDisabled={true} inputClass={'disabled'}/>
            </div>
            <div className="btn-area">
                <div className="btn active" onClick={saveAlram}>저장</div>
            </div>
        </div>
    );
}

export default InjectionAlarm;