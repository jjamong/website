const InjectionSite = (props) => {
    const {id, name, value, title, checked, changeHandler} = props;

    return (
        <div className="radio-area">
            <div className="input-radio">
                <input type="radio" id={`site-${id}`} name={name} value={value} checked={checked} onChange={(e) => changeHandler(e)}/>
            </div>
            <label htmlFor={`site-${id}`}><span>{title}</span></label>
        </div>
    )
}

export default InjectionSite