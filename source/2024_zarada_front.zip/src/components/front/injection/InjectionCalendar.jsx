import CalendarForm from "@/components/front/injection/CalendarForm";
import DatePicker from 'react-datepicker'
import {ko} from 'date-fns/locale/ko';

const InjectionCalendar = (props) => {
    const {year, month, calendar, movePrevMonth, moveNextMonth, moveInjection, moveSelectDateMonth} = props

    return (
        <div className="content-area">
            <div className="date-area">
                <div className="date-section">
                    <div className="btn prev" onClick={movePrevMonth}>
                        <img src="/img/injection_calendar_date_prev_btn.png" alt="이전"/>
                    </div>
                    <div className="date">
                        <DatePicker
                            selected={`${year}-${month}`}
                            onChange={(date) => moveSelectDateMonth(date)}
                            showMonthYearPicker
                            locale={ko}
                            dateFormat="yyyy.MM"
                        />
                    </div>
                    <div className="btn next" onClick={moveNextMonth}>
                        <img src="/img/injection_calendar_date_next_btn.png" alt="다음"/>
                    </div>
                </div>
                <div className="today-area"  onClick={() => moveSelectDateMonth('today')}>
                    <div className="today btn">오늘</div>
                </div>
            </div>
            <div className="calendar-area-wrap">
                <CalendarForm calendar={calendar} moveInjection={moveInjection}/>
            </div>
        </div>
    );
}

export default InjectionCalendar
