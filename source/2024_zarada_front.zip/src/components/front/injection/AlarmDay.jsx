const AlarmDay = (props) => {
    const {id, title, value, checked, changeHandler} = props

    return (
        <div className="checkbox-area" >
            <div className="input-checkbox"><input type="checkbox" id={`day-${id}`} name={`day-${id}`} value={value} checked={checked} onChange={() => changeHandler(id)}/></div>
            <label htmlFor={`day-${id}`}>{title}</label>
        </div>
    )
}

export default AlarmDay