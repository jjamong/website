import InjectionSite from "@/components/front/injection/InjectionSite";
import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import {dateFormat, setParam} from "@/utils/Libs/Methods/commonUtils";
import {useRecoilState} from "recoil";
import {recoilChild, recoilInjSeq} from "@/utils/Store/atom";
import {saveInjectionValidate} from "@/utils/Libs/Methods/userValidate";
import {useCallApi} from "@/utils/Query/customApi";

const today = new Date();
const year = today.getFullYear();
const month = today.getMonth() + 1;
const date = today.getDate();
const _today = `${year}${month < 10 ? `0${month}` : month}${date < 10 ? `0${date}` : date}`;

const InjectionForm = () => {
    const router = useRouter()
    const {injYmd} = router.query
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const [injSeq, setInjSeq] = useRecoilState(recoilInjSeq)
    const [injectionDate, setInjectionDate] = useState('')

    const [site, setSite] = useState(
        [
            {value: 'LA', title: '왼쪽 팔'},
            {value: 'RA', title: '오른쪽 팔'},
            {value: 'LS', title: '왼쪽 배'},
            {value: 'RS', title: '오른쪽 배'},
            {value: 'LT', title: '왼쪽 허벅지'},
            {value: 'RT', title: '오른쪽 허벅지'},
            {value: 'LH', title: '왼쪽 엉덩이'},
            {value: 'RH', title: '오른쪽 엉덩이'},
        ]
    )

    // 주사기록 조회
    const [selectChildInjectionRes, setSelectChildInjectionRes] = useState({
        injectionSeq: 0,
        childSeq: rChild.childSeq,
        recordDy: '',
        recordTm: '',
        newItemYn: '',
        itemCd: rChild.itemCd,
        injPartCd: '',
        injVol: rChild.injVol,
        recordComment: '',
        injDays: ''
    })
    const selectChildInjectionObj = {
        url: '/api/user/InjectionController/selectChildInjection',
        param: {
            childSeq: rChild.childSeq,
            recordDy: injectionDate,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setInjSeq(0)
                setParam(setSelectChildInjectionRes, {
                    injectionSeq: 0,
                    childSeq: rChild.childSeq,
                    recordDy: injectionDate,
                    itemCd: rChild.itemCd,
                    injVol: rChild.injVol,
                    recordComment: '',
                    injDays: ''
                })
                return
            }

            setSelectChildInjectionRes(data[0])
            setInjSeq(data[0].injectionSeq)
        }
    }
    const selectChildInjection = useCallApi(selectChildInjectionObj)

    // 주사기록 저장
    const saveChildInjectionObj = {
        url: '/api/user/InjectionController/saveChildInjection',
        param: selectChildInjectionRes,
        onSuccess: (data) => {
            alert('주사기록이 저장되었습니다.')
            router.replace('/front/injection')
        }
    }
    const saveChildInjection = useCallApi(saveChildInjectionObj)

    const injectionSave = () => {
        const {status, msg, elem} = saveInjectionValidate(selectChildInjectionRes)

        if(!status) {
            alert(msg)
            return
        }

        if(Number(rChild.birthday.replaceAll('-', '') > Number(selectChildInjectionRes.recordDy.replaceAll('-', '')))) {
            alert('생일 이전 날짜는 기록하실 수 없습니다.')
            return
        }

        if(!confirm('저장하시겠습니까?')) return

        saveChildInjection.isReady && saveChildInjection.call()
    }


    const inputChangeHandler = (id, e) => {
        const {value} = e.target

        if(id === 'recordDy') {
            setParam(setSelectChildInjectionRes, {recordDy: value})
            setInjectionDate(value)
        }

        if(id === 'recordTm') {
            setParam(setSelectChildInjectionRes, {recordTm: `${value}:00`})
        }

        if(id === 'newItemYn') {
            setParam(setSelectChildInjectionRes, {newItemYn: e.target.checked ? 'Y' : 'N'})
        }

        if(id === 'injPartCd') {
            setParam(setSelectChildInjectionRes, {injPartCd: value})
        }
    }

    useEffect(() => {
        if(!router.isReady) return

        setInjectionDate(dateFormat(injYmd, 'yyyymmdd', '-'))
    }, [router.isReady]);

    useEffect(() => {
        if(!injectionDate) return

        selectChildInjection.isReady && selectChildInjection.call()
    }, [injectionDate])

    return (
        <main id="container" className="container injection injection-form">
            <div className="wrap">
                <div className="content-area">
                    <div className="content">
                        <div className='form-item injection-date-time'>
                            <label htmlFor='injectionDateTime' className='tit'>주사 일자</label>
                            <div className='input-section'>
                                <div className='input-area'>
                                    <div className='input-text'>
                                        <input id='injectionDate' type='date' value={selectChildInjectionRes.recordDy} onChange={(e) => inputChangeHandler('recordDy', e)} />
                                    </div>
                                </div>
                                <div className='input-area'>
                                    <div className='input-text'>
                                        <input id='injection-time' type='time' value={selectChildInjectionRes.recordTm} onChange={(e) => inputChangeHandler('recordTm', e)} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="form-item injection-capacity">
                            <label htmlFor="injectionCapacity" className="tit">주사 용량</label>
                            <div className="input-section">
                                <div className="input-area">
                                    <div className="input-text"><input id="injectionCapacity" type="number" value={selectChildInjectionRes.injVol} readOnly={true} className='disabled'/></div>
                                </div>
                                <div className="checkbox-area">
                                    <div className="input-checkbox"><input type="checkbox" id="cartridgeUnpackYn" name="" value="Y" checked={selectChildInjectionRes.newItemYn === 'Y'} onChange={(e) => inputChangeHandler('newItemYn', e)}/></div>
                                    <label htmlFor="cartridgeUnpackYn"><span>새 카트리지 개봉</span></label>
                                </div>
                            </div>
                            <div className="desc-area">
                                <div className="desc">*최근 주사용량은  <span>마이페이지</span>에서만 수정가능합니다.</div>
                                <div className="mypage" onClick={() => router.push('/front/mypage/modiChild?childSeq=' + rChild.childSeq)}>마이페이지</div>
                            </div>
                        </div>
                        <div className="form-item injection-site">
                            <label htmlFor="injectionSite" className="tit">주사 부위</label>
                            <div className="radio-section">
                                {
                                    site.map((data, index) => {
                                        return (
                                            <InjectionSite key={index} id={index} name={'injectionSite'} value={data.value} title={data.title} checked={selectChildInjectionRes.injPartCd === data.value} changeHandler={(e) => inputChangeHandler('injPartCd', e)}/>
                                        )
                                    })
                                }
                            </div>
                        </div>
                    </div>
                    <div className="btn-area">
                        <div className="btn cancal" onClick={() => router.back()}>취소</div>
                        <div className="btn save active" onClick={injectionSave}>주사기록</div>
                    </div>
                </div>
            </div>
        </main>
    )
}

export default InjectionForm
