import Slider from "react-slick";
import {useEffect, useState} from "react";

const InjectionMethod = (props) => {
    // 탭 번호
    const [tabIndex, setTabIndex] = useState(0)

    useEffect(() => {
        // 슬라이드 이동 시 높이값 적용
        setTimeout(function() {
            slideheight(0)
        }, 500)
    }, [])

    const tabClick = (index) => {
        // 탭 액티브 효과
        let tab = document.querySelector('.tab-area').getElementsByClassName('tab')
        for (let i=0; i<tab.length; i++) {
            tab[i].classList.remove('active')
        }
        tab[index].classList.add('active')

        // 선택한 탭의 단계 노출
        if (index == 0 || index == 1) {
            let stepArea = document.getElementsByClassName('step-area')
            stepArea[0].style.display = 'flex'

            let step = document.querySelector('.step-area').getElementsByClassName('step')
            for (let i=0; i<step.length; i++) {
                step[i].classList.remove('active')
            }
            step[0].classList.add('active')
        } else {
            let stepArea = document.getElementsByClassName('step-area')
            stepArea[0].style.display = 'none'
        }

        // 선택한 탭의 슬라이드 노출
        setTabIndex(index)

        // 슬라이드 이동 시 높이값 적용
        slideheight(index)
    }

    // 슬라이드 이동 시 높이값 적용
    const slideheight = (tabIndex) => {
        tabIndex = 0
        setTimeout(function() {
            let slideStep = document.getElementsByClassName('slide-step')[tabIndex]

            if(!slideStep) return

            let contentHeight = slideStep.getElementsByClassName('slick-list')[0].style.height
            document.getElementsByClassName('content')[0].style.height = contentHeight
        }, 200)
    }

    // 카트리지 슬라이드 설정
    const cartridgeSettings = {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        adaptiveHeight: true,
        speed: 500,
        arrows: false,
        beforeChange: (currentIndex, nextIndex) => {
            let step = document.querySelector('.step-area').getElementsByClassName('step')
            for (let i=0; i<step.length; i++) {
                if (i <= nextIndex) {
                    step[i].classList.add('active')
                } else {
                    step[i].classList.remove('active')
                }
            }

            // 슬라이드 이동 시 높이값 적용
            slideheight(0)
        }
    }

    // 주사액 슬라이드 설정
    const solutionSettings = {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        adaptiveHeight: true,
        speed: 500,
        arrows: false,
        beforeChange: (currentIndex, nextIndex) => {
            let step = document.querySelector('.step-area').getElementsByClassName('step')
            for (let i=0; i<step.length; i++) {
                if (i <= nextIndex) {
                    step[i].classList.add('active')
                } else {
                    step[i].classList.remove('active')
                }
            }

            // 슬라이드 이동 시 높이값 적용
            slideheight(1)
        }
    }

    return (
        <div className="content-area">
            <div className="tab-area">
                <div className="tab active" onClick={() => tabClick(0)}>
                    <div className="tit">카트리지 20IU / 30IU</div>
                </div>
                <div className="tab" onClick={() => tabClick(1)}>
                    <div className="tit">주사액</div>
                </div>
                <div className="tab" onClick={() => tabClick(2)}>
                    <div className="tit">동영상</div>
                </div>
            </div>
            <div className="step-num-area">
                <div className="step-area">
                    <div className="step step1 active">
                        <div className="circle">1</div>
                        <div className="text">주사전</div>
                    </div>
                    <div className="step step2">
                        <hr />
                        <div className="circle">2</div>
                        <div className="text">주사약</div>
                    </div>
                    <div className="step step3">
                        <hr />
                        <div className="circle">3</div>
                        <div className="text">부위</div>
                    </div>
                    <div className="step step4">
                        <hr />
                        <div className="circle">4</div>
                        <div className="text">주사방법</div>
                    </div>
                    <div className="step step5">
                        <hr />
                        <div className="circle">5</div>
                        <div className="text">보관방법</div>
                    </div>
                </div>
            </div>
            <div className="content">
                {
                    tabIndex == 0 ?
                        <div className="slide-step cartridge-step">
                            <Slider
                                {...cartridgeSettings}>
                                <div className="step-content step1-content">
                                    <div className="cover">
                                        <div className="tit">1.주사전 준비</div>
                                        <div className="child-step step1-1">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step1_1_img.png" alt="주사전 준비" /></div>
                                            <p className="desc">
                                                · 그로트로핀-Ⅱ-카트리지
                                                <br />· 1회용 주사바늘, 알콜솜
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step2-content">
                                    <div className="cover">
                                        <div className="tit">2.주사약 준비</div>
                                        <div className="child-step step2-1">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_1_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ① 피스톤 조절링을 한 손으로 잡고, 다른 손으로 용량설정부분을 잡습니다. 용량설정부분을 시계 반대방향으로 더 이상 회전하지 않을 때까지 돌려서 피스톤 막대가 완전히 안으로 들어가게 합니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-2">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_2_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ② 약물이 들어있는 카트리지의 알루미늄 뚜껑 부분이 카트리지 덮개를 향하도록 하여 넣습니다.
                                                <br /><span className="desc">(카트리지 알루미늄캡의 고무부분을 만지지 않도록 합니다.)</span>
                                            </p>
                                        </div>
                                        <div className="child-step step2-3">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_3_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                <br />③ 새 카트리지를 끼운 후 피스톤 막대길이를 맞추기 위해 다이얼 눈금을 6.7 돌린 후 0이 될때까지 주입버튼을 누릅니다. 이 작업을 두번 진행합니다.
                                                <br /><span className="desc">(매번하는 것이 아니라 새 카트리지를 끼울때만)</span>
                                            </p>
                                        </div>
                                        <div className="child-step step2-4">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_4_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ④ 알콜솜으로 카트리지 앞 부분의 빨간고무 부분을 닦습니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-5">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_5_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ⑥ 주사바늘이 위로 향하도록 하고, 공기방울이 바늘쪽으로 가도록 합니다. 용량설정 버튼을 돌려 1클릭 이동시킨 후 주입버튼을 누릅니다. 공기방울이 완전히 제거되어 주사바늘 끝에 약물이 방울져 나올 때까지 이 과정을 반복합니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-6">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_6_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ⑤ 주사바늘의 종이덮개를 제거하고, 주사바늘을 시계방향으로 돌려 카트리지 덮개에 결합합니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-7">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step2_7_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ⑦ 용량설정 다이얼을 회전시키면서 주사하고자 하는 용량으로 설정 후 니들의 바깥뚜껑과 안뚜껑을 제거합니다. 주사용량은 용량 설정창에 숫자로 표시됩니다.
                                                <br /><span className="desc">(주사바늘을 조심하세요.)</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step3-content">
                                    <div className="cover">
                                        <div className="tit">3.주사를 놓을 수 있는 부위</div>
                                        <div className="child-step step3-1">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step3_1_img.png" alt="주사를 놓을 수 있는 부위" /></div>
                                            <p className="desc">
                                                · 복부 (배꼽을 중심으로 상하 5cm 및 좌우 10cm의 타원형 부분과 벨트나 고무밴드의 압박을 받는 부위는 주사하지 말것)
                                                <br />· 대퇴부의 몸 바깥쪽 부위 (사타구니를 중심으로 성기, 항문 주위는 주사하지 말것)
                                                <br />· 팔뚝의 뒷면 부위 (상박의 중간부위)
                                                <br />· 엉덩이 부위
                                                <span>
                                                <br />주의사항
                                                <br />· 피하주사는 피부 아래의 지방층과 근육층 사이에 있는 피하조직에 주사해야 합니다.
                                                <br />· 자연적인 인체의 성장호르몬 분비주기에 맞추기 위하여 취침전에 투여하는 것이 효과적입니다.
                                            </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step4-content">
                                    <div className="cover">
                                        <div className="tit">4. 주사방법</div>
                                        <p className="desc">
                                            제품을 사용 하기 전에 손을 깨끗이 씻습니다.
                                        </p>
                                        <div className="child-step step4-1">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step4_1_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ① 피부소독 후 45˚~90˚로 주사해 주입 버튼이 더 이상 움직이지 않을 때까지 누릅니다. 주사액이 역류하거나 흘러나오는 것을 방지하기 위하여, 피부에서 주사바늘을 제거하기 전에 항상 10초 정도 기다립니다.
                                                <br /><span>(주사한 후에 용량설정창에 “0”으로 표시되어 있는지 항상 확인해야 합니다.)</span>
                                            </p>
                                        </div>
                                        <div className="child-step step4-2">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step4_2_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ② 주사한 방향 그대로 바늘을 뽑고 알콜솜으로 주사부위를 약 10초간 눌러줍니다. 이때 문지르지 않습니다.
                                            </p>
                                        </div>
                                        <div className="child-step step4-3">
                                            <div className="img"><img src="/img/injection_cartridge2030iu_step4_3_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ③ 보관해둔 주사바늘의 바깥뚜껑을 주사바늘에 씌운 후 주사바늘을 시계반대방향으로 돌려 안전하게 제거하고 버립니다.
                                                <br /><span>(사용한 바늘은 바로 제거합니다.)</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step5-content">
                                    <div className="cover">
                                        <div className="tit">5. 보관방법 및 기타사항</div>
                                        <div className="child-step step4-1">
                                            <p className="desc">
                                                <span className="tit">1.사용시</span>
                                                <br />· 투약하기 전 30분~1시간 상온에 두어 투약하는 약물이 너무 차갑지 않게 합니다.
                                                <br />· 매번 사용하기 전에 반드시 새 주사바늘 혹은 주사기로 교체해야 합니다.
                                                <br /><br /><span className="tit">2.주사부위 바늘 제거 후 문지르지 않고 손으로 눌러줍니다.</span>
                                                <br /><br /><span className="tit">3.그로트로핀-Ⅱ 주사액 카트리지(20IU, 30IU의 경우 주사펜은 다른 사람과 함께 사용하면 안됩니다.</span>
                                                <br /><br /><span className="tit">4.보관 시 주의사항</span>
                                                <br />· 아이들의 손에 닿지 않는 곳에 보관합니다.
                                                <br />· 약물이 들어있는 카트리지와 결합되어 있는 그로트로핀-Ⅱ 펜의 보관시에는 약물제조자의 보관사항에 따르도록 합니다.
                                                <br /><span className="purple">· 그로트로핀-Ⅱ 은 냉장보관 (2~8℃)하고 얼지 않도록 주의 합니다.</span>
                                                <br />★유리병이므로 외부 충격에 약하니 떨어뜨리거나 깨지지 않도록 주의합니다.
                                                <br /><br />· 그로트로핀-Ⅱ 카트리지 20IU 개봉 후
                                                <br />냉장(2~8℃) 21일, 실온(25℃이하) 10일간보관
                                                <br />· 그로트로핀-Ⅱ 카트리지 <span>30IU 개봉 후</span>
                                                <br /><span>냉장(2~8℃) 28일, 실온(25℃이하) 10일간보관</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </Slider>
                        </div>
                        : <></>
                }
                {
                    tabIndex == 1 ?
                        <div className="slide-step solution-step">
                            <Slider
                                {...solutionSettings}>
                                <div className="step-content step1-content">
                                    <div className="cover">
                                        <div className="tit">1.주사전 준비</div>
                                        <div className="child-step step1-1">
                                            <div className="img"><img src="/img/injection_solution_step1_1_img.png" alt="주사전 준비" /></div>
                                            <p className="desc">
                                                · 그로트로핀-Ⅱ-바이알
                                                <br />· 1회용 주사기, 알콜솜
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step2-content">
                                    <div className="cover">
                                        <div className="tit">2.주사약 준비</div>
                                        <div className="child-step step2-1">
                                            <div className="img"><img src="/img/injection_solution_step2_1_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ① 준비하기 전에는 항상 손을 씻습니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-2">
                                            <div className="img"><img src="/img/injection_solution_step2_2_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ② 약품병을 손바닥으로 천천히 굴려약품을 섞습니다. 그로트로핀®-II 주사액이 들어있는 바이알의 플라스틱 커버를 엄지손가락으로 벗겨냅니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-3">
                                            <div className="img"><img src="/img/injection_solution_step2_3_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ③ 알콜솜으로 고무부분을 닦습니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-4">
                                            <div className="img"><img src="/img/injection_solution_step2_4_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ④ 주사기를 약품병의 고무마개 속으로 꽂고 약품병을 거꾸로 쥐고서 투여량 눈금까지 피스톤을 서서히 당깁니다.
                                            </p>
                                        </div>
                                        <div className="child-step step2-5">
                                            <div className="img"><img src="/img/injection_solution_step2_5_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ⑤ 만일 바이알 내부의 공기가 주사기에 들어 갔다면 주사기 몸체를 가볍게 두드려서 공기방울을 표면에 띄우고, 공기방울을 제거합니다.
                                                <br /><span>※큰 공기방울들은 주사기에서 약물이 들어갈 자리를 차지하고 투여 시 통증과 불편함을 일으킬 수 있기 때문에 제거하는 것이 중요합니다.</span>
                                            </p>
                                        </div>
                                        <div className="child-step step2-6">
                                            <div className="img"><img src="/img/injection_solution_step2_6_img.png" alt="주사약 준비" /></div>
                                            <p className="desc">
                                                ⑥ 주사기 뚜껑을 닫아 놓습니다.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step3-content">
                                    <div className="cover">
                                        <div className="tit">3.주사를 놓을 수 있는 부위</div>
                                        <div className="child-step step3-1">
                                            <div className="img"><img src="/img/injection_solution_step3_1_img.png" alt="주사를 놓을 수 있는 부위" /></div>
                                            <p className="desc">
                                                · 복부 (배꼽을 중심으로 상하 5cm 및 좌우 10cm의 타원형 부분과 벨트나 고무밴드의 압박을 받는 부위는 주사하지 말것)
                                                <br />· 대퇴부의 몸 바깥쪽 부위 (사타구니를 중심으로 성기, 항문 주위는 주사하지 말것)
                                                <br />· 팔뚝의 뒷면 부위 (상박의 중간부위)
                                                <br />· 엉덩이 부위
                                                <span>
                                            <br />주의사항
                                            <br />· 피하주사는 피부 아래의 지방층과 근육층 사이에 있는 피하조직에 주사해야 합니다.
                                            <br />· 자연적인 인체의 성장호르몬 분비주기에 맞추기 위하여 취침전에 투여하는 것이 효과적입니다.
                                            </span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step4-content">
                                    <div className="cover">
                                        <div className="tit">4. 주사방법</div>
                                        <p className="desc">
                                            제품을 사용 하기 전에 손을 깨끗이 씻습니다.
                                        </p>
                                        <div className="child-step step4-1">
                                            <div className="img"><img src="/img/injection_solution_step4_1_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ① 피부소독 후 45˚~90˚로 주사해 주입 버튼이 더 이상 움직이지 않을 때까지 누릅니다. 주사액이 역류하거나 흘러나오는 것을 방지하기 위하여, 피부에서 주사바늘을 제거하기 전에 항상 10초 정도 기다립니다.
                                                <br /><span>(주사한 후에 용량설정창에 “0”으로 표시되어 있는지 항상 확인해야 합니다.)</span>
                                            </p>
                                        </div>
                                        <div className="child-step step4-2">
                                            <div className="img"><img src="/img/injection_solution_step4_2_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ② 주사한 방향 그대로 바늘을 뽑고 알콜솜으로 주사부위를 약 10초간 눌러줍니다. 이때 문지르지 않습니다.
                                            </p>
                                        </div>
                                        <div className="child-step step4-3">
                                            <div className="img"><img src="/img/injection_solution_step4_3_img.png" alt="주사방법" /></div>
                                            <p className="desc">
                                                ③ 보관해둔 주사바늘의 바깥뚜껑을 주사바늘에 씌운 후 주사바늘을 시계반대방향으로 돌려 안전하게 제거하고 버립니다.
                                                <br /><span>(사용한 바늘은 바로 제거합니다.)</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="step-content step5-content">
                                    <div className="cover">
                                        <div className="tit">5. 보관방법 및 기타사항</div>
                                        <div className="child-step step4-1">
                                            <p className="desc">
                                                <span className="tit">1.사용시</span>
                                                <br />· 투약하기 전 30분~1시간 상온에 두어 투약하는 약물이 너무 차갑지 않게 합니다.
                                                <br />· 매번 사용하기 전에 반드시 새 주사바늘 혹은 주사기로 교체해야 합니다.
                                                <br /><br /><span className="tit">2.주사부위 바늘 제거 후 문지르지 않고 손으로 눌러줍니다.</span>
                                                <br /><br /><span className="tit">3.그로트로핀-Ⅱ 주사액 카트리지(20IU, 30IU의 경우 주사펜은 다른 사람과 함께 사용하면 안됩니다.</span>
                                                <br /><br /><span className="tit">4.보관 시 주의사항</span>
                                                <br />· 아이들의 손에 닿지 않는 곳에 보관합니다.
                                                <br />· 약물이 들어있는 카트리지와 결합되어 있는 그로트로핀-Ⅱ 펜의 보관시에는 약물제조자의 보관사항에 따르도록 합니다.
                                                <br />★유리병이므로 외부 충격에 약하니 떨어뜨리거나 깨지지 않도록 주의합니다.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </Slider>
                        </div>
                        : <></>
                }
                {
                    tabIndex == 2 ?
                        <div className="slide-step movie-step">
                            <div className="slick-list">
                                <div className="step-content">
                                    <div className="cover">
                                        <div className="tit">1. 20IU 안내 동영상</div>
                                        <div className="video">
                                            <video controls="controls">
                                                <source src="https://dahc.azurewebsites.net/resources/video/growtropin20-v2.mp4" type="video/mp4" />
                                                이 브라우저는 비디오를 지원하지 않습니다. 브라우저 업그레이드를 해주십시오.
                                            </video>
                                        </div>
                                        <div className="tit">2. 30IU 안내 동영상</div>
                                        <div className="video">
                                            <video controls="controls">
                                                <source src="https://dahc.azurewebsites.net/resources/video/growtropin30-v2.mp4" type="video/mp4" />
                                                이 브라우저는 비디오를 지원하지 않습니다. 브라우저 업그레이드를 해주십시오.
                                            </video>
                                        </div>
                                        <p className="desc">
                                            위 동영상은 그로트로핀-Ⅱ 을 처방받은 환자들을 위해 제작되었습니다.
                                            <br />그로트로핀-Ⅱ 의 안전하고 효과적인 사용을 위한 주사방법 안내 동영상입니다.
                                            <br />그로트로핀-Ⅱ 은 전문의약품입니다. 치료 및 진료와 관련된 사항은 의사 선생님과 상의해주세요.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        :<></>
                }
            </div>
        </div>
    )
}

export default InjectionMethod;