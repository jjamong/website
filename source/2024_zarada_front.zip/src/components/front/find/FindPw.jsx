import NiceForm from "@/components/front/commons/NiceForm";
import {useEffect, useRef, useState} from "react";
import LabelInput from "@/components/commons/LabelInput";
import {pwChangeValidate} from "@/utils/Libs/Methods/userValidate";
import {useCallApi} from "@/utils/Query/customApi";

const FindPw = (props) => {
    const {setPopup} = props
    const [step, setStep] = useState(0)
    const niceFormRef = useRef(null)
    const niceEncRef = useRef(null);
    const niceBtnRef = useRef(null)
    const [niceData, setNiceData] = useState({})
    const [userId, setUserId] = useState('')
    const [userIdChk, setUserIdChk] = useState(false)
    const [newPw, setNewPw] = useState('')
    const [newPw2, setNewPw2] = useState('')
    const [newPwChk, setNewPwChk] = useState(0)
    const [newPw2Chk, setNewPw2Chk] = useState(-1)


    const desc = [
        <>가입한 아이디를 입력해주세요<br/>휴대폰 본인인증을 통해 비밀번호를 변경합니다.</>,
        <>일치하는 회원이 없습니다<br />비밀번호 찾기 인증이 실패했습니다.</>,
        <>비밀번호를 변경해 주세요.</>,
    ]

    const desc2 = [
        {descClass: 'desc', descTitle: '영문, 숫자 8자리 이상 입력해 주세요. 특수문자는 사용불가입니다.'},
        {descClass: 'noti danger', descTitle: '8자리 이상 16자리 이하여야 합니다.'},
        {descClass: 'noti confirm', descTitle: '알맞은 비밀번호입니다.'},
        {descClass: 'noti danger', descTitle: '특수문자는 사용불가입니다.'},
    ]

    const desc3 = [
        {descClass: 'noti danger', descTitle: '비밀번호가 일치하지 않습니다.'},
        {descClass: 'noti confirm', descTitle: '비밀번호가 일치합니다.'},
    ]

    const [findPwRes, setFindPwRes] = useState({
        userSeq:0,
    })
    const findPwObj = {
        url: '/api/extra/JoinController/findPw',
        param: {
            userId: userId,
            phone: niceData.phone,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setStep(1)
                setFindPwRes({
                    userSeq:0,
                })
                return
            }

            setStep(2)
            setFindPwRes(data[0])
        }
    }
    const findPw = useCallApi(findPwObj)

    useEffect(() => {
        if(Object.keys(niceData).length === 0) return

        findPw.isReady && findPw.call()
    }, [niceData])

    const updateUserPwFromFindObj = {
        url: '/api/extra/JoinController/updateUserPwFromFind',
        param: {
            userSeq: findPwRes.userSeq,
            newPw,
        },
        onSuccess: (data) => {
            alert('비밀번호 변경되었습니다.')
            window.location.href = window.location.origin
        }
    }
    const updateUserPwFromFind = useCallApi(updateUserPwFromFindObj)

    const openNice = () => {
        if(userId === '') {
            alert('아이디를 입력해 주세요.')
            return
        }

        if(userId.length > 13 || userId.length < 4) {
            alert('아이디를 올바르게 입력해 주세요.')
            return
        }

        setNiceData({})
        niceBtnRef.current.click()
    }

    const reSearch = () => {
        setUserId('')
        setStep(0)
    }

    const idChange = (id, e) => {
        setUserId(e.target.value)
    }

    const pwChange = (id, e) => {
        setNewPw(e.target.value)
    }

    const pw2Change = (id, e) => {
        setNewPw2(e.target.value)
    }

    const savePw = () => {
        const {status, msg, elem} = pwChangeValidate(newPw, newPw2, newPwChk, newPw2Chk)

        if(!status) {
            alert(msg)
            return
        }

        updateUserPwFromFind.isReady && updateUserPwFromFind.call()
    }

    useEffect(() => {
        if(userId.length <= 13 && userId.length >= 4) {
            setUserIdChk(true)
        } else {
            setUserIdChk(false)
        }
    }, [userId]);

    useEffect(() => {
        const pwPattern1 = /^.{8,16}$/
        const pwPattern2 = /^[a-zA-Z0-9]+$/

        // pw
        if(newPw === '') {
            setNewPwChk(0)
        } else if(!pwPattern1.test(newPw)) {
            setNewPwChk(1)
        } else if(pwPattern2.test(newPw)) {
            setNewPwChk(2)
        } else {
            setNewPwChk(3)
        }

        // pw2
        if(newPw !== '' && newPw2 !== '' && (newPw === newPw2)) {
            setNewPw2Chk(1)
        } else if(newPw === '' && newPw2 === '') {
            setNewPw2Chk(-1)
        } else {
            setNewPw2Chk(0)
        }
    }, [newPw, newPw2])

    return (
        <div className="content-area">
            <div className="desc-area">
                <p className="desc">
                    {desc[step]}
                </p>
            </div>
            {step === 0 && <LabelInput title={'아이디'} id={'userId'} isRequire={true} type={'text'} value={userId} placeholder={'4~13자리 이내'} changeHandler={idChange}/>}
            {step === 2 && <LabelInput title={'비밀번호'} id={'newPw'} isRequire={true} type={'password'} value={newPw} placeholder={'비밀번호를 입력해 주세요.'} changeHandler={pwChange} desc={desc2[newPwChk]}/>}
            {step === 2 && <LabelInput title={'비밀번호 확인'} id={'newPw2'} isRequire={true} type={'password'} value={newPw2} placeholder={'비밀번호를 한번 더 입력해 주세요.'} changeHandler={pw2Change} desc={desc3[newPw2Chk]}/>}
            <div className="btn-area">
                {step === 0 && <div className={`btn ${userIdChk === true ? 'active' : ''}`} onClick={openNice}>휴대폰 인증하기</div>}
                {step === 1 && <div className="btn active" onClick={reSearch}>다시 찾기</div>}
                {step === 2 && <div className={`btn ${newPwChk === 2 && newPw2Chk === 1 ? 'active' : ''}`} onClick={savePw}>비밀번호 변경하기</div>}
            </div>
            <NiceForm niceFormRef={niceFormRef} niceEncRef={niceEncRef} niceBtnRef={niceBtnRef} duplCheck={false} setState={setNiceData} setPopup={setPopup}/>
        </div>
    )
}

export default FindPw