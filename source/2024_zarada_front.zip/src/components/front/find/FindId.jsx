import {useEffect, useRef, useState} from "react";
import NiceForm from "@/components/front/commons/NiceForm";
import {useCallApi} from "@/utils/Query/customApi";

const FindId = (props) => {
    const {setPopup} = props
    const [step, setStep] = useState(0)
    const niceFormRef = useRef(null)
    const niceEncRef = useRef(null);
    const niceBtnRef = useRef(null)
    const [niceData, setNiceData] = useState({})

    const desc = [
        <>아이디를 찾기 위해서 휴대폰 본인 인증이<br />필요합니다.</>,
        <>일치하는 회원이 없습니다<br />아이디 찾기 인증이 실패했습니다.</>,
        <>휴대폰 인증과 일치하는 아이디 알려드립니다</>,
    ]

    const [findIdRes, setFindIdRes] = useState({
        userId: '',
        joinDt: ''
    })
    const findIdObj = {
        url: '/api/extra/JoinController/findId',
        param: {
            phone: niceData.phone,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setStep(1)
                return
            }

            setStep(2)
            setFindIdRes(data[0])
        }
    }
    const findId = useCallApi(findIdObj)

    const openNice = () => {
        setNiceData({})
        niceBtnRef.current.click()
    }

    useEffect(() => {
        if(Object.keys(niceData).length === 0) return

        findId.isReady && findId.call()
    }, [niceData]);

    return (
        <div className="content-area">
            <div className="desc-area">
                <p className="desc">
                    {desc[step]}
                </p>
            </div>
            {
                step === 2 &&
                <div className="info">
                    <div className="id">{findIdRes.userId}</div>
                    <div className="date">{`${findIdRes.joinDt} 가입`}</div>
                </div>
            }
            <div className="btn-area">
                {step === 0 && <div className="btn active" onClick={openNice}>휴대폰 인증하기</div>}
                {step === 1 && <div className="btn active" onClick={openNice}>다시 찾기</div>}
                {step === 2 && <div className="btn active" onClick={() => window.location.href = window.location.origin}>로그인 하기</div>}
            </div>
            <NiceForm niceFormRef={niceFormRef} niceEncRef={niceEncRef} niceBtnRef={niceBtnRef} duplCheck={false} setState={setNiceData} setPopup={setPopup}/>
        </div>
    )
}

export default FindId