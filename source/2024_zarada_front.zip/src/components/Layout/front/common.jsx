import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import {useRecoilState} from "recoil";
import {recoilInjSeq, recoilGrowthSeq, recoilMenuActive} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";
import {leftPad} from "@/utils/Libs/Methods/commonUtils";
import dynamic from "next/dynamic";

const today = new Date()
const year = today.getFullYear()
const month = leftPad(today.getMonth() + 1)
const date = leftPad(today.getDate())
const _today = `${year}${month}${date}`

const MenuBar = dynamic(() => import('@/components/front/commons/MenuBar'), {ssr: false})

const FrontCommon = ({ children, title }) => {
    const router = useRouter()
    const path = router.pathname
    const {injYmd, growthYmd, childSeq} = router.query
    const [layoutType, setLayoutType] = useState('')
    const [showDelete, setShowDelete] = useState(false)
    const [showAdd, setShowAdd] = useState(false)
    const [historyBack, setHistoryBack] = useState(false)   // 뒤로가기 버튼 상태

    // recoil
    const [injSeq, setInjSeq] = useRecoilState(recoilInjSeq)
    const [growthSeq, setGrowthSeq] = useRecoilState(recoilGrowthSeq)
    const [menuActive, setMenuActive] = useRecoilState(recoilMenuActive)

    // 메뉴 닫기
    const menuClose = () => {
        setMenuActive(false)
        document.body.classList.remove('scroll-lock')
    }

    // 성장기록 삭제
    const deleteMyChildGrowthObj = {
        url: '/api/user/GrowthController/deleteMyChildGrowth',
        param: {
            growthSeq: Number(growthSeq),
        },
        onSuccess: (data) => {
            setGrowthSeq(0)
            alert('성장 기록 삭제에 성공하였습니다.')
            router.replace('/front/growth')
        }
    }
    const deleteMyChildGrowth = useCallApi(deleteMyChildGrowthObj)

    // 주사기록 삭제
    const deleteChildInjectionObj = {
        url: '/api/user/InjectionController/deleteChildInjection',
        param: {
            injectionSeq: Number(injSeq)
        },
        onSuccess: (data) => {
            setInjSeq(0)
            alert('주사 기록 삭제에 성공하였습니다.')
            router.replace('/front/injection')
        }
    }
    const deleteChildInjection = useCallApi(deleteChildInjectionObj)

    // 자녀정보 삭제
    const deleteMyChildObj = {
        url: '/api/user/ChildController/deleteMyChild',
        param: {
            childSeq: Number(childSeq)
        },
        onSuccess: (data) => {
            alert('자녀 정보 삭제에 성공하였습니다.')
            router.replace('/front/mypage/manageFaInfo')
        }
    }
    const deleteMyChild = useCallApi(deleteMyChildObj)

    // 삭제 클릭
    const deleteHandler = () => {
        if (router.pathname.indexOf('/growth') > -1) {
            if(growthSeq === 0) {
                alert('저장된 성장 기록이 없습니다.')
                return
            } else {
                if(!confirm('성장 기록을 삭제하시겠습니까?')) return
                deleteMyChildGrowth.isReady && deleteMyChildGrowth.call()
            }
        }

        if (router.pathname.indexOf('/injection') > -1) {
            if(injSeq === 0) {
                alert('저장된 주사 기록이 없습니다.')
                return
            } else {
                if(!confirm('주사 기록을 삭제하시겠습니까?')) return
                deleteChildInjection.isReady && deleteChildInjection.call()
            }
        }

        if(childSeq) {
            if(!confirm('자녀 정보를 삭제하시겠습니까?')) return

            deleteMyChild.isReady && deleteMyChild.call()
        }
    }

    // 기록 클릭
    const addHandler = () => {
        const path = router.pathname

        if(path.indexOf('/growth') > -1) {
            router.push({
                pathname: '/front/growth/reg',
                query: {growthYmd: _today}
            })
        }

        if(path.indexOf(('/injection')) > -1) {
            router.push({
                pathname: '/front/injection/reg',
                query: {injYmd: _today}
            })
        }
    }

    // layout handler
    useEffect(() => {
        if(path.indexOf('/find') > -1) {
            setLayoutType('login')
        }

        if (path.indexOf('/join') > -1) {
            setLayoutType('join')
        }

        if (path.indexOf('/injection') > -1) {
            if (path.indexOf('/injection/reg') > -1 || path.indexOf('/injection/modi') > -1) {
                setShowDelete(true)
            } else {
                setShowAdd(true)
            }
            setLayoutType('injection')
        }

        if (path.indexOf('/growth') > -1) {
            if (path.indexOf('/growth/reg') > -1 || path.indexOf('/growth/modi') > -1) {
                setShowDelete(true)
            } else {
                setShowAdd(true)
            }
            setLayoutType('growth')
        }

        if(path.indexOf('/notice') > -1) {
            setLayoutType('notice')
        }

        if(path.indexOf('/mypage') > -1) {
            childSeq && setShowDelete(true)

            setLayoutType('mypage')
        }

        if(path.indexOf('/consumables') > -1) {
            setLayoutType('consumables')
        }
        // 메인
        if(path.indexOf('/main') > -1) setLayoutType('main')

        // 교육평가
        if(path.indexOf('/education') > -1) setLayoutType('education')

        // 뒤로가기 버튼 체크
        if (path.indexOf('/front/growth/modi') > -1
            || path.indexOf('/front/growth/reg') > -1
            || path.indexOf('/front/injection/modi') > -1
            || path.indexOf('/front/injection/reg') > -1
            || path.indexOf('/front/notice/detail') > -1
            || path.indexOf('/front/join') > -1
            || path.indexOf('/front/mypage/changePaInfo') > -1
            || path.indexOf('/front/mypage/changePw') > -1
            || path.indexOf('/front/mypage/manageFaInfo') > -1
            || path.indexOf('/front/mypage/regChild') > -1
            || path.indexOf('/front/mypage/modiChild') > -1
            || path.indexOf('/front/mypage/withdrawal') > -1
            || path.indexOf('/front/find') > -1
            || path.indexOf('front/consumables/orderDetail') > -1
            || path.indexOf('front/education') > -1
            || path.indexOf('front/growth/helper') > -1
        ) {
            setHistoryBack(true)
            setShowAdd(false)
        } else {
            setHistoryBack(false)
        }

        return (() => {
            setShowDelete(false)
            setShowAdd(false)
            setMenuActive(false)
            setHistoryBack(false)
        })

    }, [router.pathname])

    return (
        <>
            <MenuBar menuActive={menuActive} setMenuActive={setMenuActive} menuClose={menuClose}/>
            <header id="header" className="header">
                <div className="left">
                    {
                        (historyBack)
                            ?
                            <div className="back" onClick={() => router.back()}>
                                <div className="img">
                                    <img src="/img/header_back_icon.png" alt="뒤로가기" />
                                </div>
                            </div>
                            : <></>
                    }
                </div>
                <div className="center">
                    {
                        layoutType === 'main'
                        ?   <div className="logo">
                                <div className="img"><img src="/img/common_main_logo.png" alt="자라다" /></div>
                            </div>
                        : <div className="title">{title}</div>
                    }
                </div>
                <div className="right">
                    {showDelete && <div className="del" onClick={deleteHandler}>삭제</div>}
                    {showAdd && <div className="record" onClick={addHandler}>기록</div>}
                </div>
            </header>

            {children}
        </>
    )
}

export default FrontCommon