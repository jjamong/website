import {useEffect} from "react"

const FrontFullPage = ({ children }) => {

    useEffect(() => {
        document.getElementsByTagName('html')[0].setAttribute('class', 'full')
        document.getElementsByTagName('body')[0].setAttribute('class', 'full login')

        return (() => {
            document.getElementsByTagName('html')[0].setAttribute('class', '')
            document.getElementsByTagName('body')[0].setAttribute('class', '')
        })
    }, [])


    return (
        <>
            {children}
        </>
    );
}

export default FrontFullPage;