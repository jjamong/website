import React, {useEffect} from 'react'
import {removeAccessToken} from "@/utils/Libs/Methods/authToken"
import {useCallApi} from "@/utils/Query/customApi";

const AdminFullPage = ({ children }) => {
    const logoutObj = {
        url: '/api/user/LoginController/logout',
        param: {},
        onSuccess: (data) => {
            // RN으로 쿠키 세팅 호출
            if(window.ReactNativeWebView) {
                const msgType = 'SET_ANDROID_COOKIE'

                window.ReactNativeWebView.postMessage(JSON.stringify({ msgType }));
            }

            removeAccessToken()
            window.location.href = window.location.origin
        }
    }
    const logout = useCallApi(logoutObj)

    const logoutClick = () => {
        logout.isReady && logout.call()
    }

    useEffect(() => {
        document.getElementsByTagName('html')[0].setAttribute('class', 'full')
        document.getElementsByTagName('body')[0].setAttribute('class', 'full main')

        return (() => {
            document.getElementsByTagName('html')[0].setAttribute('class', '')
            document.getElementsByTagName('body')[0].setAttribute('class', '')
        })
    }, [])

    return (
        <>
            <header id="header" className="header admin">
                <div className="left">
                </div>
                <div className="center">
                    <div className="logo">
                        <div className="img"><img src="/img/header_logo.png" alt="자라다" /></div>
                    </div>
                </div>
                <div className="right">
                    <div className="logout">
                        <div className='btn' onClick={logoutClick}>로그아웃</div>
                    </div>
                </div>
            </header>

            {children}

            <footer>
            </footer>
        </>
    )
}

export default AdminFullPage
