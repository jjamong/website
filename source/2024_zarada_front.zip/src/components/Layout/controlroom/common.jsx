import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import dynamic from "next/dynamic";

const MenuBar = dynamic(() => import("@/components/controlroom/commons/MenuBar"), {ssr: false});

const AdminCommon = ({ children, title}) => {
    const router = useRouter()
    const [historyBack, setHistoryBack] = useState(false)   // 뒤로가기 버튼 상태
    const [menuActive, setMenuActive] = useState(false)

    // 메뉴 열기
    const menuOpen = () => {
        setMenuActive(true)
        document.body.classList.add('scroll-lock')
    }

    // 메뉴 닫기
    const menuClose = () => {
        setMenuActive(false)
        document.body.classList.remove('scroll-lock')
    }

    useEffect(() => {
        const path = router.pathname

        // 뒤로가기 버튼 체크
        if (path.indexOf('/controlroom/admins/reg') > -1
            || path.indexOf('/controlroom/admins/modi') > -1
            || path.indexOf('/controlroom/notice/reg') > -1
            || path.indexOf('/controlroom/notice/modi') > -1
            || path.indexOf('/controlroom/notice/detail') > -1
            || path.indexOf('/controlroom/users/detail') > -1
        ) {
            setHistoryBack(true)
        } else {
            setHistoryBack(false)
        }

        return (
            () => {
                setMenuActive(false)
                setHistoryBack(false)
            }
        )
    }, [router.pathname])

    return (
        <>
            <MenuBar menuActive={menuActive} menuClose={menuClose} />

            <header id="header" className="header admin">
                <div className="left">
                    {
                        (historyBack)
                            ?  
                            <div className="back" onClick={() => router.back()}>
                                <div className="img">
                                    <img src="/img/header_back_icon.png" alt="뒤로가기" />
                                </div>
                            </div>
                            :
                            <div className="menu" onClick={menuOpen}>
                                <div className="img">
                                    <img src="/img/common_header_menu.png" alt="메뉴" />
                                </div>
                            </div>
                    }
                </div>
                <div className="center">
                    <div className="title">{title}</div>
                </div>
                <div className="right">
                </div>
            </header>

            {children}

            <footer>
            </footer>
        </>
    )
}

export default AdminCommon