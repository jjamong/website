import {
    FaAlignCenter,
    FaAlignLeft,
    FaAlignRight,
    FaBold,
    FaHeading,
    FaItalic,
    FaRegImage,
    FaUnderline
} from "react-icons/fa6";
import {LuHeading1, LuHeading2, LuHeading3, LuHeading4, LuHeading5, LuRedo2, LuUndo2} from "react-icons/lu";
import {useRef, useState} from "react";
import {imgToBase64} from "@/utils/Libs/Methods/commonUtils";

const ToolBar = (props) => {
    const {editor} = props
    const [showHeading, setShowHeading] = useState(false)
    const [showAlign, setShowAlign] = useState(false)
    const imageRef = useRef(null)

    if (!editor) return null;

    const headingClick = (level) => {
        editor.chain().focus().toggleHeading({level: level}).run()
        setShowHeading(false)
    }

    const alignClick = (alignment) => {
        editor.chain().focus().setTextAlign(alignment).run()
        setShowAlign(false)
    }

    const imageClick = () => {
        imageRef.current.click()
    }

    const upload = () => {
        let file = document.getElementById('file')

        imgToBase64(file).then((src) => {
            editor.chain().focus().setImage({ src: src }).run()
        }).catch((e) => {
            alert(e)
        })
    }

    return (
        <div className='tiptap-toolbar'>
            <div className='sub-menu'>
                <button
                    onClick={() => setShowHeading((prevState) => !prevState)}
                >
                    <FaHeading size='18'/>
                </button>
                {
                    showHeading &&
                    <div className='sub'>
                        <div className='sub-btn'>
                            <button
                                onClick={() => headingClick(1)}
                                className={editor.isActive('heading', {level: 1}) ? 'is-active' : ''}
                            >
                                <LuHeading1 size='18'/>
                            </button>
                            <button
                                onClick={() => headingClick(2)}
                                className={editor.isActive('heading', {level: 2}) ? 'is-active' : ''}
                            >
                                <LuHeading2 size='18'/>
                            </button>
                            <button
                                onClick={() => headingClick(3)}
                                className={editor.isActive('heading', {level: 3}) ? 'is-active' : ''}
                            >
                                <LuHeading3 size='18'/>
                            </button>
                            <button
                                onClick={() => headingClick(4)}
                                className={editor.isActive('heading', {level: 4}) ? 'is-active' : ''}
                            >
                                <LuHeading4 size='18'/>
                            </button>
                            <button
                                onClick={() => headingClick(5)}
                                className={editor.isActive('heading', {level: 5}) ? 'is-active' : ''}
                            >
                                <LuHeading5 size='18'/>
                            </button>
                        </div>
                    </div>
                }
            </div>
            <button
                onClick={() => editor.chain().focus().toggleBold().run()}
                className={editor.isActive('bold') ? 'is-active' : ''}>
                <FaBold size='18'/>
            </button>
            <button
                onClick={() => editor.chain().focus().toggleItalic().run()}
                className={editor.isActive('italic') ? 'is-active' : ''}>
                <FaItalic size='18'/>
            </button>
            <button
                onClick={() => editor.chain().focus().toggleUnderline().run()}
                className={editor.isActive('underline') ? 'is-active' : ''}
            >
                <FaUnderline size='18'/>
            </button>
            <input
                className='tiptap-color'
                type="color"
                onChange={event => editor.chain().focus().setColor(event.target.value).run()}
                value={editor.getAttributes('textStyle').color ?? '#000000'}
                data-testid="setColor"
            />
            <div className='sub-menu'>
                <button
                    onClick={() => setShowAlign((prevState) => !prevState)}
                >
                    <FaAlignLeft size='18'/>
                </button>
                {
                    showAlign &&
                    <div className='sub'>
                        <div className='sub-btn'>
                            <button
                                onClick={() => alignClick('left')}
                                className={editor.isActive({textAlign: 'left'}) ? 'is-active' : ''}
                            >
                                <FaAlignLeft size='14'/>
                            </button>
                            <button
                                onClick={() => alignClick('center')}
                                className={editor.isActive({textAlign: 'center'}) ? 'is-active' : ''}
                            >
                                <FaAlignCenter size='14'/>
                            </button>
                            <button
                                onClick={() => alignClick('right')}
                                className={editor.isActive({textAlign: 'right'}) ? 'is-active' : ''}
                            >
                                <FaAlignRight size='14'/>
                            </button>
                        </div>
                    </div>
                }
            </div>
            <input
                id='file'
                className='tiptap-image'
                type='file'
                onChange={(e) => {upload(e)}}
                ref={imageRef}
            />
            <FaRegImage size='18' onClick={imageClick}/>
            <button onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()}>
                <LuUndo2 size='18'/>
            </button>
            <button onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()}>
                <LuRedo2 size='18'/>
            </button>
        </div>
    )
}

export default ToolBar