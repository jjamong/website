const LabelTextArea = (props) => {
    const {
        customClass,
        title,
        id,
        isRequire,
        value,
        placeholder,
        changeHandler,
        clickHandler,
        inputRef,
        isReadOnly,
        isDisabled,
        inputClass,
        desc
    } = props;

    return (
        <div className={`form-item ${customClass ? customClass : ''}`}>
            <label htmlFor={id} className="tit">{title}{isRequire && <span className="require">*</span>}</label>
            <div className='input-area'>
                <div className='input-textarea'>
                    <textarea id={id} value={value ? value : ''} placeholder={placeholder ? placeholder : ''}
                              onChange={changeHandler ? (e) => changeHandler(id, e) : undefined}
                              ref={inputRef ? inputRef : undefined}
                              onClick={clickHandler ? () => clickHandler(value ? value : '') : undefined}
                              readOnly={isReadOnly ? isReadOnly : false} disabled={isDisabled ? isDisabled : false}
                              className={inputClass ? inputClass : ''}/>
                </div>
            </div>
            {desc ?
                <p className={desc.descClass}>{desc.descTitle}</p>
                : <></>
            }
        </div>
    )
}

export default LabelTextArea