import {useEffect, useState} from "react";

const Pagination = (props) => {
    const { changeActivePage, totalItems, activePage, itemsPerPage, pageRangeDisplayed } = props;

    let totalPage = Math.ceil(totalItems / itemsPerPage);

    const [currentpageArray, setCurrentPageArray] = useState([]);
    const [totalPageArray, setTotalPageArray] = useState([]);

    const sliceArrayByLimit = (totalPage, limit) => {
        const totalPageArray = Array(totalPage)
            .fill(1)
            .map((_, i) => i + 1);
        return Array(Math.ceil(totalPage / limit))
            .fill(1)
            .map(() => totalPageArray.splice(0, limit));
    };

    useEffect(() => {
        // 다음페이지로 넘어갈때
        if (activePage % pageRangeDisplayed === 1) {
            setCurrentPageArray(totalPageArray[Math.floor(activePage / pageRangeDisplayed)])
        } else if (activePage % pageRangeDisplayed === 0) { // 이전 페이지로 넘어갈때
            setCurrentPageArray(totalPageArray[Math.floor(activePage / pageRangeDisplayed) - 1])
        }
    }, [activePage]);

    useEffect(() => {
        const slicedPageArray = sliceArrayByLimit(totalPage, pageRangeDisplayed);
        setTotalPageArray(slicedPageArray);
        setCurrentPageArray(slicedPageArray[0])
    }, [totalPage])

    const prevPage = () => {
        if(activePage === 1) return;

        changeActivePage(activePage - 1);
    }

    const nextPage = () => {
        if(activePage >= totalPage) return;

        changeActivePage(activePage + 1);
    }

    return (
        <div className="paging-area">
            <div className="paging">
                <div className="item prev" onClick={prevPage}>
                    <img src="/img/common_paging_prev_btn.png" alt="이전" />
                </div>
                {
                    currentpageArray ?
                        currentpageArray.map((index) => {
                            return (
                                <div key={index} onClick={() => changeActivePage(index)} className='item num'><span
                                    className={`${activePage === index ? 'active' : ''}`}>{index}</span></div>
                            )
                        })
                        :
                        <div className='item num'>
                            <span className='active'>1</span>
                        </div>
                }
                <div className="item next" onClick={nextPage}>
                    <img src="/img/common_paging_next_btn.png" alt="다음" />
                </div>
            </div>
        </div>
    );
}

export default Pagination;