/**
 * @param customClass: form-item 외의 클래스 추가 시 사용 (string)
 * @param id: label의 htmlFor 및 select태그의 id로 사용 (string)
 * @param title: label의 타이틀 (string)
 * @param isRequire: 필수 * 표시 여부 (boolean)
 * @param selectRef: select태그와 연결할 ref (useRef)
 * @param value: select태그의 default value (*)
 * @param changeHandler: change이벤트 (function)
 * @param datas: option으로 들어갈 데이터 (Array)
 * */
const LabelSelect = (props) => {
    const {customClass, id, title, isRequire, selectRef, value, isDisabled, changeHandler, datas} = props;

    return (
        <div className={customClass ? `form-item ${customClass}` : 'form-item'}>
            <label htmlFor={id} className="tit">{title}{isRequire && <span className="require">*</span>}</label>
            <div className="input-section">
                <div className="select-area">
                    <div className='input-select'>
                        <select id={id} ref={selectRef ? selectRef : undefined}
                                onChange={changeHandler ? (e) => changeHandler(id, e) : undefined}
                                value={(value !== null && value !== undefined) ? value : ''}
                                disabled={isDisabled ? isDisabled : false}
                                className={isDisabled ? 'disabled' : undefined}>
                            {datas.map((data) => <option key={data.value} value={data.value}>{data.text}</option>)}
                        </select>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default LabelSelect;