const LabelSelectWithInput = (props) => {
    const {customClass, selectId, inputId, title, isRequire, selectRef, selectValue, inputRef, inputValue, inputType, isDisabled, isReadOnly, changeHandler, selectData, placeholder} = props;
    return (
        <div className={customClass ? `form-item ${customClass}` : 'form-item'}>
            <label htmlFor={selectId} className="tit">{title}{isRequire && <span className="require">*</span>}</label>
            <div className="input-section">
                <div className="select-area">
                    <div className='input-select'>
                        <select id={selectId} ref={selectRef ? selectRef : undefined}
                                onChange={changeHandler ? (e) => changeHandler(selectId, e) : undefined}
                                value={(selectValue !== null && selectValue !== undefined) ? selectValue : ''}
                                disabled={isDisabled ? isDisabled : false}
                                className={isDisabled ? 'disabled' : undefined}>
                            {selectData.map((data) => <option key={data.value} value={data.value}>{data.text}</option>)}
                        </select>
                    </div>
                </div>
                <div className="input-area">
                    <div className="input-text">
                        <input id={inputId} type={inputType ? inputType : 'text'} value={inputValue ? inputValue : ''} ref={inputRef ? inputRef : undefined}
                               onChange={changeHandler ? (e) => changeHandler(inputId, e) : undefined}
                               placeholder={placeholder ? placeholder : undefined}
                               disabled={isDisabled ? isDisabled : false} readOnly={isReadOnly ? isReadOnly : false}
                               className={isDisabled ? 'disabled' : undefined}/>
                    </div>
                </div>
            </div>
        </div>

    )
        ;
}

export default LabelSelectWithInput;