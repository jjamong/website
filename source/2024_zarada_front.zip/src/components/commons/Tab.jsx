const Tab = (props) => {
    const {active, clickHandler, id, title} = props;

    return (
        <div id={id} className={`tab ${active ? 'active' : ''}`} onClick={clickHandler ? () => clickHandler(id) : undefined}>{title}</div>
    );
}

export default Tab;