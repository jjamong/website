import {EditorContent, useEditor} from "@tiptap/react"
import {StarterKit} from "@tiptap/starter-kit"
import Underline from '@tiptap/extension-underline'
import TextStyle from '@tiptap/extension-text-style'
import {Color} from '@tiptap/extension-color'
import {TextAlign} from '@tiptap/extension-text-align'
import {Image} from "@tiptap/extension-image";
import ToolBar from "@/components/commons/ToolBar"
import {useEffect} from "react";

const TipTapEditor = (props) => {
    const {content, setContent, editable=false} = props

    const editor = useEditor({
        extensions: [
            StarterKit.configure({
                heading: {
                    levels: [1, 2, 3, 4, 5]
                },
            }),
            Underline,
            TextStyle,
            Color,
            TextAlign.configure({
                types: ['heading', 'paragraph'],
                alignments: ['left', 'center', 'right'],
                defaultAlignment: 'left',
            }),
            Image.configure({
                allowBase64: true,
            })
        ],
        editorProps: {
            attributes: {
                class: 'tiptap-custom'
            }
        },
        content: content,
        editable: editable,
        onUpdate: ({editor}) => {
            setContent(editor.getHTML())
        }
    })

    useEffect(() => {
        if(!editor) return

        const selectAll = (e) => {
            if(e.key === 'a' && (e.ctrlKey || e.metaKey)) {
                editor.commands.selectAll()
            }
        }

        let textEditor = document.getElementById('textEditor')
        textEditor.addEventListener('keydown', (e) => selectAll(e))

        return (
            textEditor.removeEventListener('keydown', selectAll)
        );
    }, [editor]);

    useEffect(() => {
        if(!editor) return

        editor.commands.setContent(content)
    }, [content]);

    if (!editor) {
        return null
    }

    return (
        <>
            {editable && <ToolBar editor={editor}/>}
            <EditorContent id='textEditor' editor={editor} />
        </>
    )
}

export default TipTapEditor