import ListTag from "@/components/commons/ListTag";
import {cdNaConvert, dateFormat} from "@/utils/Libs/Methods/commonUtils";

const TableBody = (props) => {
    const {thList, datas, handlerValue, trHandler, tagConf, dateConf} = props;

    const isHandler = (value) => {
        if(trHandler && handlerValue){
            trHandler(value);
        }
    }

    return (
        <div className="table-section">
            <table className="table">
                <thead>
                <tr>
                    {thList.map((th) => {
                        return (
                            <th key={th.colId} scope='col'>{th.title}</th>
                        );
                    })}
                </tr>
                </thead>
                <tbody>
                    {datas.length === 0 ?
                        <tr>
                            <td colSpan={thList.length}>조회된 데이터가 없습니다.</td>
                        </tr>
                    :
                        datas.map((data, index) => {
                            return (
                                <tr key={index} onClick={()=> isHandler(handlerValue ? data[handlerValue] : '')}>
                                    {thList.map((td) => {
                                        return(
                                            <td key={td.colId} className='less'>
                                                {td.colId === 'tag'
                                                    ? tagConf && <ListTag type={tagConf.type} cate={tagConf.cate} value={data[tagConf?.value]} handlerValue={handlerValue ? data[handlerValue] : ''} handler={tagConf?.tagHandler}/>
                                                    : td.colId === 'role' ? cdNaConvert(td.colId, data[td.colId])
                                                        : dateConf && td.colId.toLowerCase().includes('date') ? dateFormat(data[td.colId], dateConf.format, dateConf.delimiter)
                                                            : dateConf && td.colId.toLowerCase().includes('dt') && data[td.colId] ? data[td.colId].split(' ')[0]
                                                                : data[td.colId]}
                                            </td>
                                        );
                                    })}
                                </tr>
                            );
                        })
                    }
                </tbody>
            </table>
        </div>
    );
}

export default TableBody;