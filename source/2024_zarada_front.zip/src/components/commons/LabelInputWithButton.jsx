const LabelInputWithButton = (props) => {
    const {customClass, id, isRequire, type, placeholder, btnClass, title, btnTitle, value, clickHandler, changeHandler, isDisabled, desc, inputRef} = props;

    return (
        <div className={`form-item ${customClass ? customClass : ''}`}>
            <label htmlFor={id} className="tit">{title}{isRequire && <span className="require">*</span>}</label>
            <div className="input-area">
                <div className="input-text"><input id={id} type={type ? type : 'text'} placeholder={placeholder ? placeholder : ''} value={value ? value : ''} ref={inputRef ? inputRef : undefined}
                                                   disabled={isDisabled ? isDisabled : false} className={isDisabled ? 'disabled' : ''} onChange={changeHandler ? (e) => changeHandler(id, e) : undefined}/>
                </div>
                <div className={btnClass}>
                    <div className="btn" onClick={clickHandler ? clickHandler : undefined}>{btnTitle}</div>
                </div>
            </div>
            {desc ?
                <p className={desc.descClass}>{desc.descTitle}</p>
             : <></>
            }
        </div>
    );
}

export default LabelInputWithButton;