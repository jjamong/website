const LabelRadio = (props) => {
    const {id, name, value, checked, changeHandler, labelTitle, isDisabled, isReadOnly, customClass} = props;

    return (
        <div className="radio-area">
            <div className='input-radio'>
                <input type="radio" id={id} name={name} value={value} checked={checked}
                       onChange={(e) => changeHandler(name, e)}
                       disabled={isDisabled ? isDisabled : false} readOnly={isReadOnly ? isReadOnly : false}/>
            </div>
            <label htmlFor={id} className={customClass ? customClass : undefined}>{labelTitle}</label>
        </div>
    );
}

export default LabelRadio;