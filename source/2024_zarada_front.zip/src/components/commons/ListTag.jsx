import {eduStatusText} from "@/utils/Libs/Methods/commonUtils";

const ListTag = (props) => {
    const {type, cate, value, handlerValue, handler} = props;

    const isHandler = (value, value2) => {
        if(handler && handlerValue){
            handler(value, value2);
        }
    }

    const setTag = () => {
        if(cate == 'aa') {
            switch (value) {
                case 'ROLE_TOP_ADMIN':
                    return (
                        <div>
                            <div>-</div>
                        </div>
                    );
                default:
                    return (
                        <div className="btn status delete">
                            <div onClick={(e) => isHandler(handlerValue ? handlerValue : '', e)}>
                                <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 20 20"
                                     aria-hidden="true" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                                    <path fillRule="evenodd"
                                          d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                          clipRule="evenodd"></path>
                                </svg>
                                삭제
                            </div>
                        </div>
                    );
            }
        }

        if (cate == 'au') {
            switch (value) {
                case '10':
                    return (
                        <div className="btn status">
                            <div>미승인</div>
                        </div>
                    );
                case '20':
                    return (
                        <div className="btn status">
                            <div>승인</div>
                        </div>
                    );
                case '30':
                    return (
                        <div className="btn status">
                            <div>승인 취소</div>
                        </div>
                    );
                case '40':
                    return (
                        <div className="btn status">
                            <div>차단</div>
                        </div>
                    );
                default:
                    return (
                        <div>
                            <div>-</div>
                        </div>
                    );
            }
        }

        if(cate == 'ord') {
            switch (value) {
                case 0:
                    return (
                        <div className="btn status">
                            <div>배송준비</div>
                        </div>
                    );
                case 1:
                    return (
                        <div className="btn status">
                            <div>배송중</div>
                        </div>
                    );
                case 2:
                    return (
                        <div className="btn status">
                            <div>배송완료</div>
                        </div>
                    );
                default:
                    return (
                        <div>
                            <div>-</div>
                        </div>
                    );
            }
        }

        if(cate == 'eduStatus') {
            return (
                <div className={`btn status edu${value}`}>
                    <div>{eduStatusText(value)}</div>
                </div>
            );
        }
    }

    return (
        setTag()
    );
}

export default ListTag;