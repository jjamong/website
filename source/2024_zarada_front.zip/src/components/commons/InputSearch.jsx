const InputSearch = (props) => {
    const {selectId, selectData, inputId, type, placeholder, selectRef, inputRef, clickHandler, changeHandler} = props;

    return (
        <div className="search-section">
            <div className="select-area">
                <div className='input-select'>
                    <select id={selectId} ref={selectRef ? selectRef : undefined} onChange={changeHandler ? (e) => changeHandler(selectId, e) : undefined}>
                        {selectData.map((data) => {
                            return (
                                <option key={data.id} value={data.id}>{data.text}</option>
                            );
                        })}
                    </select>
                </div>
            </div>
            <div className="input-area">
                <div className='input-text'>
                    <input id={inputId} type={type} placeholder={placeholder} ref={inputRef ? inputRef : undefined} onChange={changeHandler ? (e) => changeHandler(inputId, e) : undefined}/>
                </div>
            </div>
            <div className="btn-area">
                <div className="btn active" onClick={clickHandler}>검색</div>
            </div>
        </div>
    );
}

export default InputSearch;