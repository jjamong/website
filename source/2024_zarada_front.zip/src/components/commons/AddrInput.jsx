const AddrInput = (props) => {
    const {id1, id2, id3, isRequire, type, value1, value2, value3, changeHandler, inputRef1, inputRef2, inputRef3, openAddr, isDisabled, isDisabled2, isReadOnly, isReadOnly2, inputClass, inputClass2} = props;

    return (
        <div className="form-item addr">
            <label htmlFor={id1} className="tit">주소{isRequire && <span className="require">*</span>}</label>
            <div className="input-section">
                <div className={`input-area ${(openAddr || !isDisabled) ? 'zipcode' : ''}`}>
                    <div className="input-text"><input id={id1} type={type ? type : 'text'} placeholder="우편번호" value={value1 ? value1 : ''} disabled={isDisabled ? isDisabled : false} readOnly={isReadOnly ? isReadOnly : false} className={inputClass ? inputClass : ''}
                        onChange={!isDisabled ? (e) => changeHandler(id1, e) : undefined} ref={inputRef1 ? inputRef1 : undefined}/></div>
                    {(openAddr || !isDisabled) &&
                        <div className="search">
                            <div className="btn" onClick={openAddr ? openAddr : undefined}>찾기</div>
                        </div>
                    }
                </div>
                <div className="input-area">
                    <div className="input-text"><input id={id2} type={type ? type : 'text'} placeholder="주소" value={value2 ? value2 : ''} disabled={isDisabled ? isDisabled : false} className={inputClass ? inputClass : ''} readOnly={isReadOnly ? isReadOnly : false}
                                                       onChange={!isDisabled ? (e) => changeHandler(id2, e) : undefined} ref={inputRef2 ? inputRef2 : undefined}/></div>
                </div>
                <div className="input-area">
                    <div className="input-text"><input id={id3} type={type ? type : 'text'} placeholder="상세주소" value={value3 ? value3 : ''} disabled={isDisabled2 ? isDisabled2 : false} className={inputClass2 ? inputClass2 : ''} readOnly={isReadOnly2 ? isReadOnly2 : false}
                                                       onChange={!isDisabled2 ? (e) => changeHandler(id3, e) : undefined} ref={inputRef3 ? inputRef3 : undefined}/></div>
                </div>
            </div>
        </div>
    );
}

export default AddrInput;