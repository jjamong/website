// component
import {useRouter} from 'next/router'
import {RecoilEnv, RecoilRoot} from 'recoil'
import {QueryClient, QueryClientProvider} from '@tanstack/react-query'
import Head from 'next/head'
import FrontCommon from "@/components/Layout/front/common";
import FrontFullPage from "@/components/Layout/front/fullpage";
import AdminCommon from "@/components/Layout/controlroom/common";
import AdminFullPage from "@/components/Layout/controlroom/fullpage";

// css
import '../../public/css/common.css'
import '../../public/css/front/consumables.css'
import '../../public/css/front/education.css'
import '../../public/css/front/growth.css'
import '../../public/css/front/injection.css'
import '../../public/css/front/join.css'
import '../../public/css/front/login.css'
import '../../public/css/front/main.css'
import '../../public/css/front/mypage.css'
import '../../public/css/front/notice.css'
import '../../public/css/controlroom/admin.css'
import '../../public/css/controlroom/main.css'

import '../../node_modules/react-datepicker/dist/react-datepicker.css'
import WebViewLayer from "@/components/front/commons/WebViewLayer";

export default function App({ Component, pageProps }) {
  const router = useRouter()

  // react-query 설정
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnMount: false, //쿼리 mount시 자동실행
        refetchOnWindowFocus: false, //윈도우에 focus시 자동실행
        refetchOnReconnect: false, //네트워크 연결이 끊겼다가 다시 연결됐을때 자동실행
        retry: false,
        retryOnMount: false,
      },
    },
  })

  if(typeof window != 'undefined') {
    window.sessionStorage.setItem('login', false)
  }

  //recoil의 키값은 고유한 값이어야한다. recoil의 atom 변경해 재렌더링 시 기능적으로는 문제가 없으나 키값이 중복이라는 에러를 뱉어낸다. 해당 오류가 나오지 않게 환경설정
  RecoilEnv.RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED = false

  // 레이아웃 설정
  const setLayout = () => {
    let layoutType = (Component.layoutType) ? Component.layoutType : 'front'
    let fullpageType = (Component.fullpageType) ? Component.fullpageType : false
    return (
        <>
          {
            layoutType == 'front' && fullpageType === true
                ?
                <FrontFullPage>
                  <Component {...pageProps} />
                </FrontFullPage>
                : <></>
          }
          {
            layoutType == 'front' && fullpageType == false
                ?
                <FrontCommon title={Component.title}>
                  <Component {...pageProps} />
                </FrontCommon>
                : <></>
          }
          {
            layoutType == 'admin' && fullpageType == true
                ?
                <AdminFullPage>
                  <Component {...pageProps} />
                </AdminFullPage>
                : <></>
          }
          {
            layoutType == 'admin' && fullpageType == false
                ?
                <AdminCommon title={Component.title}>
                  <Component {...pageProps} />
                </AdminCommon>
                : <></>
          }
        </>
    )
  }


  return (
      <>
        <Head>
          <title>ZARADA</title>
          <link rel="shortcut icon" href="/img/favicon.ico"></link>
          <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
          <meta charSet='utf-8' />
          <meta httpEquiv='X-UA-Compatible' content='IE=edge,chrome=1' />
        </Head>
        <RecoilRoot>
          <QueryClientProvider client={queryClient}>
            {/*<Loading />*/}
            <WebViewLayer>
              {setLayout()}
            </WebViewLayer>
          </QueryClientProvider>
        </RecoilRoot>
      </>
  )
}
