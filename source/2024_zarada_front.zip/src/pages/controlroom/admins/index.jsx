import {useEffect, useState} from "react"
import TableBody from "@/components/commons/TableBody"
import Pagination from "@/components/commons/Pagination"
import {useRouter} from "next/router"
import {useCallApi} from "@/utils/Query/customApi";
import {useRecoilState} from "recoil";
import {recoilUser} from "@/utils/Store/atom";

const Admins = () => {
    const router = useRouter()
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [activePage, setActivePage] = useState(1)

    const [rmAdminSeq, setRmAdminSeq] = useState(null)

    const thList = [
        {title: '이름', colId: 'userName'},
        {title: '핸드폰번호', colId: 'phone'},
        {title: '그룹', colId: 'role'},
        {title: '관리', colId: 'tag'},
    ]

    // 관리자/간호사 목록 count 조회
    const [selectNurseListCountRes, setSelectNurseListCountRes] = useState(0)
    const selectNurseListCountObj = {
        url: '/api/admin/NurseController/selectNurseListCount',
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNurseListCountRes(0)
                return
            }

            setSelectNurseListCountRes(data[0].count)
        },
    }
    const selectNurseListCount = useCallApi(selectNurseListCountObj)

    useEffect(() => {
        selectNurseListCount.isReady && selectNurseListCount.call()
    }, [])

    // 관리자/간호사 목록 조회
    const [selectNurseListRes, setSelectNurseListRes] = useState([])
    const selectNurseListObj = {
        url: '/api/admin/NurseController/selectNurseList',
        param: {
            page: activePage,
            size: 10,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNurseListRes([])
                return
            }

            setSelectNurseListRes(data)
        },
    }
    const selectNurseList = useCallApi(selectNurseListObj)
    useEffect(() => {
        selectNurseList.isReady && selectNurseList.call()
    }, [activePage])

    // 간호사 삭제
    const deleteNurseObj = {
        url: '/api/admin/NurseController/deleteNurse',
        param: {
            userSeq: rmAdminSeq,
        },
        onSuccess: (data) => {
            alert('관리자 삭제에 성공하였습니다.')

            selectNurseListCount.isReady && selectNurseListCount.call()
            if(activePage === 1) {
                selectNurseList.isReady && selectNurseList.call()
            } else {
                setActivePage(1);
            }
        }
    }
    const deleteNurse = useCallApi(deleteNurseObj);

    // TableBody
    const trHandler = (target) => {
        //     디테일 조회
        router.push({
            pathname: 'admins/modi',
            query: {userSeq: target}
        })
    }

    const handleDelAdmin = (seq, e) => {
        e.stopPropagation()

        if(!confirm('삭제하시겠습니까?')) return
        // 간호사 삭제
        setRmAdminSeq(seq);
        deleteNurse.isReady && deleteNurse.call()
    }

    const handleAddAdmin = () => {
        router.push('admins/reg')
    }

    const tagConf = {type:'b', cate:'aa', value:'role', tagHandler:handleDelAdmin}

    // Pagination
    const changeActivePage = (value) => {
        if(activePage === value) return

        setActivePage(value)
    }

    return(
        <>
            <main id="container" className="container admin list">
                <div className="wrap">
                    <TableBody thList={thList} datas={selectNurseListRes} handlerValue={'userSeq'} trHandler={trHandler} tagConf={tagConf} />
                    <Pagination changeActivePage={changeActivePage} totalItems={selectNurseListCountRes} activePage={activePage} itemsPerPage={10} pageRangeDisplayed={5} />
                    <div className="add-section" onClick={handleAddAdmin}>
                        <div className='btn-area'>
                            <div className="btn">+ 사용자 추가</div>
                        </div>
                    </div>
                </div>
            </main>
        </>
    )
}

Admins.title = '간호사 관리'
Admins.layoutType = 'admin'

export default Admins