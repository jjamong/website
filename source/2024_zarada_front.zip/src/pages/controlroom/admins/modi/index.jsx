import LabelInput from "@/components/commons/LabelInput"
import {useEffect, useState} from "react"
import {useRouter} from "next/router"
import {addAdminValidate} from "@/utils/Libs/Methods/adminValidate"
import {useCallApi} from "@/utils/Query/customApi";
import {setParam} from "@/utils/Libs/Methods/commonUtils";

const Modify = () => {
    const router = useRouter()
    const {userSeq} = router.query

    // 간호사 상세 조회
    const [selectNurseDetailRes, setSelectNurseDetailRes] = useState({
        userSeq: 0,
        userId: '',
        userPw: '',
        userName: '',
        phone: '',
        role: ''
    })
    const selectNurseDetailObj = {
        url: '/api/admin/NurseController/selectNurseDetail',
        param: {
            userSeq
        },
        onSuccess: (data) => {
            if(!data[0]) {
                alert('간호사 조회 실패')
                return
            }

            setSelectNurseDetailRes(data[0])
        }
    }
    const selectNurseDetail = useCallApi(selectNurseDetailObj)

    useEffect(() => {
        if(!router.isReady) return

        selectNurseDetail.isReady && selectNurseDetail.call()
    }, [router.isReady])

    // 간호사 수정
    const updateNurseObj = {
        url: '/api/admin/NurseController/updateNurse',
        param: selectNurseDetailRes,
        onSuccess: (data) => {
            alert('간호사 수정에 성공하였습니다.')
            router.replace('/controlroom/admins')
        }
    }
    const updateNurse = useCallApi(updateNurseObj)

    const onInputChange = (target, e) => {
        setParam(setSelectNurseDetailRes, {[target]: e.target.value})
    }

    const adminUpdate = () => {
        const {status, msg, elem} = addAdminValidate(selectNurseDetailRes, 'U')

        if(!status) {
            alert(msg)
            return
        }

        updateNurse.isReady && updateNurse.call()
    }

    return(
        <>
            <main id="container" className="container admin form">
                <div className="wrap">
                    <div className="section admin-section">
                        <div className="content">
                            <LabelInput title={'아이디'} id={'userId'} isRequire={true} type={'text'} value={selectNurseDetailRes.userId} placeholder={'영문,숫자만 사용가능 (4자리 이상)'} changeHandler={onInputChange}/>
                            <LabelInput title={'비밀번호'} id={'userPw'} type={'text'} value={selectNurseDetailRes.userPw} placeholder={'영문,숫자 포함 8자리 이상 (특수문자 사용불가)'} changeHandler={onInputChange}/>
                            <LabelInput title={'사용자 이름'} id={'userName'} isRequire={true} type={'text'} value={selectNurseDetailRes.userName} placeholder={'이름을 입력해 주세요.'} changeHandler={onInputChange}/>
                            <LabelInput title={'휴대폰 번호'} id={'phone'} isRequire={true} type={'number'} value={selectNurseDetailRes.phone} placeholder={'숫자만 입력(01044448888)'} changeHandler={onInputChange}/>
                        </div>
                    </div>
                    <div className="btn-area">
                        <div className="close btn" onClick={() => router.back()}>닫기</div>
                        <div className="save active btn" onClick={adminUpdate}>저장</div>
                    </div>
                </div>
            </main>
            <footer id="footer">
            </footer>
        </>
    )
}

Modify.title = '간호사 수정'
Modify.layoutType = 'admin'
export default Modify