import LabelInput from "@/components/commons/LabelInput"
import {useState} from "react"
import {useRouter} from "next/router"
import {addAdminValidate} from "@/utils/Libs/Methods/adminValidate"
import {useCallApi} from "@/utils/Query/customApi";
import {setParam} from "@/utils/Libs/Methods/commonUtils";

const AdminReg = () => {
    // router
    const router = useRouter()

    // state
    const [nurseInfo, setNurseInfo] = useState({
        userId: '',
        userPw: '',
        userName: '',
        phone: ''
    })

    const onInputChange = (target, e) => {
        setParam(setNurseInfo, {[target]: e.target.value})
    }

    // 사용자 등록
    const insertNurseObj = {
        url: '/api/admin/NurseController/insertNurse',
        param: nurseInfo,
        onSuccess: (data) => {
            alert('사용자 추가에 성공하였습니다.')
            router.replace('/controlroom/admins')
        },
    }
    const insertNurse = useCallApi(insertNurseObj)

    const adminAdd = () => {
        const {status, msg, elem} = addAdminValidate(nurseInfo, 'I')

        if(!status) {
            alert(msg)
            return
        }

        insertNurse.isReady && insertNurse.call()
    }

    return(
        <>
            <main id="container" className="container admin form">
                <div className="wrap">
                    <div className="section admin-section">
                        <div className="content">
                            <LabelInput title={'아이디'} id={'userId'} isRequire={true} type={'text'} value={nurseInfo.userId} placeholder={'영문,숫자만 사용가능 (4자리 이상)'} changeHandler={onInputChange}/>
                            <LabelInput title={'비밀번호'} id={'userPw'} isRequire={true} type={'text'} value={nurseInfo.userPw} placeholder={'영문,숫자 포함 8자리 이상 (특수문자 사용불가)'} changeHandler={onInputChange}/>
                            <LabelInput title={'간호사 이름'} id={'userName'} isRequire={true} type={'text'} value={nurseInfo.userName} placeholder={'이름을 입력해 주세요.'} changeHandler={onInputChange}/>
                            <LabelInput title={'휴대폰 번호'} id={'phone'} isRequire={true} type={'number'} value={nurseInfo.phone} placeholder={'숫자만 입력(01044448888)'} changeHandler={onInputChange}/>
                        </div>
                    </div>

                    <div className="section btn-section">
                        <div className="btn-area">
                            <div className="close btn" onClick={() => router.back()}>닫기</div>
                            <div className="save active btn" onClick={adminAdd}>저장</div>
                        </div>
                    </div>
                </div>
            </main>
            <footer id="footer">
            </footer>
        </>
    )
}

AdminReg.title = '간호사 등록'
AdminReg.layoutType = 'admin'

export default AdminReg