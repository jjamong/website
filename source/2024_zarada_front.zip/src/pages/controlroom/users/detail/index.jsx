import {useRouter} from "next/router"
import LabelInput from "@/components/commons/LabelInput"
import AddrInput from "@/components/commons/AddrInput"
import {useEffect, useState} from "react"
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {useCallApi} from "@/utils/Query/customApi";
import ChildForm from "@/components/controlroom/users/ChildForm";
import LabelTextArea from "@/components/commons/LabelTextArea";
import AppStatBtn from "@/components/controlroom/users/AppStatBtn";

const User = () => {
    const router = useRouter()
    const {userSeq} = router.query
    const [appStat, setAppStat] = useState('')

    const items = [
        {value: '', text: '카트리지를 선택해 주세요.'},
        {value: '40', text: '카트리지 20IU'},
        {value: '50', text: '카트리지 30IU'},
    ]

    const handlePhoneCall = (target) => {
        document.location.href = `tel:${target}`
    }

    const [selectHospitalComboRes, setSelectHospitalComboRes] = useState([])
    const selectHospitalComboObj = {
        url: '/api/extra/CommonController/selectHospitalCombo',
        onSuccess: (data) => {
            if (!data[0]) {
                setSelectHospitalComboRes([])
                return
            }

            let tempRes = [
                {value: '', text: '병원을 선택해 주세요.'}
            ]

            data.forEach((hospital) => {
                tempRes.push({value: hospital.hospitalNm, text: hospital.hospitalNm})
            })

            setSelectHospitalComboRes(tempRes)
        }
    }
    const selectHospitalCombo = useCallApi(selectHospitalComboObj)

    useEffect(() => {
        selectHospitalCombo.isReady && selectHospitalCombo.call()
    }, [])

    // 유저 상세 조회
    const [selectUserDetailRes, setSelectUserDetailRes] = useState({
        userSeq: userSeq,
        userId: '',
        userName: '',
        birthday: '',
        genderCd: '',
        phone: '',
        zipCode: '',
        addr: '',
        addrDtl: '',
        email: '',
        joinDt: '',
        appStatCd: '',
        appId: '',
        appDy: '',
        memo: '',
        role: ''
    })
    const selectUserDetailObj = {
        url: '/api/nurse/UserController/selectUserDetail',
        param: {
            userSeq: Number(userSeq),
        },
        onSuccess: (data) => {
            if (!data[0]) {
                alert('조회된 사용자가 없습니다.')
                router.back()
                return
            }

            setSelectUserDetailRes(data[0])
        }
    }
    const selectUserDetail = useCallApi(selectUserDetailObj)

    useEffect(() => {
        if (!router.isReady) return

        selectUserDetail.isReady && selectUserDetail.call()
    }, [router.isReady]);

    // 자녀정보 조회
    const [selectUserChildListRes, setSelectUserChildListRes] = useState([])
    const selectUserChildListObj = {
        url: '/api/nurse/ChildController/selectUserChildList',
        param: {
            userSeq: userSeq
        },
        onSuccess: (data) => {
            if (!data[0]) {
                alert('조회된 자녀정보가 없습니다.')
                router.back()
                return
            }

            setSelectUserChildListRes(data)
        }
    }
    const selectUserChildList = useCallApi(selectUserChildListObj)

    useEffect(() => {
        if (!router.isReady) return

        selectUserChildList.isReady && selectUserChildList.call()
    }, [router.isReady]);

    // 승인상태 변경


    // memo changeHandler
    const userChangeHandler = (id, e) => {
        setParam(setSelectUserDetailRes, {[id]: e.target.value})
    }

    // 자녀 정보 변경
    const childChangeHanlder = (idSeq, e) => {
        const [id, childSeq] = idSeq.split('-');

        const tempChildList = []
        selectUserChildListRes.forEach((child) => {
            tempChildList.push(child)
        })

        tempChildList.forEach((child) => {
            if (child.childSeq === Number(childSeq)) {
                child[id] = e.target.value
            }
        })

        setSelectUserChildListRes(tempChildList)
    }

    const [saveEnd, setSaveEnd] = useState({
        userSave: false,
        userError: false,
        childSave: false,
        childError: false,
    })

    // 회원 메모 저장
    const updateUserMemoObj = {
        url: '/api/nurse/UserController/updateUserMemo',
        param: selectUserDetailRes,
        onSuccess: (data) => {
            if (data[0].count === 0) {
                setParam(setSaveEnd, {userSave: true, userError: true})
            } else {
                setParam(setSaveEnd, {userSave: true})
            }
        }
    }
    const updateUserMemo = useCallApi(updateUserMemoObj)

    // 자녀 정보 저장
    const updateUserChildListObj = {
        url: '/api/nurse/ChildController/updateUserChildList',
        param: {
            updateUserChildList: selectUserChildListRes
        },
        onSuccess: (data) => {
            if (data[0].count === 0) {
                setParam(setSaveEnd, {childSave: true, childError: true})
            } else {
                setParam(setSaveEnd, {childSave: true})
            }
        }
    }
    const updateUserChildList = useCallApi(updateUserChildListObj)

    useEffect(() => {
        if (saveEnd.userSave && saveEnd.childSave) {
            if (saveEnd.userError) {
                alert('회원 정보 저장에 실패하였습니다.')
            } else if (saveEnd.childError) {
                alert('자녀 정보 저장에 실패하였습니다.')
            } else {
                alert('회원 및 자녀 정보 저장에 성공하였습니다.')
            }

            setParam(setSaveEnd, {userSave: false, userError: false, childSave: false, childError: false})
        }
    }, [saveEnd])

    const appStatClick = (appStat) => {
        setAppStat(appStat)
    }

    // 회원 승인 상태 변경
    const updateUserStatObj = {
        url: '/api/nurse/UserController/updateUserStat',
        param: {
            userSeq: selectUserDetailRes.userSeq,
            appStatCd: appStat
        },
        onSuccess: (data) => {
            alert('회원 승인 상태 변경에 성공하였습니다.')
            router.replace('/controlroom/users')
        }
    }
    const updateUserStat = useCallApi(updateUserStatObj)

    useEffect(() => {
        if(appStat === '') return

        let msg = ''
        switch(appStat) {
            case '10':
                msg = '미승인'
                break
            case '20':
                msg = '승인'
                break
            case '30':
                msg = '승인 취소'
                break
            case '40':
                msg = '차단'
                break
            default:
                return
        }

        if(!confirm(`회원을 ${msg}하시겠습니까?`)) return

        updateUserStat.isReady && updateUserStat.call()
    }, [appStat])

    const userInfoSave = () => {
        if (!confirm('회원 정보를 저장하시겠습니까?')) return

        updateUserMemo.isReady && updateUserMemo.call()
        updateUserChildList.isReady && updateUserChildList.call()
    }

    return (
        <>
            <main id="container" className="container admin form">
                <div className="wrap">
                    <div className="section user-section">
                        <div className="title">가입자 정보</div>
                        <div className="content">
                            <LabelInput title={'아이디'}
                                        id={'userId'}
                                        type={'text'}
                                        value={selectUserDetailRes.userId}
                                        isReadOnly={true}
                                        isDisabled={true}
                                        inputClass={'disabled'}
                            />
                            <LabelInput title={'보호자 이름'}
                                        id={'userName'}
                                        type={'text'}
                                        value={selectUserDetailRes.userName}
                                        isReadOnly={true}
                                        isDisabled={true}
                                        inputClass={'disabled'}
                            />
                            <AddrInput id1={'zipcode'}
                                       id2={'addr'}
                                       id3={'addrDtl'}
                                       isRequire={false}
                                       type={'text'}
                                       value1={selectUserDetailRes.zipCode}
                                       value2={selectUserDetailRes.addr}
                                       value3={selectUserDetailRes.addrDtl}
                                       isDisabled={true}
                                       isDisabled2={true}
                                       isReadOnly={true}
                                       isReadOnly2={true}
                                       inputClass={'disabled'}
                                       inputClass2={'disabled'}
                            />
                            <LabelInput title={'휴대폰 번호'}
                                        id={'phone'}
                                        type={'text'}
                                        value={selectUserDetailRes.phone}
                                        isReadOnly={true}
                                        inputClass={'disabled'}
                                        clickHandler={handlePhoneCall}
                            />
                            <LabelTextArea title={'메모'}
                                           id={'memo'}
                                           placeholder={'메모를 입력하세요.'}
                                           value={selectUserDetailRes.memo}
                                           changeHandler={userChangeHandler}/>
                        </div>
                    </div>
                    <ChildForm selectUserChildListRes={selectUserChildListRes}
                               selectHospitalComboRes={selectHospitalComboRes} items={items}
                               childChangeHanlder={childChangeHanlder}/>
                    <div className="section btn-section">
                        <div className="btn-area">
                            <div className="close btn" onClick={() => router.back()}>닫기</div>
                            <div className="save active btn" onClick={userInfoSave}>저장</div>
                        </div>
                        <AppStatBtn selectUserDetailRes={selectUserDetailRes} appStatClick={appStatClick}/>
                    </div>
                </div>
            </main>
        </>
    )
}

User.title = '회원 정보'
User.layoutType = 'admin'

export default User
