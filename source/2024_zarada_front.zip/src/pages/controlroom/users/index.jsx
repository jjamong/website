import {useEffect, useRef, useState} from "react"
import TableBody from "@/components/commons/TableBody"
import Pagination from "@/components/commons/Pagination"
import {useRouter} from "next/router"
import InputSearch from "@/components/commons/InputSearch"
import {handleMakeExcel} from "@/utils/Libs/Methods/adminIUtils"
import {useRecoilState} from "recoil"
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";

const Users = () => {
    const router = useRouter()

    const [excelEnabled, setExcelEnabled] = useState(false)
    const [searchParam, setSearchParam] = useState({
        appStatCd: '10',
        myAppYn: 'N',
        searchDvsn: 'I',
        searchText: '',
    })
    const [activePage, setActivePage] = useState(1)

    const keywordRef = useRef(null)
    const selectRef = useRef(null)

    const [rUser, setRUser] = useRecoilState(recoilUser)

    const thList = [
        {title: '아이디', colId: 'userId'},
        {title: '이름', colId: 'userName'},
        {title: '가입일자', colId: 'joinDt'},
        {title: '상태', colId: 'tag'},
    ]

    const topSelectData = [
        {id: '', text: '전체'},
        {id: '10', text: '미승인'},
        {id: '20', text: '승인'},
        {id: '30', text: '승인취소'},
        {id: '40', text: '차단'},
    ]

    const bottomSelectData = [
        {id: 'I', text: '아이디'},
        {id: 'N', text: '회원 이름'},
        {id: 'P', text: '휴대폰 번호'},
    ]

    // 유저수 조회
    const [selectUserListCountRes, setSelectUserListCountRes] = useState(0)
    const selectUserListCountObj = {
        url: '/api/nurse/UserController/selectUserListCount',
        param: searchParam,
        onSuccess: (data) => {
            if (!data[0]) {
                setSelectUserListCountRes(0)
                return
            }

            setSelectUserListCountRes(data[0].count)
        }
    }
    const selectUserListCount = useCallApi(selectUserListCountObj)

    // 유저목록 조회
    const [selectUserListRes, setSelectUserListRes] = useState([])
    const selectUserListObj = {
        url: '/api/nurse/UserController/selectUserList',
        param: {
            ...searchParam,
            page: activePage,
            size: 10,
        },
        onSuccess: (data) => {
            if (!data[0]) {
                setSelectUserListRes([])
                return
            }

            setSelectUserListRes(data)
        }
    }
    const selectUserList = useCallApi(selectUserListObj)

    useEffect(() => {
        selectUserListCount.isReady && selectUserListCount.call()
        selectUserList.isReady && selectUserList.call()
    }, [activePage, searchParam])

    // excelDownload
    const selectUserListExcelObj = {
        url: '/api/topAdmin/UserController/selectUserListExcel',
        onSuccess: (data) => {
            if (!data[0]) {
                alert('엑셀 데이터 조회에 실패하였습니다.')
                return
            }

            handleMakeExcel(data)
        }
    }
    const selectUserListExcel = useCallApi(selectUserListExcelObj)

    const search = () => {
        // 검색어 조회
        setParam(setSearchParam, {searchDvsn: selectRef.current.value, searchText: keywordRef.current.value})
    }

    const appStatChange = (id, e) => {
        const {value} = e.target

        setParam(setSearchParam, {
            [id]: value,
            myAppYn: value === '20' ? 'Y' : 'N',
            searchDvsn: selectRef.current.value,
            searchText: keywordRef.current.value
        })
    }

    const myUserChange = (e) => {
        setParam(setSearchParam, {
            myAppYn: e.target.checked ? 'Y' : 'N',
            searchDvsn: selectRef.current.value,
            searchText: keywordRef.current.value
        })
    }

    const tagConf = {type: 'd', cate: 'au', value: 'appStatCd'}
    const dateConf = {format: 'yyyymmdd', delimiter: '-'}

    const trHandler = (target) => {
        router.push({
            pathname: 'users/detail',
            query: {userSeq: target}
        })
    }

    // Pagination
    const changeActivePage = (value) => {
        if (activePage === value) return

        setActivePage(value)
    }

    const excelDown = () => {
        if (rUser.role !== 'ROLE_ADMIN') {
            alert('관리자만 다운로드 가능합니다.')
            return
        }

        selectUserListExcel.isReady && selectUserListExcel.call()
    }

    return (
        <>
            <main id="container" className="container admin list">
                <div className="wrap">
                    <div className="top-search-section">
                        <div className="select-area">
                            <div className='input-select'>
                                <select id={'appStatCd'}
                                        onChange={(e) => appStatChange('appStatCd', e)}
                                        value={searchParam.appStatCd}>
                                    {topSelectData.map((data) => {
                                        return (
                                            <option key={data.id} value={data.id}>{data.text}</option>
                                        );
                                    })}
                                </select>
                            </div>
                        </div>
                        <div className="checkbox-area">
                            <div className="input-checkbox"><input type="checkbox" id="loginMaintain"
                                                                    name="loginMaintain"
                                                                    checked={searchParam.myAppYn === 'Y'}
                                                                    onChange={(e) => myUserChange(e)}/></div>
                            <label htmlFor="loginMaintain">내가 승인한 회원</label>
                        </div>
                    </div>
                    <TableBody thList={thList} datas={selectUserListRes} handlerValue={'userSeq'} trHandler={trHandler}
                               tagConf={tagConf} dateConf={dateConf}/>
                    <Pagination changeActivePage={changeActivePage} totalItems={selectUserListCountRes}
                                activePage={activePage}
                                itemsPerPage={10} pageRangeDisplayed={5}/>
                    <InputSearch selectId={'selectOption'} selectData={bottomSelectData} inputId={'keyword'}
                                 type={'text'}
                                 placeholder={'검색어 입력'} selectRef={selectRef} inputRef={keywordRef}
                                 clickHandler={search}/>
                    {/* 추후 요청 시 엑셀 다운로드 주석 해제 */}
                    {/*<div className='excel-section'>*/}
                    {/*    <div className='btn-area'>*/}
                    {/*        <div className='btn' onClick={excelDown}>엑셀 다운로드</div>*/}
                    {/*    </div>*/}
                    {/*</div>*/}
                </div>
            </main>
        </>
    )
}

Users.title = '회원 정보'
Users.layoutType = 'admin'
export default Users