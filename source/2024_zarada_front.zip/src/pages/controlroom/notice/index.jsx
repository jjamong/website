import {useEffect, useState} from "react";
import Pagination from "@/components/commons/Pagination";
import {useRouter} from "next/router";
import {useCallApi} from "@/utils/Query/customApi";
import {useRecoilState} from "recoil";
import {recoilUser} from "@/utils/Store/atom";

const Notice = () => {
    const router = useRouter()
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [mounted, setMounted] = useState(false)

    const thList = [
        {title: 'NO.', colId: 'noticeSeq'},
        {title: '제목', colId: 'noticeTitle'},
        {title: '작성시간', colId: 'writeDy'},
    ]

    const trHandler = (target) => {
        // 관리자만 공지사항 수정가능
        if(rUser.role === 'ROLE_ADMIN') {
            router.push({
                pathname: 'notice/modi',
                query: {noticeSeq: target}
            })
        } else {
            router.push({
                pathname: 'notice/detail',
                query: {noticeSeq: target}
            })
        }
    }

    const [activePage, setActivePage] = useState(1)

    const [selectNoticeListCountRes, setSelectNoticeListCountRes] = useState(0)
    const selectNoticeListCountObj = {
        url: '/api/user/NoticeController/selectNoticeListCount',
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNoticeListCountRes(0)
                return
            }

            setSelectNoticeListCountRes(data[0].count)
        }
    }
    const selectNoticeListCount = useCallApi(selectNoticeListCountObj)

    useEffect(() => {
        setMounted(true)
        selectNoticeListCount.isReady && selectNoticeListCount.call()
    }, [])

    const [selectNoticeListRes, setSelectNoticeListRes] = useState([])
    const selectNoticeListObj = {
        url: '/api/user/NoticeController/selectNoticeList',
        param: {
            page: activePage,
            size: 10,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNoticeListRes([])
                return
            }

            setSelectNoticeListRes(data)
        }
    }
    const selectNoticeList = useCallApi(selectNoticeListObj)

    useEffect(() => {
        selectNoticeList.isReady && selectNoticeList.call()
    }, []);

    // Pagination
    const changeActivePage = (value) => {
        if(activePage === value) return

        setActivePage(value)
    }

    return(
        <main id="container" className="container admin list">
            <div className="wrap">
                <div className="table-section">
                    <table className="table">
                        <thead>
                        <tr>
                            {thList.map((th) => {
                                return (
                                    <th key={th.colId} scope='col'>{th.title}</th>
                                );
                            })}
                        </tr>
                        </thead>
                        <tbody>
                        {
                            selectNoticeListRes.length === 0
                                ? <tr className="nodata">
                                    <td colSpan={thList.length}>일치하는 검색 결과가 없습니다.</td>
                                </tr>
                                : selectNoticeListRes.map((data, index) => {
                                    return (
                                        data.topYn !== 'Y'
                                            ? <tr key={index} onClick={() => trHandler(data['noticeSeq'])}>
                                                {thList.map((td) => {
                                                    return (
                                                        <td key={td.colId} className='less'>{data[td.colId]}</td>
                                                    );
                                                })}
                                            </tr>
                                            : <tr key={index} onClick={() => trHandler(data['noticeSeq'])}>
                                                {thList.map((td) => {
                                                    return (
                                                        <td key={td.colId} className='less'>
                                                            {   td.colId.toLowerCase().includes('seq')
                                                                ? <svg stroke="currentColor" fill="none" strokeWidth="2"
                                                                       viewBox="0 0 24 24"
                                                                       strokeLinecap="round" strokeLinejoin="round"
                                                                       color="#949494"
                                                                       height="16px"
                                                                       width="16px" xmlns="http://www.w3.org/2000/svg"
                                                                >
                                                                    <path stroke="none" d="M0 0h24v24H0z"
                                                                          fill="none"></path>
                                                                    <path
                                                                        d="M15.113 3.21l.094 .083l5.5 5.5a1 1 0 0 1 -1.175 1.59l-3.172 3.171l-1.424 3.797a1 1 0 0 1 -.158 .277l-.07 .08l-1.5 1.5a1 1 0 0 1 -1.32 .082l-.095 -.083l-2.793 -2.792l-3.793 3.792a1 1 0 0 1 -1.497 -1.32l.083 -.094l3.792 -3.793l-2.792 -2.793a1 1 0 0 1 -.083 -1.32l.083 -.094l1.5 -1.5a1 1 0 0 1 .258 -.187l.098 -.042l3.796 -1.425l3.171 -3.17a1 1 0 0 1 1.497 -1.26z"
                                                                        strokeWidth="0" fill="currentColor"></path>
                                                                </svg>
                                                                :
                                                                data[td.colId]
                                                            }
                                                        </td>
                                                    );
                                                })}
                                            </tr>
                                    );
                                })
                        }
                        </tbody>
                    </table>
                </div>
                <Pagination changeActivePage={changeActivePage} totalItems={selectNoticeListCountRes}
                            activePage={activePage} itemsPerPage={10} pageRangeDisplayed={5}/>
                {
                    rUser.role === 'ROLE_ADMIN' && mounted &&
                    <div className='add-section'>
                        <div className='btn-area right'>
                            <div className='btn active' onClick={() => router.push('notice/reg')}>글쓰기</div>
                        </div>
                    </div>
                }
            </div>
        </main>
    )
}

Notice.layoutType = 'admin'
Notice.title = '공지사항'
export default Notice