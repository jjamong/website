import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {addNoticeValidate} from "@/utils/Libs/Methods/adminValidate";
import {useCallApi} from "@/utils/Query/customApi";
import TipTapEditor from "@/components/commons/TipTapEditor";

const NoticeModi = () => {
    const router = useRouter()
    const {noticeSeq} = router.query

    const [selectNoticeRes, setSelectNoticeRes] = useState({
        noticeSeq: noticeSeq,
        noticeTitle: '',
        noticeContent: '',
        topYn: 'N',
        writeDy: '',
        writeTm: ''
    })
    const selectNoticeObj = {
        url: '/api/user/NoticeController/selectNotice',
        param: {
            noticeSeq
        },
        onSuccess: (data) => {
            if(!data[0]) {
                alert('공지사항 조회 실패')
                router.back()
            }

            setParam(setSelectNoticeRes, {...data[0]})
        }
    }
    const selectNotice = useCallApi(selectNoticeObj)

    useEffect(() => {
        if(!router.isReady) return

        selectNotice.isReady && selectNotice.call()
    }, [router.isReady]);

    const updateNoticeObj = {
        url: '/api/admin/NoticeController/updateNotice',
        param: selectNoticeRes,
        onSuccess: (data) => {
            alert('수정에 성공하였습니다.')
            router.back()
        }
    }
    const updateNotice = useCallApi(updateNoticeObj)

    const deleteNoticeObj = {
        url: '/api/admin/NoticeController/deleteNotice',
        param: noticeSeq,
        onSuccess: (data) => {
            alert('삭제에 성공하였습니다.')
            router.back()
        }
    }
    const deleteNotice = useCallApi(deleteNoticeObj)

    const titleChange = (e) => {
        setParam(setSelectNoticeRes, {noticeTitle: e.target.value})
    }

    const badgeChange = () => {
        setParam(setSelectNoticeRes, {topYn: selectNoticeRes.topYn === 'N' ? 'Y' : 'N'})
    }

    const contentChange = (value) => {
        setParam(setSelectNoticeRes, {noticeContent: value})
    }

    const addNotice = () => {
        const {status, msg, elem} = addNoticeValidate(selectNoticeRes)

        if(!status) {
            alert(msg)
            return
        }

        if(!confirm('수정 하시겠습니까?')) return

        updateNotice.isReady && updateNotice.call()
    }

    const delNotice = () => {
        if(!confirm('삭제 하시겠습니까?')) return

        deleteNotice.isReady && deleteNotice.call()
    }

    return (
        <main id="container" className="container admin notice-detail">
            <div className="wrap">
                <div className="content-area">
                    <div className="title-area">
                        <div className='form-item'>
                            <div className='badge-area'>
                                <label htmlFor='noticeTitle' className="tit">글 제목<span
                                    className="require">*</span></label>
                                <label className='badge' onClick={badgeChange}>
                                    {
                                        selectNoticeRes.topYn === 'N' ?
                                            <>
                                                <svg stroke="currentColor" fill="none" strokeWidth="2"
                                                     viewBox="0 0 24 24"
                                                     strokeLinecap="round" strokeLinejoin="round" color="#949494"
                                                     height="16px"
                                                     width="16px" xmlns="http://www.w3.org/2000/svg"
                                                >
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                    <path
                                                        d="M15.113 3.21l.094 .083l5.5 5.5a1 1 0 0 1 -1.175 1.59l-3.172 3.171l-1.424 3.797a1 1 0 0 1 -.158 .277l-.07 .08l-1.5 1.5a1 1 0 0 1 -1.32 .082l-.095 -.083l-2.793 -2.792l-3.793 3.792a1 1 0 0 1 -1.497 -1.32l.083 -.094l3.792 -3.793l-2.792 -2.793a1 1 0 0 1 -.083 -1.32l.083 -.094l1.5 -1.5a1 1 0 0 1 .258 -.187l.098 -.042l3.796 -1.425l3.171 -3.17a1 1 0 0 1 1.497 -1.26z"
                                                        strokeWidth="0" fill="currentColor"></path>
                                                </svg>
                                                <span>고정</span>
                                            </>
                                            :
                                            <>
                                                <svg stroke="currentColor" fill="none" strokeWidth="2"
                                                     viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round"
                                                     color="#2A3765" height="16px" width="16px"
                                                     xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                    <path d="M3 3l18 18"></path>
                                                    <path
                                                        d="M15 4.5l-3.249 3.249m-2.57 1.433l-2.181 .818l-1.5 1.5l7 7l1.5 -1.5l.82 -2.186m1.43 -2.563l3.25 -3.251"></path>
                                                    <path d="M9 15l-4.5 4.5"></path>
                                                    <path d="M14.5 4l5.5 5.5"></path>
                                                </svg>
                                                <span>고정 해제</span>
                                            </>
                                    }
                                </label>
                            </div>
                            <div className='input-area'>
                                <div className='input-text'>
                                    <input id='noticeTitle' type='text' value={selectNoticeRes.noticeTitle}
                                           placeholder='글 제목을 입력해 주세요.'
                                           onChange={(e) => titleChange(e)}/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <TipTapEditor content={selectNoticeRes.noticeContent} setContent={contentChange} editable={true}/>
                    <div className="btn-area two">
                        <div className="btn" onClick={delNotice}>삭제</div>
                        <div className="btn active" onClick={addNotice}>수정 완료</div>
                    </div>
                </div>
            </div>
        </main>
    )
}

NoticeModi.layoutType = 'admin'
NoticeModi.title = '공지사항 수정'

export default NoticeModi