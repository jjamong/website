import NavFooter from "@/components/front/commons/NavFooter";
import ChildSelect from "@/components/front/commons/ChildSelect";
import TabArea from "@/components/front/commons/TabArea";
import ChildInfo from "@/components/front/commons/ChildInfo";
import GrowthGraph from "@/components/front/growth/GrowthGraph";
import GrowthDay from "@/components/front/growth/GrowthDay";
import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import {useRecoilState} from "recoil";
import {recoilChild, recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";

const Growth = () => {
    const router = useRouter()
    const [page, setPage] = useState('graph')
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const [childSelectShow, setChildSelectShow] = useState(false)

    // 성장그래프
    const [graphViewType, setGraphViewType] = useState('year')
    const [graphType, setGraphType] = useState('height')
    const [graphGenderCd, setGraphGenderCd] = useState('M')
    const [graphChildMonth, setGraphChildMonth] = useState(0)
 
    // 성장 데이터
    const [pagingCount, setPagingCount] = useState(0)
    const [pagingList, setPagingList] = useState([])
    const [showBtn, setShowBtn] = useState(false)

    useEffect(() => {
        // 내 자녀 목록 조회
        selectMyChildList.isReady && selectMyChildList.call()
    }, [])

    useEffect(() => {
        // 내 자녀 정보 상세 조회
        setSelectMyChildDetailParam({ childSeq: rChild.childSeq })
    }, [rChild.childSeq])

    // 내 자녀 정보 상세 조회
    const [selectMyChildDetailRes, setSelectMyChildDetailRes] = useState()
    const [selectMyChildDetailParam, setSelectMyChildDetailParam] = useState({ childSeq: rChild.childSeq })
    const selectMyChildDetailObj = {
        url: '/api/user/ChildController/selectMyChildDetail',
        param: selectMyChildDetailParam,
        onSuccess: (data) => {
            setSelectMyChildDetailRes(data[0])
        }
    }
    const selectMyChildDetail = useCallApi(selectMyChildDetailObj)
    useEffect(() => {
        // 내 자녀 정보 상세 조회
        selectMyChildDetail.isReady && selectMyChildDetail.call()
        // 성장 기록 조회
        selectMyChildGrowth.isReady && selectMyChildGrowth.call()
    }, [selectMyChildDetailParam])

    useEffect(() => {
        if (selectMyChildDetailRes) {
            setGraphGenderCd(selectMyChildDetailRes.genderCd)

            let arr = selectMyChildDetailRes.birthday.split('-')
            let date1 = new Date(arr[0], arr[1], arr[2])
            let date2 = new Date()
            let date1Year = date1.getFullYear()
            let date2Year = date2.getFullYear()
            let yearDiff = Math.abs(date2Year - date1Year)
            let monthDiff = yearDiff * 12 + Math.abs(date2.getMonth() - date1.getMonth())
            setGraphChildMonth(monthDiff)

            // 성장도표 조회
            setSelectGrowthChartParam({
                dvsn : graphViewType.toUpperCase(),
                chartDvsn : graphType.toUpperCase(),
                genderCd : selectMyChildDetailRes.genderCd,
                month: monthDiff,
                childSeq : selectMyChildDetailRes.childSeq,
            })
        }
    }, [selectMyChildDetailRes])

    // 내 자녀 목록 조회
    const [selectMyChildListRes, setSelectMyChildListRes] = useState([])
    const selectMyChildListObj = {
        url: '/api/user/ChildController/selectMyChildList',
        param: {},
        onSuccess: (data) => {
            if(!data[0]) {
                return
            }
            setSelectMyChildListRes(data)
        }
    }
    const selectMyChildList = useCallApi(selectMyChildListObj)

    // 자녀 선택 창
    const openSelect = () => {
        setChildSelectShow(true)
    }
    const closeSelect = () => {
        setChildSelectShow(false)
    }
    useEffect(() => {
        let dim = document.getElementById('dim')
        let selectChildList = document.getElementById('select-child-list')
        if(childSelectShow) {
            dim.classList.add('active')
            selectChildList.classList.add('active')
        } else {
            dim.classList.remove('active')
            selectChildList.classList.remove('active')
        }
    }, [childSelectShow])

    // 성장도표 조회
    const [selectGrowthChartRes, setSelectGrowthChartRes] = useState([])
    const [selectGrowthChartParam, setSelectGrowthChartParam] = useState()
    const selectGrowthChartObj = {
        url: '/api/user/GrowthController/selectGrowthChart',
        param: selectGrowthChartParam,
        onSuccess: (data) => {
            setSelectGrowthChartRes(data)
        }
    }
    const selectGrowthChart = useCallApi(selectGrowthChartObj)
    
    useEffect(() => {
        if (selectGrowthChartParam) {
            selectGrowthChart.isReady && selectGrowthChart.call()
        }
    }, [selectGrowthChartParam])


    // 성장그래프 유형 선택 시
    const graphTypeClickHandler = (target) => {
        setGraphType(target)

        // 성장도표 조회
        setSelectGrowthChartParam({
            childSeq : rChild.childSeq,
            dvsn : graphViewType.toUpperCase(),
            chartDvsn : target.toUpperCase(),
            genderCd : graphGenderCd,
            month: graphChildMonth
        })
    }

    // 성장그래프 보기유형 선택 시
    const graphViewTypeClickHandler = (target) => {
        setGraphViewType(target)

        // 전체보기
        if (target == 'year') {
            // 성장도표 조회
            setSelectGrowthChartParam({
                childSeq : rChild.childSeq,
                dvsn : target.toUpperCase(),
                chartDvsn : graphType.toUpperCase(),
                genderCd : graphGenderCd,
                month: graphChildMonth,
            })

            // 최근보기
        } else {
            if (selectMyChildDetailRes) {
                // 성장도표 조회
                setSelectGrowthChartParam({
                    childSeq : selectMyChildDetailRes.childSeq,
                    dvsn : target.toUpperCase(),
                    chartDvsn : graphType.toUpperCase(),
                    genderCd : graphGenderCd,
                    month: graphChildMonth,
                })
            }
        }
    }

    const addToGrowthForm = () => {
        router.push('growth/reg')
    }

    const updateToGrowthForm = (target) => {
        router.push({
            pathname: 'growth/modi',
            query: {growthYmd: target}
        })
    }

    const plusCount = () => {
        setPagingCount((prevState) => prevState + 1)
    }
    
    // 탭 선택
    const tabClickHandler = (target) => {
        setPage(target)
    }
    const tabInfo = [
        {id: 'graph', active: page === 'graph', clickHandler: tabClickHandler, title: '성장그래프'},
        {id: 'day', active: page === 'day', clickHandler: tabClickHandler, title: '성장일별표'},
    ]

    // 성장 기록 조회
    const [selectMyChildGrowthRes, setSelectMyChildGrowthRes] = useState([])
    const selectMyChildGrowthObj = {
        url: '/api/user/GrowthController/selectMyChildGrowth',
        param: {
            childSeq: rChild.childSeq
        },
        onSuccess: (data) => {
            setSelectMyChildGrowthRes(data)
            setPagingList([])
            setPagingCount(0)
        }
    }
    const selectMyChildGrowth = useCallApi(selectMyChildGrowthObj)
    
    useEffect(() => {
        const totalCount = Math.ceil(selectMyChildGrowthRes.length / 5)
        if(selectMyChildGrowthRes.length > 5) {
            setShowBtn(true)
        }

        if(totalCount - 1 === pagingCount) {
            setShowBtn(false)
        }

        const tempList = selectMyChildGrowthRes.slice(pagingCount * 5, (pagingCount + 1) * 5)

        setPagingList((prevArr) => {
            return [...prevArr, ...tempList]
        })

    }, [selectMyChildGrowthRes, pagingCount])

    return (
        <>
            <main id="container" className={`container growth ${page}`}>
                <div className="wrap">
                    {selectMyChildDetailRes && <ChildInfo selectMyChildDetailRes={selectMyChildDetailRes} openSelect={openSelect} />}
                    <TabArea tabInfo={tabInfo}/>
                    {page === 'graph' &&
                        <GrowthGraph
                            selectGrowthChartRes={selectGrowthChartRes}
                            selectMyChildGrowthRes={selectMyChildGrowthRes[0]}
                            graphType={graphType}
                            graphTypeClickHandler={graphTypeClickHandler}
                            graphViewType={graphViewType}
                            graphViewTypeClickHandler={graphViewTypeClickHandler}
                            addToGrowthForm={addToGrowthForm}
                        />}
                    {page === 'day' &&
                        <GrowthDay
                            updateToGrowthForm={updateToGrowthForm}
                            showBtn={showBtn}
                            plusCount={plusCount}
                            pagingList={pagingList}
                        />}
                </div>
            </main>
            <ChildSelect selectMyChildListRes={selectMyChildListRes} closeSelect={closeSelect} />
            <NavFooter/>
        </>
    )
}

Growth.title = '성장 관리'
export default Growth