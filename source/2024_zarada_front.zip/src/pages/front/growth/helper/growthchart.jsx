
const GrowthHelperGrowthchart = () => {

    return(
        <main id="container" className="container growth graph-helper growthchart">
            <div className="wrap">
                <div className="top-area">
                    <div className="title-area">
                        <div className="title">소아청소년<br />성장도표</div>
                        <div className="desc">2017년<br />소아청소년 성장도표</div>
                    </div>
                    <div className="img-area">
                        <div className="img"><img src="/img/growth_helper_growthchart_title_img.png" alt="성장도표 이미지" /></div>
                    </div>
                </div>
                <div className="content active">
                    <table>
                        <thead>
                            <tr className="head1">
                                <th scope="col" colSpan="2" className="m">남자</th>
                                <th scope="col"></th>
                                <th scope="col" colSpan="2" className="g">여자</th>
                            </tr>
                            <tr className="head2">
                                <th scope="col">키(cm)</th>
                                <th scope="col">몸무게(kg)</th>
                                <th scope="col">만 나이</th>
                                <th scope="col">키(cm)</th>
                                <th scope="col">몸무게(kg)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>103.1</td>
                                <td>16.8</td>
                                <td>4세</td>
                                <td>101.9</td>
                                <td>16.3</td>
                            </tr>
                            <tr>
                                <td>106.3</td>
                                <td>17.9</td>
                                <td>4세 6개월</td>
                                <td>105.1</td>
                                <td>17.3</td>
                            </tr>
                            <tr>
                                <td>109.6</td>
                                <td>19.0</td>
                                <td>5세</td>
                                <td>108.4</td>
                                <td>18.4</td>
                            </tr>
                            <tr>
                                <td>112.8</td>
                                <td>20.1</td>
                                <td>5세 6개월</td>
                                <td>111.6</td>
                                <td>19.5</td>
                            </tr>
                            <tr>
                                <td>115.9</td>
                                <td>21.3</td>
                                <td>6세</td>
                                <td>114.7</td>
                                <td>20.7</td>
                            </tr>
                            <tr>
                                <td>119.0</td>
                                <td>22.7</td>
                                <td>6세 6개월</td>
                                <td>117.81</td>
                                <td>22.01</td>
                            </tr>
                            <tr>
                                <td>122.1</td>
                                <td>24.2</td>
                                <td>7세</td>
                                <td>120.8</td>
                                <td>23.4</td>
                            </tr>
                            <tr>
                                <td>127.9</td>
                                <td>27.5</td>
                                <td>8세</td>
                                <td>126.7</td>
                                <td>26.6</td>
                            </tr>
                            <tr>
                                <td>133.4</td>
                                <td>31.3</td>
                                <td>9세</td>
                                <td>132.6</td>
                                <td>30.2</td>
                            </tr>
                            <tr>
                                <td>138.8</td>
                                <td>35.5</td>
                                <td>10세</td>
                                <td>139.1</td>
                                <td>34.4</td>
                            </tr>
                            <tr>
                                <td>144.7</td>
                                <td>40.2</td>
                                <td>11세</td>
                                <td>145.8</td>
                                <td>39.1</td>
                            </tr>
                            <tr>
                                <td>151.4</td>
                                <td>45.4</td>
                                <td>12세</td>
                                <td>151.7</td>
                                <td>43.7</td>
                            </tr>
                            <tr>
                                <td>158.6</td>
                                <td>50.9</td>
                                <td>13세</td>
                                <td>155.9</td>
                                <td>47.7</td>
                            </tr>
                            <tr>
                                <td>165.0</td>
                                <td>56.0</td>
                                <td>14세</td>
                                <td>158.3</td>
                                <td>50.5</td>
                            </tr>
                            <tr>
                                <td>169.2</td>
                                <td>60.1</td>
                                <td>15세</td>
                                <td>159.5</td>
                                <td>52.6</td>
                            </tr>
                            <tr>
                                <td>171.4</td>
                                <td>63.1</td>
                                <td>16세</td>
                                <td>160.0</td>
                                <td>53.7</td>
                            </tr>
                            <tr>
                                <td>172.6</td>
                                <td>65.0</td>
                                <td>17세</td>
                                <td>160.2</td>
                                <td>54.1</td>
                            </tr>
                            <tr>
                                <td>173.6</td>
                                <td>66.7</td>
                                <td>18세</td>
                                <td>160.6</td>
                                <td>54.0</td>
                            </tr>
                        </tbody>
                    </table>
                    <div className="desc">표준치는 2017 소아청소년성장도표 50백분위수 값을 의미</div>
                </div>
            </div>
        </main>
    )
}

GrowthHelperGrowthchart.title = '성장도우미 성장도표'

export default GrowthHelperGrowthchart