
const GrowthHelperExercise = () => {

    return(
        <main id="container" className="container growth graph-helper exercise">
            <div className="wrap">
                <div className="top-area">
                    <div className="title-area">
                        <div className="title">운동</div>
                        <div className="desc">키가 크는 바른성장 운동법</div>
                    </div>
                    <div className="img-area">
                        <div className="img"><img src="/img/growth_helper_exercise_title_img.png" alt="식습관 이미지" /></div>
                    </div>
                </div>
                <div className="content active">
                    <div className="step-area step1">
                        <div className="tit">01. 하루 30분 이상 운동하기</div>
                        <p className="desc">
                            규칙적이고 적당한 운동은 성장과 더불어 비만 예방에 많은 도움이 됩니다. 충분한 성장을 위해서는 <span className="highlight">매일 한 시간 이상 운동</span>하는 것이 가장 이상적이며, <span className="highlight">최소한 하루 30분 이상은 활발한 신체활동</span>을 해야 합니다.
                            <br />그 중 <span className="highlight">수영, 자전거, 에어로빅과 같은 유산소 운동</span>이 주 3회 이상, <span className="highlight">철봉에 매달리기와 같은 근력강화 운동</span>이 주 3회 이상 포함되면 더욱 좋습니다. 운동은 비만을 예방하고 심폐기능을 향상시키며 두뇌발달에도 도움이 됩니다.
                            <br />평소 운동이 부족하던 아이에게 갑자기 과격한 운동을 강요하는 것은 무리가 될 수 있으므로, 아이가 감당할 수 있을 만큼의 운동으로 시작하여 매일 조금씩 늘려 나가야 합니다.
                        </p>
                        <div className="img"><img src="/img/growth_helper_exercise1_img.png" alt="운동 이미지" /></div>
                        <p className="desc desc1">
                            하기 싫은 운동을 억지로 하는 것은 도움이 되지 않으므로, 아이가 좋아하는 운동을 선택하여 즐거운 마음으로 꾸준히 하는 것이 가장 중요합니다. 특별한 운동이 정해져 있는 것은 아닙니다. 몸에 적절한 자극이 되는 유산소 운동은 모두 좋습니다.
                            <br />운동은 스트레스를 해소해주며 정서적으로도 많은 도움이 됩니다.
                            <br />단체로 하는 운동은 아이의 협동심과 사회성을 길러주기도 합니다.
                            <br />아이들은 부모의 생활습관을 그대로 물려받기 때문에 부모가 먼저 규칙적으로 운동하고 활발한 신체활동을 즐기는 모습을 보여주는 것이 아이의 건강한 성장을 위해 필요합니다.
                        </p>
                    </div>
                    <div className="step-area step2">
                        <div className="tit">02. 키 크기 운동법</div>
                        <div className="img"><img src="/img/growth_helper_exercise2_img.png" alt="운동 이미지" /></div>
                        <p className="desc desc1">
                            (01) 손바닥을 위로 향하게 하고, 깍지를 낀 후 두팔을 약간 뒤로하여 쭉 뻗는다. 오른쪽, 왼쪽을 몸을 굽히며 충분히 스트레칭한다.
                            <br />(02) 다리를 어깨넓이로 벌린 후 허리를 똑바로 굽히며, 손바닥을 땅에 닿도록 한다.
                            <br />(03) 한쪽다리를 편 후, 허리를 똑바로 펴고, 몸을 기울인다. 양쪽을 교대로 한다.
                            <br />(04) 한쪽 무릅을 굽히며, 반대편 다리를 편 후 스트레칭한다. 양쪽을 교대로 시행한다.
                            <br />(05) 편안히 똑바로 누운 채, 한쪽다리를 가슴으로 당긴다. 양쪽을 교대로 시행한다.
                            <br />(06) 똑바로 누운 후, 한쪽 다리를 반대편 무릎에 올린 후 눌러 스트레칭한다.
                        </p>
                    </div>
                </div>
            </div>
        </main>
    )
}

GrowthHelperExercise.title = '성장도우미 운동'

export default GrowthHelperExercise