import {useState} from "react";

const GrowthHelperEatinghabits = () => {
    const [tab, setTab] = useState(1)

    return(
        <main id="container" className="container growth graph-helper eatinghabits">
            <div className="wrap">
                <div className="top-area">
                    <div className="title-area">
                        <div className="title">식습관</div>
                        <div className="desc">건강하게 성장하는 식습관</div>
                    </div>
                    <div className="img-area">
                        <div className="img"><img src="/img/growth_helper_eatinghabits_title_img.png" alt="식습관 이미지" /></div>
                    </div>
                </div>
                
                <div className="tab-area">
                    <div className={`tab ${tab == 1 ? 'active' : ''}`} onClick={() => setTab(1)}>식습관 1</div>
                    <div className={`tab ${tab == 2 ? 'active' : ''}`} onClick={() => setTab(2)}>식습관 2</div>
                    <div className={`tab ${tab == 3 ? 'active' : ''}`} onClick={() => setTab(3)}>식습관 3</div>
                </div>

                {
                    tab == 1 ?
                    <div className="content1">
                        <div className="step-title">“음식은 다양하게 골고루”</div>
                        <div className="step-area step1">
                            <div className="tit">01. 편식하지 않고, 골고루 먹습니다!</div>
                            <div className="img"><img src="/img/growth_helper_eatinghabits1_img.png" alt="식습관 이미지" /></div>
                            <p className="desc">
                                우리 몸에 필요한 여러 가지 영양소를 공급하기 위해서는
                                <br /><span className="highlight">다양한 식품군의 섭취</span>가 필요합니다.
                                <br />어린 시절에 다양한 식품을 섭취하는 바람직한 식습관을 형성하여 어른이 되어서도 좋은 식습관이 유지되도록 합니다.
                            </p>
                        </div>
                        <div className="step-area step2">
                            <div className="tit">02. 끼니마다 다양한 채소 반찬을 먹습니다.</div>
                            <p className="desc">
                                다양한 채소와 과일들은 각기 다른 여러 가지 영양소를 공급하므로 여러 종류를 섭취해야 합니다.
                                <br />부족하기 쉬운<span className="highlight">비타민, 무기질, 섬유소의 섭취를 증가시키기 위해</span>채소와 과일을 즐겨 먹습니다.
                            </p>
                        </div>
                        <div className="step-area step3">
                            <div className="tit">03. 생선, 살코기, 콩제품, 달걀 등 단백질 식품을 매일 1회 이상 먹습니다.</div>
                            <p className="desc">
                                <span className="highlight">고기, 생선, 달걀 및 콩 제품을 매일 먹어</span>에너지, 단백질, 지방 등의 영양소를 충분히 섭취함으로써 몸의 기본 구성을 튼튼하게 해야 합니다.
                                <br />단백질은 우리 몸의 성장과 유지는 물론, 외부로부터의 감염을 치료하기 위해서도 꼭 필요한 영양소입니다.
                                <br />고기, 생선 등의 식품을 채소, 곡류 등과 함께 섭취하여 균형 있는 식사가 되도록 합니다.
                                <br />등푸른 생선에 많은 오메가-3 지방산 중 DHA는 뇌세포의 구성 성분 이므로 어린이의 두뇌 발달에 꼭 필요한 것으로 알려져 있습니다.
                            </p>
                        </div>
                        <div className="step-area step4">
                            <div className="tit">04. 우유를 매일 2컵 정도 마십니다.</div>
                            <div className="desc">
                                <p>
                                    우유 한 컵에는 약 200-250mg의 칼슘이 들어 있으므로, (어린이의 1일 권장량은 600-800mg)다른 식품에서 섭취 되는
                                    칼슘량이 많지 않은 점을 고려할 때 어린이의
                                </p>
                                <div className="split">
                                    <p>
                                        성장과 건강 유지를 위해 <span className="highlight">일 최소 2컵 이상</span>1의 우유가 필요합니다.
                                        <br />성장기 어린이에게는 건강한 뼈의 성장을 위한 칼슘의 섭취가 더욱 중요하므로 우유와 유제품 섭취에 주의를 기울여야 합니다.
                                    </p>
                                    <div><img src="/img/growth_helper_eatinghabits2_img.png" alt="식습관 이미지" /></div>
                                </div>
                            </div>
                        </div>
                        <div className="sources">
                            <p>출처 : 한국인을 위한 식생활 지침(어린이용),한국보건산업진흥원, 2014년 11월</p>
                        </div>
                    </div>
                    : <></>
                }
                {
                    tab == 2 ?
                    <div className="content2">
                        <div className="step-title">“식사는 제때에, 싱겁게”</div>
                        <div className="step-area step1">
                            <div className="tit">01. 아침식사는 꼭 먹습니다.</div>
                            <p className="desc">
                                ▶ 하루의 필요한 영양소를 충분히 공급
                                <br />▶ 두뇌활동을 활발하게 해줌 → 오전 수업집중력을 높임
                                <br />▶ 규칙적인 식습관 형성 → 체중조절 , 건강
                            </p>
                            <div className="img"><img src="/img/growth_helper_eatinghabits3_img.png" alt="식습관 이미지" /></div>
                            <p className="desc desc1">
                                비만예방을 위한 생활습관으로 음식은 20번 이상 꼭꼭 씹어먹습니다.
                            </p>
                        </div>
                        <div className="step-area step2">
                            <div className="tit">02. 음식은 천천히 꼭꼭 씹어 먹습니다.</div>
                            <p className="desc">
                                비만예방을 위한 생활습관으로 음식은 20번 이상 꼭꼭 씹어먹습니다.
                            </p>
                        </div>
                        <div className="step-area step3">
                            <div className="tit">03. 짠 음식, 단 음식, 기름진 음식을 적게 먹습니다.</div>
                            <p className="desc">
                                짜고 단 음식들은 균형 있는 식품섭취의 장애요인으로 작용할 수 있기 때문에 이를 제한합니다.
                            </p>
                        </div>
                        <div className="sources">
                            <p>출처 : 한국인을 위한 식생활 지침(어린이용),한국보건산업진흥원, 2014년 11월</p>
                        </div>
                    </div>
                    : <></>
                }
                {
                    tab == 3 ?
                    <div className="content3">
                        <div className="step-title">“간식은 안전하고, 슬기롭게”</div>
                        <div className="step-area step1">
                            <div className="img"><img src="/img/growth_helper_eatinghabits4_img.png" alt="식습관 이미지" /></div>
                            <div className="tit">01. 간식으로 신선한 과일과 우유 등을 먹습니다.</div>
                            <p className="desc">
                                아동기에는 활동량이 많고 성장 발달이 이루어지므로 많은 양의 영양소가 필요합니다.
                                <br />그러나 어린이는 위의 크기가 작아서 한 번에 먹을 수 있는 양이 제한되므로 세 끼 식사만으로는 충분한 영양소를 공급할 수 없습니다.
                                <br />그러므로 성장에 필요한 <span className="highlight">영양소가 풍부한 우유나 과일 같은 식품을 간식으로 섭취</span>하는 것이 좋습니다.
                            </p>
                        </div>
                        <div className="step-area step2">
                            <div className="tit">02. 과자나 탄산음료, 패스트푸드를 자주 먹지 않습니다.</div>
                            <p className="desc">
                                과자나 음료수, 패스트푸드는 다른 영양소에 비해 에너지만 많이 공급하므로 과도하게 섭취하면 다음 식사에 영향을 미치고 비만으로 이어질 가능성이 높으므로 더욱 주의하여야 합니다.
                            </p>
                        </div>
                        <div className="step-area step3">
                            <div className="tit">03. 불량식품을 구별할 줄 알고, 먹지 않으려고 노력합니다.</div>
                            <p className="desc">
                                대부분의 불량식품은 저질원료와 타르색소를 이용하여 만들어진 것으로 성장기 어린이들이 먹었을 경우 몸에 매우 안 좋은 영향을 줄 수 있습니다.
                                <br />이들이 불량식품이라는 사실을 숨기기 위해 사용하는 방법으로는 유통기한, 재료명, 영양소의 양 등에 대한 표시를 하지 않아 정확한 내용 등을 먹는 사람으로 하여금 알 수 없게 하는 것입니다.
                                <br />비위생적인 불량식품은 식중독을 일으킬 수 있으므로 먹지 말아야 합니다!
                            </p>
                        </div>
                        <div className="step-area step4">
                            <div className="tit">04. 식품의 영양표시와 유통기한을 확인하고 선택합니다.</div>
                            <p className="desc">
                                영양표시는 제품에 들어 있는 영양소의 종류와 양을 정확히 알게 해 주어서, 우리가 어떤 영양소를 얼마나 먹는지를 쉽게 알게 해 줍니다.
                            </p>
                        </div>
                        <div className="sources">
                            <p>출처 : 한국인을 위한 식생활 지침(어린이용),한국보건산업진흥원, 2014년 11월</p>
                        </div>
                    </div>
                    : <></>
                }
            </div>
        </main>
    )
}

GrowthHelperEatinghabits.title = '성장도우미 식습관'

export default GrowthHelperEatinghabits