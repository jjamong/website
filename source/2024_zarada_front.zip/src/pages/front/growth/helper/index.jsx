import {useRouter} from "next/router"

const GrowthHelper = () => {
    const router = useRouter()

    return(
        <main id="container" className="container growth graph-helper">
            <div className="wrap">
                <div className="eatinghabits-area" onClick={() => router.push('/front/growth/helper/eatinghabits')}>
                    <div className="title">식습관</div>
                    <div className="desc">건강하게 성장하는 식습관</div>
                    <div className="detail">
                        <div className="left">
                            <div>음식은 다양하게 골고루</div>
                            <div>식사는 제때에, 싱겁게</div>
                            <div>간식은 안전하고, 슬기롭게</div>
                        </div>
                        <div className="right">
                            <div className="img"><img src="/img/growth_helper_eatinghabits_title_img.png" alt="식습관 이미지" /></div>
                        </div>
                    </div>
                </div>
                <div className="bottom-area">
                    <div className="exercise-area" onClick={() => router.push('/front/growth/helper/exercise')}>
                        <div className="title-area">
                            <div className="title">운동</div>
                            <div className="desc">키가 크는 바른성장<br />운동법</div>
                        </div>
                        <div className="img"><img src="/img/growth_helper_exercise_title_img.png" alt="운동 이미지" /></div>
                    </div>
                    <div className="growthchart-area" onClick={() => router.push('/front/growth/helper/growthchart')}>
                        <div className="title-area">
                            <div className="title">소아청소년<br />성장도표</div>
                            <div className="desc">키가 크는 바른성장<br />운동법</div>
                        </div>
                        <div className="img"><img src="/img/growth_helper_growthchart_title_img.png" alt="소아청소년 성장도표 이미지" /></div>
                    </div>
                </div>
            </div>  
        </main>
    )
}

GrowthHelper.title = '성장도우미'

export default GrowthHelper