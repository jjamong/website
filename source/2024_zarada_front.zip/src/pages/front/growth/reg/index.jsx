import GrowthForm from "@/components/front/growth/GrowthForm";

const GrowthReg = () => {
    return(
        <GrowthForm />
    );
}

GrowthReg.title = '성장 입력';

export default GrowthReg;