import GrowthForm from "@/components/front/growth/GrowthForm";

const GrowthModi = () => {

    return (
        <GrowthForm />
    );
}

GrowthModi.title = '성장 입력';

export default GrowthModi;