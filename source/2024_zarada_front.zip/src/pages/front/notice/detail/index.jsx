import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import TipTapEditor from "@/components/commons/TipTapEditor";
import {useCallApi} from "@/utils/Query/customApi";

const NoticeDetail = () => {
    const router = useRouter()
    const {noticeSeq} = router.query

    const [selectNoticeRes, setSelectNoticeRes] = useState({
        noticeSeq: noticeSeq,
        noticeTitle: '',
        noticeContent: '',
        topYn: '',
        writeDy: '',
        writeTm: '',
    })
    const selectNoticeObj = {
        url: '/api/user/NoticeController/selectNotice',
        param: {
            noticeSeq: Number(noticeSeq),
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNoticeRes({
                    noticeSeq: noticeSeq,
                    noticeTitle: '',
                    noticeContent: '',
                    topYn: '',
                    writeDy: '',
                    writeTm: '',
                })
                return
            }

            setSelectNoticeRes(data[0])
        }
    }
    const selectNotice = useCallApi(selectNoticeObj)

    useEffect(() => {
        if(!router.isReady) return

        selectNotice.isReady && selectNotice.call()
    }, [router.isReady]);

    return (
        <main id="container" className="container notice notice-detail">
            <div className="wrap">
                <div className="content-area">
                    <div className="title-area">
                        <div className="tit">{selectNoticeRes.noticeTitle}</div>
                        <div className="date">{`${selectNoticeRes.writeDy}`}</div>
                    </div>
                    <TipTapEditor content={selectNoticeRes.noticeContent}/>
                    <div className="btn-area">
                        <div className="btn" onClick={() => router.back()}>공지사항 목록가기</div>
                    </div>
                </div>
            </div>
        </main>
    )
}

NoticeDetail.title = '공지사항'

export default NoticeDetail