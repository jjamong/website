import NavFooter from "@/components/front/commons/NavFooter";
import {useEffect, useState} from "react";
import Pagination from "@/components/commons/Pagination";
import {useRouter} from "next/router";
import NoticeList from "@/components/front/notice/NoticeList";
import {useCallApi} from "@/utils/Query/customApi";

const Notice = () => {
    const router = useRouter()
    const [noticeActivePage, setNoticeActivePage] = useState(1);

    // 공지사항 count 조회
    const [selectNoticeListCountRes, setSelectNoticeListCountRes] = useState(0);
    const selectNoticeListCountObj = {
        url: '/api/user/NoticeController/selectNoticeListCount',
        onSuccess: (data) => {
            setSelectNoticeListCountRes(data[0].count)
        }
    }
    const selectNoticeListCount = useCallApi(selectNoticeListCountObj)

    useEffect(() => {
        selectNoticeListCount.isReady && selectNoticeListCount.call()
    }, [])

    // 공지사항 조회
    const [selectNoticeListRes, setSelectNoticeListRes] = useState([])
    const selectNoticeListObj = {
        url: '/api/user/NoticeController/selectNoticeList',
        param: {
            page: noticeActivePage,
            size: 5,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNoticeListRes([])
                return
            }

            setSelectNoticeListRes(data)
        }
    }
    const selectNoticeList = useCallApi(selectNoticeListObj)

    useEffect(() => {
        selectNoticeList.isReady && selectNoticeList.call()
    }, [noticeActivePage]);

    // Pagination
    const changeActivePage = (value) => {
            if(noticeActivePage === value) return;

            setNoticeActivePage(value);
    }

    // func
    const moveNoticeDetail = (seq) => {
        router.push({
            pathname: 'notice/detail',
            query: {noticeSeq: seq}
        })
    }

    return (
        <>
            <main id="container" className="container notice notice-list">
                <div className="wrap">
                    <div className="content-area">
                        <NoticeList selectNoticeListRes={selectNoticeListRes} moveNoticeDetail={moveNoticeDetail}/>
                        <Pagination changeActivePage={changeActivePage} totalItems={selectNoticeListCountRes} activePage={noticeActivePage} itemsPerPage={5} pageRangeDisplayed={5}/>
                    </div>
                </div>
            </main>
            <NavFooter />
        </>
    )
}

Notice.title = '공지사항'

export default Notice