import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import FindId from "@/components/front/find/FindId";
import FindPw from "@/components/front/find/FindPw";
import TabArea from "@/components/front/commons/TabArea";

const Find = () => {
    const router = useRouter()
    const {cate} = router.query
    const [page, setPage] = useState('id')
    const [popup, setPopup] = useState(null)

    const tabClickHandler = (target) => {
        setPage(target)
    }

    const tabInfo = [
        {id: 'id', active: page === 'id', clickHandler: tabClickHandler, title: '아이디 찾기'},
        {id: 'pw', active: page === 'pw', clickHandler: tabClickHandler, title: '비밀번호 찾기'},
    ]

    useEffect(() => {
        if(!router.isReady) return

        setPage(cate)
    }, [router.isReady]);

    useEffect(() => {
        if(popup) {
            popup.close()
            setPopup(null)
        }
    }, [page]);

    return (
        <main id="container" className="container id-search">
            <div className="wrap">
                <TabArea tabInfo={tabInfo}/>
                {page === 'id' && <FindId setPopup={setPopup}/>}
                {page === 'pw' && <FindPw setPopup={setPopup}/>}
            </div>
        </main>
    )
}

Find.title = '아이디 찾기 / 비밀번호 찾기'

export default Find