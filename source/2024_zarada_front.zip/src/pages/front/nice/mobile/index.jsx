import {useEffect} from "react";

const Mobile = () => {
    useEffect(() => {

        const urlParams = new URL(location.href).searchParams;
        const msgType = 'NICE_SUCCESS'
        const encData = urlParams.get("EncodeData");

        window.ReactNativeWebView.postMessage(JSON.stringify({ msgType, encData }));
    }, []);

    return <></>;
}

export default Mobile;
