import {useEffect} from "react";

const Nice = () => {
    useEffect(() => {
        if(!window.opener) return;

        const urlParams = new URL(location.href).searchParams;
        const encodeData = urlParams.get("EncodeData");

        window.opener.postMessage(JSON.stringify({ encodeData }));
        window.close();

    }, []);

    return <></>;
}

export default Nice;
