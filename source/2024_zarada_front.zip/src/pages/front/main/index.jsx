import {useRouter} from "next/router";
import {useEffect, useRef, useState} from "react";
import {useRecoilState} from "recoil";
import {recoilChild, recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";
import {cdNaConvert, dateFormat, timeFormat} from "@/utils/Libs/Methods/commonUtils";
import ChildSelect from "@/components/front/commons/ChildSelect";
import ChildInfo from "@/components/front/commons/ChildInfo"
import NavFooter from "@/components/front/commons/NavFooter"

import Slider from "react-slick";

const Main = () => {
    const router = useRouter();
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const [childSelectShow, setChildSelectShow] = useState(false)

    useEffect(() => {
        // 내 자녀 목록 조회
        selectMyChildList.isReady && selectMyChildList.call()
        // 공지사항 조회
        selectNoticeList.isReady && selectNoticeList.call()
    }, [])

    useEffect(() => {
        // 내 자녀 정보 상세 조회
        setSelectMyChildDetailParam({ childSeq: rChild.childSeq })
        // 주사 기록 조회
        selectChildInjection.isReady && selectChildInjection.call()
        
        // 오늘 날짜로 슬라이드 이동
        let currentDate = new Date()
        if (sliderRef) sliderRef.slickGoTo(currentDate.getDay())
    }, [rChild.childSeq])

    // 내 자녀 정보 상세 조회
    const [selectMyChildDetailRes, setSelectMyChildDetailRes] = useState([])
    const [selectMyChildDetailParam, setSelectMyChildDetailParam] = useState({ childSeq: rChild.childSeq })
    const selectMyChildDetailObj = {
        url: '/api/user/ChildController/selectMyChildDetail',
        param: {
            childSeq: rChild.childSeq
        },
        onSuccess: (data) => {
            if(!data[0]) {
                return
            }
            setSelectMyChildDetailRes(data[0])
        }
    }
    const selectMyChildDetail = useCallApi(selectMyChildDetailObj)
    useEffect(() => {
        selectMyChildDetail.isReady && selectMyChildDetail.call()
    }, [selectMyChildDetailParam])

    // 내 자녀 목록 조회
    const [selectMyChildListRes, setSelectMyChildListRes] = useState([])
    const selectMyChildListObj = {
        url: '/api/user/ChildController/selectMyChildList',
        param: {},
        onSuccess: (data) => {
            if(!data[0]) {
                return
            }
            setSelectMyChildListRes(data)
        }
    }
    const selectMyChildList = useCallApi(selectMyChildListObj)

    // 자녀 선택 창
    const openSelect = () => {
        setChildSelectShow(true)
    }
    const closeSelect = () => {
        setChildSelectShow(false)
    }
    useEffect(() => {
        let dim = document.getElementById('dim')
        let selectChildList = document.getElementById('select-child-list')
        if(childSelectShow) {
            dim.classList.add('active')
            selectChildList.classList.add('active')
        } else {
            dim.classList.remove('active')
            selectChildList.classList.remove('active')
        }
    }, [childSelectShow])

    // 주사 기록 조회
    const [selectChildInjectionRes, setSelectChildInjectionRes] = useState([])
    const selectChildInjectionObj = {
        url: '/api/user/InjectionController/selectChildInjection',
        param: {
            childSeq: rChild.childSeq,
            mainYn: 'Y'
        },
        onSuccess: (data) => {
            let currentDate = new Date()
            let result = []
            
            // 7일 반복
            for (let i=0; i<7; i++) {
                let resultDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + (i - currentDate.getDay()))
                let year = resultDate.getFullYear()
                let month = resultDate.getMonth() + 1
                month = String(month).length === 1 ? '0' + month : month
                let day = resultDate.getDate()
                day = String(day).length === 1 ? '0' + day : day
                
                // 이번주 7일 날짜 셋팅
                result[i] = {date : dateFormat(year + month + day)}
                
                // 이번주 7일 날짜에 주사기록 데이터가 있으면 셋팅
                for (let j=0; j<data.length; j++) {
                    if (result[i].date == data[j].recordDy) result[i].inj = data[j]
                }
            }

            setSelectChildInjectionRes(result)
        }
    }
    const selectChildInjection = useCallApi(selectChildInjectionObj)

    // 슬라이드 설정
    let sliderRef = useRef(null)
    const slideSettings = {
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        speed: 500,
        arrows: false,
        appendDots: dots => {
            return (
                <div>
                    <ul className="calendar">
                        {dots}
                    </ul>
                </div>
            )
        },
        customPaging: (j) => {
            let currentDate = new Date()
            let today = currentDate.getDate()
            let days = []
            
            // 7일 반복
            for (let i=0; i<7; i++) {
                let resultDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + (i - currentDate.getDay()))
                let month = resultDate.getMonth() + 1
                month = String(month).length === 1 ? '0' + month : month
                let day = resultDate.getDate()

                days[i] = day
                day = String(day).length === 1 ? '0' + day : day

            }

            let day = ''
            switch (j) {
                case 0: day = '일'; break
                case 1: day = '월'; break
                case 2: day = '화'; break
                case 3: day = '수'; break
                case 4: day = '목'; break
                case 5: day = '금'; break
                case 6: day = '토'; break
            }

            return (
                <div className={`li ${today == days[j] ? 'today' : ''}`}>
                    <div className="day">{day}</div>
                    <div className="num">{days[j]}</div>
                    <div className="mark"></div>
                </div>
            )
        }
    }

    // 주사기록 폼 이동
    const moveInjection = () => {
        
        let injSeq = document.querySelector('.slick-slide.slick-active .injection').dataset['injseq']
        let injYmd = document.querySelector('.slick-slide.slick-active .injection').dataset['injymd']

        let currentDate = new Date()
        let year = currentDate.getFullYear()
        let month = currentDate.getMonth() + 1
        month = String(month).length === 1 ? '0' + month : month
        let day = currentDate.getDate()
        day = String(day).length === 1 ? '0' + day : day
            
        if(Number(year + month + day) < Number(dateFormat(injYmd, 'yyyymmdd', ''))) {
            alert('미리 기록하실 수 없습니다.')
            return
        }

        if(!injSeq) {
            router.push({
                pathname: 'injection/reg',
                query: {injYmd},
            })
        } else {
            router.push({
                pathname: 'injection/modi',
                query: {injYmd},
            })
        }
    }

    // 공지사항 조회
    const [selectNoticeListRes, setSelectNoticeListRes] = useState([])
    const selectNoticeListObj = {
        url: '/api/user/NoticeController/selectNoticeList',
        param: {
            page: 1,
            size: 2,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectNoticeListRes([])
                return
            }

            setSelectNoticeListRes(data)
        }
    }
    const selectNoticeList = useCallApi(selectNoticeListObj)

    return(
        <>
            <main id="container" className="container main">
                <div className="wrap">
                    <div className="cover">
                        {selectMyChildDetailRes && <ChildInfo selectMyChildDetailRes={selectMyChildDetailRes} openSelect={openSelect} type={'main'}/>}
                        <div className="content-area">
                            <div className="content">
                                <div className="title-area">
                                    <div className="title">이번주 주사 기록</div>
                                    <div className="cal">
                                        <div className="img btn" onClick={() => {router.push({pathname: '/front/injection' }) }}><img src="/img/main_calendar_icon.png" alt="캘린더 이동" /></div>
                                    </div>
                                </div>
                                <div key={selectMyChildDetailRes.childSeq} className="cartridge-area">
                                    <div className="cartridge">최근 카트리지 개봉일 {selectMyChildDetailRes.recentlyNewItemDate ? dateFormat(selectMyChildDetailRes.recentlyNewItemDate, 'yyyymmdd', '.') : '-'}</div>
                                    <div className="info">
                                        {
                                            (selectMyChildDetailRes.injVol && selectMyChildDetailRes.itemCd)
                                            ? <><span>{selectMyChildDetailRes.injVol}IU</span> ({cdNaConvert('item', selectMyChildDetailRes.itemCd)})</>
                                            : <></>
                                        }
                                    </div>
                                </div>
                            <div className="injection-area">
                                <Slider ref={slider => {sliderRef = slider}} {...slideSettings}>
                                    {   
                                        selectChildInjectionRes && selectChildInjectionRes.map((data, index) => {
                                            return (
                                                <div key={index} className={`injection ${data.inj ? '' : 'nodata'}`}
                                                    data-injseq={data.inj ? data.inj.injectionSeq : ''}
                                                    data-injymd={data.inj ? data.inj.recordDy : data.date}
                                                >
                                                    <div className="date-area">
                                                        <div className="day">{data.date}</div>
                                                        {
                                                            data.inj
                                                            ? <div className="time">{timeFormat(data.inj.recordTm)} {data.inj.recordTm.substring(0, 5)}</div>
                                                            : ''
                                                        }
                                                    </div>
                                                    <div className="info-area">
                                                        <div className="left">
                                                            {
                                                                data.inj
                                                                ? <div className="inj-date">{`${data.inj.injDays > 0 ? '투여 +' + data.inj.injDays : ''}`}</div>
                                                                : ''
                                                            }
                                                            <div className="desc">
                                                                {
                                                                    data.inj
                                                                    ? <><span>{selectMyChildDetailRes.childName} 어린이,<br />{cdNaConvert('injPartCd', data.inj.injPartCd)}</span>에 맞았습니다!</>
                                                                    : <><span>{selectMyChildDetailRes.childName} 어린이,</span><br />기록을 해주세요!</>
                                                                }
                                                            </div>
                                                        </div>
                                                        <div className="right">
                                                            <div className="img">
                                                                {
                                                                    data.inj
                                                                    ? <img src="../../../img/main_injection_mascot_img.png" alt="마스코트 이미지" />
                                                                    : <img src="../../../img/main_injection_mascot_nodata_img.png" alt="마스코트 이미지" />
                                                                }
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    }
                                </Slider>
                            </div>
                            <div className="btn-area" onClick={() => moveInjection()}>
                                <div className="btn">주사기록 하기</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bottom-cover">
                    <div className="injection-method-area"
                        onClick={() => {
                            router.push({
                                pathname: '/front/injection',
                                query: {cate : 'method'}
                            })
                        }}
                    >
                        <div className="left">
                            <div className="title">주사방법</div>
                            <div className="desc">성장주사 펜 사용법에<br />대해 알려드려요!</div>
                        </div>
                        <div className="right">
                            <div className="img"><img src="../../../img/main_injection_img.png" alt="주사 이미지" /></div>
                        </div>
                    </div>
                    <div className="notice-area">
                        <div className="title">공지사항</div>
                        <ul>
                            {
                                selectNoticeListRes && selectNoticeListRes.map((data, index) => {
                                    return (
                                        <li key={index} onClick={() => {
                                            router.push({
                                                pathname: '/front/notice/detail',
                                                query: {noticeSeq: data.noticeSeq}
                                            })
                                        }}>
                                            <div className="tit less">{data.noticeTitle}</div>
                                            <div className="date">{data.writeDy ? dateFormat(data.writeDy, 'yyyymmdd', '.') : ''}</div>
                                        </li>
                                    )
                                })
                            }
                        </ul>
                    </div>
                </div>
            </div>  
        </main>
        <ChildSelect selectMyChildListRes={selectMyChildListRes} closeSelect={closeSelect} />
        <NavFooter />
        </>
    );
}

Main.layoutType = 'front'
export default Main;
