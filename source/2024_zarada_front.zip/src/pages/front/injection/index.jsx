import {useEffect, useState} from "react"
import ChildInfo from "@/components/front/commons/ChildInfo"
import NavFooter from "@/components/front/commons/NavFooter"
import TabArea from "@/components/front/commons/TabArea"
import {getWeeks} from "@/utils/Libs/Methods/userUtils"
import {leftPad, setParam} from "@/utils/Libs/Methods/commonUtils"
import {useRecoilState} from "recoil";
import ChildSelect from "@/components/front/commons/ChildSelect";
import {useRouter} from "next/router";
import {saveAlarmValidate} from "@/utils/Libs/Methods/userValidate";
import {recoilChild, recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";
import InjectionCalendar from "@/components/front/injection/InjectionCalendar";
import InjectionAlarm from "@/components/front/injection/InjectionAlarm";
import InjectionMethod from "@/components/front/injection/InjectionMethod";

const today = new Date()
const _year = today.getFullYear()
const _month = leftPad(today.getMonth() + 1)
const _date = leftPad(today.getDate())
// yyyyMMdd
const _today = `${_year}${_month}${_date}`

const Injection = () => {
    const [page, setPage] = useState('calendar')
    const [year, setYear] = useState(_year)
    const [month, setMonth] = useState(_month)
    const [calendar, setCalendar] = useState([])
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const [childSelectShow, setChildSelectShow] = useState(false)
    const router = useRouter()

    // 주사방법 페이지 이동
    const {cate} = router.query
    useEffect(() => {
        if(!router.isReady) return
        cate && setPage(cate)
    }, [router.isReady]);

    // 자녀 상세 조회
    const [selectMyChildDetailRes, setSelectMyChildDetailRes] = useState([])
    const selectMyChildDetailObj = {
        url: '/api/user/ChildController/selectMyChildDetail',
        param: {
            childSeq: rChild.childSeq,
        },
        onSuccess: (data) => {
            if (!data[0]) {
                setSelectMyChildDetailRes([])
                return
            }

            setSelectMyChildDetailRes(data)
        },
    }
    const selectMyChildDetail = useCallApi(selectMyChildDetailObj)

    // 자녀 목록 조회
    const [selectMyChildListRes, setSelectMyChildListRes] = useState([])
    const selectMyChildListObj = {
        url: '/api/user/ChildController/selectMyChildList',
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectMyChildListRes([])
                return
            }

            setSelectMyChildListRes(data)
        }
    }
    const selectMyChildList = useCallApi(selectMyChildListObj)

    // 주사기록 조회
    const [selectChildInjectionRes, setSelectChildInjectionRes] = useState([])
    const selectChildInjectionObj = {
        url: '/api/user/InjectionController/selectChildInjection',
        param: {
            childSeq: rChild.childSeq,
            injMonth: `${year}-${month}`,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectChildInjectionRes([])
                return
            }

            setSelectChildInjectionRes(data)
        }
    }
    const selectChildInjection = useCallApi(selectChildInjectionObj)

    useEffect(() => {
        selectMyChildList.isReady && selectMyChildList.call()
    }, [])

    // 알람 조회
    const [selectAlarmRes, setSelectAlarmRes] = useState({
        alarmSeq: 0,
        userSeq: rUser.userSeq,
        childSeq: rChild.childSeq,
        alYn: 'N',
        alTm: (new Date()).getHours() + ':' + (new Date()).getMinutes(),
        monYn: 'N',
        tueYn: 'N',
        wedYn: 'N',
        thuYn: 'N',
        friYn: 'N',
        satYn: 'N',
        sunYn: 'N'
    })
    const selectAlarmObj = {
        url: '/api/user/InjectionController/selectAlarm',
        param: {
            childSeq: rChild.childSeq
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectAlarmRes({
                    alarmSeq: 0,
                    userSeq: rUser.userSeq,
                    childSeq: rChild.childSeq,
                    alYn: 'N',
                    alTm: (new Date()).getHours() + ':' + (new Date()).getMinutes(),
                    monYn: 'N',
                    tueYn: 'N',
                    wedYn: 'N',
                    thuYn: 'N',
                    friYn: 'N',
                    satYn: 'N',
                    sunYn: 'N'
                })
                return
            }

            setSelectAlarmRes({...data[0], injVol: rChild.injVol ?? 0})
        }
    }
    const selectAlarm = useCallApi(selectAlarmObj)

    // 알람 저장
    const saveAlarmObj = {
        url: '/api/user/InjectionController/saveAlarm',
        param: selectAlarmRes,
        onSuccess: (data) => {
            alert('주사 알람이 저장되었습니다.')
        }
    }
    const saveAlarm = useCallApi(saveAlarmObj)

    // func
    // 자녀 선택 창
    const openSelect = () => {
        setChildSelectShow(true)
    }
    const closeSelect = () => {
        setChildSelectShow(false)
    }

    const tabClickHandler = (target) => {
        setPage(target)
    }

    const tabInfo = [
        {id: 'calendar', active: page === 'calendar', clickHandler: tabClickHandler, title: '주사기록'},
        {id: 'alarm', active: page === 'alarm', clickHandler: tabClickHandler, title: '주사알람'},
        {id: 'method', active: page === 'method', clickHandler: tabClickHandler, title: '주사방법'},
    ]

    // 이전달
    const movePrevMonth = () => {
        const date = new Date(Number(year), Number(month) - 1, 0);
        const pmYear = date.getFullYear();
        const pmMonth = (leftPad(date.getMonth() + 1));

        setYear(pmYear);
        setMonth(pmMonth);
    }

    // 다음달
    const moveNextMonth = () => {
        const date = new Date(Number(year), Number(month) + 1, 0);
        const nmYear = date.getFullYear();
        const nmMonth = (leftPad(date.getMonth() + 1));

        setYear(nmYear);
        setMonth(nmMonth);
    }

    // 전년
    const movePreviousYear = () => {
        setYear((year) => (Number(year) - 1));
    }

    // 다음년
    const moveNextYear = () => {
        setYear((year) => (Number(year) + 1));
    }

    // 날짜, 월 선택
    const moveSelectDateMonth = (date) => {
        if (!date) return

        // 오늘 선택 시
        if (date === 'today') {
            let today = new Date()
            setYear(today.getFullYear())
            setMonth(leftPad(today.getMonth() + 1))
        // 날짜 선택 시
        } else {
            setYear(date.getFullYear())
            setMonth(leftPad(date.getMonth() + 1))
        }
    }

    // 주사기록 폼 이동
    const moveInjection = (injSeq, injYmd) => {
        
        if(Number(rChild.birthday.replaceAll('-', '') > Number(injYmd))) {
            alert('생일 이전 날짜는 기록하실 수 없습니다.')
            return
        }

        if(Number(_today) < Number(injYmd)) {
            alert('미리 기록하실 수 없습니다.')
            return
        }

        if(injSeq === 0 || injSeq === '' || injSeq === undefined || injSeq === null) {
            router.push({
                pathname: 'injection/reg',
                query: {injYmd},
            })
        } else {
            router.push({
                pathname: 'injection/modi',
                query: {injYmd},
            })
        }
    }

    // 주사 알람
    const alYnChange = (e) => {
        setParam(setSelectAlarmRes, {alYn: e.target.checked ? 'Y' : 'N'})
    }

    const clickDay = (day, value) => {
        setParam(setSelectAlarmRes, {[day]: value === 'Y' ? 'N' : 'Y'})
    }

    const alTmChange = (e) => {
        const {value} = e.target

        setParam(setSelectAlarmRes, {alTm: `${value}:00`})
    }

    const saveAlram = () => {
        const {status, msg, elem} = saveAlarmValidate(selectAlarmRes, rChild.injVol)

        if(!status) {
            alert(msg)
            return
        }

        if(!confirm('주사 알람을 저장하시겠습니까?')) return

        saveAlarm.isReady && saveAlarm.call()
    }

    // useEffect
    useEffect(() => {
        selectChildInjection.isReady && selectChildInjection.call()
    }, [year, month])

    useEffect(() => {
        selectMyChildDetail.isReady && selectMyChildDetail.call()
        selectAlarm.isReady && selectAlarm.call()
        selectChildInjection.isReady && selectChildInjection.call()
    }, [rChild.childSeq])

    useEffect(() => {
        setCalendar(getWeeks(selectChildInjectionRes, _year, _month, _date, year, month))
    }, [selectChildInjectionRes]);

    useEffect(() => {
        let dim = document.getElementById('dim')
        let selectChildList = document.getElementById('select-child-list')
        if(childSelectShow) {
            dim.classList.add('active')
            selectChildList.classList.add('active')
        } else {
            dim.classList.remove('active')
            selectChildList.classList.remove('active')
        }
    }, [childSelectShow])

    return (
        <>
            <main id="container" className={`container injection ${page}`}>
                <div className="wrap">
                    {selectMyChildDetailRes[0] && <ChildInfo selectMyChildDetailRes={selectMyChildDetailRes[0]} openSelect={openSelect}/>}
                    <TabArea tabInfo={tabInfo}/>
                    {
                        page === 'calendar' &&
                        <InjectionCalendar
                            year={year}
                            month={month}
                            movePrevMonth={movePrevMonth}
                            moveNextMonth={moveNextMonth}
                            movePreviousYear={movePreviousYear}
                            moveNextYear={moveNextYear}
                            moveSelectDateMonth={moveSelectDateMonth}
                            calendar={calendar}
                            moveInjection={moveInjection}/>
                    }
                    {page === 'alarm' && <InjectionAlarm
                        selectAlarmRes={selectAlarmRes}
                        injVol={rChild.injVol}
                        alYnChange={alYnChange}
                        clickDay={clickDay}
                        alTmChange={alTmChange}
                        saveAlram={saveAlram}/>
                    }
                    {page === 'method' && <InjectionMethod/>}
                </div>
            </main>
            <ChildSelect selectMyChildListRes={selectMyChildListRes} closeSelect={closeSelect} />
            <NavFooter />
        </>

    )
}

Injection.title = '주사 관리'

export default Injection