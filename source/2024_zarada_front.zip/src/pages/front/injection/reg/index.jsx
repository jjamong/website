import InjectionForm from "@/components/front/injection/InjectionForm";

const InjectionReg = () => {
    return (
        <InjectionForm />
    )
}

InjectionReg.title = '주사 입력'

export default InjectionReg