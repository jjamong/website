import InjectionForm from "@/components/front/injection/InjectionForm";

const InjectionModi = () => {
    return (
        <InjectionForm />
    )
}

InjectionModi.title = '주사 입력'

export default InjectionModi