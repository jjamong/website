import {useEffect, useRef, useState} from "react"
import JoinFirst from "@/components/front/join/JoinFirst"
import JoinSecond from "@/components/front/join/JoinSecond"
import JoinThird from "@/components/front/join/JoinThird"
import JoinFourth from "@/components/front/join/JoinFourth"
import JoinComplete from "@/components/front/join/JoinComplete"
import {joinValidate} from "@/utils/Libs/Methods/userValidate"
import Agree from "@/components/front/join/Agree"
import {leftPad, setParam} from "@/utils/Libs/Methods/commonUtils"
import {useCallApi} from "@/utils/Query/customApi";
import {useDaumPostcodePopup} from "react-daum-postcode";

const Join = () => {
    const [step, setStep] = useState(1)
    const [nextEnabled, setNextEnabled] = useState(false)
    const [isRNWebview, setIsRNWebview] = useState(false)
    const [joinInfo, setJoinInfo] = useState({
        userId: '',
        userPw: '',
        userPw2: '',
        userName: '',
        userBirthday: '',
        userGenderCd: '',
        phone: '',
        zipCode: '',
        addr: '',
        addrDtl: '',
        email: '',
        psnInfoDvsn10: '',
        childName: '',
        childBirthday: '',
        childGenderCd: '',
        itemCd: '',
        hospitalNm: '',
        doctorNm: '',
        childFile: ''
    })

    // 회원가입 - 동의
    const [agree, setAgree] = useState({agreeAll: false, agree1: false})
    const [viewAgree, setViewAgree] = useState(false)
    const userIdRef = useRef(null)
    const userPwRef = useRef(null)
    const userPw2Ref = useRef(null)

    // 회원가입 - 동의 선택
    const agreeChangeHandler = (target) => {
        if (target === 'agreeAll') {
            setAgree((prevState) => {
                const checked = prevState[target]

                return {agreeAll: !checked, agree1: !checked}
            })
        } else {
            const tempAgree = agree
            for (const id in tempAgree) {
                if (target === id) {
                    tempAgree[target] = !tempAgree[target]
                    tempAgree['agreeAll'] = tempAgree.agree1
                }
            }

            setAgree((prevState) => {
                return {...prevState, tempAgree}
            })
        }
    }

    useEffect(() => {
        // 개인정보 동의 시간 추가
        if (agree.agreeAll) {
            const today = new Date();
            const year = today.getFullYear()
            const month = leftPad(today.getMonth() + 1)
            const date = leftPad(today.getDate())
            const hours = (`0${today.getHours()}`).slice(-2)
            const minutes = (`0${today.getMinutes()}`).slice(-2)
            const seconds = (`0${today.getSeconds()}`).slice(-2)

            setParam(setJoinInfo, {psnInfoDvsn10: `${year}-${month}-${date} ${hours}:${minutes}:${seconds}`})

            // 개인정보 동의 시간 제거
        } else {
            setParam(setJoinInfo, {psnInfoDvsn10: ''})
        }
    }, [agree.agreeAll])

    const viewAgreeHandler = () => {
        setViewAgree((prevState) => !prevState)
    }

    // join2
    const addrRef1 = useRef(null)
    const addrRef2 = useRef(null)
    const addrRef3 = useRef(null)
    const niceFormRef = useRef(null)
    const niceEncRef = useRef(null)
    const niceBtnRef = useRef(null)
    const [isEmbedVisible, setIsEmbedVisible] = useState('none');

    const open = useDaumPostcodePopup()

    // 주소찾기
    const openAddr = () => {
        if (isRNWebview) setIsEmbedVisible('block')
        else open({onComplete: fOnComplete});
    }

    const fCloseLayer = () => {
        setIsEmbedVisible('none');
    };

    const fOnComplete = (data) => {
        fCloseLayer()
        console.log('complete')
        setParam(setJoinInfo, {zipCode: data.zonecode, addr: data.address, addrDtl: ''})
        document.getElementById("addrDtl")?.focus();
    }

    // join2 func
    const addrChangeHandler = (id, e) => {
        setParam(setJoinInfo, {[id]: e.target.value})
    }

    // nice 인증
    const openNice = () => {
        niceBtnRef.current.click()
    }

    // join3
    const [userIdChk, setUserIdChk] = useState(-1)
    const [userPwChk, setUserPwChk] = useState(0)
    const [userPw2Chk, setUserPw2Chk] = useState(-1)

    // join3 func
    const userInfoChange = (id, e) => {
        if (id === 'userId') {
            if (e.target.value === '') {
                setUserIdChk(-1)
            } else {
                setUserIdChk(0)
            }
            setParam(setJoinInfo, {[id]: e.target.value})
        } else {
            setParam(setJoinInfo, {[id]: e.target.value})
        }
    }

    // 아이디 중복 확인
    const checkDuplIdObj = {
        url: '/api/extra/JoinController/checkDuplId',
        param: {
            userId: joinInfo.userId,
        },
        onSuccess: (data) => {
            if (data[0].count === 0) {
                alert('사용가능한 아이디입니다.')
                setUserIdChk(2)
            } else {
                alert('중복된 아이디입니다.')
                userIdRef.current.focus()
                setUserIdChk(1)
            }
        }
    }
    const checkDuplId = useCallApi(checkDuplIdObj)

    const idDupl = () => {
        if (joinInfo.userId === '') {
            alert('아이디를 입력 후 중복확인 해 주세요.')
            return
        } else if (joinInfo.userId.length < 4 || joinInfo.userId.length > 13) {
            alert('아이디는 4~13자리 이내로 입력해 주세요.')
            return
        }

        checkDuplId.isReady && checkDuplId.call()
    }

    useEffect(() => {
        const pwPattern1 = /^.{8,16}$/
        const pwPattern2 = /^[a-zA-Z0-9]+$/

        // pw
        if (joinInfo.userPw === '') {
            setUserPwChk(0)
        } else if (!pwPattern1.test(joinInfo.userPw)) {
            setUserPwChk(1)
        } else if (pwPattern2.test(joinInfo.userPw)) {
            setUserPwChk(2)
        } else {
            setUserPwChk(3)
        }

        // pw2
        if (joinInfo.userPw !== '' && joinInfo.userPw2 !== '' && (joinInfo.userPw === joinInfo.userPw2)) {
            setUserPw2Chk(1)
        } else if (joinInfo.userPw === '' && joinInfo.userPw2 === '') {
            setUserPw2Chk(-1)
        } else {
            setUserPw2Chk(0)
        }
    }, [joinInfo])

    // join4
    const childNameRef = useRef(null)
    const childBirthdayRef = useRef(null)
    const childHospitalRef = useRef(null)


    // join4 func
    const childInfoChange = (id, e) => {
        setParam(setJoinInfo, {[id]: e.target.value})
    }

    const childInfoNumChange = (id, e) => {
        setParam(setJoinInfo, {[id]: Number(e.target.value)})
    }

    // 병원 목록 조회
    //
    const [selectHospitalComboRes, setSelectHospitalComboRes] = useState([])
    const selectHospitalComboObj = {
        url: '/api/extra/CommonController/selectHospitalCombo',
        onSuccess: (data) => {
            if (!data[0]) {
                setSelectHospitalComboRes([])
                return
            }

            let tempRes = [
                {value: '', text: '병원을 선택해 주세요.'}
            ]

            data.forEach((hospital) => {
                tempRes.push({value: hospital.hospitalNm, text: hospital.hospitalNm})
            })

            setSelectHospitalComboRes(tempRes)
        }
    }
    const selectHospitalCombo = useCallApi(selectHospitalComboObj)
    useEffect(() => {
        selectHospitalCombo.isReady && selectHospitalCombo.call()
    }, []);

    // 회원가입
    const joinObj = {
        url: '/api/extra/JoinController/join',
        param: joinInfo,
        onSuccess: (data) => {
            stepChangeHandler('next')
        }
    }
    const join = useCallApi(joinObj)

    const doJoin = () => {
        if (confirm('회원가입 하시겠습니까?')) {
            join.isReady && join.call()
        }
    }

    // join common func
    const stepChangeHandler = (type) => {
        if (type === 'prev') {
            setStep((prevState) => prevState - 1)
            setNextEnabled(false)
        }

        if (type === 'next') {
            setStep((prevState) => prevState + 1)
            setNextEnabled(false)
        }
    }

    // 각 가입 단계 validation
    const stepValidate = () => {
        const {status, msg, elem} = joinValidate(step, agree, joinInfo, userIdChk, userPwChk, userPw2Chk)
        if (!status) {
            alert(msg)
            switch (elem) {
                case 'addrDtl':
                    addrRef3.current.focus()
                    break
                case 'userId':
                    userIdRef.current.focus()
                    break
                case 'userPw':
                    userPwRef.current.focus()
                    break
                case 'userPw2':
                    userPw2Ref.current.focus()
                    break
                case 'childName':
                    childNameRef.current.focus()
                    break
                case 'childBirthday':
                    childBirthdayRef.current.focus()
                    break
                case 'childHospital':
                    childHospitalRef.current.focus()
                    break
            }

            return
        }

        if (step !== 4) {
            stepChangeHandler('next')
        } else {
            doJoin()
        }
    }

    // 다음 페이지 활성화
    useEffect(() => {
        const {status} = joinValidate(step, agree, joinInfo, userIdChk, userPwChk, userPw2Chk)

        if (status) {
            setNextEnabled(true)
        } else {
            setNextEnabled(false)
        }

    }, [step, agree, joinInfo, userIdChk, userPwChk, userPw2Chk])

    useEffect(() => {
        if (window.ReactNativeWebView) {
            setIsRNWebview(true)
        }
    }, [])

    return (
        <>
            <main id="container" className={`container join join${step}`}>
                <div className="wrap">
                    {step !== 5 && !viewAgree &&
                        <div className="nav-area">
                            <div className="nav">
                                <div className={`step step1 ${step === 1 ? 'active' : ''}`}></div>
                                <div className={`step step2 ${step === 2 ? 'active' : ''}`}></div>
                                <div className={`step step3 ${step === 3 ? 'active' : ''}`}></div>
                                <div className={`step step4 ${step === 4 ? 'active' : ''}`}></div>
                            </div>
                        </div>
                    }
                    {step === 1 && !viewAgree &&
                        <JoinFirst nextEnabled={nextEnabled} agree={agree} agreeChangeHandler={agreeChangeHandler}
                                   stepValidate={stepValidate} viewAgreeHandler={viewAgreeHandler}/>}
                    {step === 1 && viewAgree && <Agree viewAgreeHandler={viewAgreeHandler}/>}
                    {step === 2 && <JoinSecond nextEnabled={nextEnabled} stepChangeHandler={stepChangeHandler}
                                               isEmbedVisible={isEmbedVisible} fCloseLayer={fCloseLayer} fOnComplete={fOnComplete}
                                               stepValidate={stepValidate} joinInfo={joinInfo}
                                               addrChangeHandler={addrChangeHandler}
                                               addrRef3={addrRef3}
                                               openAddr={openAddr}
                                               setState={setJoinInfo} openNice={openNice} niceFormRef={niceFormRef}
                                               niceEncRef={niceEncRef} niceBtnRef={niceBtnRef}/>}
                    {step === 3 && <JoinThird nextEnabled={nextEnabled} stepChangeHandler={stepChangeHandler}
                                              stepValidate={stepValidate} userInfo={joinInfo}
                                              userInfoChange={userInfoChange}
                                              idDupl={idDupl} userIdChk={userIdChk} userPwChk={userPwChk}
                                              userPw2Chk={userPw2Chk} userIdRef={userIdRef} userPwRef={userPwRef}
                                              userPw2Ref={userPw2Ref}/>}
                    {step === 4 && <JoinFourth nextEnabled={nextEnabled} stepChangeHandler={stepChangeHandler}
                                               stepValidate={stepValidate} childInfo={joinInfo}
                                               childInfoChange={childInfoChange} childInfoNumChange={childInfoNumChange}
                                               childNameRef={childNameRef} childBirthdayRef={childBirthdayRef}
                                               childHospitalRef={childHospitalRef}
                                               selectHospitalComboRes={selectHospitalComboRes}/>}
                    {step === 5 && <JoinComplete childName={joinInfo.childName}/>}
                </div>
            </main>
        </>
    )
}

Join.title = '회원 가입'

export default Join
