import ChildImage from "@/components/front/mypage/ChildImage";
import LabelInput from "@/components/commons/LabelInput";
import LabelRadio from "@/components/commons/LabelRadio";
import {useRouter} from "next/router";
import {useRecoilState} from "recoil";
import {recoilUser, recoilChild} from "@/utils/Store/atom";
import {useEffect, useState} from "react";
import {imgToBase64, numberFormat, setParam} from "@/utils/Libs/Methods/commonUtils";
import {changeChildValidate} from "@/utils/Libs/Methods/userValidate";
import LabelSelect from "@/components/commons/LabelSelect";
import {useCallApi} from "@/utils/Query/customApi";

const ModiChild = () => {
    const router = useRouter()
    const [rChild, setRChild] = useRecoilState(recoilChild)
    const {childSeq} = router.query

    const items = [
        {value: '', text: '카트리지를 선택해 주세요.'},
        {value: '40', text: '카트리지 20IU'},
        {value: '50', text: '카트리지 30IU'},
    ]

    const [selectHospitalComboRes, setSelectHospitalComboRes] = useState([])
    const selectHospitalComboObj = {
        url: '/api/extra/CommonController/selectHospitalCombo',
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectHospitalComboRes([])
                return
            }

            let tempRes = [
                {value: '', text: '병원을 선택해 주세요.'}
            ]

            data.forEach((hospital) => {
                tempRes.push({value: hospital.hospitalNm, text: hospital.hospitalNm})
            })

            setSelectHospitalComboRes(tempRes)
        }
    }
    const selectHospitalCombo = useCallApi(selectHospitalComboObj)

    useEffect(() => {
        selectHospitalCombo.isReady && selectHospitalCombo.call()
    }, [])

    const [selectMyChildDetailRes, setSelectMyChildDetailRes] = useState({
        childSeq: 0,
        childName: '',
        birthday: '',
        genderCd: '',
        itemCd: '',
        hospitalNm: '',
        doctorNm: '',
        injVol: 0,
        childFile: ''
    })
    const selectMyChildDetailObj = {
        url: '/api/user/ChildController/selectMyChildDetail',
        param: {
            childSeq
        },
        onSuccess: (data) => {
            if(!data[0]) {
                alert('자녀 조회에 실패하였습니다.')
                router.back()
            }

            setSelectMyChildDetailRes(data[0])
        }
    }
    const selectMyChildDetail = useCallApi(selectMyChildDetailObj)

    useEffect(() => {
        if(!router.isReady) return

        selectMyChildDetail.isReady && selectMyChildDetail.call()
    }, [router.isReady]);

    // 자녀 수정
    const updateMyChildObj = {
        url: '/api/user/ChildController/updateMyChild',
        param: selectMyChildDetailRes,
        onSuccess: (data) => {
            setRChild({
                childSeq : selectMyChildDetailRes.childSeq,
                birthday: selectMyChildDetailRes.birthday,
                injVol : selectMyChildDetailRes.injVol,
                itemCd : selectMyChildDetailRes.itemCd
            })

            alert('자녀 정보 변경에 성공하였습니다.')
            router.back()
        }
    }
    const updateMyChild = useCallApi(updateMyChildObj)

    const changeUpdateChild = (target, e) => {
        setParam(setSelectMyChildDetailRes, {[target]: e.target.value})
    }

    const childUpdate = () => {
        const {status, msg, elem} = changeChildValidate(selectMyChildDetailRes)

        if(!status) {
            alert(msg)
            return
        }

        if(!confirm('자녀 정보를 변경하시겠습니까?')) return

        updateMyChild.isReady && updateMyChild.call()
    }

    const upLoad = (e) => {
        let file = document.getElementById('file')

        imgToBase64(file).then((src) => {
            setParam(setSelectMyChildDetailRes, {childFile: src})
        }).catch((e) => {
            alert(e)
        })
    }

    const imageDelete = (e) => {
        e.preventDefault()

        let file = document.getElementById('file')
        file.value = ''
        setParam(setSelectMyChildDetailRes, {childFile: ''})
    }

    const volChange = (id, e) => {
        const value = numberFormat(Number(e.target.value), 2, 1)

        if(value !== false) {
            setParam(setSelectMyChildDetailRes, {[id]: value.toString()})
        }
    }

    const itemChange = (id, e) => {
        setParam(setSelectMyChildDetailRes, {[id]: e.target.value})
    }

    return (
        <main id="container" className="container mypage child-form">
            <div className="wrap">
                <div className="content-area">
                    <div className="desc-area">
                        <p className="desc1">아이 정보를 적어주세요.</p>
                    </div>
                    <div className="content">
                        <ChildImage imageSrc={selectMyChildDetailRes.childFile} changeHandler={upLoad} imageDelete={imageDelete}/>
                        <LabelInput id={'childName'} type={'text'} title={'아이 이름'} isRequire={true} value={selectMyChildDetailRes.childName} placeholder={'아이 이름을 입력해 주세요.'} changeHandler={changeUpdateChild}/>
                        <LabelInput id={'birthday'} type={'date'} title={'아이 생년월일'} isRequire={true} value={selectMyChildDetailRes.birthday} changeHandler={changeUpdateChild}/>
                        <div className="form-item">
                            <label htmlFor="childSex" className="tit">아이 성별<span className="require">*</span></label>
                            <div className="radio-section">
                                <LabelRadio id={'childSexMan'} name={'genderCd'} value={'M'} checked={selectMyChildDetailRes.genderCd === 'M'} changeHandler={changeUpdateChild} labelTitle={'남자'}/>
                                <LabelRadio id={'childSexFemale'} name={'genderCd'} value={'F'} checked={selectMyChildDetailRes.genderCd === 'F'} changeHandler={changeUpdateChild} labelTitle={'여자'}/>
                            </div>
                        </div>
                        <LabelSelect customClass={'itemCd'} id={'itemCd'} title={'카트리지'} value={selectMyChildDetailRes.itemCd} changeHandler={itemChange} datas={items}/>
                        <LabelSelect customClass={'hospitalNm'} id={'hospitalNm'} title={'병원명'} value={selectMyChildDetailRes.hospitalNm} changeHandler={changeUpdateChild} datas={selectHospitalComboRes}/>
                        <LabelInput title={'의사명'} id={'doctorNm'} type={'text'} value={selectMyChildDetailRes.doctorNm} placeholder={'의사명을 입력해 주세요.'} changeHandler={changeUpdateChild}/>
                        <LabelInput id={'injVol'} type={'number'} title={'주사 용량'} value={selectMyChildDetailRes.injVol === '' ? 0 : selectMyChildDetailRes.injVol} changeHandler={volChange}/>
                        <div className="btn-area">
                            <div className="btn" onClick={() => router.back()}>취소</div>
                            <div className="btn active" onClick={childUpdate}>수정하기</div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}

ModiChild.title = '자녀 변경'

export default ModiChild
