import NavFooter from "@/components/front/commons/NavFooter";
import {useRef, useState} from "react";
import LabelInput from "@/components/commons/LabelInput";
import {useRouter} from "next/router";
import {useCallApi} from "@/utils/Query/customApi";

const Withdrawal = () => {
    const router = useRouter()
    const [userPw, setUserPw] = useState('')
    const checkRef = useRef(null)

    // 회원 탈퇴
    const withdrawalObj = {
        url: '/api/user/JoinController/withdrawal',
        param: {
            userPw,
        },
        onSuccess: (data) => {
            alert('회원 탈퇴가 완료되었습니다.')
            window.location.href = window.location.origin
        },
        onError: (e) => {
            setUserPw('')
            checkRef.current.checked = false
        }
    }
    const withdrawal = useCallApi(withdrawalObj)

    const changePw = (target, e) => {
        setUserPw(e.target.value)
    }

    const doWithdrawal = () => {
        if(userPw === '') {
            alert('비밀번호를 입력해 주세요.')
            return
        }

        if(!checkRef.current.checked) {
            alert('탈퇴 동의를 체크해 주세요.')
            return
        }

        withdrawal.isReady && withdrawal.call()
    }

    return (
        <>
            <main id="container" className="container mypage withdrawal">
                <div className="wrap">
                    <div className="content-area">
                        <div className="desc-area">
                            <p className="desc1">탈퇴 시 주의 사항</p>
                        </div>
                        <div className="content">
                            <div className="guide-area">
                                <div className="guide">
                                    <p>
                                        탈퇴 시 본 사이트를 통해 <span className="bold">등록된 모든 정보가 즉시 삭제되며,</span><br/>
                                        <span className="red">다시는 복구 할 수 없습니다.</span><br/>
                                        정말로 탈퇴를 원하신다면 아래에 비밀번호를 입력하고<br/>‘탈퇴하기’버튼을 눌러주세요.
                                    </p>
                                </div>
                            </div>
                            <LabelInput id={'userPw'} isRequire={true} title={'비밀번호'} type={'password'} placeholder={'비밀번호를 입력해 주세요.'} value={userPw} changeHandler={changePw}/>
                            <div className="agree-area">
                                <div className="checkbox-area">
                                    <div className="input-checkbox"><input type="checkbox" id="check" ref={checkRef}
                                                                           name="loginMaintain" value="Y"/></div>
                                    <label htmlFor="check">위 내용을 모두 확인하였으며, 회원탈퇴에 동의합니다.</label>
                                </div>
                            </div>
                            <div className="btn-area">
                                <div className="btn" onClick={() => router.back()}>취소</div>
                                <div className="btn active" onClick={doWithdrawal}>탈퇴하기</div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <NavFooter />
        </>
    )
}

Withdrawal.title = '회원 탈퇴'

export default Withdrawal