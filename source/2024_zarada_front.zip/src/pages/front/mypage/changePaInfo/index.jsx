import NavFooter from "@/components/front/commons/NavFooter";
import {useRouter} from "next/router";
import AddrInput from "@/components/commons/AddrInput";
import LabelInputWithButton from "@/components/commons/LabelInputWithButton";
import LabelInput from "@/components/commons/LabelInput";
import {useEffect, useRef, useState} from "react";
import {useDaumPostcodePopup} from "react-daum-postcode";
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {updateUserValidate} from "@/utils/Libs/Methods/userValidate";
import NiceForm from "@/components/front/commons/NiceForm";
import {useCallApi} from "@/utils/Query/customApi";
import DaumAddrMo from "@/components/front/commons/DaumAddrMo";

const ChangePaInfo = () => {
    const router = useRouter()
    const [isRNWebview, setIsRNWebview] = useState(false);
    const [isEmbedVisible, setIsEmbedVisible] = useState("none");

    const addrRef3 = useRef(null)
    const niceFormRef = useRef(null)
    const niceEncRef = useRef(null)
    const niceBtnRef = useRef(null)

    const open = useDaumPostcodePopup()

    // 마이페이지 조회
    const [selectMypageRes, setSelectMypageRes] = useState({
        userSeq: 0,
        userId: '',
        userName: '',
        birthday: '',
        genderCd: '',
        phone: '',
        zipCode: '',
        addr: '',
        addrDtl: '',
        email: '',
        joinDt: ''
    })
    const selectMypageObj = {
        url: '/api/user/MypageController/selectMypage',
        onSuccess: (data) => {
            if (!data[0]) {
                alert('마이페이지 정보 조회에 실패하였습니다.')
                router.back()
                return
            }

            setSelectMypageRes(data[0])
        },
    }
    const selectMypage = useCallApi(selectMypageObj)

    useEffect(() => {
        selectMypage.isReady && selectMypage.call()
    }, [])

    const desc = {
        descClass: 'desc',
        descTitle: '나이스평가정보에서 인증받은 휴대폰 번호를 사용하고 있습니다.'
    }

    // 주소찾기
    const openAddr = () => {
        if (isRNWebview) setIsEmbedVisible('block')
        else open({onComplete: fOnComplete});
    }

    const fCloseLayer = () => {
        setIsEmbedVisible("none");
    };

    const fOnComplete = (data) => {
        fCloseLayer()
        setParam(setSelectMypageRes, {zipCode: data.zonecode, addr: data.address, addrDtl: ''})
        document.getElementById("addrDtl")?.focus();
    }

    const addrChangeHandler = (id, e) => {
        setParam(setSelectMypageRes, {[id]: e.target.value})
    }

    // nice 인증
    const openNice = () => {
        niceBtnRef.current.click()
    }

    // 마이페이지 정보 수정
    const updateMypageObj = {
        url: '/api/user/MypageController/updateMypage',
        param: selectMypageRes,
        onSuccess: (data) => {
            alert('보호자 정보 수정에 성공하였습니다.')
            router.push('/front/main')
        }
    }
    const updateMypage = useCallApi(updateMypageObj)

    const update = () => {
        const {status, msg, elem} = updateUserValidate(selectMypageRes)

        if (!status) {
            alert(msg)
            if (elem === 'addrDtl') {
                addrRef3.current.focus()
                return
            }
            return
        }

        if (!confirm('수정하시겠습니까?')) return

        updateMypage.isReady && updateMypage.call()
    }

    useEffect(() => {
        if (window.ReactNativeWebView) setIsRNWebview(true)
    }, [])

    return (
        <>
            <main id="container" className="container mypage parents-form">
                <div className="wrap">
                    <div className="content-area">
                        <div className="desc-area">
                            <p className="desc1">보호자 정보를 적어주세요</p>
                        </div>
                        <div className="content">
                            <LabelInputWithButton
                                customClass={'phone'}
                                id={'phone'}
                                isRequire={true}
                                title={'휴대폰'}
                                placeholder={'인증해 주세요.'}
                                isDisabled={true}
                                value={selectMypageRes.phone}
                                btnClass={'certification'}
                                btnTitle={'인증하기'}
                                desc={desc}
                                clickHandler={openNice}
                            />
                            <LabelInput
                                id={'userName'}
                                title={'보호자 이름'}
                                isRequire={true}
                                type={'text'}
                                placeholder={'인증해 주세요.'}
                                value={selectMypageRes.userName}
                                isReadOnly={true}
                                isDisabled={true}
                                inputClass={'disabled'}
                            />
                            <AddrInput
                                id1={'zipCode'}
                                id2={'addr'}
                                id3={'addrDtl'}
                                isRequire={true}
                                value1={selectMypageRes.zipCode}
                                value2={selectMypageRes.addr}
                                value3={selectMypageRes.addrDtl}
                                inputRef3={addrRef3}
                                openAddr={openAddr}
                                changeHandler={addrChangeHandler}
                                isDisabled={true}
                                isReadOnly={true}
                                inputClass={'disabled'}
                            />
                            <NiceForm niceFormRef={niceFormRef} niceEncRef={niceEncRef} niceBtnRef={niceBtnRef}
                                      duplCheck={true} setState={setSelectMypageRes}/>
                            <DaumAddrMo isEmbedVisible={isEmbedVisible} fOnComplete={fOnComplete}
                                        fCloseLayer={fCloseLayer}/>
                            <div className="withdrawal-area">
                                <div className="withdrawal btn" onClick={() => router.push('withdrawal')}>회원탈퇴</div>
                            </div>
                            <div className="btn-area">
                                <div className="btn" onClick={() => router.back()}>취소</div>
                                <div className="btn active" onClick={update}>수정하기</div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <NavFooter/>
        </>
    )
}

ChangePaInfo.title = '보호자 정보 변경'

export default ChangePaInfo
