import LabelInput from "@/components/commons/LabelInput";
import LabelRadio from "@/components/commons/LabelRadio";
import {useRouter} from "next/router";
import {useEffect, useState} from "react";
import {imgToBase64, numberFormat, setParam} from "@/utils/Libs/Methods/commonUtils";
import {changeChildValidate} from "@/utils/Libs/Methods/userValidate";
import ChildImage from "@/components/front/mypage/ChildImage";
import {useCallApi} from "@/utils/Query/customApi";
import LabelSelect from "@/components/commons/LabelSelect";

const RegChild = () => {
    const router = useRouter()
    const [addChild, setAddChild] = useState({
        childName: '',
        birthday: '',
        genderCd: '',
        itemCd: '',
        hospitalNm: '',
        doctorNm: '',
        injVol: 0,
        childFile: ''
    })

    const items = [
        {value: '', text: '카트리지를 선택해 주세요.'},
        {value: '40', text: '카트리지 20IU'},
        {value: '50', text: '카트리지 30IU'},
    ]

    const [selectHospitalComboRes, setSelectHospitalComboRes] = useState([])
    const selectHospitalComboObj = {
        url: '/api/extra/CommonController/selectHospitalCombo',
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectHospitalComboRes([])
                return
            }

            let tempRes = [
                {value: '', text: '병원을 선택해 주세요.'}
            ]

            data.forEach((hospital) => {
                tempRes.push({value: hospital.hospitalNm, text: hospital.hospitalNm})
            })

            setSelectHospitalComboRes(tempRes)
        }
    }
    const selectHospitalCombo = useCallApi(selectHospitalComboObj)

    useEffect(() => {
        selectHospitalCombo.isReady && selectHospitalCombo.call()
    }, [])

    // 자녀 추가
    const insertMyChildObj = {
        url: '/api/user/ChildController/insertMyChild',
        param: addChild,
        onSuccess: (data) => {
            alert('자녀 추가에 성공하였습니다.')
            router.replace('manageFaInfo')
        }
    }
    const insertMyChild = useCallApi(insertMyChildObj)

    const changeAddChild = (target, e) => {
        setParam(setAddChild, {[target]: e.target.value})
    }

    const itemChange = (id, e) => {
        setParam(setAddChild, {[id]: e.target.value})
    }

    const volChange = (id, e) => {
        const value = numberFormat(Number(e.target.value), 2, 1)

        if(value !== false) {
            setParam(setAddChild, {[id]: value.toString()})
        }
    }

    const saveChild = () => {
        const {status, msg, elem} = changeChildValidate(addChild)

        if(!status) {
            alert(msg)
            return
        }

        if(!confirm('자녀를 추가하시겠습니까?')) return

        insertMyChild.isReady && insertMyChild.call()
    }

    const upLoad = (e) => {
        let file = document.getElementById('file')

        imgToBase64(file).then((src) => {
            setParam(setAddChild, {childFile: src})
        }).catch((e) => {
            alert(e)
        })
    }

    const imageDelete = (e) => {
        e.preventDefault()

        let file = document.getElementById('file')
        file.value = ''
        setParam(setAddChild, {childFile: ''})
    }

    return (
        <main id="container" className="container mypage child-form">
            <div className="wrap">
                <div className="content-area">
                    <div className="desc-area">
                        <p className="desc1">아이 정보를 적어주세요.</p>
                    </div>
                    <div className="content">
                        <ChildImage imageSrc={addChild.childFile} changeHandler={upLoad} imageDelete={imageDelete}/>
                        <LabelInput id={'childName'} title={'아이 이름'} isRequire={true} type={'text'} placeholder={'아이 이름을 입력해 주세요.'} value={addChild.childName} changeHandler={changeAddChild}/>
                        <LabelInput id={'birthday'} title={'아이 생년월일'} isRequire={true} type={'date'} value={addChild.birthday} changeHandler={changeAddChild}/>
                        <div className="form-item">
                            <label htmlFor="childSex" className="tit">아이 성별<span className="require">*</span></label>
                            <div className="radio-section">
                                <LabelRadio id={'childSexMan'} name={'genderCd'} value={'M'} checked={addChild.genderCd === 'M'} labelTitle={'남자'} changeHandler={changeAddChild}/>
                                <LabelRadio id={'childSexFemale'} name={'genderCd'} value={'F'} checked={addChild.genderCd === 'F'} labelTitle={'여자'} changeHandler={changeAddChild}/>
                            </div>
                        </div>
                        <LabelSelect customClass={'itemCd'} id={'itemCd'} title={'카트리지'} value={addChild.itemCd} changeHandler={itemChange} datas={items}/>
                        <LabelSelect customClass={'hospitalNm'} id={'hospitalNm'} title={'병원명'} value={addChild.hospitalNm} changeHandler={changeAddChild} datas={selectHospitalComboRes}/>
                        <LabelInput title={'의사명'} id={'doctorNm'} type={'text'} value={addChild.doctorNm} placeholder={'의사명을 입력해 주세요.'} changeHandler={changeAddChild}/>
                        <LabelInput id={'injVol'} type={'number'} title={'주사 용량'} value={addChild.injVol} changeHandler={volChange}/>
                        <div className="btn-area">
                            <div className="btn" onClick={() => router.back()}>취소</div>
                            <div className="btn active" onClick={saveChild}>추가하기</div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}

RegChild.title = '자녀 추가'

export default RegChild
