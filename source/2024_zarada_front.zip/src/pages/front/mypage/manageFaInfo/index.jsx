import {useRouter} from "next/router";
import NavFooter from "@/components/front/commons/NavFooter";
import {useRecoilState} from "recoil";
import {useEffect, useState} from "react";
import ChildList from "@/components/front/mypage/ChildList";
import {recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";

const ManageFaInfo = () => {
    const router = useRouter()
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [mounted, setMounted] = useState(false)

    // 자녀목록 조회
    const [selectMyChildListRes, setSelectMyChildListRes] = useState([])
    const selectMyChildListObj = {
        url: '/api/user/ChildController/selectMyChildList',
        param: {
            userSeq: rUser.userSeq,
        },
        onSuccess: (data) => {
            if(!data[0]) {
                setSelectMyChildListRes([])
                return
            }

            setSelectMyChildListRes(data)
        }
    }
    const selectMyChildList = useCallApi(selectMyChildListObj)

    useEffect(() => {
        setMounted(true)
        selectMyChildList.isReady && selectMyChildList.call()
    }, [])

    const moveChildDetail = (childSeq) => {
        router.push({
            pathname: 'modiChild',
            query: {childSeq}
        })
    }

    return(
        <>
            <main id="container" className="container mypage family-list">
                <div className="wrap">
                    <div className="content-area">
                        <div className="parents-area">
                            <div className="type">보호자</div>
                            <div className="nameid">
                            {
                                mounted ? 
                                <>{rUser.userName}<span>{`(${rUser.userId})`}</span></>
                                : <></>
                            }
                            </div>
                            <div className="update btn" onClick={() => router.push('changePaInfo')}>보호자 정보 수정</div>
                        </div>
                        <ChildList selectMyChildListRes={selectMyChildListRes} moveChildDetail={moveChildDetail}/>
                        <div className="btn-area">
                            <div className="btn" onClick={() => router.push('regChild')}>+ 자녀추가</div>
                        </div>
                    </div>
                </div>
            </main>
            <NavFooter />
        </>
    )
}

ManageFaInfo.title = '가족 관리'

export default ManageFaInfo