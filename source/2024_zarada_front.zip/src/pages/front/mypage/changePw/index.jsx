import NavFooter from "@/components/front/commons/NavFooter";
import LabelInput from "@/components/commons/LabelInput";
import {useRouter} from "next/router";
import {useEffect, useRef, useState} from "react";
import {setParam} from "@/utils/Libs/Methods/commonUtils";
import {useRecoilState} from "recoil";
import {changePwValidate} from "@/utils/Libs/Methods/userValidate";
import {removeAccessToken} from "@/utils/Libs/Methods/authToken";
import {recoilUser} from "@/utils/Store/atom";
import {useCallApi} from "@/utils/Query/customApi";

const ChangePw = () => {
    const router = useRouter()
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [pwInfo, setPwInfo] = useState({
        userSeq: rUser.userSeq,
        newPw: '',
        newPw2: '',
        userPw: '',
    })
    const [newPwChk, setnewPwChk] = useState(0);
    const [newPw2Chk, setnewPw2Chk] = useState(-1);

    const userPwRef = useRef(null);
    const newPwRef = useRef(null);
    const newPw2Ref = useRef(null);

    const desc = [
        {descClass: 'desc', descTitle: '영문, 숫자 8자리 이상 입력해 주세요. 특수문자는 사용불가입니다.'},
        {descClass: 'noti danger', descTitle: '8자리 이상 16자리 이하여야 합니다.'},
        {descClass: 'noti confirm', descTitle: '알맞은 비밀번호입니다.'},
        {descClass: 'noti danger', descTitle: '특수문자는 사용불가입니다.'},
    ]

    const desc2 = [
        {descClass: 'noti danger', descTitle: '비밀번호가 일치하지 않습니다.'},
        {descClass: 'noti confirm', descTitle: '비밀번호가 일치합니다.'},
    ]

    // 비밀번호 변경 성공 시 로그아웃
    const logoutObj = {
        url: '/api/user/LoginController/logout',
        param: {},
        onSuccess: (data) => {
            removeAccessToken();
            window.location.href = window.location.origin;
        }
    }
    const logout = useCallApi(logoutObj)

    // 비밀번호 변경
    const updateUserPwFromMypageObj = {
        url: '/api/user/MypageController/updateUserPwFromMypage',
        param: pwInfo,
        onSuccess: (data) => {
            alert('비밀번호 변경에 성공하였습니다. 다시 로그인해 주세요.')
            logout.isReady && logout.call()
        }
    }
    const updateUserPwFromMypage = useCallApi(updateUserPwFromMypageObj)

    const pwInfoChange = (id, e) => {
        setParam(setPwInfo, {[id]: e.target.value})
    }

    const changePw = () => {
        const {status, msg, elem} = changePwValidate(pwInfo, newPwChk, newPw2Chk)

        if(!status) {
            alert(msg)
            switch (elem) {
                case 'userPw':
                    userPwRef.current.focus()
                    return
                case 'newPw':
                    newPwRef.current.focus()
                    return
                case 'newPw2':
                    newPw2Ref.current.focus()
                    return
            }
        }

        if(!confirm('비밀번호를 변경하시겠습니까?')) return

        updateUserPwFromMypage.isReady && updateUserPwFromMypage.call()
    }

    useEffect(() => {
        const pwPattern1 = /^.{8,16}$/;
        const pwPattern2 = /^[a-zA-Z0-9]+$/;

        // pw
        if(pwInfo.newPw === '') {
            setnewPwChk(0);
        } else if(!pwPattern1.test(pwInfo.newPw)) {
            setnewPwChk(1);
        } else if(pwPattern2.test(pwInfo.newPw)) {
            setnewPwChk(2);
        } else {
            setnewPwChk(3);
        }

        // pw2
        if(pwInfo.newPw !== '' && pwInfo.newPw2 !== '' && (pwInfo.newPw === pwInfo.newPw2)) {
            setnewPw2Chk(1);
        } else if(pwInfo.newPw === '' && pwInfo.newPw2 === '') {
            setnewPw2Chk(-1);
        } else {
            setnewPw2Chk(0);
        }
    }, [pwInfo]);

    return(
        <>
            <main id="container" className="container mypage password-form">
                <div className="wrap">
                    <div className="content-area">
                        <div className="desc-area">
                            <p className="desc1">신규 비밀번호를 적어주세요</p>
                        </div>
                        <div className="content">
                            <LabelInput title={'현재 비밀번호'} id={'userPw'} isRequire={true} type={'password'} value={pwInfo.userPw} placeholder={'현재 비밀번호를 입력해 주세요.'} changeHandler={pwInfoChange} inputRef={userPwRef}/>
                            <LabelInput title={'신규 비밀번호'} id={'newPw'} isRequire={true} type={'password'} value={pwInfo.newPw} placeholder={'비밀번호는 변경을 원할 경우만 입력해 주세요.'} changeHandler={pwInfoChange} desc={desc[newPwChk]} inputRef={newPwRef}/>
                            <LabelInput title={'신규 비밀번호 확인'} id={'newPw2'} isRequire={true} type={'password'} value={pwInfo.newPw2} placeholder={'비밀번호를 한번 더 입력해 주세요.'} changeHandler={pwInfoChange} desc={desc2[newPw2Chk]} inputRef={newPw2Ref}/>
                            <div className="btn-area">
                                <div className="btn" onClick={() => router.back()}>취소</div>
                                <div className="btn active" onClick={changePw}>수정하기</div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <NavFooter />
        </>
    )
}

ChangePw.title = '비밀번호 변경'

export default ChangePw
