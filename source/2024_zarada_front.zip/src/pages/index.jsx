import {useEffect, useState} from "react";
import {useRouter} from "next/router";
import {useRecoilState} from "recoil";
import {recoilChild, recoilUser} from "@/utils/Store/atom";
import {setAccessToken} from "@/utils/Libs/Methods/authToken";
import {useCallApi} from "@/utils/Query/customApi";
import {loginValidate} from "@/utils/Libs/Methods/userValidate";

const Index = () => {
    const router = useRouter()


    const [id, setId] = useState('')
    const [pw, setPw] = useState('')
    const [autoLoginYn, setAutoLoginYn] = useState('N')
    const [rUser, setRUser] = useRecoilState(recoilUser)
    const [rChild, setRChild] = useRecoilState(recoilChild)

    // 로그인, 자동로그인 성공 시 실행 함수
    const loginSuccess = (data) => {
        if(!data[0]) {
            return
        }

        window.sessionStorage.setItem('login', true)

        const {userSeq, userId, role, userName, birthday, appStatCd, childSeq, injVol, itemCd} = data[0]

        // 10: 미승인, 20: 승인 30: 승인 취소 40: 차단
        if(role === 'ROLE_USER' && appStatCd === '10') {
            alert('관리자 승인 후 로그인 가능합니다.')
            return
        }

        if(role === 'ROLE_USER' && (appStatCd === '30' || appStatCd === '40')) {
            alert('로그인 불가 계정입니다. 관리자에게 문의해 주세요.')
            return
        }

        // 정상 로그인
        // 토큰 세팅
        setAccessToken(data[0].accessToken)
        setRUser({userSeq, userId, role, userName})
        setRChild({childSeq, injVol, itemCd, birthday})

        // RN으로 쿠키 세팅 호출 및 웹 로딩 완료 호출
        if(window.ReactNativeWebView) {
            const msgTypeCookie = 'SET_ANDROID_COOKIE'
            const msgTypeOnLoad = 'WEBVIEW_ONLOAD'

            window.ReactNativeWebView.postMessage(JSON.stringify({ msgType: msgTypeCookie }));
            window.ReactNativeWebView.postMessage(JSON.stringify({ msgType: msgTypeOnLoad }));
        }


        // role에 따른 사용자 / 관리자 메뉴 이동
        if(role === '') {
            alert('권한 오류입니다. 관리자에게 문의해 주세요.')
        } else if(role === 'ROLE_USER') {
            router.push('/front/main')
        } else {
            router.push('/controlroom/users')
        }
    }

    // 로그인
    const loginObj = {
        url: '/api/extra/LoginController/login',
        param: {
            id,
            pw,
            autoLogin: autoLoginYn,
        },
        onSuccess: (data) => {
            loginSuccess(data)
        },
    }

    const login = useCallApi(loginObj)

    // 자동 로그인
    const autoLoginObj = {
        url: '/api/extra/LoginController/autoLogin',
        param: {},
        onSuccess: (data) => {
            loginSuccess(data)
        },
    }
    const autoLogin = useCallApi(autoLoginObj)

    useEffect(() => {
        //     최초 접속 시 자동로그인 호출
        autoLogin.isReady && autoLogin.call();
    }, [])

    const setValue = (e, flag) => {
        if(flag === 'id') {
            setId(e.target.value)
            return
        }

        setPw(e.target.value)
    }

    const loginClick = () => {
        const {status, msg} = loginValidate(id, pw)

        if(!status) {
            alert(msg)
            return
        }
        login.isReady && login.call();
    }

    const autoLoginClick = (e) => {
        setAutoLoginYn(e.target.checked ? 'Y' : 'N')
    }

    return (
        <main id="container" className="container login">
            <div className="wrap">
                <div className="mascot-section">
                    <div className="mascot">
                        <div className="img img1"><img src="/img/login_mascot_img.png" alt="마스코드"/></div>
                    </div>
                </div>
                <div className="content-section">
                    <div className="content">
                        <div className="logo">
                            <div className="img"><img src="/img/login_logo.png" alt="자라다"/></div>
                        </div>
                        <p className="desc">성장 주사관리를 위한 앱</p>
                        <div className="input-section">
                            <div className="input-area">
                                <div className="input-text">
                                    <input type="text" placeholder="아이디" onChange={(e) => setValue(e, 'id')}/>
                                </div>
                            </div>

                            <div className="input-area">
                                <div className="input-text">
                                    <input type="password" placeholder="비밀번호" onChange={(e) => setValue(e, 'pw')}/>
                                </div>
                            </div>
                        </div>
                        <div className="option-area">
                            <div className="checkbox-area">
                                <div className="input-checkbox"><input type="checkbox" id="loginMaintain"
                                                                       name="loginMaintain"
                                                                       onClick={(e) => autoLoginClick(e)}/></div>
                                <label htmlFor="loginMaintain">로그인 상태 유지</label>
                            </div>
                        </div>
                        <div className="btn-area">
                            <div className="btn" onClick={loginClick}>로그인</div>
                        </div>
                        <div className="sub-area">
                            <div className="txt btn"
                                 onClick={() => router.push({pathname: 'front/find', query: {cate: 'id'}})}>아이디 찾기
                            </div>
                            <div className="txt btn"
                                 onClick={() => router.push({pathname: 'front/find', query: {cate: 'pw'}})}>비밀번호 재설정
                            </div>
                            <div className="txt btn" onClick={() => router.push('front/join')}>회원 가입</div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    )
}

Index.layoutType = 'front'
Index.fullpageType = true
export default Index
