# 개요

동아ST ZARADA 앱 고도화 프로젝트 Backend (Spring Boot)

### 세트 프로젝트

- zarada_back
- zarada_front
- zarada_rn

# 실행

IntelliJ
1. Reload All Gradle Project
2. 실행
