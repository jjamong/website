package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqUpdateMypageDTO;
import com.dai.zarada_back.dto.request.ReqUpdateUserPwFromMypageDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectMypageDTO;

import java.util.List;

public interface MypageService {
    List<ResSelectMypageDTO> selectMypage(ReqDummyDTO dto);

    List<ResCountDTO> updateMypage(ReqUpdateMypageDTO dto);

    List<ResCountDTO> updateUserPwFromMypage(ReqUpdateUserPwFromMypageDTO dto);
}
