package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "JWT Test Request DTO")
public class ReqJwtTestDTO extends ReqLoginInfoDTO {
    @Schema(description = "비밀번호")
    private String password;

    @Schema(description = "테스트 구분 (\"C\" / \"V\" / \"G\")")
    private String dvsn;

    @Schema(description = "토큰")
    private String token;

    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')")
    private String role;

    @Schema(description = "자동로그인 여부")
    private String autoLogin;
}
