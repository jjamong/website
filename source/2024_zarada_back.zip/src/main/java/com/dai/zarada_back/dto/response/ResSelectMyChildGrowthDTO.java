package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = " Response DTO")
public class ResSelectMyChildGrowthDTO {
    @Schema(description = "자녀 성장 기록 SEQ")
    private long growthSeq;

    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "신장")
    private float childHeight;

    @Schema(description = "체중")
    private float childWeight;

    @Schema(description = "BMI")
    private float childBmi;

    @Schema(description = "기록 코멘트")
    private String recordComment;

    @Schema(description = "최초 투여일로부터 일자")
    private String injDays;

    @Schema(description = "나이")
    private int age;

    @Schema(description = "개월수")
    private int month;

    @Schema(description = "성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String genderCd;

    @Schema(description = "신장 퍼센트")
    private float childHeightPercent;

    @Schema(description = "체중 퍼센트")
    private float childWeightPercent;

    @Schema(description = "BMI 퍼센트")
    private float childBmiPercent;
}
