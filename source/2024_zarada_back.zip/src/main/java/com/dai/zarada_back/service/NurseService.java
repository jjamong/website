package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseListDTO;

import java.util.List;

public interface NurseService {
    List<ResCountDTO> selectNurseListCount(ReqDummyDTO dto);

    List<ResSelectNurseListDTO> selectNurseList(ReqSelectNurseListDTO dto);

    List<ResSelectNurseDetailDTO> selectNurseDetail(ReqSelectNurseDetailDTO dto);

    List<ResCountDTO> insertNurse(ReqInsertNurseDTO dto);

    List<ResCountDTO> updateNurse(ReqUpdateNurseDTO dto);

    List<ResCountDTO> deleteNurse(ReqDeleteNurseDTO dto);
}
