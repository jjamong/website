package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "FCM Test Request DTO")
public class ReqFcmTestDTO extends ReqLoginInfoDTO {
    @Schema(description = "비밀번호")
    private String password;

    @Schema(description = "FCM Token")
    private String fcmToken;

    @Schema(description = "알림 제목")
    private String title;

    @Schema(description = "알림 내용")
    private String body;

    @Schema(description = "URL")
    private String moveUrl;
}
