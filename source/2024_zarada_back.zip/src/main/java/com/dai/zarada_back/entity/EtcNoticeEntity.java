package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class EtcNoticeEntity {
    private long noticeSeq;
    private String noticeTitle;
    private String noticeContent;
    private String topYn;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
    private String writeDy;
    private String writeTm;
}
