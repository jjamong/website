package com.dai.zarada_back.vo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ResponseResultFlag {
    SUCCESS(true, "S", "SUCCESS"),
    FAILURE(false, "F", "FAILURE");

    private final boolean status;
    private final String code;
    private final String msg;
}
