package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqNiceDecryptDTO;
import com.dai.zarada_back.dto.request.ReqNiceEncryptDTO;
import com.dai.zarada_back.dto.response.ResNiceDecryptDTO;
import com.dai.zarada_back.dto.response.ResNiceEncryptDTO;
import com.dai.zarada_back.service.NiceService;
import com.dai.zarada_back.util.DAException;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NiceServiceImpl implements NiceService {
    private final String NICE_SITE_CODE = "BY659"; // NICE로부터 부여받은 사이트 코드
    private final String NICE_SITE_PASSWORD = "OdPE3paEDAFD"; // NICE로부터 부여받은 사이트 패스워드

    @Override
    public List<ResNiceEncryptDTO> niceEncrypt(ReqNiceEncryptDTO dto, HttpServletResponse httpServletResponse) {
        // libs/NiceID_v1.1.jar 모듈사용
        NiceID.Check.CPClient niceCheck = new NiceID.Check.CPClient();

        String sRequestNumber = niceCheck.getRequestNO(this.NICE_SITE_CODE);
        String sAuthType = ""; // 없으면 기본 선택화면, M(휴대폰), X(인증서공통), U(공동인증서), F(금융인증서), S(PASS인증서), C(신용카드)
        String sReturnUrl = dto.getReturnUrl() == null ? "" : dto.getReturnUrl(); // 성공시 이동될 URL
        String sErrorUrl = dto.getErrorUrl() == null ? "" : dto.getErrorUrl(); // 실패시 이동될 URL
        String customize = ""; // 없으면 기본 웹페이지 / Mobile : 모바일페이지

        httpServletResponse.setContentType("application/x-www-form-urlencoded");
        httpServletResponse.setCharacterEncoding("UTF-8");

        String sPlainData = "7:REQ_SEQ" + sRequestNumber.getBytes().length + ":" + sRequestNumber +
                "8:SITECODE" + this.NICE_SITE_CODE.getBytes().length + ":" + this.NICE_SITE_CODE +
                "9:AUTH_TYPE" + sAuthType.getBytes().length + ":" + sAuthType +
                "7:RTN_URL" + sReturnUrl.getBytes().length + ":" + sReturnUrl +
                "7:ERR_URL" + sErrorUrl.getBytes().length + ":" + sErrorUrl +
                "9:CUSTOMIZE" + customize.getBytes().length + ":" + customize;

        String sEncData = "";

        int iNiceCode = niceCheck.fnEncode(this.NICE_SITE_CODE, this.NICE_SITE_PASSWORD, sPlainData);

        if (iNiceCode == 0) {
            sEncData = niceCheck.getCipherData();
        } else if (iNiceCode == -1) {
            throw new DAException("암호화 시스템 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -2) {
            throw new DAException(iNiceCode + "암호화 처리오류입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -3) {
            throw new DAException(iNiceCode + "암호화 데이터 오류입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -9) {
            throw new DAException(iNiceCode + "입력 데이터 오류입니다.\r\ncode: " + iNiceCode);
        } else {
            throw new DAException(iNiceCode + "알수 없는 에러 입니다.\r\ncode: " + iNiceCode);
        }

        ResNiceEncryptDTO resultDTO = new ResNiceEncryptDTO();
        resultDTO.setEncData(sEncData);

        List<ResNiceEncryptDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResNiceDecryptDTO> niceDecrypt(ReqNiceDecryptDTO dto) {
        // libs/NiceID_v1.1.jar 모듈사용
        NiceID.Check.CPClient niceCheck = new NiceID.Check.CPClient();

        String sEncData = this.requestReplace(dto.getEncData() == null ? "" : dto.getEncData(), "encData");
        String sCipherTime = ""; // 복호화한 시간
        String sRequestNumber = ""; // 요청 번호
        String sResponseNumber = ""; // 인증 고유번호
        String sAuthType = ""; // 인증 수단
        String sName = ""; // 성명
        String sDupInfo = ""; // 중복가입 확인값 (DI_64 byte)
        String sConnInfo = ""; // 연계정보 확인값 (CI_88 byte)
        String sBirthDate = ""; // 생년월일(YYYYMMDD)
        String sGender = ""; // 성별
        String sNationalInfo = ""; // 내/외국인정보 (개발가이드 참조)
        String sMobileNo = ""; // 휴대폰번호
        String sMobileCo = ""; // 통신사
        String sPlainData = "";


        int iNiceCode = niceCheck.fnDecode(this.NICE_SITE_CODE, this.NICE_SITE_PASSWORD, sEncData);

        if (iNiceCode == 0) {
            sPlainData = niceCheck.getPlainData();
            sCipherTime = niceCheck.getCipherDateTime();

            // 데이터 추출
            java.util.HashMap mapresult = niceCheck.fnParse(sPlainData);
            sRequestNumber = (String) mapresult.get("REQ_SEQ");
            sResponseNumber = (String) mapresult.get("RES_SEQ");
            sAuthType = (String) mapresult.get("AUTH_TYPE");
            sName = (String) mapresult.get("NAME");
            // sName = (String)mapresult.get("UTF8_NAME"); //charset utf8 사용시 주석 해제 후 사용
            sBirthDate = (String) mapresult.get("BIRTHDATE");
            sGender = (String) mapresult.get("GENDER");
            sNationalInfo = (String) mapresult.get("NATIONALINFO");
            sDupInfo = (String) mapresult.get("DI");
            sConnInfo = (String) mapresult.get("CI");
            sMobileNo = (String) mapresult.get("MOBILE_NO");
            sMobileCo = (String) mapresult.get("MOBILE_CO");
        } else if (iNiceCode == -1) {
            throw new DAException(iNiceCode + "복호화 시스템 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -4) {
            throw new DAException(iNiceCode + "복호화 처리 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -5) {
            throw new DAException(iNiceCode + "복호화 해쉬 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -6) {
            throw new DAException(iNiceCode + "복호화 데이터 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -9) {
            throw new DAException(iNiceCode + "입력 에러입니다.\r\ncode: " + iNiceCode);
        } else if (iNiceCode == -12) {
            throw new DAException(iNiceCode + "사이트 패스워드 오류입니다.\r\ncode: " + iNiceCode);
        } else {
            throw new DAException(iNiceCode + "알수 없는 에러 입니다.\r\ncode: " + iNiceCode);
        }

        ResNiceDecryptDTO resultDTO = new ResNiceDecryptDTO();
        resultDTO.setCipherTime(sCipherTime);
        resultDTO.setRequestNumber(sRequestNumber);
        resultDTO.setResponseNumber(sResponseNumber);
        resultDTO.setAuthType(sAuthType);
        resultDTO.setName(sName);
        resultDTO.setDupInfo(sDupInfo);
        resultDTO.setConnInfo(sConnInfo);
        resultDTO.setBirthDate(sBirthDate);
        resultDTO.setGender(sGender);
        resultDTO.setNationalInfo(sNationalInfo);
        resultDTO.setMobileCo(sMobileCo);
        resultDTO.setMobileNo(sMobileNo);

        List<ResNiceDecryptDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    private String requestReplace(String paramValue, String gubun) {
        String result = "";

        if (paramValue != null) {
            paramValue = paramValue.replaceAll("<", "&lt;").replaceAll(">", "&gt;");

            paramValue = paramValue.replaceAll("\\*", "");
            paramValue = paramValue.replaceAll("\\?", "");
            paramValue = paramValue.replaceAll("\\[", "");
            paramValue = paramValue.replaceAll("\\{", "");
            paramValue = paramValue.replaceAll("\\(", "");
            paramValue = paramValue.replaceAll("\\)", "");
            paramValue = paramValue.replaceAll("\\^", "");
            paramValue = paramValue.replaceAll("\\$", "");
            paramValue = paramValue.replaceAll("'", "");
            paramValue = paramValue.replaceAll("@", "");
            paramValue = paramValue.replaceAll("%", "");
            paramValue = paramValue.replaceAll(";", "");
            paramValue = paramValue.replaceAll(":", "");
            paramValue = paramValue.replaceAll("-", "");
            paramValue = paramValue.replaceAll("#", "");
            paramValue = paramValue.replaceAll("--", "");
            paramValue = paramValue.replaceAll("-", "");
            paramValue = paramValue.replaceAll(",", "");

            if (!"encData".equals(gubun)) {
                paramValue = paramValue.replaceAll("\\+", "");
                paramValue = paramValue.replaceAll("/", "");
                paramValue = paramValue.replaceAll("=", "");
            }

            result = paramValue;
        }

        return result;
    }
}
