package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqLoginDTO;
import com.dai.zarada_back.dto.request.ReqUpdateFcmTokenDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResLoginDTO;
import com.dai.zarada_back.dto.response.ResReissueDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public interface LoginService {
    List<ResLoginDTO> login(ReqLoginDTO dto, HttpServletResponse httpServletResponse);

    List<ResLoginDTO> autoLogin(ReqDummyDTO dto, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse);

    List<ResReissueDTO> reissue(ReqDummyDTO dto, HttpServletRequest httpServletRequest);

    List<ResCountDTO> logout(ReqDummyDTO dto, HttpServletResponse httpServletResponse);

    List<ResCountDTO> updateFcmToken(ReqUpdateFcmTokenDTO dto);
}
