package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.*;
import com.dai.zarada_back.service.GrowthService;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class GrowthController {
    private final DaiHelper daiHelper;
    private final GrowthService growthService;

    @Tag(name = "600.Growth", description = "성장 기록 API")
    @Operation(
            summary = "성장 기록 조회",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResSelectMyChildGrowthDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/GrowthController/selectMyChildGrowth")
    public ResponseEntity<ResCommonDTO<Object>> selectMyChildGrowth(@RequestBody ReqSelectMyChildGrowthDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResSelectMyChildGrowthDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = growthService.selectMyChildGrowth(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "600.Growth", description = "성장 기록 API")
    @Operation(
            summary = "성장 기록 저장",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/GrowthController/saveMyChildGrowth")
    public ResponseEntity<ResCommonDTO<Object>> saveMyChildGrowth(@RequestBody ReqSaveMyChildGrowthDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = growthService.saveMyChildGrowth(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "600.Growth", description = "성장 기록 API")
    @Operation(
            summary = "성장 기록 삭제",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/GrowthController/deleteMyChildGrowth")
    public ResponseEntity<ResCommonDTO<Object>> deleteMyChildGrowth(@RequestBody ReqDeleteMyChildGrowthDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = growthService.deleteMyChildGrowth(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "600.Growth", description = "성장 기록 API")
    @Operation(
            summary = "성장 도표 조회",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResSelectGrowthChartDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/GrowthController/selectGrowthChart")
    public ResponseEntity<ResCommonDTO<Object>> selectGrowthChart(@RequestBody ReqSelectGrowthChartDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResSelectGrowthChartDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = growthService.selectGrowthChart(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }
}
