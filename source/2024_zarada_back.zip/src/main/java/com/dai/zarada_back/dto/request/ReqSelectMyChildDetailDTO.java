package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "내 자녀 정보 상세 조회 Request DTO")
public class ReqSelectMyChildDetailDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀정보 SEQ")
    private long childSeq;
}
