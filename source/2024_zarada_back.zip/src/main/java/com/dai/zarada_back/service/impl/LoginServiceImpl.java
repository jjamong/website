package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqLoginDTO;
import com.dai.zarada_back.dto.request.ReqUpdateFcmTokenDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResLoginDTO;
import com.dai.zarada_back.dto.response.ResReissueDTO;
import com.dai.zarada_back.entity.ChlChildEntity;
import com.dai.zarada_back.entity.UsrUserEntity;
import com.dai.zarada_back.mapper.ChlChildMapper;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.LoginService;
import com.dai.zarada_back.util.*;
import com.dai.zarada_back.vo.JwtResultType;
import com.dai.zarada_back.vo.MessageCode;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {
    private final UsrUserMapper usrUserMapper;
    private final ChlChildMapper chlChildMapper;
    private final AriaUtil ariaUtil;
    private final JwtUtil jwtUtil;
    private final RedisUtil redisUtil;
    private final CookieUtil cookieUtil;

    @Override
    public List<ResLoginDTO> login(ReqLoginDTO dto, HttpServletResponse httpServletResponse) {
        /* 아이디와 비밀번호로 회원정보 테이블 조회 */
        String id = DaiHelper.nullToEmptyStr(dto.getId());
        String pw = DaiHelper.nullToEmptyStr(dto.getPw());

        if (id.isEmpty() || pw.isEmpty())
            throw new DAException(MessageCode.MSG_0002.getMessage());

        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("userId", id);
        inputSelectUsrUserData.put("userPw", ariaUtil.encrypt(pw));
        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        if (usrUserEntityList.isEmpty())
            throw new DAException(MessageCode.MSG_0003.getMessage());

        long userSeq = usrUserEntityList.get(0).getUserSeq();
        String userId = usrUserEntityList.get(0).getUserId();
        String userName = usrUserEntityList.get(0).getUserName();
        String appStatCd = usrUserEntityList.get(0).getAppStatCd();
        String role = usrUserEntityList.get(0).getRole();

        String autoLogin = DaiHelper.nullToEmptyStr(dto.getAutoLogin());
        autoLogin = autoLogin.isEmpty() ? "N" : autoLogin;

        /*
         * 로그인 성공시
         * 1. JWT 토큰 발급
         * 2. Redis 저장
         * 3. Cookie set
         */
        String refreshToken = jwtUtil.createRefreshToken(userSeq, userId, role, autoLogin);
        String accessToken = jwtUtil.createAccessToken(userSeq, userId, role, autoLogin);

        redisUtil.set(userId, refreshToken);

        Cookie createRefreshTokenCookie = cookieUtil.createCookie("refreshToken", refreshToken);
        httpServletResponse.addCookie(createRefreshTokenCookie);

        /* 로그인 로그 INSERT */
        Map<String, Object> inputInsertUsrLoginLogData = DaiHelper.createInputData(dto);
        inputInsertUsrLoginLogData.put("userSeq", userSeq);
        inputInsertUsrLoginLogData.put("userId", userId);
        usrUserMapper.insertUsrLoginlog(inputInsertUsrLoginLogData);

        /* 로그인 정보 set */
        ResLoginDTO resultDTO = new ResLoginDTO();
        resultDTO.setUserSeq(userSeq);
        resultDTO.setUserId(userId);
        resultDTO.setUserName(userName);
        resultDTO.setAppStatCd(appStatCd);
        resultDTO.setRole(role);
        resultDTO.setAccessToken(accessToken);

        /* 로그인 Response에 회원의 첫번째 자녀정보 추가 */
        Map<String, Object> inputSelectChlChildData = DaiHelper.createInputData(dto);
        inputSelectChlChildData.put("userSeq", userSeq);
        inputSelectChlChildData.put("delYn", "N");

        List<ChlChildEntity> chlChildEntityList = chlChildMapper.selectChlChild(inputSelectChlChildData);

        if (!chlChildEntityList.isEmpty()) {
            resultDTO.setChildSeq(chlChildEntityList.get(0).getChildSeq());
            resultDTO.setInjVol(chlChildEntityList.get(0).getInjVol());
            resultDTO.setItemCd(chlChildEntityList.get(0).getItemCd());
            resultDTO.setBirthday(chlChildEntityList.get(0).getBirthday());
        }

        List<ResLoginDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResLoginDTO> autoLogin(ReqDummyDTO dto, HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) {
        /* Refresh Token 확인 */
        String refreshToken = cookieUtil.getCookieValue("refreshToken", httpServletRequest);

        JwtResultType jwtResultType = jwtUtil.validationToken(refreshToken);

        if (jwtResultType != JwtResultType.VALID_JWT) {
            return new ArrayList<>();
        }

        String userId = jwtUtil.getTokenUserId(refreshToken);
        String autoLogin = jwtUtil.getTokenAutoLogin(refreshToken);

        /* Redis에 저장된 토큰과 비교, 자동 로그인 여부 확인 */
        String redisToken = DaiHelper.nullToEmptyStr(redisUtil.get(userId));

        if (!redisToken.equals(refreshToken) || !"Y".equals(autoLogin)) {
            return new ArrayList<>();
        }

        /* 로그인 정보 세팅 후 로그인 */
        long userSeq = jwtUtil.getTokenUserSeq(refreshToken);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        if (usrUserEntityList.isEmpty()) {
            return new ArrayList<>();
        }

        ReqLoginDTO reqLoginDTO = new ReqLoginDTO();
        reqLoginDTO.setId(usrUserEntityList.get(0).getUserId());
        reqLoginDTO.setPw(ariaUtil.decrypt(usrUserEntityList.get(0).getUserPw()));
        reqLoginDTO.setAutoLogin("Y");

        return this.login(reqLoginDTO, httpServletResponse);
    }

    @Override
    public List<ResReissueDTO> reissue(ReqDummyDTO dto, HttpServletRequest httpServletRequest) {
        /* Refresh Token 확인 */
        String refreshToken = cookieUtil.getCookieValue("refreshToken", httpServletRequest);

        JwtResultType jwtResultType = jwtUtil.validationToken(refreshToken);

        if (jwtResultType != JwtResultType.VALID_JWT)
            throw new DAException(MessageCode.MSG_0004.getMessage());

        long userSeq = jwtUtil.getTokenUserSeq(refreshToken);
        String userId = jwtUtil.getTokenUserId(refreshToken);
        String role = jwtUtil.getTokenRole(refreshToken);
        String autoLogin = jwtUtil.getTokenAutoLogin(refreshToken);

        /* Redis에 저장된 토큰과 비교 */
        String redisToken = DaiHelper.nullToEmptyStr(redisUtil.get(userId));

        if (!redisToken.equals(refreshToken))
            throw new DAException(MessageCode.MSG_0004.getMessage());

        /* Access Token 재발급 */
        String accessToken = jwtUtil.createAccessToken(userSeq, userId, role, autoLogin);

        ResReissueDTO resultDTO = new ResReissueDTO();
        resultDTO.setAccessToken(accessToken);

        List<ResReissueDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> logout(ReqDummyDTO dto, HttpServletResponse httpServletResponse) {
        int count = 0;

        /* FCM_TOKEN 삭제 */
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", dto.get_loginSeq());
        inputData.put("fcmToken", null);
        count += usrUserMapper.updateFcmToken(inputData);

        /* 쿠키 삭제 */
        Cookie cookie = cookieUtil.deleteCookie("refreshToken");
        httpServletResponse.addCookie(cookie);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateFcmToken(ReqUpdateFcmTokenDTO dto) {
        String fcmToken = dto.getFcmToken() == null ? "" : dto.getFcmToken();
        int count = 0;

        if (!fcmToken.isEmpty()) {
            Map<String, Object> inputData = DaiHelper.createInputData(dto);
            inputData.put("userSeq", dto.get_loginSeq());
            inputData.put("fcmToken", fcmToken);
            count += usrUserMapper.updateFcmToken(inputData);
        }

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
