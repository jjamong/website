package com.dai.zarada_back.scheduler;

import com.dai.zarada_back.entity.UserAlarmEntity;
import com.dai.zarada_back.mapper.ChlInjectionMapper;
import com.dai.zarada_back.service.FCMService;
import com.dai.zarada_back.util.DaiHelper;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Component
public class MainScheduler {
    private final FCMService fcmService;
    private final ChlInjectionMapper chlInjectionMapper;

    private static final Logger logger = LogManager.getLogger(MainScheduler.class);

    /**
     * 주사 알림 push
     */
    @Scheduled(cron = "0 * * * * *")
    public void injectionNotification() {
        logger.info("주사 알림 push START");

        LocalDateTime currentTime = LocalDateTime.now(); // 현재 시간
        DayOfWeek dayOfWeek = currentTime.getDayOfWeek(); // 현재 요일

        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");

        logger.info("dateFormat: " + currentTime.format(dateFormat));
        logger.info("timeFormat: " + currentTime.format(timeFormat));

        Map<String, Object> inputData = new HashMap<>();
        inputData.put("currentTime", currentTime.format(timeFormat));
        inputData.put("dayOfWeek", dayOfWeek.toString());

        List<UserAlarmEntity> userAlarmEntityList = chlInjectionMapper.selectUserAlarm(inputData);

        // 알림 push
        for (UserAlarmEntity userAlarmEntity : userAlarmEntityList) {
            String fcmToken = DaiHelper.nullToEmptyStr(userAlarmEntity.getFcmToken());

            if (!fcmToken.isEmpty()) {
                String body = userAlarmEntity.getChildName() + " 자녀의 주사 알림 입니다.";
                String moveUrl = "/front/injection/reg?injYmd=" + currentTime.format(dateFormat);
                fcmService.sendNotification(fcmToken, "자라다", body, moveUrl);
            }
        }
    }
}
