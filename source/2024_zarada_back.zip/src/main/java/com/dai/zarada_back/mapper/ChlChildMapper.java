package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.ChlChildEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ChlChildMapper {
    List<ChlChildEntity> selectChlChild(Object inputData);

    int insertChlChild(Object inputData);

    int updateChlChild(Object inputData);

    int deleteChlChild(Object inputData);

    int updateChildFromNurse(Object inputData);

    int updateChildFromUser(Object inputData);

    int updateChildDelYn(Object inputData);
}
