package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqLoginDTO;
import com.dai.zarada_back.dto.request.ReqUpdateFcmTokenDTO;
import com.dai.zarada_back.dto.response.*;
import com.dai.zarada_back.service.LoginService;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class LoginController {
    private final DaiHelper daiHelper;
    private final LoginService loginService;

    @Tag(name = "100.Login", description = "로그인 API")
    @Operation(
            summary = "로그인",
            description = """
                    로그인 테스트 계정
                                        
                    dauser / da1234!!
                                        
                    danurse / da1234!!
                                        
                    daadmin / da1234!!
                    """,
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResLoginDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/extra/LoginController/login")
    public ResponseEntity<ResCommonDTO<Object>> login(@RequestBody ReqLoginDTO dto, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResLoginDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = loginService.login(dto, httpServletResponse);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "100.Login", description = "로그인 API")
    @Operation(
            summary = "자동 로그인",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResLoginDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/extra/LoginController/autoLogin")
    public ResponseEntity<ResCommonDTO<Object>> autoLogin(@RequestBody ReqDummyDTO dto, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResLoginDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = loginService.autoLogin(dto, httpServletRequest, httpServletResponse);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "100.Login", description = "로그인 API")
    @Operation(
            summary = "토큰 재발급",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResReissueDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/extra/LoginController/reissue")
    public ResponseEntity<ResCommonDTO<Object>> reissue(@RequestBody ReqDummyDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResReissueDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = loginService.reissue(dto, httpServletRequest);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "100.Login", description = "로그인 API")
    @Operation(
            summary = "로그아웃",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/LoginController/logout")
    public ResponseEntity<ResCommonDTO<Object>> logout(@RequestBody ReqDummyDTO dto, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = loginService.logout(dto, httpServletResponse);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "100.Login", description = "로그인 API")
    @Operation(
            summary = "Update FCM Token",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/LoginController/updateFcmToken")
    public ResponseEntity<ResCommonDTO<Object>> updateFcmToken(@RequestBody ReqUpdateFcmTokenDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = loginService.updateFcmToken(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }
}
