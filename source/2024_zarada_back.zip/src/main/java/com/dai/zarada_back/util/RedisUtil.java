package com.dai.zarada_back.util;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

@Component
public class RedisUtil {
    private final RedisTemplate<String, String> redisTemplate;
    private final long REDIS_EXPIRATION = 14 * 24 * 60 * 60L;

    public RedisUtil(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /**
     * 전체 키 조회
     *
     * @return null: 오류
     */
    public Set<String> keys() {
        try {
            return redisTemplate.keys("*");
        } catch (Exception e) {
            this.redisError("keys");
            return null;
        }
    }

    /**
     * get
     *
     * @return null: 오류
     */
    public String get(String key) {
        try {
            return redisTemplate.opsForValue().get(key);
        } catch (Exception e) {
            this.redisError("get");
            return null;
        }
    }

    /**
     * set
     */
    public void set(String key, String value) {
        try {
            redisTemplate.opsForValue().set(key, value);
        } catch (Exception e) {
            this.redisError("set");
        }
    }

    /**
     * set Timeout
     */
    public void setex(String key, String value) {
        try {
            redisTemplate.opsForValue().set(key, value, Duration.ofSeconds(REDIS_EXPIRATION));
        } catch (Exception e) {
            this.redisError("setex");
        }
    }

    /**
     * 유효시간 조회 (초)
     *
     * @return -1: 유효시간이 지정되지 않은 키<br>
     * -2: 키없음<br>
     * -99: 오류
     */
    public Long ttl(String key) {
        try {
            return redisTemplate.getExpire(key);
        } catch (Exception e) {
            this.redisError("ttl");
            return -99L;
        }
    }

    /**
     * 키 삭제
     */
    public void del(String key) {
        try {
            redisTemplate.delete(key);
        } catch (Exception e) {
            this.redisError("del");
        }
    }

    /**
     * 전체 키 삭제
     */
    public void flushall() {
        try {
            Set<String> allKeys = redisTemplate.keys("*");
            if (allKeys != null) {
                redisTemplate.delete(allKeys);
            }
        } catch (Exception e) {
            this.redisError("flushall");
        }
    }

    public void redisError(String errorMethod) {
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTime = currentTime.format(formatter);
    }
}
