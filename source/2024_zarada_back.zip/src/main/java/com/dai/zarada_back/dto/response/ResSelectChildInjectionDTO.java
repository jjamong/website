package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "주사 기록 조회 Response DTO")
public class ResSelectChildInjectionDTO {
    @Schema(description = "자녀 주사 기록 SEQ")
    private long injectionSeq;

    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "기록 시간 'HH24:MI:SS'")
    private String recordTm;

    @Schema(description = "신규 카트리지 개봉 여부")
    private String newItemYn;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "주사 부위 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'INJ_PART_CD')")
    private String injPartCd;

    @Schema(description = "투여량")
    private float injVol;

    @Schema(description = "기록 코멘트")
    private String recordComment;

    @Schema(description = "최초 투여일로부터 일자")
    private String injDays;
}
