package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원 목록 조회(paging) Response DTO")
public class ResSelectUserListDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "휴대폰 번호 'XXXXXXXXXXX' (암호화 대상)")
    private String phone;

    @Schema(description = "가입시간")
    private String joinDt;

    @Schema(description = "승인 상태 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'APP_STAT_CD')")
    private String appStatCd;

    @Schema(description = "승인 상태명")
    private String appStatNm;
}
