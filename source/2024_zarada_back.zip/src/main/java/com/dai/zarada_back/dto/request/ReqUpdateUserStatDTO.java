package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원 승인 / 승인 취소 / 차단 Request DTO")
public class ReqUpdateUserStatDTO extends ReqLoginInfoDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "승인 상태 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'APP_STAT_CD')")
    private String appStatCd;
}
