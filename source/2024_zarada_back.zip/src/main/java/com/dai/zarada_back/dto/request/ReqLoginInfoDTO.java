package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "로그인 사용자 정보 Request DTO")
public class ReqLoginInfoDTO {
    @Schema(name = "_loginSeq", description = "로그인 회원정보 SEQ", hidden = true)
    private long _loginSeq;

    @Schema(name = "_loginId", description = "로그인 회원 아이디", hidden = true)
    private String _loginId;

    @Schema(name = "_loginRole", description = "로그인 권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')", hidden = true)
    private String _loginRole;
}
