package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공통코드 조회 Response DTO")
public class ResSelectCommonCodeDTO {
    @Schema(description = "그룹코드")
    private String clsfCd;

    @Schema(description = "공통코드")
    private String comnCd;

    @Schema(description = "공통코드명")
    private String comnNm;

    @Schema(description = "공통코드 상세명")
    private String comnDtlNm;

    @Schema(description = "사용 여부")
    private String useYn;

    @Schema(description = "정렬 순서")
    private int sort;

    @Schema(description = "비고1")
    private String bigo1;

    @Schema(description = "비고2")
    private String bigo2;

    @Schema(description = "비고3")
    private String bigo3;

    @Schema(description = "비고4")
    private String bigo4;

    @Schema(description = "비고5")
    private String bigo5;
}
