package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원별 자녀 목록 조회 Request DTO")
public class ReqSelectUserChildListDTO extends ReqLoginInfoDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;
}
