package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "주사 알림 조회 Response DTO")
public class ResSelectAlarmDTO {
    @Schema(description = "주사 알림 SEQ")
    private long alarmSeq;

    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "알림 여부")
    private String alYn;

    @Schema(description = "알림 시간")
    private String alTm;

    @Schema(description = "월요일")
    private String monYn;

    @Schema(description = "화요일")
    private String tueYn;

    @Schema(description = "수요일")
    private String wedYn;

    @Schema(description = "목요일")
    private String thuYn;

    @Schema(description = "금요일")
    private String friYn;

    @Schema(description = "토요일")
    private String satYn;

    @Schema(description = "일요일")
    private String sunYn;
}
