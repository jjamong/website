package com.dai.zarada_back.vo;

public enum JwtResultType {
    // 정상 토큰
    VALID_JWT,

    // 오류 - 토큰 없음
    EMPTY_JWT,

    // 오류 - 위변조
    SIGNATURE_JWT,

    // 오류 - 유효시간 만료
    EXPIRED_JWT,

    // 오류
    EXCEPTION_JWT
}
