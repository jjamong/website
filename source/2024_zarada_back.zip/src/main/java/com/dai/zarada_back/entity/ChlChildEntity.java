package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ChlChildEntity {
    private long childSeq;
    private long userSeq;
    private String childName;
    private String birthday;
    private String genderCd;
    private String itemCd;
    private String hospitalNm;
    private String doctorNm;
    private float injVol;
    private String delYn;
    private String childFile;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
    private String birthText;
    private String ageText;
    private String recentlyNewItemDate;
    private float recentlyChildHeight;
    private float recentlyChildWeight;
    private float recentlyChildBmi;
}
