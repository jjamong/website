package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ChildGrowthEntity {
    private long growthSeq;
    private long childSeq;
    private String recordDy;
    private float childHeight;
    private float childWeight;
    private float childBmi;
    private String recordComment;
    private String injDays;
    private int age;
    private int month;
    private String genderCd;
    private float childHeightPercent;
    private float childWeightPercent;
    private float childBmiPercent;
}
