package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "로그인 Response DTO")
public class ResLoginDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "승인 상태 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'APP_STAT_CD')")
    private String appStatCd;

    @Schema(description = "권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')")
    private String role;

    @Schema(description = "Access Token")
    private String accessToken;

    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "투여량")
    private float injVol;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "생년월일 'YYYY-MM-DD'")
    private String birthday;
}
