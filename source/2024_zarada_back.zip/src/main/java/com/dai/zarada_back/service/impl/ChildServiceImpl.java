package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildListDTO;
import com.dai.zarada_back.dto.response.ResSelectUserChildListDTO;
import com.dai.zarada_back.entity.ChlChildEntity;
import com.dai.zarada_back.mapper.ChlChildMapper;
import com.dai.zarada_back.service.ChildService;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ChildServiceImpl implements ChildService {
    private final ChlChildMapper chlChildMapper;

    @Override
    public List<ResSelectUserChildListDTO> selectUserChildList(ReqSelectUserChildListDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0021.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        inputData.put("delYn", "N");

        List<ChlChildEntity> chlChildEntityList = chlChildMapper.selectChlChild(inputData);

        List<ResSelectUserChildListDTO> resultData = new ArrayList<>();

        for (ChlChildEntity chlChildEntity : chlChildEntityList) {
            ResSelectUserChildListDTO resultDTO = new ResSelectUserChildListDTO();
            resultDTO.setChildSeq(chlChildEntity.getChildSeq());
            resultDTO.setUserSeq(chlChildEntity.getUserSeq());
            resultDTO.setChildName(chlChildEntity.getChildName());
            resultDTO.setBirthday(chlChildEntity.getBirthday());
            resultDTO.setGenderCd(chlChildEntity.getGenderCd());
            resultDTO.setItemCd(chlChildEntity.getItemCd());
            resultDTO.setHospitalNm(chlChildEntity.getHospitalNm());
            resultDTO.setDoctorNm(chlChildEntity.getDoctorNm());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    @Transactional
    public List<ResCountDTO> updateUserChildList(ReqUpdateUserChildListDTO dto) {
        List<ReqUpdateUserChildDTO> updateUserChildDTOList = dto.getUpdateUserChildList();

        if (updateUserChildDTOList == null || updateUserChildDTOList.isEmpty())
            throw new DAException(MessageCode.MSG_0023.getMessage());

        int count = 0;

        for (ReqUpdateUserChildDTO reqUpdateUserChildDTO : updateUserChildDTOList) {
            Map<String, Object> inputData = DaiHelper.createInputData(dto);
            inputData.put("childSeq", reqUpdateUserChildDTO.getChildSeq());
            inputData.put("itemCd", reqUpdateUserChildDTO.getItemCd());
            inputData.put("hospitalNm", reqUpdateUserChildDTO.getHospitalNm());
            inputData.put("doctorNm", reqUpdateUserChildDTO.getDoctorNm());

            count += chlChildMapper.updateChildFromNurse(inputData);
        }

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResSelectMyChildListDTO> selectMyChildList(ReqDummyDTO dto) {
        long userSeq = dto.get_loginSeq();

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        inputData.put("delYn", "N");

        List<ChlChildEntity> chlChildEntityList = chlChildMapper.selectChlChild(inputData);

        List<ResSelectMyChildListDTO> resultData = new ArrayList<>();

        for (ChlChildEntity chlChildEntity : chlChildEntityList) {
            ResSelectMyChildListDTO resultDTO = new ResSelectMyChildListDTO();
            resultDTO.setChildSeq(chlChildEntity.getChildSeq());
            resultDTO.setChildName(chlChildEntity.getChildName());
            resultDTO.setBirthday(chlChildEntity.getBirthday());
            resultDTO.setGenderCd(chlChildEntity.getGenderCd());
            resultDTO.setChildFile(chlChildEntity.getChildFile());
            resultDTO.setAgeText(chlChildEntity.getAgeText());
            resultDTO.setInjVol(chlChildEntity.getInjVol());
            resultDTO.setItemCd(chlChildEntity.getItemCd());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectMyChildDetailDTO> selectMyChildDetail(ReqSelectMyChildDetailDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", dto.getChildSeq());
        inputData.put("userSeq", dto.get_loginSeq());
        inputData.put("delYn", "N");

        List<ChlChildEntity> chlChildEntityList = chlChildMapper.selectChlChild(inputData);

        List<ResSelectMyChildDetailDTO> resultData = new ArrayList<>();

        for (ChlChildEntity chlChildEntity : chlChildEntityList) {
            ResSelectMyChildDetailDTO resultDTO = new ResSelectMyChildDetailDTO();
            resultDTO.setChildSeq(chlChildEntity.getChildSeq());
            resultDTO.setChildName(chlChildEntity.getChildName());
            resultDTO.setBirthday(chlChildEntity.getBirthday());
            resultDTO.setGenderCd(chlChildEntity.getGenderCd());
            resultDTO.setItemCd(chlChildEntity.getItemCd());
            resultDTO.setHospitalNm(chlChildEntity.getHospitalNm());
            resultDTO.setDoctorNm(chlChildEntity.getDoctorNm());
            resultDTO.setInjVol(chlChildEntity.getInjVol());
            resultDTO.setChildFile(chlChildEntity.getChildFile());
            resultDTO.setBirthText(chlChildEntity.getBirthText());
            resultDTO.setAgeText(chlChildEntity.getAgeText());
            resultDTO.setChildFile(chlChildEntity.getChildFile());
            resultDTO.setRecentlyNewItemDate(chlChildEntity.getRecentlyNewItemDate());
            resultDTO.setRecentlyChildHeight(chlChildEntity.getRecentlyChildHeight());
            resultDTO.setRecentlyChildWeight(chlChildEntity.getRecentlyChildWeight());
            resultDTO.setRecentlyChildBmi(chlChildEntity.getRecentlyChildBmi());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> insertMyChild(ReqInsertMyChildDTO dto) {
        String childName = DaiHelper.nullToEmptyStr(dto.getChildName());
        String birthday = DaiHelper.nullToEmptyStr(dto.getBirthday());

        if (childName.isEmpty() || birthday.isEmpty())
            throw new DAException(MessageCode.MSG_0024.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", dto.get_loginSeq());
        inputData.put("childName", childName);
        inputData.put("birthday", birthday);
        inputData.put("genderCd", dto.getGenderCd());
        inputData.put("itemCd", dto.getItemCd());
        inputData.put("hospitalNm", dto.getHospitalNm());
        inputData.put("doctorNm", dto.getDoctorNm());
        inputData.put("injVol", dto.getInjVol());
        inputData.put("delYn", "N");
        inputData.put("childFile", dto.getChildFile());

        int count = chlChildMapper.insertChlChild(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateMyChild(ReqUpdateMyChildDTO dto) {
        String childName = DaiHelper.nullToEmptyStr(dto.getChildName());
        String birthday = DaiHelper.nullToEmptyStr(dto.getBirthday());

        if (childName.isEmpty() || birthday.isEmpty())
            throw new DAException(MessageCode.MSG_0024.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", dto.getChildSeq());
        inputData.put("userSeq", dto.get_loginSeq());
        inputData.put("childName", childName);
        inputData.put("birthday", birthday);
        inputData.put("genderCd", dto.getGenderCd());
        inputData.put("itemCd", dto.getItemCd());
        inputData.put("hospitalNm", dto.getHospitalNm());
        inputData.put("doctorNm", dto.getDoctorNm());
        inputData.put("injVol", dto.getInjVol());
        inputData.put("childFile", dto.getChildFile());

        int count = chlChildMapper.updateChildFromUser(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> deleteMyChild(ReqDeleteMyChildDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", dto.getChildSeq());
        inputData.put("userSeq", dto.get_loginSeq());
        inputData.put("delYn", "Y");

        int count = chlChildMapper.updateChildDelYn(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
