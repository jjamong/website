package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "JWT Test Response DTO")
public class ResJwtTestDTO {
    @Schema(description = "Refresh Token")
    private String refreshToken;

    @Schema(description = "Access Token")
    private String accessToken;

    @Schema(description = "유효성 검사 결과 메세지")
    private String validMsg;

    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')")
    private String role;

    @Schema(description = "자동 로그인 여부")
    private String autoLogin;
}
