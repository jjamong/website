package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildListDTO;
import com.dai.zarada_back.dto.response.ResSelectUserChildListDTO;

import java.util.List;

public interface ChildService {
    List<ResSelectUserChildListDTO> selectUserChildList(ReqSelectUserChildListDTO dto);

    List<ResCountDTO> updateUserChildList(ReqUpdateUserChildListDTO dto);

    List<ResSelectMyChildListDTO> selectMyChildList(ReqDummyDTO dto);

    List<ResSelectMyChildDetailDTO> selectMyChildDetail(ReqSelectMyChildDetailDTO dto);

    List<ResCountDTO> insertMyChild(ReqInsertMyChildDTO dto);

    List<ResCountDTO> updateMyChild(ReqUpdateMyChildDTO dto);

    List<ResCountDTO> deleteMyChild(ReqDeleteMyChildDTO dto);
}
