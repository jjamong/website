package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "나이스 암호화 Request DTO")
public class ReqNiceEncryptDTO extends ReqLoginInfoDTO {
    @Schema(description = "인증 성공시 요청할 URL")
    private String returnUrl;

    @Schema(description = "인증 실패시 요청할 URL")
    private String errorUrl;
}
