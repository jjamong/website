package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ComCategorydetailEntity {
    private String clsfCd;
    private String comnCd;
    private String comnNm;
    private String comnDtlNm;
    private String useYn;
    private int sort;
    private String bigo1;
    private String bigo2;
    private String bigo3;
    private String bigo4;
    private String bigo5;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
}
