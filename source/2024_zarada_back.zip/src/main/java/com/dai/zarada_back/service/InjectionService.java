package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectAlarmDTO;
import com.dai.zarada_back.dto.response.ResSelectChildInjectionDTO;

import java.util.List;

public interface InjectionService {
    List<ResSelectChildInjectionDTO> selectChildInjection(ReqSelectChildInjectionDTO dto);

    List<ResCountDTO> saveChildInjection(ReqSaveChildInjectionDTO dto);

    List<ResCountDTO> deleteChildInjection(ReqDeleteChildInjectionDTO dto);

    List<ResSelectAlarmDTO> selectAlarm(ReqSelectAlarmDTO dto);

    List<ResCountDTO> saveAlarm(ReqSaveAlarmDTO dto);
}
