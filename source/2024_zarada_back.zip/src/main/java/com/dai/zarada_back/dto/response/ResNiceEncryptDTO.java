package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "나이스 암호화 Response DTO")
public class ResNiceEncryptDTO {
    @Schema(description = "암호화 데이터")
    private String encData;
}
