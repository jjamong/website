package com.dai.zarada_back.util;

public class DAException extends RuntimeException {
    public DAException(String message) {
        super(message);
    }
}
