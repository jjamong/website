package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.CountEntity;
import com.dai.zarada_back.entity.EtcNoticeEntity;
import com.dai.zarada_back.entity.NoticeListEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface EtcNoticeMapper {
    List<EtcNoticeEntity> selectNotice(Object inputData);

    int insertNotice(Object inputData);

    int updateNotice(Object inputData);

    int deleteNotice(Object inputData);

    List<CountEntity> selectNoticeListCount(Object inputData);

    List<NoticeListEntity> selectNoticeList(Object inputData);
}
