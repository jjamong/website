package com.dai.zarada_back.config;

import com.dai.zarada_back.util.CookieUtil;
import com.dai.zarada_back.util.JwtUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class SecurityConfig implements WebMvcConfigurer {
    JwtAuthenticationFilter jwtAuthenticationFilter(CookieUtil cookieUtil, JwtUtil jwtUtil) {
        return new JwtAuthenticationFilter(cookieUtil, jwtUtil);
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, CookieUtil cookieUtil, JwtUtil jwtUtil) throws Exception {
        return http.csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(
                        authorize -> authorize
                                .requestMatchers("/api/extra/**", "/api/dev/**", "/swagger-ui/**", "/v3/**").permitAll() /* Backend, Swagger */
                                .requestMatchers("/", "/index.html", "/_next/**", "/css/**", "/img/**", "/front/**", "/controlroom/**").permitAll() /* Frontend */
                                .requestMatchers("/api/user/**").hasAnyRole("ADMIN", "NURSE", "USER")
                                .requestMatchers("/api/nurse/**").hasAnyRole("ADMIN", "NURSE")
                                .requestMatchers("/api/admin/**").hasAnyRole("ADMIN"))
                .addFilterBefore(jwtAuthenticationFilter(cookieUtil, jwtUtil),
                        UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setMaxAge(3000L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new Interceptor())
                .addPathPatterns("/api/**");
    }
}