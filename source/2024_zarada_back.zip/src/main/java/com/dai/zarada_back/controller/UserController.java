package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCommonDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectUserDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectUserListDTO;
import com.dai.zarada_back.service.UserService;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class UserController {
    private final DaiHelper daiHelper;
    private final UserService userService;

    @Tag(name = "410.User", description = "회원 관리 API")
    @Operation(
            summary = "회원 목록 count",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/nurse/UserController/selectUserListCount")
    public ResponseEntity<ResCommonDTO<Object>> selectUserListCount(@RequestBody ReqSelectUserListCountDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = userService.selectUserListCount(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "410.User", description = "회원 관리 API")
    @Operation(
            summary = "회원 목록 조회(paging)",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResSelectUserListDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/nurse/UserController/selectUserList")
    public ResponseEntity<ResCommonDTO<Object>> selectUserList(@RequestBody ReqSelectUserListDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResSelectUserListDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = userService.selectUserList(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "410.User", description = "회원 관리 API")
    @Operation(
            summary = "회원 정보 상세 조회",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResSelectUserDetailDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/nurse/UserController/selectUserDetail")
    public ResponseEntity<ResCommonDTO<Object>> selectUserDetail(@RequestBody ReqSelectUserDetailDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResSelectUserDetailDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = userService.selectUserDetail(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "410.User", description = "회원 관리 API")
    @Operation(
            summary = "회원 메모 수정",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/nurse/UserController/updateUserMemo")
    public ResponseEntity<ResCommonDTO<Object>> updateUserMemo(@RequestBody ReqUpdateUserMemoDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = userService.updateUserMemo(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "410.User", description = "회원 관리 API")
    @Operation(
            summary = "회원 승인 / 승인 취소 / 차단",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/nurse/UserController/updateUserStat")
    public ResponseEntity<ResCommonDTO<Object>> updateUserStat(@RequestBody ReqUpdateUserStatDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = userService.updateUserStat(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }
}
