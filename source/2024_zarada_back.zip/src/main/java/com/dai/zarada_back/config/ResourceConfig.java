package com.dai.zarada_back.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ResourceConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        // 로그인
        registry.addViewController("/").setViewName("/index.html");
        registry.addViewController("/front/join").setViewName("/front/join.html");
        registry.addViewController("/front/find").setViewName("/front/find.html");
        registry.addViewController("/front/nice").setViewName("/front/nice.html");
        registry.addViewController("/front/nice/mobile").setViewName("/front/nice/mobile.html");

        // 메인
        registry.addViewController("/front/main").setViewName("/front/main.html");

        // 성장관리
        registry.addViewController("/front/growth").setViewName("/front/growth.html");
        registry.addViewController("/front/growth/reg").setViewName("/front/growth/reg.html");
        registry.addViewController("/front/growth/modi").setViewName("/front/growth/modi.html");

        // 주사관리
        registry.addViewController("/front/injection").setViewName("/front/injection.html");
        registry.addViewController("/front/injection/method").setViewName("/front/injection/method.html");
        registry.addViewController("/front/injection/modi").setViewName("/front/injection/modi.html");
        registry.addViewController("/front/injection/reg").setViewName("/front/injection/reg.html");

        // 마이페이지
        registry.addViewController("/front/mypage").setViewName("/front/mypage.html");
        registry.addViewController("/front/mypage/changePaInfo").setViewName("/front/mypage/changePaInfo.html");
        registry.addViewController("/front/mypage/changePw").setViewName("/front/mypage/changePw.html");
        registry.addViewController("/front/mypage/manageFaInfo").setViewName("/front/mypage/manageFaInfo.html");
        registry.addViewController("/front/mypage/modiChild").setViewName("/front/mypage/modiChild.html");
        registry.addViewController("/front/mypage/regChild").setViewName("/front/mypage/regChild.html");
        registry.addViewController("/front/mypage/withdrawal").setViewName("/front/mypage/withdrawal.html");

        // 공지사항
        registry.addViewController("/front/notice").setViewName("/front/notice.html");
        registry.addViewController("/front/notice/faqDetail").setViewName("/front/notice/faqDetail.html");
        registry.addViewController("/front/notice/noticeDetail").setViewName("/front/notice/noticeDetail.html");

        // 관리자 메뉴
        registry.addViewController("/controlroom/users").setViewName("/controlroom/users.html");
        registry.addViewController("/controlroom/users/detail").setViewName("/controlroom/users/detail.html");
        registry.addViewController("/controlroom/notice").setViewName("/controlroom/notice.html");
        registry.addViewController("/controlroom/notice/reg").setViewName("/controlroom/notice/reg.html");
        registry.addViewController("/controlroom/notice/modi").setViewName("/controlroom/notice/modi.html");
        registry.addViewController("/controlroom/notice/detail").setViewName("/controlroom/notice/detail.html");
        registry.addViewController("/controlroom/admins").setViewName("/controlroom/admins.html");
        registry.addViewController("/controlroom/admins/reg").setViewName("/controlroom/admins/reg.html");
        registry.addViewController("/controlroom/admins/modi").setViewName("/controlroom/admins/modi.html");
        registry.addViewController("/controlroom/adminInjectionMethod").setViewName("/controlroom/adminInjectionMethod.html");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/out/")
                .resourceChain(true);
    }
}
