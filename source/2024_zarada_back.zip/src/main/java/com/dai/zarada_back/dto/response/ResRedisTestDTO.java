package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Redis Test Response DTO")
public class ResRedisTestDTO {
    @Schema(description = "전체 키 조회 결과값")
    private Set<String> keysVal;

    @Schema(description = "get 결과값")
    private String getVal;

    @Schema(description = "유효시간 조회 (초) 결과값")
    private long ttlVal;
}
