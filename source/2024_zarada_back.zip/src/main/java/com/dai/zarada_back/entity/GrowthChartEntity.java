package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class GrowthChartEntity {
    private String age;
    private String month;
    private String val1;
    private String val3;
    private String val5;
    private String val10;
    private String val15;
    private String val25;
    private String val50;
    private String val75;
    private String val85;
    private String val90;
    private String val95;
    private String val97;
    private String val99;
    private String childAge;
    private String childHeight;
    private String childWeight;
    private String childBmi;
}
