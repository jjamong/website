package com.dai.zarada_back.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    private Info apiInfo() {
        return new Info()
                .title("ZARADA Backend API") // API의 제목
                .description("""
                        #### 1. 권한이 필요한 경우 로그인 후 Access Token 세팅 필요
                        #### 2. 통신 결과 코드
                        - 200 : 성공
                        - 403 : API 권한 없음
                        - 900 : Access Token 에러(토큰 없음, 위변조 등)
                        - 901 : Access Token 유효시간 만료 => 토큰 재발급 필요
                        - 902 : Refresh Token과 Access Token 로그인 정보 불일치
                        """) // API에 대한 설명
                .version("1.0.0"); // API의 버전
    }

    @Bean
    public OpenAPI openAPI() {
        String jwt = "JWT";
        SecurityRequirement securityRequirement = new SecurityRequirement().addList(jwt);
        Components components = new Components().addSecuritySchemes(jwt, new SecurityScheme()
                .name(jwt)
                .type(SecurityScheme.Type.HTTP)
                .scheme("Bearer")
                .bearerFormat("JWT")
        );
        return new OpenAPI()
                .components(new Components())
                .info(apiInfo())
                .addSecurityItem(securityRequirement)
                .components(components);
    }
}
