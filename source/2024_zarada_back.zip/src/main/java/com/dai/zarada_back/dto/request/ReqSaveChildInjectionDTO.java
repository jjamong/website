package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "주사 기록 저장 Request DTO")
public class ReqSaveChildInjectionDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "기록 시간 'HH24:MI:SS'")
    private String recordTm;

    @Schema(description = "신규 카트리지 개봉 여부")
    private String newItemYn;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "주사 부위 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'INJ_PART_CD')")
    private String injPartCd;

    @Schema(description = "투여량")
    private float injVol;

    @Schema(description = "기록 코멘트")
    private String recordComment;
}
