package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqDeleteMyChildGrowthDTO;
import com.dai.zarada_back.dto.request.ReqSaveMyChildGrowthDTO;
import com.dai.zarada_back.dto.request.ReqSelectGrowthChartDTO;
import com.dai.zarada_back.dto.request.ReqSelectMyChildGrowthDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectGrowthChartDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildGrowthDTO;
import com.dai.zarada_back.entity.ChildGrowthEntity;
import com.dai.zarada_back.entity.ChlGrowthEntity;
import com.dai.zarada_back.entity.GrowthChartEntity;
import com.dai.zarada_back.mapper.ChlGrowthMapper;
import com.dai.zarada_back.service.GrowthService;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class GrowthServiceImpl implements GrowthService {
    private final ChlGrowthMapper chlGrowthMapper;

    @Override
    public List<ResSelectMyChildGrowthDTO> selectMyChildGrowth(ReqSelectMyChildGrowthDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("growthSeq", dto.getGrowthSeq());
        inputData.put("recordDy", dto.getRecordDy());
        inputData.put("childSeq", dto.getChildSeq());

        List<ChildGrowthEntity> childGrowthEntityList = chlGrowthMapper.selectChildGrowth(inputData);

        List<ResSelectMyChildGrowthDTO> resultData = new ArrayList<>();

        for (ChildGrowthEntity childGrowthEntity : childGrowthEntityList) {
            ResSelectMyChildGrowthDTO resultDTO = new ResSelectMyChildGrowthDTO();
            resultDTO.setGrowthSeq(childGrowthEntity.getGrowthSeq());
            resultDTO.setChildSeq(childGrowthEntity.getChildSeq());
            resultDTO.setRecordDy(childGrowthEntity.getRecordDy());
            resultDTO.setChildHeight(childGrowthEntity.getChildHeight());
            resultDTO.setChildWeight(childGrowthEntity.getChildWeight());
            resultDTO.setChildBmi(childGrowthEntity.getChildBmi());
            resultDTO.setRecordComment(childGrowthEntity.getRecordComment());
            resultDTO.setInjDays(childGrowthEntity.getInjDays());
            resultDTO.setAge(childGrowthEntity.getAge());
            resultDTO.setMonth(childGrowthEntity.getMonth());
            resultDTO.setGenderCd(childGrowthEntity.getGenderCd());
            resultDTO.setChildHeightPercent(childGrowthEntity.getChildHeightPercent());
            resultDTO.setChildWeightPercent(childGrowthEntity.getChildWeightPercent());
            resultDTO.setChildBmiPercent(childGrowthEntity.getChildBmiPercent());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> saveMyChildGrowth(ReqSaveMyChildGrowthDTO dto) {
        long childSeq = dto.getChildSeq();
        String recordDy = DaiHelper.nullToEmptyStr(dto.getRecordDy());

        if (childSeq == 0)
            throw new DAException(MessageCode.MSG_0026.getMessage());

        if (recordDy.isEmpty())
            throw new DAException(MessageCode.MSG_0025.getMessage());

        float childHeight = dto.getChildHeight();
        float childWeight = dto.getChildWeight();
        float childBmi = childWeight / (childHeight / 100.0f * childHeight / 100.0f);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", childSeq);
        inputData.put("recordDy", recordDy);

        List<ChlGrowthEntity> chlGrowthEntityList = chlGrowthMapper.selectChlGrowth(inputData);

        int count = 0;
        inputData.put("childHeight", childHeight);
        inputData.put("childWeight", childWeight);
        inputData.put("childBmi", childBmi);
        inputData.put("recordComment", dto.getRecordComment());

        if (chlGrowthEntityList.isEmpty())
            count += chlGrowthMapper.insertChlGrowth(inputData);
        else
            count += chlGrowthMapper.updateChildGrowth(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> deleteMyChildGrowth(ReqDeleteMyChildGrowthDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("growthSeq", dto.getGrowthSeq());

        int count = chlGrowthMapper.deleteChlGrowth(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResSelectGrowthChartDTO> selectGrowthChart(ReqSelectGrowthChartDTO dto) {
        String dvsn = DaiHelper.nullToEmptyStr(dto.getDvsn());
        String chartDvsn = DaiHelper.nullToEmptyStr(dto.getChartDvsn());
        String genderCd = DaiHelper.nullToEmptyStr(dto.getGenderCd());
        int month = dto.getMonth();
        long childSeq = dto.getChildSeq();

        if (dvsn.isEmpty() || chartDvsn.isEmpty() || genderCd.isEmpty() || childSeq == 0)
            throw new DAException(MessageCode.MSG_0027.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("dvsn", dvsn);
        inputData.put("chartDvsn", chartDvsn);
        inputData.put("genderCd", genderCd);
        inputData.put("month", dto.getMonth());
        inputData.put("childSeq", childSeq);

        List<GrowthChartEntity> growthChartEntityList = chlGrowthMapper.selectGrowthChart(inputData);

        List<ResSelectGrowthChartDTO> resultData = new ArrayList<>();

        for (GrowthChartEntity growthChartEntity : growthChartEntityList) {
            ResSelectGrowthChartDTO resultDTO = new ResSelectGrowthChartDTO();
            resultDTO.setAge(growthChartEntity.getAge());
            resultDTO.setMonth(growthChartEntity.getMonth());
            resultDTO.setVal1(growthChartEntity.getVal1());
            resultDTO.setVal1(growthChartEntity.getVal1());
            resultDTO.setVal3(growthChartEntity.getVal3());
            resultDTO.setVal5(growthChartEntity.getVal5());
            resultDTO.setVal10(growthChartEntity.getVal10());
            resultDTO.setVal15(growthChartEntity.getVal15());
            resultDTO.setVal25(growthChartEntity.getVal25());
            resultDTO.setVal50(growthChartEntity.getVal50());
            resultDTO.setVal75(growthChartEntity.getVal75());
            resultDTO.setVal85(growthChartEntity.getVal85());
            resultDTO.setVal90(growthChartEntity.getVal90());
            resultDTO.setVal95(growthChartEntity.getVal95());
            resultDTO.setVal97(growthChartEntity.getVal97());
            resultDTO.setVal99(growthChartEntity.getVal99());
            resultDTO.setChildAge(growthChartEntity.getChildAge());
            resultDTO.setChildHeight(growthChartEntity.getChildHeight());
            resultDTO.setChildWeight(growthChartEntity.getChildWeight());
            resultDTO.setChildBmi(growthChartEntity.getChildBmi());

            resultData.add(resultDTO);
        }

        return resultData;
    }
}
