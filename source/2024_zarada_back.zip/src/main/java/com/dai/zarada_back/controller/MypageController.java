package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqUpdateMypageDTO;
import com.dai.zarada_back.dto.request.ReqUpdateUserPwFromMypageDTO;
import com.dai.zarada_back.dto.response.ResCommonDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectMypageDTO;
import com.dai.zarada_back.service.MypageService;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class MypageController {
    private final DaiHelper daiHelper;
    private final MypageService mypageService;

    @Tag(name = "310.Mypage", description = "마이페이지 API")
    @Operation(
            summary = "마이페이지 조회",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResSelectMypageDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/MypageController/selectMypage")
    public ResponseEntity<ResCommonDTO<Object>> selectMypage(@RequestBody ReqDummyDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResSelectMypageDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = mypageService.selectMypage(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "310.Mypage", description = "마이페이지 API")
    @Operation(
            summary = "마이페이지 정보 수정",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/MypageController/updateMypage")
    public ResponseEntity<ResCommonDTO<Object>> updateMypage(@RequestBody ReqUpdateMypageDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = mypageService.updateMypage(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "310.Mypage", description = "마이페이지 API")
    @Operation(
            summary = "비밀번호 변경(mypage)",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResCountDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/user/MypageController/updateUserPwFromMypage")
    public ResponseEntity<ResCommonDTO<Object>> updateUserPwFromMypage(@RequestBody ReqUpdateUserPwFromMypageDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResCountDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = mypageService.updateUserPwFromMypage(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }
}
