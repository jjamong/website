package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "병원 Combo 조회 Response DTO")
public class ResSelectHospitalComboDTO {
    @Schema(description = "병원 기준정보 SEQ")
    private long hospitalSeq;

    @Schema(description = "지역")
    private String local;

    @Schema(description = "시구군")
    private String localHost;

    @Schema(description = "병원명")
    private String hospitalNm;
}
