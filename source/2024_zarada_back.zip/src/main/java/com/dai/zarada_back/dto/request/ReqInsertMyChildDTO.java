package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "내 자녀 추가 Request DTO")
public class ReqInsertMyChildDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀 이름")
    private String childName;

    @Schema(description = "생년월일 'YYYY-MM-DD'")
    private String birthday;

    @Schema(description = "성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String genderCd;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "처방 병원명")
    private String hospitalNm;

    @Schema(description = "처방 의사명")
    private String doctorNm;

    @Schema(description = "투여량")
    private float injVol;

    @Schema(description = "자녀 이미지")
    private String childFile;
}
