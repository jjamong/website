package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqAriaTestDTO;
import com.dai.zarada_back.dto.request.ReqFcmTestDTO;
import com.dai.zarada_back.dto.request.ReqJwtTestDTO;
import com.dai.zarada_back.dto.request.ReqRedisTestDTO;
import com.dai.zarada_back.dto.response.ResAriaTestDTO;
import com.dai.zarada_back.dto.response.ResFcmTestDTO;
import com.dai.zarada_back.dto.response.ResJwtTestDTO;
import com.dai.zarada_back.dto.response.ResRedisTestDTO;
import com.dai.zarada_back.service.DevService;
import com.dai.zarada_back.service.FCMService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.JwtUtil;
import com.dai.zarada_back.util.RedisUtil;
import com.dai.zarada_back.vo.JwtResultType;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DevServiceImpl implements DevService {
    private final RedisUtil redisUtil;
    private final JwtUtil jwtUtil;
    private final AriaUtil ariaUtil;
    private final FCMService fcmService;

    @Override
    public List<ResRedisTestDTO> redisTest(ReqRedisTestDTO dto) {
        List<ResRedisTestDTO> resultData = new ArrayList<>();
        ResRedisTestDTO resultDTO = new ResRedisTestDTO();

        String dvsn = dto.getDvsn() == null ? "" : dto.getDvsn();
        String key = dto.getKey() == null ? "" : dto.getKey();
        String value = dto.getValue() == null ? "" : dto.getValue();

        if ("KEYS".equals(dvsn)) {
            resultDTO.setKeysVal(redisUtil.keys());
            resultData.add(resultDTO);
        } else if ("GET".equals(dvsn)) {
            resultDTO.setGetVal(redisUtil.get(key));
            resultData.add(resultDTO);
        } else if ("SET".equals(dvsn)) {
            redisUtil.set(key, value);
        } else if ("SETEX".equals(dvsn)) {
            redisUtil.setex(key, value);
        } else if ("TTL".equals(dvsn)) {
            resultDTO.setTtlVal(redisUtil.ttl(key));
            resultData.add(resultDTO);
        } else if ("DEL".equals(dvsn)) {
            redisUtil.del(key);
        } else if ("FLUSHALL".equals(dvsn)) {
            redisUtil.flushall();
        }

        return resultData;
    }

    @Override
    public List<ResJwtTestDTO> jwtTest(ReqJwtTestDTO dto) {
        List<ResJwtTestDTO> resultData = new ArrayList<>();
        ResJwtTestDTO resultDTO = new ResJwtTestDTO();

        String dvsn = dto.getDvsn() == null ? "" : dto.getDvsn();
        String token = dto.getToken() == null ? "" : dto.getToken();
        long userSeq = dto.getUserSeq();
        String userId = dto.getUserId() == null ? "" : dto.getUserId();
        String role = dto.getRole() == null ? "" : dto.getRole();
        String autoLogin = dto.getAutoLogin() == null ? "" : dto.getAutoLogin();

        if ("C".equals(dvsn)) {
            resultDTO.setRefreshToken(jwtUtil.createRefreshToken(userSeq, userId, role, autoLogin));
            resultDTO.setAccessToken(jwtUtil.createAccessToken(userSeq, userId, role, autoLogin));
            resultData.add(resultDTO);
        } else if ("V".equals(dvsn)) {
            JwtResultType jwtResultType = jwtUtil.validationToken(token);
            if (jwtResultType == JwtResultType.VALID_JWT) {
                resultDTO.setValidMsg(MessageCode.MSG_9001.getMessage());
            } else if (jwtResultType == JwtResultType.EXPIRED_JWT) {
                resultDTO.setValidMsg(MessageCode.MSG_9003.getMessage());
            } else {
                resultDTO.setValidMsg(MessageCode.MSG_9002.getMessage());
            }
            resultData.add(resultDTO);
        } else if ("G".equals(dvsn)) {
            resultDTO.setUserSeq(jwtUtil.getTokenUserSeq(token));
            resultDTO.setUserId(jwtUtil.getTokenUserId(token));
            resultDTO.setRole(jwtUtil.getTokenRole(token));
            resultDTO.setAutoLogin(jwtUtil.getTokenAutoLogin(token));
            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResAriaTestDTO> ariaTest(ReqAriaTestDTO dto) {
        List<ResAriaTestDTO> resultData = new ArrayList<>();
        ResAriaTestDTO resultDTO = new ResAriaTestDTO();

        String dvsn = dto.getDvsn() == null ? "" : dto.getDvsn();
        String str = dto.getStr() == null ? "" : dto.getStr();

        if ("E".equals(dvsn)) {
            resultDTO.setEncryptVal(ariaUtil.encrypt(str));
            resultData.add(resultDTO);
        } else if ("D".equals(dvsn)) {
            resultDTO.setDecryptVal(ariaUtil.decrypt(str));
            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResFcmTestDTO> fcmTest(ReqFcmTestDTO dto) {
        String token = dto.getFcmToken();
        String title = dto.getTitle();
        String body = dto.getBody();
        String moveUrl = dto.getMoveUrl();

        List<ResFcmTestDTO> resultData = new ArrayList<>();
        ResFcmTestDTO resultDTO = new ResFcmTestDTO();
        resultDTO.setFcmMsg(fcmService.sendNotificationTest(token, title, body, moveUrl));
        resultData.add(resultDTO);

        return resultData;
    }
}
