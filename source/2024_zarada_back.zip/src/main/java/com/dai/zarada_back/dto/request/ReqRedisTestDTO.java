package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Redis Test Request DTO")
public class ReqRedisTestDTO extends ReqLoginInfoDTO {
    @Schema(description = "비밀번호")
    private String password;

    @Schema(description = "테스트 구분 (\"KEYS\" / \"GET\" / \"SET\" / \"SETEX\" / \"TTL\" / \"DEL\" / \"FLUSHALL\")")
    private String dvsn;

    @Schema(description = "키")
    private String key;

    @Schema(description = "값")
    private String value;
}
