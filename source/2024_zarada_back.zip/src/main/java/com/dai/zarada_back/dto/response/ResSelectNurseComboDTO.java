package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "간호사 Combo 조회 Response DTO")
public class ResSelectNurseComboDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "휴대폰 번호 'XXXXXXXXXXX' (암호화 대상)")
    private String phone;

    @Schema(description = "회원 이름 + (휴대폰 번호)")
    private String userNamePhone;

    @Schema(description = "권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')")
    private String role;
}
