package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원 정보 수정 Request DTO")
public class ReqUpdateUserMemoDTO extends ReqLoginInfoDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "메모")
    private String memo;
}
