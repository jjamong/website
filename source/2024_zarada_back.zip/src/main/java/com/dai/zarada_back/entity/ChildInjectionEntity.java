package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ChildInjectionEntity {
    private long injectionSeq;
    private long childSeq;
    private String recordDy;
    private String recordTm;
    private String newItemYn;
    private String itemCd;
    private String injPartCd;
    private float injVol;
    private String recordComment;
    private String injDays;
}
