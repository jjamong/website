package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UsrUserMapper {
    List<UsrUserEntity> selectUsrUser(Object inputData);

    int insertUsrUser(Object inputData);

    int updateUsrUser(Object inputData);

    int deleteUsrUser(Object inputData);

    List<NurseComboEntity> selectNurseCombo(Object inputData);

    List<CountEntity> selectNurseListCount(Object inputData);

    List<NurseListEntity> selectNurseList(Object inputData);

    List<NurseDetailEntity> selectNurseDetail(Object inputData);

    List<CountEntity> selectUserListCount(Object inputData);

    List<UserListEntity> selectUserList(Object inputData);

    int insertUsrLoginlog(Object inputData);

    int insertUsrPsninfo(Object inputData);

    int insertUsrWithdrawal(Object inputData);

    int insertNurse(Object inputData);

    int updateFcmToken(Object inputData);

    int updateUserPw(Object inputData);

    int updateMypage(Object inputData);

    int updateNurse(Object inputData);

    int updateUserMemo(Object inputData);

    int updateUserStat(Object inputData);
}
