package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Aria Test Request DTO")
public class ReqAriaTestDTO extends ReqLoginInfoDTO {
    @Schema(description = "비밀번호")
    private String password;

    @Schema(description = "테스트 구분 (\"E\" / \"D\")")
    private String dvsn;

    @Schema(description = "문자열")
    private String str;
}
