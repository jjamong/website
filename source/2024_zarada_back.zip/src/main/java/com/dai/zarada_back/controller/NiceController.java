package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.ReqNiceDecryptDTO;
import com.dai.zarada_back.dto.request.ReqNiceEncryptDTO;
import com.dai.zarada_back.dto.response.ResCommonDTO;
import com.dai.zarada_back.dto.response.ResNiceDecryptDTO;
import com.dai.zarada_back.dto.response.ResNiceEncryptDTO;
import com.dai.zarada_back.service.NiceService;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class NiceController {
    private final DaiHelper daiHelper;
    private final NiceService niceService;

    @Tag(name = "300.Join", description = "회원가입 API")
    @Operation(
            summary = "나이스 인증 암호화",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "true / false")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "'S' / 'F'")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "Message")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResNiceEncryptDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/extra/NiceController/niceEncrypt")
    public ResponseEntity<ResCommonDTO<Object>> niceEncrypt(@RequestBody ReqNiceEncryptDTO dto, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResNiceEncryptDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = niceService.niceEncrypt(dto, httpServletResponse);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> responseBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(responseBody);
    }

    @Tag(name = "300.Join", description = "회원가입 API")
    @Operation(
            summary = "나이스 인증 복호화",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "true / false")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "'S' / 'F'")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "Message")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResNiceDecryptDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/extra/NiceController/niceDecrypt")
    public ResponseEntity<ResCommonDTO<Object>> niceDecrypt(@RequestBody ReqNiceDecryptDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResNiceDecryptDTO> data = new ArrayList<>();

        try {
            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = niceService.niceDecrypt(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> responseBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(responseBody);
    }
}
