package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공지사항 내용 조회 Request DTO")
public class ReqSelectNoticeDTO extends ReqLoginInfoDTO {
    @Schema(description = "공지사항 SEQ")
    private long noticeSeq;
}
