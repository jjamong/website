package com.dai.zarada_back.util;

import com.dai.zarada_back.vo.MessageCode;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class DaiHelper {
    @Value("${dev.password}")
    private String devPassword;

    private final JwtUtil jwtUtil;

    public <T> T setLoginInfo(T dto, HttpServletRequest httpServletRequest) {
        try {
            String loginToken = jwtUtil.resolveToken(httpServletRequest);
            long userSeq = jwtUtil.getTokenUserSeq(loginToken);
            String userId = jwtUtil.getTokenUserId(loginToken);
            String role = jwtUtil.getTokenRole(loginToken);

            Class<?> clazz = dto.getClass();
            ArrayList<Field> fields = new ArrayList<>();
            while (clazz != null) {
                fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
                clazz = clazz.getSuperclass();
            }

            for (Field field : fields) {
                field.setAccessible(true);

                if ("_loginSeq".equals(field.getName())) {
                    field.set(dto, userSeq);
                }
                if ("_loginId".equals(field.getName())) {
                    field.set(dto, userId);
                }
                if ("_loginRole".equals(field.getName())) {
                    field.set(dto, role);
                }
            }
        } catch (Exception e) {
            throw new DAException(MessageCode.MSG_0001.getMessage());
        }

        return dto;
    }

    public static <T> Map<String, Object> createInputData(T dto) {
        Map<String, Object> inputData = new HashMap<>();

        try {
            Class<?> clazz = dto.getClass();
            ArrayList<Field> fields = new ArrayList<>();
            while (clazz != null) {
                fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
                clazz = clazz.getSuperclass();
            }

            for (Field field : fields) {
                field.setAccessible(true);

                if ("_loginSeq".equals(field.getName())) {
                    inputData.put("_loginSeq", field.get(dto));
                }
                if ("_loginId".equals(field.getName())) {
                    inputData.put("_loginId", field.get(dto));
                }
                if ("_loginRole".equals(field.getName())) {
                    inputData.put("_loginRole", field.get(dto));
                }
            }
        } catch (Exception e) {
            throw new DAException(MessageCode.MSG_0001.getMessage());
        }

        return inputData;
    }

    public boolean checkDevPw(String password) {
        return password.equals(this.devPassword);
    }

    public static String nullToEmptyStr(String str) {
        return str == null ? "" : str;
    }

    public static int pageCalculation(int page, int size) {
        if (page < 1 || size < 1)
            throw new DAException(MessageCode.MSG_0017.getMessage());

        return (page - 1) * size;
    }
}
