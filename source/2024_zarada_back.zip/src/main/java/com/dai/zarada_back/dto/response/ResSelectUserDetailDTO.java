package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원 정보 상세 조회 Response DTO")
public class ResSelectUserDetailDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "생년월일 'YYYY-MM-DD'")
    private String birthday;

    @Schema(description = "성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String genderCd;

    @Schema(description = "휴대폰 번호 'XXXXXXXXXXX' (암호화 대상)")
    private String phone;

    @Schema(description = "우편번호 (암호화 대상)")
    private String zipCode;

    @Schema(description = "주소 (암호화 대상)")
    private String addr;

    @Schema(description = "상세주소 (암호화 대상)")
    private String addrDtl;

    @Schema(description = "이메일")
    private String email;

    @Schema(description = "가입시간")
    private String joinDt;

    @Schema(description = "승인 상태 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'APP_STAT_CD')")
    private String appStatCd;

    @Schema(description = "승인자 ID")
    private String appId;

    @Schema(description = "승인일자 'YYYY-MM-DD'")
    private String appDy;

    @Schema(description = "메모")
    private String memo;

    @Schema(description = "권한 (COM_CATEGORYDETAIL.CLSF_CD = 'ROLE')")
    private String role;
}
