package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqSelectCommonCodeDTO;
import com.dai.zarada_back.dto.response.ResSelectCommonCodeDTO;
import com.dai.zarada_back.dto.response.ResSelectHospitalComboDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseComboDTO;

import java.util.List;

public interface CommonService {
    List<ResSelectCommonCodeDTO> selectCommonCode(ReqSelectCommonCodeDTO dto);

    List<ResSelectNurseComboDTO> selectNurseCombo(ReqDummyDTO dto);

    List<ResSelectHospitalComboDTO> selectHospitalCombo(ReqDummyDTO dto);
}
