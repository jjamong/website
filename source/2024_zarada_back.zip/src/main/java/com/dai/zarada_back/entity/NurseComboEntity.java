package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class NurseComboEntity {
    private long userSeq;
    private String userId;
    private String userName;
    private String phone;
    private String role;
}
