package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.ChildInjectionEntity;
import com.dai.zarada_back.entity.ChlInjectionEntity;
import com.dai.zarada_back.entity.AlarmEntity;
import com.dai.zarada_back.entity.UserAlarmEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ChlInjectionMapper {
    List<ChlInjectionEntity> selectChlInjection(Object inputData);

    int insertChlInjection(Object inputData);

    int updateChlInjection(Object inputData);

    int deleteChlInjection(Object inputData);

    List<ChildInjectionEntity> selectChildInjection(Object inputData);

    List<AlarmEntity> selectAlarm(Object inputData);

    List<UserAlarmEntity> selectUserAlarm(Object inputData);

    int insertAlarm(Object inputData);

    int updateChildInjection(Object inputData);

    int updateAlarm(Object inputData);
}
