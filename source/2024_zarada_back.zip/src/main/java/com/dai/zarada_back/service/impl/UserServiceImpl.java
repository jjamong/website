package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectUserDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectUserListDTO;
import com.dai.zarada_back.entity.CountEntity;
import com.dai.zarada_back.entity.UserListEntity;
import com.dai.zarada_back.entity.UsrUserEntity;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.UserService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UsrUserMapper usrUserMapper;
    private final AriaUtil ariaUtil;

    @Override
    public List<ResCountDTO> selectUserListCount(ReqSelectUserListCountDTO dto) {
        String searchDvsn = DaiHelper.nullToEmptyStr(dto.getSearchDvsn());
        String searchText = DaiHelper.nullToEmptyStr(dto.getSearchText());

        if ("P".equals(searchDvsn) && !searchText.isEmpty())
            searchText = ariaUtil.encrypt(searchText);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("appStatCd", dto.getAppStatCd());
        inputData.put("myAppYn", dto.getMyAppYn());
        inputData.put("searchDvsn", searchDvsn);
        inputData.put("searchText", searchText);

        List<CountEntity> countEntityList = usrUserMapper.selectUserListCount(inputData);

        List<ResCountDTO> resultData = new ArrayList<>();

        for (CountEntity countEntity : countEntityList) {
            ResCountDTO resultDTO = new ResCountDTO();
            resultDTO.setCount(countEntity.getCount());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectUserListDTO> selectUserList(ReqSelectUserListDTO dto) {
        String searchDvsn = DaiHelper.nullToEmptyStr(dto.getSearchDvsn());
        String searchText = DaiHelper.nullToEmptyStr(dto.getSearchText());
        int page = dto.getPage();
        int size = dto.getSize();
        page = DaiHelper.pageCalculation(page, size);

        if ("P".equals(searchDvsn) && !searchText.isEmpty())
            searchText = ariaUtil.encrypt(searchText);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("appStatCd", dto.getAppStatCd());
        inputData.put("myAppYn", dto.getMyAppYn());
        inputData.put("searchDvsn", searchDvsn);
        inputData.put("searchText", searchText);
        inputData.put("page", page);
        inputData.put("size", size);

        List<UserListEntity> userListEntityList = usrUserMapper.selectUserList(inputData);

        List<ResSelectUserListDTO> resultData = new ArrayList<>();

        for (UserListEntity userListEntity : userListEntityList) {
            ResSelectUserListDTO resultDTO = new ResSelectUserListDTO();
            resultDTO.setUserSeq(userListEntity.getUserSeq());
            resultDTO.setUserId(userListEntity.getUserId());
            resultDTO.setUserName(userListEntity.getUserName());
            resultDTO.setPhone(ariaUtil.decrypt(userListEntity.getPhone()));
            resultDTO.setJoinDt(userListEntity.getJoinDt());
            resultDTO.setAppStatCd(userListEntity.getAppStatCd());
            resultDTO.setAppStatNm(userListEntity.getAppStatNm());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectUserDetailDTO> selectUserDetail(ReqSelectUserDetailDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0021.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        inputData.put("role", "ROLE_USER");

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        List<ResSelectUserDetailDTO> resultData = new ArrayList<>();

        for (UsrUserEntity usrUserEntity : usrUserEntityList) {
            ResSelectUserDetailDTO resultDTO = new ResSelectUserDetailDTO();
            resultDTO.setUserSeq(usrUserEntity.getUserSeq());
            resultDTO.setUserId(usrUserEntity.getUserId());
            resultDTO.setUserName(usrUserEntity.getUserName());
            resultDTO.setBirthday(usrUserEntity.getBirthday());
            resultDTO.setGenderCd(usrUserEntity.getGenderCd());
            resultDTO.setPhone(ariaUtil.decrypt(usrUserEntity.getPhone()));
            resultDTO.setZipCode(ariaUtil.decrypt(usrUserEntity.getZipCode()));
            resultDTO.setAddr(ariaUtil.decrypt(usrUserEntity.getAddr()));
            resultDTO.setAddrDtl(ariaUtil.decrypt(usrUserEntity.getAddrDtl()));
            resultDTO.setEmail(usrUserEntity.getEmail());
            resultDTO.setJoinDt(usrUserEntity.getJoinDt());
            resultDTO.setAppStatCd(usrUserEntity.getAppStatCd());
            resultDTO.setAppId(usrUserEntity.getAppId());
            resultDTO.setAppDy(usrUserEntity.getAppDy());
            resultDTO.setMemo(usrUserEntity.getMemo());
            resultDTO.setRole(usrUserEntity.getRole());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateUserMemo(ReqUpdateUserMemoDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0021.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        inputData.put("memo", dto.getMemo());

        int count = usrUserMapper.updateUserMemo(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateUserStat(ReqUpdateUserStatDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0021.getMessage());

        // 현재시간
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedTime = currentTime.format(formatter);

        String appStatCd = DaiHelper.nullToEmptyStr(dto.getAppStatCd());
        String appId = DaiHelper.nullToEmptyStr(dto.get_loginId());
        String appDy = formattedTime;

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);

        // 승인 취소 또는 차단
        if ("30".equals(appStatCd) || "40".equals(appStatCd)) {
            List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

            if (usrUserEntityList.isEmpty())
                throw new DAException(MessageCode.MSG_0021.getMessage());

            String memo = DaiHelper.nullToEmptyStr(usrUserEntityList.get(0).getMemo());

            if (memo.isEmpty())
                throw new DAException(MessageCode.MSG_0022.getMessage());

            appId = null;
            appDy = null;
        }

        inputData.put("appStatCd", appStatCd);
        inputData.put("appId", appId);
        inputData.put("appDy", appDy);

        int count = usrUserMapper.updateUserStat(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
