package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "아이디 찾기 Response DTO")
public class ResFindIdDTO {
    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "가입시간")
    private String joinDt;
}
