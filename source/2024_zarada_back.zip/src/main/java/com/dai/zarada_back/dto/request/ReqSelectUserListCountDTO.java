package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원 목록 count Request DTO")
public class ReqSelectUserListCountDTO extends ReqLoginInfoDTO {
    @Schema(description = "승인 상태 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'APP_STAT_CD')")
    private String appStatCd;

    @Schema(description = "내 승인 여부")
    private String myAppYn;

    @Schema(description = "검색 구분 (\"I\":회원 아이디, \"N\":회원 이름, \"P\":휴대폰 번호 'XXXXXXXXXXX' (암호화 대상))")
    private String searchDvsn;

    @Schema(description = "검색어")
    private String searchText;
}
