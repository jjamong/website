package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqAriaTestDTO;
import com.dai.zarada_back.dto.request.ReqFcmTestDTO;
import com.dai.zarada_back.dto.request.ReqJwtTestDTO;
import com.dai.zarada_back.dto.request.ReqRedisTestDTO;
import com.dai.zarada_back.dto.response.ResAriaTestDTO;
import com.dai.zarada_back.dto.response.ResFcmTestDTO;
import com.dai.zarada_back.dto.response.ResJwtTestDTO;
import com.dai.zarada_back.dto.response.ResRedisTestDTO;

import java.util.List;

public interface DevService {
    List<ResRedisTestDTO> redisTest(ReqRedisTestDTO dto);

    List<ResJwtTestDTO> jwtTest(ReqJwtTestDTO dto);

    List<ResAriaTestDTO> ariaTest(ReqAriaTestDTO dto);

    List<ResFcmTestDTO> fcmTest(ReqFcmTestDTO dto);
}
