package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공지사항 내용 조회 Response DTO")
public class ResSelectNoticeDTO {
    @Schema(description = "공지사항 SEQ")
    private long noticeSeq;

    @Schema(description = "제목")
    private String noticeTitle;

    @Schema(description = "내용")
    private String noticeContent;

    @Schema(description = "상단 고정 여부")
    private String topYn;

    @Schema(description = "작성 일자")
    private String writeDy;

    @Schema(description = "작성 시간")
    private String writeTm;
}
