package com.dai.zarada_back.util;

import com.dai.zarada_back.vo.JwtResultType;
import io.jsonwebtoken.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Date;

@Component
public class JwtUtil {
    @Value("${jwt.secret.key}")
    private String jwtSecretKey;

    private final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
    private final long REFRESH_TOKEN_EXPIRATION = 14 * 24 * 60 * 60 * 1000L;
    private final long ACCESS_TOKEN_EXPIRATION = 5 * 60 * 1000L;

    /**
     * Refresh Token 생성
     */
    public String createRefreshToken(long userSeq, String userId, String role, String autoLogin) {
        Claims claims = Jwts.claims();
        claims.put("userSeq", userSeq);
        claims.put("userId", userId);
        claims.put("role", role);
        claims.put("autoLogin", autoLogin);

        // refresh token은 만료시간 없음
        String token = Jwts.builder()
                .setHeaderParam(Header.TYPE, Header.JWT_TYPE)
                .setIssuedAt(new Date(System.currentTimeMillis())) // 발급시간
                .setExpiration(new Date(System.currentTimeMillis() + REFRESH_TOKEN_EXPIRATION)) // 만료시간
                .addClaims(claims)
                .signWith(signatureAlgorithm.HS256, jwtSecretKey)
                .compact();

        return token;
    }

    /**
     * Access Token 생성
     */
    public String createAccessToken(long userSeq, String userId, String role, String autoLogin) {
        Claims claims = Jwts.claims();
        claims.put("userSeq", userSeq);
        claims.put("userId", userId);
        claims.put("role", role);
        claims.put("autoLogin", autoLogin);

        String token = Jwts.builder()
                .setHeaderParam(Header.TYPE, Header.JWT_TYPE)
                .setIssuedAt(new Date(System.currentTimeMillis())) // 발급시간
                .setExpiration(new Date(System.currentTimeMillis() + ACCESS_TOKEN_EXPIRATION)) // 만료시간
                .addClaims(claims)
                .signWith(signatureAlgorithm.HS256, jwtSecretKey)
                .compact();

        return token;
    }

    /**
     * 토큰 유효성 검사
     */
    public JwtResultType validationToken(String token) {
        if (token == null || token.isEmpty()) {
            return JwtResultType.EMPTY_JWT;
        }

        try {
            Jwts.parser().setSigningKey(jwtSecretKey).parseClaimsJws(token).getBody();
        } catch (SignatureException signEx) {
            return JwtResultType.SIGNATURE_JWT;
        } catch (ExpiredJwtException expiredEx) {
            return JwtResultType.EXPIRED_JWT;
        } catch (Exception e) {
            return JwtResultType.EXCEPTION_JWT;
        }

        return JwtResultType.VALID_JWT;
    }

    /**
     * resolveToken
     */
    public String resolveToken(HttpServletRequest req) {
        String bearerToken = req.getHeader("Authorization");

        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }

        return "";
    }

    /**
     * getTokenUserSeq
     */
    public long getTokenUserSeq(String token) {
        try {
            if (token == null || token.isEmpty())
                return 0;

            Claims tokenPayload = Jwts.parser().setSigningKey(jwtSecretKey).parseClaimsJws(token).getBody();

            return tokenPayload.get("userSeq", Integer.class);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * getTokenUserId
     */
    public String getTokenUserId(String token) {
        try {
            if (token == null || token.isEmpty())
                return "";

            Claims tokenPayload = Jwts.parser().setSigningKey(jwtSecretKey).parseClaimsJws(token).getBody();

            return tokenPayload.get("userId", String.class);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * getTokenRole
     */
    public String getTokenRole(String token) {
        try {
            if (token == null || token.isEmpty())
                return "";

            Claims tokenPayload = Jwts.parser().setSigningKey(jwtSecretKey).parseClaimsJws(token).getBody();

            return tokenPayload.get("role", String.class);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * getTokenAutoLogin
     */
    public String getTokenAutoLogin(String token) {
        try {
            if (token == null || token.isEmpty())
                return "";

            Claims tokenPayload = Jwts.parser().setSigningKey(jwtSecretKey).parseClaimsJws(token).getBody();

            return tokenPayload.get("autoLogin", String.class);
        } catch (Exception e) {
            return "";
        }
    }
}
