package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "간호사 정보 수정 Request DTO")
public class ReqUpdateNurseDTO extends ReqLoginInfoDTO {
    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 비밀번호 (암호화 대상)")
    private String userPw;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "휴대폰 번호 'XXXXXXXXXXX' (암호화 대상)")
    private String phone;
}
