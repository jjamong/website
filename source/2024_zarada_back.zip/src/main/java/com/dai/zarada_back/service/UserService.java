package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectUserDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectUserListDTO;

import java.util.List;

public interface UserService {
    List<ResCountDTO> selectUserListCount(ReqSelectUserListCountDTO dto);

    List<ResSelectUserListDTO> selectUserList(ReqSelectUserListDTO dto);

    List<ResSelectUserDetailDTO> selectUserDetail(ReqSelectUserDetailDTO dto);

    List<ResCountDTO> updateUserMemo(ReqUpdateUserMemoDTO dto);

    List<ResCountDTO> updateUserStat(ReqUpdateUserStatDTO dto);
}
