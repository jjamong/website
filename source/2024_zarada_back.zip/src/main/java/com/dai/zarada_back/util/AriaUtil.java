package com.dai.zarada_back.util;

import com.dai.zarada_back.config.Aria;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AriaUtil {
    @Value("${aria.secret.key}")
    private String ariaSecretKey;

    /**
     * Aria 암호화
     */
    public String encrypt(String str) {
        try {
            Aria aria = new Aria(ariaSecretKey);
            return aria.Encrypt(str);
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Aria 복호화
     */
    public String decrypt(String str) {
        try {
            Aria aria = new Aria(ariaSecretKey);
            return aria.Decrypt(str);
        } catch (Exception e) {
            return "";
        }
    }
}
