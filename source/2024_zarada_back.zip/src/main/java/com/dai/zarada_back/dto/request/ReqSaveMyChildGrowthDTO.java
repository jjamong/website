package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "성장 기록 저장 Request DTO")
public class ReqSaveMyChildGrowthDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "신장")
    private float childHeight;

    @Schema(description = "체중")
    private float childWeight;

    @Schema(description = "기록 코멘트")
    private String recordComment;
}
