package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = " Response DTO")
public class ResSelectGrowthChartDTO {
    @Schema(description = "나이")
    private String age;

    @Schema(description = "개월수")
    private String month;

    private String val1;
    private String val3;
    private String val5;
    private String val10;
    private String val15;
    private String val25;
    private String val50;
    private String val75;
    private String val85;
    private String val90;
    private String val95;
    private String val97;
    private String val99;

    @Schema(description = "자녀 나이")
    private String childAge;

    @Schema(description = "자녀 신장")
    private String childHeight;

    @Schema(description = "자녀 체중")
    private String childWeight;

    @Schema(description = "자녀 BMI")
    private String childBmi;
}
