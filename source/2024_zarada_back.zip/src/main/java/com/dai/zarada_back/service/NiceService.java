package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqNiceDecryptDTO;
import com.dai.zarada_back.dto.request.ReqNiceEncryptDTO;
import com.dai.zarada_back.dto.response.ResNiceDecryptDTO;
import com.dai.zarada_back.dto.response.ResNiceEncryptDTO;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public interface NiceService {
    List<ResNiceEncryptDTO> niceEncrypt(ReqNiceEncryptDTO dto, HttpServletResponse res);

    List<ResNiceDecryptDTO> niceDecrypt(ReqNiceDecryptDTO dto);
}
