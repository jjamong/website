package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.ComCategorydetailEntity;
import com.dai.zarada_back.entity.StdHospitalEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ComCategorydetailMapper {
    List<ComCategorydetailEntity> selectComCategorydetail(Object inputData);

    int insertComCategorydetail(Object inputData);

    int updateComCategorydetail(Object inputData);

    int deleteComCategorydetail(Object inputData);

    List<StdHospitalEntity> selectStdHospital(Object inputData);
}
