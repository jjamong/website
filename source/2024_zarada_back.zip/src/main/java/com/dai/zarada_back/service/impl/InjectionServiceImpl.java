package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectAlarmDTO;
import com.dai.zarada_back.dto.response.ResSelectChildInjectionDTO;
import com.dai.zarada_back.entity.ChildInjectionEntity;
import com.dai.zarada_back.entity.ChlInjectionEntity;
import com.dai.zarada_back.entity.AlarmEntity;
import com.dai.zarada_back.mapper.ChlInjectionMapper;
import com.dai.zarada_back.service.InjectionService;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class InjectionServiceImpl implements InjectionService {
    private final ChlInjectionMapper chlInjectionMapper;

    @Override
    public List<ResSelectChildInjectionDTO> selectChildInjection(ReqSelectChildInjectionDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", dto.getChildSeq());
        inputData.put("recordDy", dto.getRecordDy());
        inputData.put("injMonth", dto.getInjMonth());
        inputData.put("mainYn", dto.getMainYn());

        List<ChildInjectionEntity> childInjectionEntityList = chlInjectionMapper.selectChildInjection(inputData);

        List<ResSelectChildInjectionDTO> resultData = new ArrayList<>();

        for (ChildInjectionEntity childInjectionEntity : childInjectionEntityList) {
            ResSelectChildInjectionDTO resultDTO = new ResSelectChildInjectionDTO();
            resultDTO.setInjectionSeq(childInjectionEntity.getInjectionSeq());
            resultDTO.setChildSeq(childInjectionEntity.getChildSeq());
            resultDTO.setRecordDy(childInjectionEntity.getRecordDy());
            resultDTO.setRecordTm(childInjectionEntity.getRecordTm());
            resultDTO.setNewItemYn(childInjectionEntity.getNewItemYn());
            resultDTO.setItemCd(childInjectionEntity.getItemCd());
            resultDTO.setInjPartCd(childInjectionEntity.getInjPartCd());
            resultDTO.setInjVol(childInjectionEntity.getInjVol());
            resultDTO.setRecordComment(childInjectionEntity.getRecordComment());
            resultDTO.setInjDays(childInjectionEntity.getInjDays());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> saveChildInjection(ReqSaveChildInjectionDTO dto) {
        long childSeq = dto.getChildSeq();
        String recordDy = DaiHelper.nullToEmptyStr(dto.getRecordDy());

        if (childSeq == 0)
            throw new DAException(MessageCode.MSG_0026.getMessage());

        if (recordDy.isEmpty())
            throw new DAException(MessageCode.MSG_0025.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("childSeq", childSeq);
        inputData.put("recordDy", recordDy);

        List<ChlInjectionEntity> chlInjectionEntityList = chlInjectionMapper.selectChlInjection(inputData);

        int count = 0;
        inputData.put("recordTm", dto.getRecordTm());
        inputData.put("newItemYn", dto.getNewItemYn());
        inputData.put("itemCd", dto.getItemCd());
        inputData.put("injPartCd", dto.getInjPartCd());
        inputData.put("injVol", dto.getInjVol());
        inputData.put("recordComment", dto.getRecordComment());

        if (chlInjectionEntityList.isEmpty())
            count += chlInjectionMapper.insertChlInjection(inputData);
        else
            count += chlInjectionMapper.updateChildInjection(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> deleteChildInjection(ReqDeleteChildInjectionDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("injectionSeq", dto.getInjectionSeq());

        int count = chlInjectionMapper.deleteChlInjection(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResSelectAlarmDTO> selectAlarm(ReqSelectAlarmDTO dto) {
        long _loginSeq = dto.get_loginSeq();

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", _loginSeq);
        inputData.put("childSeq", dto.getChildSeq());

        List<AlarmEntity> alarmEntityList = chlInjectionMapper.selectAlarm(inputData);

        List<ResSelectAlarmDTO> resultData = new ArrayList<>();

        for (AlarmEntity alarmEntity : alarmEntityList) {
            ResSelectAlarmDTO resultDTO = new ResSelectAlarmDTO();
            resultDTO.setAlarmSeq(alarmEntity.getAlarmSeq());
            resultDTO.setUserSeq(alarmEntity.getUserSeq());
            resultDTO.setChildSeq(alarmEntity.getChildSeq());
            resultDTO.setAlYn(alarmEntity.getAlYn());
            resultDTO.setAlTm(alarmEntity.getAlTm());
            resultDTO.setMonYn(alarmEntity.getMonYn());
            resultDTO.setTueYn(alarmEntity.getTueYn());
            resultDTO.setWedYn(alarmEntity.getWedYn());
            resultDTO.setThuYn(alarmEntity.getThuYn());
            resultDTO.setFriYn(alarmEntity.getFriYn());
            resultDTO.setSatYn(alarmEntity.getSatYn());
            resultDTO.setSunYn(alarmEntity.getSunYn());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> saveAlarm(ReqSaveAlarmDTO dto) {
        long _loginSeq = dto.get_loginSeq();

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", _loginSeq);
        inputData.put("childSeq", dto.getChildSeq());

        List<AlarmEntity> alarmEntityList = chlInjectionMapper.selectAlarm(inputData);

        int count = 0;
        inputData.put("alYn", dto.getAlYn());
        inputData.put("alTm", dto.getAlTm());
        inputData.put("monYn", dto.getMonYn());
        inputData.put("tueYn", dto.getTueYn());
        inputData.put("wedYn", dto.getWedYn());
        inputData.put("thuYn", dto.getThuYn());
        inputData.put("friYn", dto.getFriYn());
        inputData.put("satYn", dto.getSatYn());
        inputData.put("sunYn", dto.getSunYn());

        if (alarmEntityList.isEmpty())
            count += chlInjectionMapper.insertAlarm(inputData);
        else
            count += chlInjectionMapper.updateAlarm(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
