package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AlarmEntity {
    private long alarmSeq;
    private long userSeq;
    private long childSeq;
    private String alYn;
    private String alTm;
    private String monYn;
    private String tueYn;
    private String wedYn;
    private String thuYn;
    private String friYn;
    private String satYn;
    private String sunYn;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
}
