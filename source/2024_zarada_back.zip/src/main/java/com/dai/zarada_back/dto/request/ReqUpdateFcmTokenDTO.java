package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Update FCM Token Request DTO")
public class ReqUpdateFcmTokenDTO extends ReqLoginInfoDTO {
    @Schema(description = "FCM Token")
    private String fcmToken;
}
