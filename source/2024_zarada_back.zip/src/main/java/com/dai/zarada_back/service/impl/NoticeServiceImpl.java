package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectNoticeDTO;
import com.dai.zarada_back.dto.response.ResSelectNoticeListDTO;
import com.dai.zarada_back.entity.CountEntity;
import com.dai.zarada_back.entity.EtcNoticeEntity;
import com.dai.zarada_back.entity.NoticeListEntity;
import com.dai.zarada_back.mapper.EtcNoticeMapper;
import com.dai.zarada_back.service.NoticeService;
import com.dai.zarada_back.util.DaiHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class NoticeServiceImpl implements NoticeService {
    private final EtcNoticeMapper etcNoticeMapper;

    @Override
    public List<ResCountDTO> selectNoticeListCount(ReqDummyDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);

        List<CountEntity> countEntityList = etcNoticeMapper.selectNoticeListCount(inputData);

        int count = countEntityList.get(0).getCount();

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResSelectNoticeListDTO> selectNoticeList(ReqSelectNoticeListDTO dto) {
        int page = dto.getPage();
        int size = dto.getSize();
        page = DaiHelper.pageCalculation(page, size);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("page", page);
        inputData.put("size", size);

        List<NoticeListEntity> noticeListEntityList = etcNoticeMapper.selectNoticeList(inputData);

        List<ResSelectNoticeListDTO> resultData = new ArrayList<>();

        for (NoticeListEntity noticeListEntity : noticeListEntityList) {
            ResSelectNoticeListDTO resultDTO = new ResSelectNoticeListDTO();
            resultDTO.setNoticeSeq(noticeListEntity.getNoticeSeq());
            resultDTO.setNoticeTitle(noticeListEntity.getNoticeTitle());
            resultDTO.setTopYn(noticeListEntity.getTopYn());
            resultDTO.setWriteDy(noticeListEntity.getWriteDy());
            resultDTO.setWriteTm(noticeListEntity.getWriteTm());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectNoticeDTO> selectNotice(ReqSelectNoticeDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("noticeSeq", dto.getNoticeSeq());

        List<EtcNoticeEntity> etcNoticeEntityList = etcNoticeMapper.selectNotice(inputData);

        List<ResSelectNoticeDTO> resultData = new ArrayList<>();

        for (EtcNoticeEntity etcNoticeEntity : etcNoticeEntityList) {
            ResSelectNoticeDTO resultDTO = new ResSelectNoticeDTO();
            resultDTO.setNoticeSeq(etcNoticeEntity.getNoticeSeq());
            resultDTO.setNoticeTitle(etcNoticeEntity.getNoticeTitle());
            resultDTO.setNoticeContent(etcNoticeEntity.getNoticeContent());
            resultDTO.setTopYn(etcNoticeEntity.getTopYn());
            resultDTO.setWriteDy(etcNoticeEntity.getWriteDy());
            resultDTO.setWriteTm(etcNoticeEntity.getWriteTm());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> insertNotice(ReqInsertNoticeDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("noticeTitle", dto.getNoticeTitle());
        inputData.put("noticeContent", dto.getNoticeContent());
        inputData.put("topYn", dto.getTopYn());

        int count = etcNoticeMapper.insertNotice(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateNotice(ReqUpdateNoticeDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("noticeSeq", dto.getNoticeSeq());
        inputData.put("noticeTitle", dto.getNoticeTitle());
        inputData.put("noticeContent", dto.getNoticeContent());
        inputData.put("topYn", dto.getTopYn());

        int count = etcNoticeMapper.updateNotice(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> deleteNotice(ReqDeleteNoticeDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("noticeSeq", dto.getNoticeSeq());

        int count = etcNoticeMapper.deleteNotice(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
