package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.ReqDeleteMyChildGrowthDTO;
import com.dai.zarada_back.dto.request.ReqSaveMyChildGrowthDTO;
import com.dai.zarada_back.dto.request.ReqSelectGrowthChartDTO;
import com.dai.zarada_back.dto.request.ReqSelectMyChildGrowthDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectGrowthChartDTO;
import com.dai.zarada_back.dto.response.ResSelectMyChildGrowthDTO;

import java.util.List;

public interface GrowthService {
    List<ResSelectMyChildGrowthDTO> selectMyChildGrowth(ReqSelectMyChildGrowthDTO dto);

    List<ResCountDTO> saveMyChildGrowth(ReqSaveMyChildGrowthDTO dto);

    List<ResCountDTO> deleteMyChildGrowth(ReqDeleteMyChildGrowthDTO dto);

    List<ResSelectGrowthChartDTO> selectGrowthChart(ReqSelectGrowthChartDTO dto);
}
