package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "주사 기록 조회 Request DTO")
public class ReqSelectChildInjectionDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "조회월 'YYYY-MM'")
    private String injMonth;

    @Schema(description = "메인화면 조회 여부'")
    private String mainYn;
}
