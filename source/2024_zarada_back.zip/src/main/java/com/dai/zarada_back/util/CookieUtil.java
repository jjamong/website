package com.dai.zarada_back.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

@Component
public class CookieUtil {
    private final int COOKIE_EXPIRATION = 14 * 24 * 60 * 60;

    /**
     * 쿠키 생성
     */
    public Cookie createCookie(String key, String value) {
        Cookie cookie = new Cookie(key, value);
        cookie.setPath("/");
        cookie.setMaxAge(COOKIE_EXPIRATION);
        cookie.setHttpOnly(true);

        return cookie;
    }

    /**
     * 쿠키 삭제
     */
    public Cookie deleteCookie(String key) {
        Cookie cookie = new Cookie(key, "");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        cookie.setHttpOnly(true);

        return cookie;
    }

    /**
     * getCookieValue
     */
    public String getCookieValue(String key, HttpServletRequest req) {
        final Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(key))
                    return cookie.getValue();
            }
        }

        return "";
    }
}
