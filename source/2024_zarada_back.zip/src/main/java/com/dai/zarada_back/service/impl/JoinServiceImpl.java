package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResFindIdDTO;
import com.dai.zarada_back.dto.response.ResFindPwDTO;
import com.dai.zarada_back.entity.UsrUserEntity;
import com.dai.zarada_back.mapper.ChlChildMapper;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.JoinService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class JoinServiceImpl implements JoinService {
    private final UsrUserMapper usrUserMapper;
    private final ChlChildMapper chlChildMapper;
    private final AriaUtil ariaUtil;

    @Override
    @Transactional
    public List<ResCountDTO> join(ReqJoinDTO dto) {
        // 회원가입시 필요한 필수 입력 항목
        String userId = DaiHelper.nullToEmptyStr(dto.getUserId());
        String userPw = DaiHelper.nullToEmptyStr(dto.getUserPw());
        String userName = DaiHelper.nullToEmptyStr(dto.getUserName());
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());
        String psnInfoDvsn10 = DaiHelper.nullToEmptyStr(dto.getPsnInfoDvsn10());
        String childName = DaiHelper.nullToEmptyStr(dto.getChildName());
        String childBirthday = DaiHelper.nullToEmptyStr(dto.getChildBirthday());

        if (userId.isEmpty() || userPw.isEmpty() || userName.isEmpty() || phone.isEmpty() || psnInfoDvsn10.isEmpty() || childName.isEmpty() || childBirthday.isEmpty())
            throw new DAException(MessageCode.MSG_0009.getMessage());

        /* 아이디, 휴대폰 번호 중복 체크 */
        ReqCheckDuplIdDTO inputCheckDuplIdData = new ReqCheckDuplIdDTO();
        inputCheckDuplIdData.setUserId(userId);
        List<ResCountDTO> checkList1 = this.checkDuplId(inputCheckDuplIdData);

        if (checkList1.get(0).getCount() > 0)
            throw new DAException(MessageCode.MSG_0010.getMessage());

        ReqCheckDuplPhoneDTO inputCheckDuplPhoneData = new ReqCheckDuplPhoneDTO();
        inputCheckDuplPhoneData.setPhone(phone);
        List<ResCountDTO> checkList2 = this.checkDuplPhone(inputCheckDuplPhoneData);

        if (checkList2.get(0).getCount() > 0)
            throw new DAException(MessageCode.MSG_0011.getMessage());

        int count = 0;

        /* 회원정보 INSERT */
        Map<String, Object> inputInsertUsrUserData = DaiHelper.createInputData(dto);
        inputInsertUsrUserData.put("userId", userId);
        inputInsertUsrUserData.put("userPw", ariaUtil.encrypt(userPw));
        inputInsertUsrUserData.put("userName", userName);
        inputInsertUsrUserData.put("birthday", dto.getUserBirthday());
        inputInsertUsrUserData.put("genderCd", dto.getUserGenderCd());
        inputInsertUsrUserData.put("phone", ariaUtil.encrypt(phone));
        inputInsertUsrUserData.put("zipCode", ariaUtil.encrypt(dto.getZipCode()));
        inputInsertUsrUserData.put("addr", ariaUtil.encrypt(dto.getAddr()));
        inputInsertUsrUserData.put("addrDtl", ariaUtil.encrypt(dto.getAddrDtl()));
        inputInsertUsrUserData.put("email", dto.getEmail());
        inputInsertUsrUserData.put("appStatCd", "10");
        inputInsertUsrUserData.put("appId", null);
        inputInsertUsrUserData.put("appDy", null);
        inputInsertUsrUserData.put("memo", null);
        inputInsertUsrUserData.put("role", "ROLE_USER");
        inputInsertUsrUserData.put("fcmToken", null);
        count += usrUserMapper.insertUsrUser(inputInsertUsrUserData);

        // 회원정보 SEQ get
        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("userId", userId);

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        long userSeq = usrUserEntityList.get(0).getUserSeq();

        /* 개인정보동의 INSERT */
        // 개인정보동의 항목이 늘어난다면 로직 수정 필요 (COM_CATEGORYDETAIL.CLSF_CD = 'PSN_INFO_DVSN') 의 size 만큼 for문
        Map<String, Object> inputInsertUsrPsninfoData = DaiHelper.createInputData(dto);
        inputInsertUsrPsninfoData.put("userSeq", userSeq);
        inputInsertUsrPsninfoData.put("psnInfoDvsn", "10");
        inputInsertUsrPsninfoData.put("consentYn", "Y");
        inputInsertUsrPsninfoData.put("psnInfoDvsn10", psnInfoDvsn10);
        count += usrUserMapper.insertUsrPsninfo(inputInsertUsrPsninfoData);

        /* 자녀정보 INSERT */
        Map<String, Object> inputInsertChlChildData = DaiHelper.createInputData(dto);
        inputInsertChlChildData.put("userSeq", userSeq);
        inputInsertChlChildData.put("childName", childName);
        inputInsertChlChildData.put("birthday", childBirthday);
        inputInsertChlChildData.put("genderCd", dto.getChildGenderCd());
        inputInsertChlChildData.put("itemCd", dto.getItemCd());
        inputInsertChlChildData.put("hospitalNm", dto.getHospitalNm());
        inputInsertChlChildData.put("doctorNm", dto.getDoctorNm());
        inputInsertChlChildData.put("injVol", null);
        inputInsertChlChildData.put("delYn", "N");
        inputInsertChlChildData.put("childFile", dto.getChildFile());

        count += chlChildMapper.insertChlChild(inputInsertChlChildData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    @Transactional
    public List<ResCountDTO> withdrawal(ReqWithdrawalDTO dto) {
        long _loginSeq = dto.get_loginSeq();
        String _loginRole = dto.get_loginRole();

        if (!"ROLE_USER".equals(_loginRole))
            throw new DAException(MessageCode.MSG_0013.getMessage());

        String userPw = DaiHelper.nullToEmptyStr(dto.getUserPw());

        if (userPw.isEmpty())
            throw new DAException(MessageCode.MSG_0012.getMessage());

        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("userSeq", _loginSeq);
        inputSelectUsrUserData.put("userPw", ariaUtil.encrypt(userPw));

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        if (usrUserEntityList.isEmpty())
            throw new DAException(MessageCode.MSG_0012.getMessage());

        String userId = usrUserEntityList.get(0).getUserId();
        int count = 0;

        /* 회원정보 DELETE */
        Map<String, Object> inputDeleteUsrUserData = DaiHelper.createInputData(dto);
        inputDeleteUsrUserData.put("userSeq", _loginSeq);

        count += usrUserMapper.deleteUsrUser(inputDeleteUsrUserData);

        /* 회원탈퇴 INSERT */
        Map<String, Object> inputInsertUsrWithdrawalData = DaiHelper.createInputData(dto);
        inputInsertUsrWithdrawalData.put("userSeq", _loginSeq);
        inputInsertUsrWithdrawalData.put("userId", userId);

        count += usrUserMapper.insertUsrWithdrawal(inputInsertUsrWithdrawalData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResFindIdDTO> findId(ReqFindIdDTO dto) {
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());

        if (phone.isEmpty())
            throw new DAException(MessageCode.MSG_0006.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("phone", ariaUtil.encrypt(phone));
        inputData.put("role", "ROLE_USER");

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        List<ResFindIdDTO> resultData = new ArrayList<>();

        for (UsrUserEntity usrUserEntity : usrUserEntityList) {
            ResFindIdDTO resFindIdDTO = new ResFindIdDTO();
            resFindIdDTO.setUserId(usrUserEntity.getUserId());
            resFindIdDTO.setJoinDt(usrUserEntity.getJoinDt());

            resultData.add(resFindIdDTO);
        }

        return resultData;
    }

    @Override
    public List<ResFindPwDTO> findPw(ReqFindPwDTO dto) {
        String userId = DaiHelper.nullToEmptyStr(dto.getUserId());
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());

        if (userId.isEmpty() || phone.isEmpty())
            throw new DAException(MessageCode.MSG_0007.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userId", userId);
        inputData.put("phone", ariaUtil.encrypt(phone));
        inputData.put("role", "ROLE_USER");

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        List<ResFindPwDTO> resultData = new ArrayList<>();

        for (UsrUserEntity usrUserEntity : usrUserEntityList) {
            ResFindPwDTO resFindIdDTO = new ResFindPwDTO();
            resFindIdDTO.setUserSeq(usrUserEntity.getUserSeq());

            resultData.add(resFindIdDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateUserPwFromFind(ReqUpdateUserPwFromFindDTO dto) {
        String newPw = DaiHelper.nullToEmptyStr(dto.getNewPw());

        if (newPw.isEmpty())
            throw new DAException(MessageCode.MSG_0008.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", dto.getUserSeq());
        inputData.put("userPw", ariaUtil.encrypt(newPw));

        int count = usrUserMapper.updateUserPw(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> checkDuplId(ReqCheckDuplIdDTO dto) {
        String userId = DaiHelper.nullToEmptyStr(dto.getUserId());

        if (userId.isEmpty())
            throw new DAException(MessageCode.MSG_0005.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userId", userId);

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        int count = usrUserEntityList.size();
        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> checkDuplPhone(ReqCheckDuplPhoneDTO dto) {
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());

        if (phone.isEmpty())
            throw new DAException(MessageCode.MSG_0006.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("phone", ariaUtil.encrypt(phone));
        inputData.put("role", "ROLE_USER");

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        int count = usrUserEntityList.size();
        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
