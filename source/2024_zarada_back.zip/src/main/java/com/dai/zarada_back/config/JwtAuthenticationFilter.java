package com.dai.zarada_back.config;

import com.dai.zarada_back.util.CookieUtil;
import com.dai.zarada_back.util.JwtUtil;
import com.dai.zarada_back.vo.JwtResultType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

import static org.springframework.security.core.authority.AuthorityUtils.createAuthorityList;

public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final CookieUtil cookieUtil;
    private final JwtUtil jwtUtil;

    public JwtAuthenticationFilter(CookieUtil cookieUtil, JwtUtil jwtUtil) {
        this.cookieUtil = cookieUtil;
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        // 호출 URL
        String requestURL = httpServletRequest.getRequestURI();

        // Refresh Token
        String refreshToken = cookieUtil.getCookieValue("refreshToken", httpServletRequest);

        // Access Token
        String accessToken = jwtUtil.resolveToken(httpServletRequest);

        if (!this.urlValidation(requestURL)) {
            // Access Token 유효성 검사
            JwtResultType jwtResultType = jwtUtil.validationToken(accessToken);

            // 정상 토큰이 아닌 경우
            if (jwtResultType != JwtResultType.VALID_JWT) {
                if (jwtResultType == JwtResultType.EMPTY_JWT) {
                    httpServletResponse.setStatus(900);
                } else if (jwtResultType == JwtResultType.EXPIRED_JWT) {
                    httpServletResponse.setStatus(901);
                } else if (jwtResultType == JwtResultType.SIGNATURE_JWT) {
                    httpServletResponse.setStatus(900);
                } else if (jwtResultType == JwtResultType.EXCEPTION_JWT) {
                    httpServletResponse.setStatus(900);
                }

                return;
            }

            // Token Value
            String refreshTokenUserId = jwtUtil.getTokenUserId(refreshToken);
            String accessTokenUserId = jwtUtil.getTokenUserId(accessToken);
            String accessTokenRole = jwtUtil.getTokenRole(accessToken);

            // 토큰 아이디가 다른경우
            if (!refreshTokenUserId.equals(accessTokenUserId)) {
                httpServletResponse.setStatus(902);
                return;
            }

            Authentication authentication = new UsernamePasswordAuthenticationToken(accessTokenUserId, "", createAuthorityList(accessTokenRole));

            SecurityContextHolder.getContext().setAuthentication(authentication);
        }

        filterChain.doFilter(httpServletRequest, httpServletResponse);
    }

    private boolean urlValidation(String requestURL) {
        // SecurityConfig.filterChain() 의 permitAll() 설정과 동일하게 구성
        return requestURL.startsWith("/api/extra") || requestURL.startsWith("/api/dev")
                || requestURL.startsWith("/swagger-ui") || requestURL.startsWith("/v3")
                || requestURL.equals("/")
                || requestURL.startsWith("/index.html") || requestURL.startsWith("/_next") || requestURL.startsWith("/css")
                || requestURL.startsWith("/img") || requestURL.startsWith("/front") || requestURL.startsWith("/controlroom");
    }
}
