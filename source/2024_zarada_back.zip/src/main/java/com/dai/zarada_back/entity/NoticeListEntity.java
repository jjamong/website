package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class NoticeListEntity {
    private long noticeSeq;
    private String noticeTitle;
    private String topYn;
    private String writeDy;
    private String writeTm;
}
