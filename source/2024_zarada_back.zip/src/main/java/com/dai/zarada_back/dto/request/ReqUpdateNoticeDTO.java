package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공지사항 수정 Request DTO")
public class ReqUpdateNoticeDTO extends ReqLoginInfoDTO {
    @Schema(description = "공지사항 SEQ")
    private long noticeSeq;

    @Schema(description = "제목")
    private String noticeTitle;

    @Schema(description = "내용")
    private String noticeContent;

    @Schema(description = "상단 고정 여부")
    private String topYn;
}
