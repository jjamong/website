package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResFindIdDTO;
import com.dai.zarada_back.dto.response.ResFindPwDTO;

import java.util.List;

public interface JoinService {
    List<ResCountDTO> join(ReqJoinDTO dto);

    List<ResCountDTO> withdrawal(ReqWithdrawalDTO dto);

    List<ResFindIdDTO> findId(ReqFindIdDTO dto);

    List<ResFindPwDTO> findPw(ReqFindPwDTO dto);

    List<ResCountDTO> updateUserPwFromFind(ReqUpdateUserPwFromFindDTO dto);

    List<ResCountDTO> checkDuplId(ReqCheckDuplIdDTO dto);

    List<ResCountDTO> checkDuplPhone(ReqCheckDuplPhoneDTO dto);
}
