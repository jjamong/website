package com.dai.zarada_back.service;

public interface FCMService {
    void sendNotification(String token, String title, String body, String moveUrl);

    String sendNotificationTest(String token, String title, String body, String moveUrl);
}
