package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공통 Count Response DTO")
public class ResCountDTO {
    @Schema(description = "Count")
    private int count;
}
