package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqUpdateMypageDTO;
import com.dai.zarada_back.dto.request.ReqUpdateUserPwFromMypageDTO;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectMypageDTO;
import com.dai.zarada_back.entity.UsrUserEntity;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.MypageService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MypageServiceImpl implements MypageService {
    private final UsrUserMapper usrUserMapper;
    private final AriaUtil ariaUtil;

    @Override
    public List<ResSelectMypageDTO> selectMypage(ReqDummyDTO dto) {
        long _loginSeq = dto.get_loginSeq();

        if (_loginSeq == 0)
            throw new DAException(MessageCode.MSG_0014.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", _loginSeq);

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputData);

        List<ResSelectMypageDTO> resultData = new ArrayList<>();

        for (UsrUserEntity usrUserEntity : usrUserEntityList) {
            String phone = ariaUtil.decrypt(usrUserEntity.getPhone());
            String zipCode = ariaUtil.decrypt(usrUserEntity.getZipCode());
            String addr = ariaUtil.decrypt(usrUserEntity.getAddr());
            String addrDtl = ariaUtil.decrypt(usrUserEntity.getAddrDtl());

            ResSelectMypageDTO resultDTO = new ResSelectMypageDTO();
            resultDTO.setUserSeq(usrUserEntity.getUserSeq());
            resultDTO.setUserId(usrUserEntity.getUserId());
            resultDTO.setUserName(usrUserEntity.getUserName());
            resultDTO.setBirthday(usrUserEntity.getBirthday());
            resultDTO.setGenderCd(usrUserEntity.getGenderCd());
            resultDTO.setPhone(phone);
            resultDTO.setZipCode(zipCode);
            resultDTO.setAddr(addr);
            resultDTO.setAddrDtl(addrDtl);
            resultDTO.setEmail(usrUserEntity.getEmail());
            resultDTO.setJoinDt(usrUserEntity.getJoinDt());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateMypage(ReqUpdateMypageDTO dto) {
        long _loginSeq = dto.get_loginSeq();
        String _loginRole = DaiHelper.nullToEmptyStr(dto.get_loginRole());

        if (!"ROLE_USER".equals(_loginRole))
            throw new DAException(MessageCode.MSG_0015.getMessage());

        // 휴대폰 번호 확인
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());
        phone = ariaUtil.encrypt(phone);

        if (phone.isEmpty())
            throw new DAException(MessageCode.MSG_0006.getMessage());

        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("phone", phone);
        inputSelectUsrUserData.put("role", "ROLE_USER");

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        if (!usrUserEntityList.isEmpty()) {
            long selectUserSeq = usrUserEntityList.get(0).getUserSeq();

            if (_loginSeq != selectUserSeq)
                throw new DAException(MessageCode.MSG_0011.getMessage());
        }

        // Mypage 정보 수정
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", _loginSeq);
        inputData.put("userName", dto.getUserName());
        inputData.put("birthday", dto.getBirthday());
        inputData.put("genderCd", dto.getGenderCd());
        inputData.put("phone", phone);
        inputData.put("zipCode", ariaUtil.encrypt(dto.getZipCode()));
        inputData.put("addr", ariaUtil.encrypt(dto.getAddr()));
        inputData.put("addrDtl", ariaUtil.encrypt(dto.getAddrDtl()));
        inputData.put("email", dto.getEmail());

        int count = usrUserMapper.updateMypage(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateUserPwFromMypage(ReqUpdateUserPwFromMypageDTO dto) {
        long _loginSeq = dto.get_loginSeq();
        String _loginRole = DaiHelper.nullToEmptyStr(dto.get_loginRole());
        String userPw = DaiHelper.nullToEmptyStr(dto.getUserPw());
        String newPw = DaiHelper.nullToEmptyStr(dto.getNewPw());
        userPw = ariaUtil.encrypt(userPw);
        newPw = ariaUtil.encrypt(newPw);

        if (!"ROLE_USER".equals(_loginRole))
            throw new DAException(MessageCode.MSG_0015.getMessage());

        if (userPw.isEmpty())
            throw new DAException(MessageCode.MSG_0016.getMessage());

        if (newPw.isEmpty())
            throw new DAException(MessageCode.MSG_0008.getMessage());

        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("userSeq", _loginSeq);
        inputSelectUsrUserData.put("userPw", userPw);

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        if (usrUserEntityList.isEmpty())
            throw new DAException(MessageCode.MSG_0016.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", _loginSeq);
        inputData.put("userPw", newPw);

        int count = usrUserMapper.updateUserPw(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
