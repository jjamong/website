package com.dai.zarada_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class ZaradaBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZaradaBackApplication.class, args);
    }

}
