package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.ReqDummyDTO;
import com.dai.zarada_back.dto.request.ReqSelectCommonCodeDTO;
import com.dai.zarada_back.dto.response.ResSelectCommonCodeDTO;
import com.dai.zarada_back.dto.response.ResSelectHospitalComboDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseComboDTO;
import com.dai.zarada_back.entity.ComCategorydetailEntity;
import com.dai.zarada_back.entity.NurseComboEntity;
import com.dai.zarada_back.entity.StdHospitalEntity;
import com.dai.zarada_back.mapper.ComCategorydetailMapper;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.CommonService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.DaiHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CommonServiceImpl implements CommonService {
    private final ComCategorydetailMapper comCategorydetailMapper;
    private final UsrUserMapper usrUserMapper;
    private final AriaUtil ariaUtil;

    @Override
    public List<ResSelectCommonCodeDTO> selectCommonCode(ReqSelectCommonCodeDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("clsfCd", dto.getClsfCd());
        inputData.put("comnCd", dto.getComnCd());
        inputData.put("useYn", dto.getUseYn());

        List<ComCategorydetailEntity> selectList = comCategorydetailMapper.selectComCategorydetail(inputData);

        List<ResSelectCommonCodeDTO> resultData = new ArrayList<>();
        for (ComCategorydetailEntity comCategorydetailEntity : selectList) {
            ResSelectCommonCodeDTO resultDTO = new ResSelectCommonCodeDTO();
            resultDTO.setClsfCd(comCategorydetailEntity.getClsfCd());
            resultDTO.setComnCd(comCategorydetailEntity.getComnCd());
            resultDTO.setComnNm(comCategorydetailEntity.getComnNm());
            resultDTO.setComnDtlNm(comCategorydetailEntity.getComnDtlNm());
            resultDTO.setUseYn(comCategorydetailEntity.getUseYn());
            resultDTO.setSort(comCategorydetailEntity.getSort());
            resultDTO.setBigo1(comCategorydetailEntity.getBigo1());
            resultDTO.setBigo2(comCategorydetailEntity.getBigo2());
            resultDTO.setBigo3(comCategorydetailEntity.getBigo3());
            resultDTO.setBigo4(comCategorydetailEntity.getBigo4());
            resultDTO.setBigo5(comCategorydetailEntity.getBigo5());
            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectNurseComboDTO> selectNurseCombo(ReqDummyDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);

        List<NurseComboEntity> nurseComboEntityList = usrUserMapper.selectNurseCombo(inputData);

        List<ResSelectNurseComboDTO> resultData = new ArrayList<>();

        for (NurseComboEntity nurseComboEntity : nurseComboEntityList) {
            String userName = nurseComboEntity.getUserName();
            String phone = ariaUtil.decrypt(nurseComboEntity.getPhone());
            String userNamePhone = userName;

            if (!phone.isEmpty())
                userNamePhone = userNamePhone + " (" + phone + ")";

            ResSelectNurseComboDTO resSelectNurseComboDTO = new ResSelectNurseComboDTO();
            resSelectNurseComboDTO.setUserSeq(nurseComboEntity.getUserSeq());
            resSelectNurseComboDTO.setUserId(nurseComboEntity.getUserId());
            resSelectNurseComboDTO.setUserName(userName);
            resSelectNurseComboDTO.setPhone(phone);
            resSelectNurseComboDTO.setUserNamePhone(userNamePhone);
            resSelectNurseComboDTO.setRole(nurseComboEntity.getRole());

            resultData.add(resSelectNurseComboDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectHospitalComboDTO> selectHospitalCombo(ReqDummyDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);

        List<StdHospitalEntity> stdHospitalEntityList = comCategorydetailMapper.selectStdHospital(inputData);

        List<ResSelectHospitalComboDTO> resultData = new ArrayList<>();

        for (StdHospitalEntity stdHospitalEntity : stdHospitalEntityList) {
            ResSelectHospitalComboDTO resultDTO = new ResSelectHospitalComboDTO();
            resultDTO.setHospitalSeq(stdHospitalEntity.getHospitalSeq());
            resultDTO.setLocal(stdHospitalEntity.getLocal());
            resultDTO.setLocalHost(stdHospitalEntity.getLocalHost());
            resultDTO.setHospitalNm(stdHospitalEntity.getHospitalNm());

            resultData.add(resultDTO);
        }

        return resultData;
    }
}
