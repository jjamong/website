package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원별 자녀 목록 조회 Response DTO")
public class ResSelectUserChildListDTO {
    @Schema(description = "자녀정보 SEQ")
    private long childSeq;

    @Schema(description = "회원정보 SEQ")
    private long userSeq;

    @Schema(description = "자녀 이름")
    private String childName;

    @Schema(description = "생년월일 'YYYY-MM-DD'")
    private String birthday;

    @Schema(description = "성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String genderCd;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "처방 병원명")
    private String hospitalNm;

    @Schema(description = "처방 의사명")
    private String doctorNm;
}
