package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ChlGrowthEntity {
    private long growthSeq;
    private long childSeq;
    private String recordDy;
    private float childHeight;
    private float childWeight;
    private float childBmi;
    private String recordComment;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
}
