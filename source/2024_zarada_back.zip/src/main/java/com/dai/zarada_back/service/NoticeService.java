package com.dai.zarada_back.service;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectNoticeDTO;
import com.dai.zarada_back.dto.response.ResSelectNoticeListDTO;

import java.util.List;

public interface NoticeService {
    List<ResCountDTO> selectNoticeListCount(ReqDummyDTO dto);

    List<ResSelectNoticeListDTO> selectNoticeList(ReqSelectNoticeListDTO dto);

    List<ResSelectNoticeDTO> selectNotice(ReqSelectNoticeDTO dto);

    List<ResCountDTO> insertNotice(ReqInsertNoticeDTO dto);

    List<ResCountDTO> updateNotice(ReqUpdateNoticeDTO dto);

    List<ResCountDTO> deleteNotice(ReqDeleteNoticeDTO dto);
}
