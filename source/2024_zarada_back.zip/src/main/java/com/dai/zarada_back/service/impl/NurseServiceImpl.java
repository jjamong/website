package com.dai.zarada_back.service.impl;

import com.dai.zarada_back.dto.request.*;
import com.dai.zarada_back.dto.response.ResCountDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseDetailDTO;
import com.dai.zarada_back.dto.response.ResSelectNurseListDTO;
import com.dai.zarada_back.entity.CountEntity;
import com.dai.zarada_back.entity.NurseDetailEntity;
import com.dai.zarada_back.entity.NurseListEntity;
import com.dai.zarada_back.entity.UsrUserEntity;
import com.dai.zarada_back.mapper.UsrUserMapper;
import com.dai.zarada_back.service.JoinService;
import com.dai.zarada_back.service.NurseService;
import com.dai.zarada_back.util.AriaUtil;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class NurseServiceImpl implements NurseService {
    private final UsrUserMapper usrUserMapper;
    private final AriaUtil ariaUtil;
    private final JoinService joinService;

    @Override
    public List<ResCountDTO> selectNurseListCount(ReqDummyDTO dto) {
        Map<String, Object> inputData = DaiHelper.createInputData(dto);

        List<CountEntity> countEntityList = usrUserMapper.selectNurseListCount(inputData);

        List<ResCountDTO> resultData = new ArrayList<>();

        for (CountEntity countEntity : countEntityList) {
            ResCountDTO resultDTO = new ResCountDTO();
            resultDTO.setCount(countEntity.getCount());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectNurseListDTO> selectNurseList(ReqSelectNurseListDTO dto) {
        int page = dto.getPage();
        int size = dto.getSize();
        page = DaiHelper.pageCalculation(page, size);

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("page", page);
        inputData.put("size", size);

        List<NurseListEntity> nurseListEntityList = usrUserMapper.selectNurseList(inputData);

        List<ResSelectNurseListDTO> resultData = new ArrayList<>();

        for (NurseListEntity nurseListEntity : nurseListEntityList) {
            ResSelectNurseListDTO resultDTO = new ResSelectNurseListDTO();
            resultDTO.setUserSeq(nurseListEntity.getUserSeq());
            resultDTO.setUserId(nurseListEntity.getUserId());
            resultDTO.setUserName(nurseListEntity.getUserName());
            resultDTO.setPhone(ariaUtil.decrypt(nurseListEntity.getPhone()));
            resultDTO.setRole(nurseListEntity.getRole());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResSelectNurseDetailDTO> selectNurseDetail(ReqSelectNurseDetailDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0018.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);

        List<NurseDetailEntity> nurseDetailEntityList = usrUserMapper.selectNurseDetail(inputData);

        List<ResSelectNurseDetailDTO> resultData = new ArrayList<>();

        for (NurseDetailEntity nurseDetailEntity : nurseDetailEntityList) {
            ResSelectNurseDetailDTO resultDTO = new ResSelectNurseDetailDTO();
            resultDTO.setUserSeq(nurseDetailEntity.getUserSeq());
            resultDTO.setUserId(nurseDetailEntity.getUserId());
            resultDTO.setUserName(nurseDetailEntity.getUserName());
            resultDTO.setPhone(ariaUtil.decrypt(nurseDetailEntity.getPhone()));
            resultDTO.setRole(nurseDetailEntity.getRole());

            resultData.add(resultDTO);
        }

        return resultData;
    }

    @Override
    public List<ResCountDTO> insertNurse(ReqInsertNurseDTO dto) {
        String userId = DaiHelper.nullToEmptyStr(dto.getUserId());
        String userPw = DaiHelper.nullToEmptyStr(dto.getUserPw());
        String userName = DaiHelper.nullToEmptyStr(dto.getUserName());
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());

        // 필수값 체크
        if (userId.isEmpty() || userPw.isEmpty() || userName.isEmpty() || phone.isEmpty())
            throw new DAException(MessageCode.MSG_0019.getMessage());

        // 아이디 중복 확인
        ReqCheckDuplIdDTO inputCheckDuplIdData = new ReqCheckDuplIdDTO();
        inputCheckDuplIdData.setUserId(userId);
        List<ResCountDTO> checkList = joinService.checkDuplId(inputCheckDuplIdData);

        if (checkList.get(0).getCount() > 0)
            throw new DAException(MessageCode.MSG_0010.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userId", userId);
        inputData.put("userPw", ariaUtil.encrypt(userPw));
        inputData.put("userName", userName);
        inputData.put("phone", ariaUtil.encrypt(phone));

        int count = usrUserMapper.insertNurse(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> updateNurse(ReqUpdateNurseDTO dto) {
        long userSeq = dto.getUserSeq();
        String userId = DaiHelper.nullToEmptyStr(dto.getUserId());
        String userPw = DaiHelper.nullToEmptyStr(dto.getUserPw());
        String userName = DaiHelper.nullToEmptyStr(dto.getUserName());
        String phone = DaiHelper.nullToEmptyStr(dto.getPhone());

        // 필수값 체크
        if (userId.isEmpty() || userName.isEmpty() || phone.isEmpty())
            throw new DAException(MessageCode.MSG_0020.getMessage());

        // 선택한 간호사의 최신 정보 조회
        Map<String, Object> inputSelectUsrUserData = DaiHelper.createInputData(dto);
        inputSelectUsrUserData.put("userSeq", userSeq);

        List<UsrUserEntity> usrUserEntityList = usrUserMapper.selectUsrUser(inputSelectUsrUserData);

        if (userSeq == 0 || usrUserEntityList.isEmpty())
            throw new DAException(MessageCode.MSG_0018.getMessage());

        String selectId = usrUserEntityList.get(0).getUserId();
        String selectPw = usrUserEntityList.get(0).getUserPw();
        selectPw = ariaUtil.decrypt(selectPw);

        // 아이디 중복 확인
        if (!userId.equals(selectId)) {
            ReqCheckDuplIdDTO inputCheckDuplIdData = new ReqCheckDuplIdDTO();
            inputCheckDuplIdData.setUserId(userId);
            List<ResCountDTO> checkList = joinService.checkDuplId(inputCheckDuplIdData);

            if (checkList.get(0).getCount() > 0)
                throw new DAException(MessageCode.MSG_0010.getMessage());
        }

        // 비밀번호 세팅
        if (userPw.isEmpty())
            userPw = selectPw;

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);
        inputData.put("userId", userId);
        inputData.put("userPw", ariaUtil.encrypt(userPw));
        inputData.put("userName", userName);
        inputData.put("phone", ariaUtil.encrypt(phone));

        int count = usrUserMapper.updateNurse(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }

    @Override
    public List<ResCountDTO> deleteNurse(ReqDeleteNurseDTO dto) {
        long userSeq = dto.getUserSeq();

        if (userSeq == 0)
            throw new DAException(MessageCode.MSG_0018.getMessage());

        Map<String, Object> inputData = DaiHelper.createInputData(dto);
        inputData.put("userSeq", userSeq);

        int count = usrUserMapper.deleteUsrUser(inputData);

        ResCountDTO resultDTO = new ResCountDTO();
        resultDTO.setCount(count);

        List<ResCountDTO> resultData = new ArrayList<>();
        resultData.add(resultDTO);

        return resultData;
    }
}
