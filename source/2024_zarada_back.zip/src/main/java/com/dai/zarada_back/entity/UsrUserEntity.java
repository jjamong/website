package com.dai.zarada_back.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UsrUserEntity {
    private long userSeq;
    private String userId;
    private String userPw;
    private String userName;
    private String birthday;
    private String genderCd;
    private String phone;
    private String zipCode;
    private String addr;
    private String addrDtl;
    private String email;
    private String joinDt;
    private String appStatCd;
    private String appId;
    private String appDy;
    private String memo;
    private String role;
    private String fcmToken;
    private String rgstDt;
    private String rgstId;
    private String mdfyDt;
    private String mdfyId;
}
