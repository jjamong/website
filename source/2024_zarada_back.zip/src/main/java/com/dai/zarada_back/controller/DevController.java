package com.dai.zarada_back.controller;

import com.dai.zarada_back.dto.request.ReqAriaTestDTO;
import com.dai.zarada_back.dto.request.ReqFcmTestDTO;
import com.dai.zarada_back.dto.request.ReqJwtTestDTO;
import com.dai.zarada_back.dto.request.ReqRedisTestDTO;
import com.dai.zarada_back.dto.response.*;
import com.dai.zarada_back.service.DevService;
import com.dai.zarada_back.util.DAException;
import com.dai.zarada_back.util.DaiHelper;
import com.dai.zarada_back.vo.MessageCode;
import com.dai.zarada_back.vo.ResponseResultFlag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.SchemaProperty;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class DevController {
    private final DaiHelper daiHelper;
    private final DevService devService;

    @Tag(name = "900.Developer", description = "개발자용 API")
    @Operation(
            summary = "Redis Test",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResRedisTestDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/dev/DevController/redisTest")
    public ResponseEntity<ResCommonDTO<Object>> redisTest(@RequestBody ReqRedisTestDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResRedisTestDTO> data = new ArrayList<>();

        try {
            // 개발자 비밀번호 확인
            String password = dto.getPassword() == null ? "" : dto.getPassword();
            if (!daiHelper.checkDevPw(password))
                throw new DAException(MessageCode.MSG_9000.getMessage());

            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = devService.redisTest(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "900.Developer", description = "개발자용 API")
    @Operation(
            summary = "JWT Test",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResJwtTestDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/dev/DevController/jwtTest")
    public ResponseEntity<ResCommonDTO<Object>> jwtTest(@RequestBody ReqJwtTestDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResJwtTestDTO> data = new ArrayList<>();

        try {
            // 개발자 비밀번호 확인
            String password = dto.getPassword() == null ? "" : dto.getPassword();
            if (!daiHelper.checkDevPw(password))
                throw new DAException(MessageCode.MSG_9000.getMessage());

            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = devService.jwtTest(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "900.Developer", description = "개발자용 API")
    @Operation(
            summary = "Aria Test",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResAriaTestDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/dev/DevController/ariaTest")
    public ResponseEntity<ResCommonDTO<Object>> ariaTest(@RequestBody ReqAriaTestDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResAriaTestDTO> data = new ArrayList<>();

        try {
            // 개발자 비밀번호 확인
            String password = dto.getPassword() == null ? "" : dto.getPassword();
            if (!daiHelper.checkDevPw(password))
                throw new DAException(MessageCode.MSG_9000.getMessage());

            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = devService.ariaTest(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }

    @Tag(name = "900.Developer", description = "개발자용 API")
    @Operation(
            summary = "FCM Test",
            description = "",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "OK",
                            content = @Content(
                                    mediaType = "application/json",
                                    schemaProperties = {
                                            @SchemaProperty(name = "status", schema = @Schema(type = "boolean", description = "수행 결과 (true / false)")),
                                            @SchemaProperty(name = "code", schema = @Schema(type = "string", description = "수행 결과 코드 (\"S\" / \"F\")")),
                                            @SchemaProperty(name = "msg", schema = @Schema(type = "string", description = "수행 결과 메세지")),
                                            @SchemaProperty(name = "data", array = @ArraySchema(schema = @Schema(implementation = ResFcmTestDTO.class)))
                                    }
                            )
                    )
            }
    )
    @PostMapping("/api/dev/DevController/fcmTest")
    public ResponseEntity<ResCommonDTO<Object>> fcmTest(@RequestBody ReqFcmTestDTO dto, HttpServletRequest httpServletRequest) {
        boolean status = ResponseResultFlag.SUCCESS.isStatus();
        String code = ResponseResultFlag.SUCCESS.getCode();
        String msg = ResponseResultFlag.SUCCESS.getMsg();
        List<ResFcmTestDTO> data = new ArrayList<>();

        try {
            // 개발자 비밀번호 확인
            String password = dto.getPassword() == null ? "" : dto.getPassword();
            if (!daiHelper.checkDevPw(password))
                throw new DAException(MessageCode.MSG_9000.getMessage());

            dto = daiHelper.setLoginInfo(dto, httpServletRequest);
            data = devService.fcmTest(dto);
        } catch (Exception e) {
            status = ResponseResultFlag.FAILURE.isStatus();
            code = ResponseResultFlag.FAILURE.getCode();
            msg = e.getMessage();
        }

        ResCommonDTO<Object> resBody = ResCommonDTO.builder()
                .status(status)
                .code(code)
                .msg(msg)
                .data(data)
                .build();

        return ResponseEntity.status(HttpStatus.OK).body(resBody);
    }
}
