package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = " Request DTO")
public class ReqSelectMyChildGrowthDTO extends ReqLoginInfoDTO {
    @Schema(description = "자녀 성장 기록 SEQ")
    private long growthSeq;

    @Schema(description = "기록 일자 'YYYY-MM-DD'")
    private String recordDy;

    @Schema(description = "자녀정보 SEQ")
    private long childSeq;
}
