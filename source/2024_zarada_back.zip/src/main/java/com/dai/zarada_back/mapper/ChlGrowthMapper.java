package com.dai.zarada_back.mapper;

import com.dai.zarada_back.entity.ChildGrowthEntity;
import com.dai.zarada_back.entity.ChlGrowthEntity;
import com.dai.zarada_back.entity.GrowthChartEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ChlGrowthMapper {
    List<ChlGrowthEntity> selectChlGrowth(Object inputData);

    int insertChlGrowth(Object inputData);

    int updateChlGrowth(Object inputData);

    int deleteChlGrowth(Object inputData);

    List<ChildGrowthEntity> selectChildGrowth(Object inputData);

    List<GrowthChartEntity> selectGrowthChart(Object inputData);

    int updateChildGrowth(Object inputData);
}
