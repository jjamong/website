package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "회원가입 Request DTO")
public class ReqJoinDTO extends ReqLoginInfoDTO {
    @Schema(description = "회원 아이디")
    private String userId;

    @Schema(description = "회원 비밀번호 (암호화 대상)")
    private String userPw;

    @Schema(description = "회원 이름")
    private String userName;

    @Schema(description = "회원 생년월일 'YYYY-MM-DD'")
    private String userBirthday;

    @Schema(description = "회원 성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String userGenderCd;

    @Schema(description = "휴대폰 번호 'XXXXXXXXXXX' (암호화 대상)")
    private String phone;

    @Schema(description = "우편번호 (암호화 대상)")
    private String zipCode;

    @Schema(description = "주소 (암호화 대상)")
    private String addr;

    @Schema(description = "상세주소 (암호화 대상)")
    private String addrDtl;

    @Schema(description = "이메일")
    private String email;

    @Schema(description = "개인정보 수집 및 이용 동의 시간 'YYYY-MM-DD HH24:MI:SS'")
    private String psnInfoDvsn10;

    @Schema(description = "자녀 이름")
    private String childName;

    @Schema(description = "자녀 생년월일 'YYYY-MM-DD'")
    private String childBirthday;

    @Schema(description = "자녀 성별 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'GENDER_CD')")
    private String childGenderCd;

    @Schema(description = "처방 아이템 코드 (COM_CATEGORYDETAIL.CLSF_CD = 'ITEM_CD')")
    private String itemCd;

    @Schema(description = "처방 병원명")
    private String hospitalNm;

    @Schema(description = "처방 의사명")
    private String doctorNm;

    @Schema(description = "자녀 이미지")
    private String childFile;
}
