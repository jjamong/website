package com.dai.zarada_back.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "공통코드 조회 Request DTO")
public class ReqSelectCommonCodeDTO extends ReqLoginInfoDTO {
    @Schema(description = "그룹코드")
    private String clsfCd;

    @Schema(description = "공통코드")
    private String comnCd;

    @Schema(description = "사용 여부")
    private String useYn;
}
