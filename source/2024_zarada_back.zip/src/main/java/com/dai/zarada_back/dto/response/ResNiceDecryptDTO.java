package com.dai.zarada_back.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "나이스 복호화 Response DTO")
public class ResNiceDecryptDTO {
    @Schema(description = "복호화 시간")
    private String cipherTime;

    @Schema(description = "요청 번호")
    private String requestNumber;

    @Schema(description = "인증 고유 번호")
    private String responseNumber;

    @Schema(description = "인증 수단")
    private String authType;

    @Schema(description = "성명")
    private String name;

    @Schema(description = "중복가입 확인값 (DI_64 byte)")
    private String dupInfo;

    @Schema(description = "연계정보 확인값 (CI_88 byte)")
    private String connInfo;

    @Schema(description = "생년월일(YYYYMMDD)")
    private String birthDate;

    @Schema(description = "성별")
    private String gender;

    @Schema(description = "내/외국인정보")
    private String nationalInfo;

    @Schema(description = "휴대폰 통신사")
    private String mobileCo;

    @Schema(description = "휴대폰 번호")
    private String mobileNo;
}
