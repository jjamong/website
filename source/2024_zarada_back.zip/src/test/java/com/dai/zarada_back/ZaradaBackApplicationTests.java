package com.dai.zarada_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZaradaBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
