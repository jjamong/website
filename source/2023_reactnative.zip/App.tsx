import React, { useEffect, useState, useRef } from "react";
import { Alert, View, BackHandler, SafeAreaView, StyleSheet } from "react-native";
import { WebView } from 'react-native-webview'
import messaging from '@react-native-firebase/messaging';
import Modal from "react-native-modal";

// 백그라운드 푸시
messaging().setBackgroundMessageHandler(async remoteMessage => {
    console.log('[Background Remote Message]', remoteMessage)
})

// IOS푸시 허용
async function requestUserPermission() {
    const authStatus = await messaging().requestPermission();
    const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

    if (enabled) {
        console.log('Authorization status:', authStatus);
    }
}
requestUserPermission()

const App = () => {
    const webview = useRef();
    //const source = {uri: 'http://10.2.14.241:8080'}; // 로컬
    const source = {uri: 'https://dahc-staging.azurewebsites.net'}; // 스테이징
    const [backState, setBackState] = useState({url: '', canGoBack: false})

    const [modalVisible, setModalVisible] = useState(false)
    const [modalSource, setModalSource] = useState({uri: ''})
    
    // FCM토큰 가져오기
    const getFcmToken = async () => {
        try {
            const fcmToken = await messaging().getToken();
            console.log('[FCM Token] ', fcmToken);
        } catch (error) {
            console.log('[FCM Token] error', error);
        }
    }

    useEffect(() => {
        getFcmToken()

        // 포그라운드 푸시
        messaging().onMessage(async remoteMessage => {
            console.log('[Remote Message] ', JSON.stringify(remoteMessage));
            let message = JSON.stringify(remoteMessage)
            Alert.alert("", remoteMessage.notification?.body)
        })
    }, [])

    useEffect(() => {
        // 종료 창
        function close() {
            Alert.alert("", "확인을 누르면 종료합니다.", [
                {text: "취소", onPress: () => {}, style: "cancel"},
                {text: "확인", onPress: () => BackHandler.exitApp()},
            ])
        }

        // 뒤로가기
        const backAction = (): boolean => {
            if (backState.canGoBack) {
                if (backState.url == source.uri + "/resources/index.html#/login") {
                    close();
                } else {
                    // 뒤로 갈 수 있는 상태라면 이전 웹페이지로 이동한다
                    webview.current.goBack()
                }
            } else {
                close();
            }
            return true;
        }
        
        BackHandler.addEventListener('hardwareBackPress', backAction)
        return (): void => {
            BackHandler.removeEventListener('hardwareBackPress', backAction)
        };
    }, [backState.url, backState.canGoBack])

    // WebView 메시지
    const webViewMessage = (response): void => {
        response = JSON.parse(response);
        let key = response.key;
        let data = response.data;
        
        // 나이스인증 열기
        if (key === 'niceidOpen') {
            setModalVisible(true)
            setModalSource({uri: source.uri + '/checkplus_main'})
        // 나이스인증 닫기
        } else if (key === 'niceidClose') {
            setModalVisible(false)
            webview.current.postMessage(JSON.stringify(response))
        // 주소찾기 열기
        } else if (key === 'addrSearchOpen') {
            setModalVisible(true)
            setModalSource({uri: source.uri + '/resources/daum.jsp'})
        // 주소찾기 닫기
        } else if (key === 'addrSearchClose') {
            setModalVisible(false)
            webview.current.postMessage(JSON.stringify(response))
        }
    }

    return (
		<> 
            {/* 기본 웹뷰 */}
            <SafeAreaView style={{ flex: 1 }}>
                <WebView
                    ref={webview}
                    source={source}
                    setSupportMultipleWindows={false}
                    onNavigationStateChange={(navState) => {
                        setBackState({ url: navState.url, canGoBack: navState.canGoBack })
                    }}
                    onMessage={event => {
                        webViewMessage(event.nativeEvent.data)
                    }}
                />
            </SafeAreaView>
            
            <Modal isVisible={modalVisible} transparent={true} animationType="slide" onRequestClose={() => setModalVisible(false)} 
                style={{ position:'absolute', margin: 0, height:'100%', width:'100%', zIndex:1, alignSelf:'center'}}>
                <SafeAreaView style={{ flex: 1 }}>
                    <WebView
                        source={modalSource}
                        onMessage={event => {
                            webViewMessage(event.nativeEvent.data)
                        }}
                    />
                </SafeAreaView>
            </Modal>
		</>
    );
};

export default App;